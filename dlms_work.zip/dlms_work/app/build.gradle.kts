plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dlmsmini.equalizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dlmsmini.equalizer"
        minSdk = 28
        targetSdk = 35
        versionCode = 16
        versionName = "3.5"
    }
    buildFeatures { viewBinding = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // NewPipeExtractor memakai API Java 8+/NIO; minSdk di bawah 33 butuh desugaring (artefak _nio).
        isCoreLibraryDesugaringEnabled = true
    }
    packaging {
        resources.excludes += setOf(
            "META-INF/DEPENDENCIES", "META-INF/LICENSE", "META-INF/LICENSE.txt", "META-INF/NOTICE",
            "META-INF/NOTICE.txt", "META-INF/INDEX.LIST", "META-INF/AL2.0", "META-INF/LGPL2.1",
            "META-INF/versions/9/OSGI-INF/MANIFEST.MF"
        )
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.work:work-runtime:2.9.1")

    // --- Musik (v3.2) ---
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.4")
    implementation("com.github.teamnewpipe:NewPipeExtractor:v0.26.5") // ekstraksi stream (lokal di perangkat)
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.guava:guava:33.3.1-android")
    testImplementation("junit:junit:4.13.2")
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dlmsmini.equalizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dlmsmini.equalizer"
        minSdk = 28
        targetSdk = 35
        versionCode = 12
        versionName = "3.1"
    }
    buildFeatures { viewBinding = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.work:work-runtime:2.9.1")
    testImplementation("junit:junit:4.13.2")
}

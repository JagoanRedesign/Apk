plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dlmsmini.equalizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.dlmsmini.equalizer"
        minSdk = 23
        targetSdk = 32
        versionCode = 4
        versionName = "2.2"
    }
    buildFeatures { viewBinding = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("androidx.appcompat:appcompat:1.7.0") }

package com.dlmsmini.equalizer

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Uji susunan band (5/10/13/15/21/31), konversi antar susunan, dan format preset EQ L/R terpisah. */
class BandsTest {
    @Test
    fun everyLayoutIsConsistentAndAscending() {
        for (n in Bands.COUNTS) {
            val l = Bands.forCount(n)
            assertEquals(n, l.count)
            assertEquals(n, l.labels.size)
            assertEquals(n, l.centerHz.size)
            assertEquals(n, l.edgeHz.size)
            for (i in 1 until n) assertTrue("band $n: pusat harus naik ($i)", l.centerHz[i] > l.centerHz[i - 1])
            for (i in 1 until n) assertTrue("band $n: batas harus naik ($i)", l.edgeHz[i] > l.edgeHz[i - 1])
            assertEquals(22000f, l.edgeHz[n - 1], 0.001f)
        }
    }

    @Test
    fun newLayoutsAreRegistered() {
        assertTrue(Bands.isValid(15))
        assertTrue(Bands.isValid(31))
        assertFalse(Bands.isValid(7))
        assertEquals(20, Bands.forCount(31).centerHz.first())
        assertEquals(20000, Bands.forCount(31).centerHz.last())
        assertEquals(25, Bands.forCount(15).centerHz.first())
        assertEquals(16000, Bands.forCount(15).centerHz.last())
    }

    @Test
    fun keysForLeftAndRightNeverCollide() {
        val keys = HashSet<String>()
        for (n in Bands.COUNTS) for (i in 0 until n) {
            assertTrue(keys.add(Bands.key(n, i)))
            assertTrue(keys.add(Bands.keyR(n, i)))
        }
        assertEquals("band_3", Bands.key(10, 3)) // kunci lama tetap terbaca
    }

    @Test
    fun resampleKeepsFlatCurveFlatAndEndsMatch() {
        for (from in Bands.COUNTS) for (to in Bands.COUNTS) {
            val flat = Bands.resample(IntArray(from), Bands.forCount(to))
            assertEquals(to, flat.size)
            assertTrue(flat.all { it == 0 })
        }
        val bass = Bands.resample(intArrayOf(12, 0, 0, 0, 0, 0, 0, 0, 0, 0), Bands.forCount(31))
        assertEquals(12, bass.first())
        assertEquals(0, bass.last())
    }

    @Test
    fun presetRoundTripKeepsRightChannel() {
        val left = IntArray(15) { it - 7 }
        val right = IntArray(15) { 7 - it }
        val text = PresetCodec.export(listOf(PresetCodec.Item("Studio", left, valuesR = right)))
        assertTrue(text.startsWith(PresetCodec.HEADER))
        val r = PresetCodec.parse(text)
        assertTrue(r.errors.joinToString(), r.errors.isEmpty())
        assertEquals(1, r.items.size)
        assertArrayEquals(left, r.items[0].values)
        assertArrayEquals(right, r.items[0].valuesR)
    }

    @Test
    fun presetWithoutRightChannelStaysStereoAndOldHeadersWork() {
        val r = PresetCodec.parse("DLMS-PRESET v4\nLama|0,2,4,0,-2,0,2,4,2,0")
        assertTrue(r.errors.isEmpty())
        assertNull(r.items[0].valuesR)
        assertNotNull(r.items[0].values)
    }

    @Test
    fun presetRejectsMismatchedOrOutOfRangeRightChannel() {
        val wrongSize = PresetCodec.parse("DLMS-PRESET v5\nA|0,0,0,0,0|R1,2,3")
        assertTrue(wrongSize.items.isEmpty() && wrongSize.errors.isNotEmpty())
        val tooLoud = PresetCodec.parse("DLMS-PRESET v5\nA|0,0,0,0,0|R0,0,0,0,99")
        assertTrue(tooLoud.items.isEmpty() && tooLoud.errors.isNotEmpty())
        val ok31 = PresetCodec.parse("DLMS-PRESET v5\nB|" + List(31) { 0 }.joinToString(","))
        assertTrue(ok31.errors.isEmpty())
        assertEquals(31, ok31.items[0].values.size)
    }
}

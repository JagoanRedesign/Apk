package com.dlmsmini.equalizer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.pow

/** Uji matematika filter: biquad PEQ, crossover Linkwitz-Riley, sintesis grid, dan estimasi limiter. */
class DspMathTest {
    @Test
    fun peakFilterHasRequestedGainAtCenter() {
        val bq = DspMath.biquad(PeqType.PEAK, 1000.0, 6.0, 1.0)
        assertEquals(6.0, DspMath.magnitudeDb(bq, 1000.0), 0.05)
        val cut = DspMath.biquad(PeqType.PEAK, 3000.0, -9.0, 2.0)
        assertEquals(-9.0, DspMath.magnitudeDb(cut, 3000.0), 0.05)
    }

    @Test
    fun shelvesReachFullGainAwayFromCorner() {
        val low = DspMath.biquad(PeqType.LOW_SHELF, 200.0, 6.0, 0.7)
        assertEquals(6.0, DspMath.magnitudeDb(low, 20.0), 0.2)
        assertEquals(0.0, DspMath.magnitudeDb(low, 10000.0), 0.2)
        val high = DspMath.biquad(PeqType.HIGH_SHELF, 5000.0, 6.0, 0.7)
        assertEquals(6.0, DspMath.magnitudeDb(high, 18000.0), 0.3)
    }

    @Test
    fun crossoverIsMinus6AtCornerAndSumsFlat() {
        for (order in intArrayOf(2, 4, 6, 8)) {
            assertEquals(-6.02, DspMath.crossoverDb(700.0, 700.0, order, true), 0.02)
            assertEquals(-6.02, DspMath.crossoverDb(700.0, 700.0, order, false), 0.02)
            for (f in doubleArrayOf(50.0, 300.0, 700.0, 2000.0, 9000.0)) {
                val sum = 10.0.pow(DspMath.crossoverDb(f, 700.0, order, true) / 20) +
                    10.0.pow(DspMath.crossoverDb(f, 700.0, order, false) / 20)
                assertEquals(1.0, sum, 1e-6)
            }
        }
    }

    @Test
    fun crossoverSlopeMatchesSetting() {
        // Satu oktaf di atas titik pisah, jauh dari tikungan: selisih per oktaf ≈ slope.
        for (slope in CrossoverSpec.SLOPES) {
            val order = slope / 6
            val a = DspMath.crossoverDb(5600.0, 700.0, order, true)
            val b = DspMath.crossoverDb(11200.0, 700.0, order, true)
            assertEquals(slope.toDouble(), a - b, 0.5)
        }
    }

    @Test
    fun gridIsMonotonicAndEndsAt22k() {
        val g = FilterGrid(64)
        for (i in 1 until g.count) assertTrue(g.edgeHz[i] > g.edgeHz[i - 1])
        assertEquals(22000f, g.edgeHz[g.count - 1], 0.01f)
    }

    @Test
    fun synthSplitsChannelsAndRespectsFloor() {
        val g = FilterGrid(64)
        val xo = CrossoverSettings(freqHz = 700, slopeDbOct = 48)
        val t = FilterSynth.build(g, EffectSettings(), PeqSettings(), xo, false, -60f)
        assertTrue(t.left.first() > -1f)              // LOW lolos di bass
        assertTrue(t.right.first() <= -59f)           // HIGH dipotong di bass
        assertTrue(t.left.last() <= -59f)             // LOW dipotong di treble
        assertTrue(t.right.last() > -1f)
        val sw = FilterSynth.build(g, EffectSettings(), PeqSettings(), xo, true, -60f)
        assertTrue(sw.right.first() > -1f && sw.left.last() > -1f)
        assertTrue(t.left.all { it >= -60f && it <= FilterSynth.CAP_DB })
    }

    @Test
    fun synthWithoutCrossoverKeepsChannelsEqual() {
        val g = FilterGrid(64)
        val peq = PeqSettings(true, listOf(PeqBand(true, PeqType.PEAK, 1000f, 6f, 1f)))
        val t = FilterSynth.build(g, EffectSettings(), peq, null, false, -60f)
        assertTrue(t.left.indices.all { abs(t.left[it] - t.right[it]) < 1e-6f })
        assertTrue(t.peakBoostDb in 4f..6.5f)
    }

    @Test
    fun limiterEstimateInvertsStaticCurve() {
        val lim = LimiterSettings(true, 1f, 60f, 10f, -2f, 0f)
        val below = Meter.limiterEstimate(-10f, lim)
        assertEquals(-10f, below.first, 0.001f)
        assertEquals(0f, below.second, 0.001f)
        val above = Meter.limiterEstimate(-1.5f, lim)   // 0,5 dB di atas threshold, ratio 10 → masukan +3 dB
        assertEquals(3f, above.first, 0.01f)
        assertEquals(4.5f, above.second, 0.01f)
    }

    @Test
    fun waveMeterReadsPeakAndClip() {
        val silent = ByteArray(256) { 128.toByte() }
        assertEquals(Meter.FLOOR_DB, Meter.readWave8(silent).peakDb, 0.01f)
        val hot = ByteArray(256) { if (it % 2 == 0) 255.toByte() else 1.toByte() }
        val r = Meter.readWave8(hot)
        assertTrue(r.clipped)
        assertTrue(r.peakDb > -0.2f)
    }

    @Test
    fun peqTextRoundTrips() {
        val s = PeqSettings(true, listOf(PeqBand(true, PeqType.LOW_SHELF, 80f, 4f, 0.7f), PeqBand(false, PeqType.NOTCH, 50f, 0f, 5f)))
        val back = PeqStore.fromText(PeqStore.toText(s))!!
        assertEquals(2, back.bands.size)
        assertEquals(PeqType.NOTCH, back.bands[1].type)
        assertEquals(80f, back.bands[0].freqHz, 0.01f)
        assertTrue(back.on)
    }
}

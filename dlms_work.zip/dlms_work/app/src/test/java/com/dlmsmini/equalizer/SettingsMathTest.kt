package com.dlmsmini.equalizer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Uji perhitungan murni: konversi volume L/R dan pemetaan crossover. */
class SettingsMathTest {
    @Test
    fun volumeConversionMatchesPercent() {
        val m = MasterSettings()
        assertEquals(0f, m.volumeDb(100), 0.001f)
        assertEquals(-6.02f, m.volumeDb(50), 0.05f)
        assertEquals(-80f, m.volumeDb(0), 0.001f)
    }

    @Test
    fun crossoverMappingIsMonotonicAndBounded() {
        var prev = 0
        for (p in 0..Store.XO_STEPS) {
            val hz = Store.crossoverFromProgress(p)
            assertTrue(hz in Store.MIN_CROSSOVER..Store.MAX_CROSSOVER)
            assertTrue(hz >= prev)
            prev = hz
        }
        assertEquals(Store.MIN_CROSSOVER, Store.crossoverFromProgress(0))
        assertEquals(Store.MAX_CROSSOVER, Store.crossoverFromProgress(Store.XO_STEPS))
    }
}

package com.dlmsmini.equalizer

import com.dlmsmini.equalizer.music.LrcParser
import com.dlmsmini.equalizer.music.LrcLib
import com.dlmsmini.equalizer.music.LyricsCandidate
import com.dlmsmini.equalizer.music.Mp4Tagger
import com.dlmsmini.equalizer.music.OfficialRank
import com.dlmsmini.equalizer.music.TitleClean
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.ByteBuffer

class MusicLogicTest {
    @Test fun lrcParsesStampsAndSkipsTags() {
        val l = LrcParser.parse("[ar:Artis]\n[00:01.50]satu\n[00:03.00][00:05.25]dua\n")
        assertEquals(3, l.size)
        assertEquals(1500L, l[0].timeMs)
        assertEquals("dua", l[1].text)
        assertEquals(5250L, l[2].timeMs)
        assertEquals(-1, LrcParser.indexAt(l, 500))
        assertEquals(0, LrcParser.indexAt(l, 2000))
        assertEquals(2, LrcParser.indexAt(l, 99_000))
    }

    @Test fun officialRankPrefersTopicAndPenalizesCovers() {
        val official = OfficialRank.score("Judul", "Artis - Topic", true, true, "judul")
        val cover = OfficialRank.score("Judul (cover)", "Fulan", false, false, "judul")
        assertTrue(official > cover)
        assertTrue(OfficialRank.isOfficial(official))
        // Bila pengguna memang mencari "remix", penalti tidak berlaku.
        assertTrue(OfficialRank.score("Judul remix", "Fulan", false, false, "judul remix") > OfficialRank.score("Judul remix", "Fulan", false, false, "judul"))
    }

    @Test fun titleCleanForLyrics() {
        val (t, a) = TitleClean.forLyrics("Artis - Judul (Official Video) feat. Lain", "Artis - Topic")
        assertEquals("Judul", t)
        assertEquals("Artis", a)
    }

    @Test fun pickBestUsesDurationAndPrefersSynced() {
        fun c(id: Long, dur: Int, synced: String?) = LyricsCandidate(id, "t", "a", "", dur, false, synced, "x")
        val best = LrcLib.pickBest(listOf(c(1, 300, "[00:01.00]a"), c(2, 200, null), c(3, 201, "[00:01.00]a")), 200)
        assertEquals(3L, best?.id)
        assertEquals(null, LrcLib.pickBest(listOf(c(1, 300, null)), 200))
    }

    private fun box(type: String, payload: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        DataOutputStream(o).apply { writeInt(payload.size + 8); write(type.toByteArray(Charsets.ISO_8859_1)); write(payload) }
        return o.toByteArray()
    }

    @Test fun taggerShiftsChunkOffsetsWhenMoovBeforeMdat() {
        val ftyp = box("ftyp", "M4A \u0000\u0000\u0000\u0000M4A ".toByteArray(Charsets.ISO_8859_1))
        fun moov(offset: Int): ByteArray {
            val stco = ByteBuffer.allocate(12).putInt(0).putInt(1).putInt(offset).array()
            return box("moov", box("trak", box("mdia", box("minf", box("stbl", box("stco", stco))))))
        }
        val mdat = box("mdat", ByteArray(64) { it.toByte() })
        val oldMoovSize = moov(0).size
        val file = File.createTempFile("tag", ".m4a")
        file.writeBytes(ftyp + moov(ftyp.size + oldMoovSize + 8) + mdat)
        val ok = Mp4Tagger.write(file, Mp4Tagger.Meta("Judul", "Artis", null, "lirik", byteArrayOf(1, 2, 3)))
        assertTrue(ok)
        val out = file.readBytes()
        val s = String(out, Charsets.ISO_8859_1)
        assertTrue(s.contains("ilst") && s.contains("covr"))
        // Offset pertama yang baru harus menunjuk tepat ke isi mdat.
        val mdatPos = s.indexOf("mdat") - 4
        val stcoPos = s.indexOf("stco")
        val off = ByteBuffer.wrap(out).getInt(stcoPos + 4 + 8)
        assertEquals(mdatPos + 8, off)
        assertNotNull(file.delete())
    }
}

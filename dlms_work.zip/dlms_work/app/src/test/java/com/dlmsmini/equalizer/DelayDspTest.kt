package com.dlmsmini.equalizer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Uji DSP Delay di JVM: waktu gema, feedback, Wet/Dry, Stereo, Ping Pong, kompensasi latensi, kestabilan. */
class DelayDspTest {
    private val fs = 48000

    private class Out(val l: FloatArray, val r: FloatArray)

    private fun run(inL: FloatArray, inR: FloatArray, s: DelaySettings, latencyMs: Float = 0f): Out {
        val dsp = DelayDsp(fs)
        val n = inL.size
        val oL = FloatArray(n)
        val oR = FloatArray(n)
        var pos = 0
        val chunk = 480
        while (pos < n) {
            val len = minOf(chunk, n - pos)
            val a = inL.copyOfRange(pos, pos + len)
            val b = inR.copyOfRange(pos, pos + len)
            val ol = FloatArray(len)
            val or = FloatArray(len)
            dsp.process(a, b, ol, or, len, s, latencyMs)
            ol.copyInto(oL, pos)
            or.copyInto(oR, pos)
            pos += len
        }
        return Out(oL, oR)
    }

    private fun impulse(n: Int): FloatArray = FloatArray(n).also { it[0] = 1f }

    private fun peakIndex(x: FloatArray, from: Int, to: Int): Int {
        var best = from
        for (i in from until to) if (abs(x[i]) > abs(x[best])) best = i
        return best
    }

    private fun base() = DelaySettings(
        enabled = true, timeMs = 100, feedbackPct = 0, wetPct = 100, dryPct = 0,
        stereo = false, pingPong = false, highCutHz = 20000, lowCutHz = 20
    )

    @Test
    fun echoAppearsAtRequestedTime() {
        val out = run(impulse(fs), FloatArray(fs), base())
        val idx = peakIndex(out.l, 100, fs)
        assertTrue("echo di sampel $idx", abs(idx - 4800) <= 4)
        assertTrue(abs(out.l[idx]) > 0.2f)
    }

    @Test
    fun latencyCompensationShortensDelay() {
        val out = run(impulse(fs), FloatArray(fs), base(), latencyMs = 40f)
        val idx = peakIndex(out.l, 100, fs)
        assertTrue("echo di sampel $idx", abs(idx - 2880) <= 4)
    }

    @Test
    fun feedbackRepeatsEchoWithDecay() {
        val out = run(impulse(fs * 2), FloatArray(fs * 2), base().copy(feedbackPct = 50))
        val first = abs(out.l[peakIndex(out.l, 100, 6000)])
        val second = abs(out.l[peakIndex(out.l, 6000, 12000)])
        assertTrue(second > first * 0.35f && second < first * 0.65f)
    }

    @Test
    fun zeroFeedbackGivesSingleEcho() {
        val out = run(impulse(fs * 2), FloatArray(fs * 2), base())
        val second = abs(out.l[peakIndex(out.l, 6000, 12000)])
        assertTrue(second < 0.01f)
    }

    @Test
    fun dryOnlyPassesInputAndWetOnlyDoesNot() {
        val dryOnly = run(impulse(fs), FloatArray(fs), base().copy(wetPct = 0, dryPct = 100))
        assertEquals(1f, dryOnly.l[0], 0.001f)
        assertTrue(abs(dryOnly.l[4800]) < 0.001f)
        val wetOnly = run(impulse(fs), FloatArray(fs), base())
        assertTrue(abs(wetOnly.l[0]) < 0.001f)
    }

    @Test
    fun stereoDelaysRightChannelLonger() {
        val out = run(impulse(fs), impulse(fs), base().copy(stereo = true))
        assertTrue(abs(peakIndex(out.l, 100, fs) - 4800) <= 4)
        assertTrue(abs(peakIndex(out.r, 100, fs) - 7200) <= 4)
    }

    @Test
    fun pingPongAlternatesChannels() {
        val n = fs * 2
        val out = run(impulse(n), FloatArray(n), base().copy(feedbackPct = 50, pingPong = true))
        assertTrue(abs(peakIndex(out.l, 100, 6000) - 4800) <= 4)
        var rBefore = 0f
        for (i in 0 until 9000) rBefore = maxOf(rBefore, abs(out.r[i]))
        assertTrue("kanan harus senyap sebelum 2T", rBefore < 0.001f)
        assertTrue(abs(peakIndex(out.r, 100, 12000) - 9600) <= 6)
    }

    @Test
    fun maximumFeedbackStaysStableAndFinite() {
        val n = fs * 3
        val noise = FloatArray(n) { ((it * 7919) % 2000 - 1000) / 1000f }
        val out = run(noise, noise, base().copy(feedbackPct = 90, wetPct = 100, dryPct = 100, tape = true, stereo = true))
        for (v in out.l) assertTrue(v.isFinite() && abs(v) <= 4f)
        for (v in out.r) assertTrue(v.isFinite() && abs(v) <= 4f)
    }

    @Test
    fun presetsAreWithinSpecRanges() {
        for (p in DelayPresets.all) {
            val s = p.settings
            assertTrue(s.timeMs in 1..1000)
            assertTrue(s.feedbackPct in 0..90)
            assertTrue(s.wetPct in 0..100 && s.dryPct in 0..100)
            assertTrue(s.highCutHz in 1000..20000 && s.lowCutHz in 20..1000)
        }
        assertEquals(setOf("Short Echo", "Ping Pong", "Tape Delay", "Long Echo"), DelayPresets.all.map { it.name }.toSet())
    }

    @Test
    fun volumeConversionMatchesPercent() {
        val m = MasterSettings()
        assertEquals(0f, m.volumeDb(100), 0.001f)
        assertEquals(-6.02f, m.volumeDb(50), 0.05f)
        assertEquals(-80f, m.volumeDb(0), 0.001f)
    }

    @Test
    fun crossoverMappingIsMonotonicAndBounded() {
        var prev = 0
        for (p in 0..Store.XO_STEPS) {
            val hz = Store.crossoverFromProgress(p)
            assertTrue(hz in Store.MIN_CROSSOVER..Store.MAX_CROSSOVER)
            assertTrue(hz >= prev)
            prev = hz
        }
        assertEquals(Store.MIN_CROSSOVER, Store.crossoverFromProgress(0))
        assertEquals(Store.MAX_CROSSOVER, Store.crossoverFromProgress(Store.XO_STEPS))
    }
}

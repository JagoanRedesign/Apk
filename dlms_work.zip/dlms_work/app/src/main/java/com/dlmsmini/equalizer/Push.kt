package com.dlmsmini.equalizer

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Konfigurasi Firebase Cloud Messaging. Isi 4 nilai berikut dari Firebase Console › Project settings › General
 * (aplikasi Android dengan package com.dlmsmini.equalizer). Tanpa berkas google-services.json: nilai diberikan langsung di sini.
 */
object FcmConfig {
    const val APP_ID = "GANTI-APP-ID"          // contoh: 1:1234567890:android:abcdef123456
    const val API_KEY = "GANTI-API-KEY"        // contoh: AIzaSy...
    const val PROJECT_ID = "GANTI-PROJECT-ID"  // contoh: dlms-mini
    const val SENDER_ID = "GANTI-SENDER-ID"    // contoh: 1234567890 (Project number)
    const val TOPIC = "all"

    val configured: Boolean
        get() = listOf(APP_ID, API_KEY, PROJECT_ID, SENDER_ID).none { it.contains("GANTI-") }
}

/** Application: menyiapkan Firebase sedini mungkin, termasuk saat proses dibangunkan oleh pesan push. */
class DlmsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PushManager.init(this)
    }
}

object PushManager {
    const val CHANNEL = "dlms_push"
    private const val NOTIF_ID = 4301

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Pesan & pengumuman", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Pengumuman dari pengembang (push)"
            }
        )
    }

    /** Inisialisasi Firebase, lalu langganan/berhenti langganan topik sesuai saklar Notifikasi push. */
    fun init(ctx: Context) {
        ensureChannel(ctx)
        if (!FcmConfig.configured) return
        try {
            if (FirebaseApp.getApps(ctx).isEmpty()) {
                FirebaseApp.initializeApp(
                    ctx,
                    FirebaseOptions.Builder()
                        .setApplicationId(FcmConfig.APP_ID)
                        .setApiKey(FcmConfig.API_KEY)
                        .setProjectId(FcmConfig.PROJECT_ID)
                        .setGcmSenderId(FcmConfig.SENDER_ID)
                        .build()
                )
            }
            val enabled = Store.prefs(ctx).getBoolean(Store.KEY_PUSH, true)
            val fm = FirebaseMessaging.getInstance()
            fm.isAutoInitEnabled = enabled
            if (enabled) {
                fm.subscribeToTopic(FcmConfig.TOPIC)
                fm.token.addOnSuccessListener { t ->
                    Store.prefs(ctx).edit().putString(Store.PREF_PUSH_TOKEN, t).apply()
                }
            } else {
                fm.unsubscribeFromTopic(FcmConfig.TOPIC)
            }
        } catch (e: Exception) {
            DiagLog.log("Push (FCM) gagal diinisialisasi: ${e.javaClass.simpleName} ${e.message ?: ""}")
        }
    }

    fun token(ctx: Context): String = Store.prefs(ctx).getString(Store.PREF_PUSH_TOKEN, "") ?: ""

    fun show(ctx: Context, title: String, body: String) {
        ensureChannel(ctx)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            ctx, 30,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(
                NOTIF_ID,
                NotificationCompat.Builder(ctx, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
            )
        } catch (_: Exception) {
        }
    }
}

/**
 * Penerima pesan push (FCM).
 *  - data {"type":"update"}            : periksa update.json sekarang dan tampilkan notifikasi pembaruan bila ada.
 *  - data {"title":"..","body":".."}   : tampilkan sebagai notifikasi biasa.
 * Pesan berisi "notification" yang tiba saat aplikasi di latar belakang ditampilkan sendiri oleh sistem.
 */
class DlmsMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Store.prefs(this).edit().putString(Store.PREF_PUSH_TOKEN, token).apply()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        if (!Store.prefs(this).getBoolean(Store.KEY_PUSH, true)) return
        val data = message.data
        if (data["type"] == "update") {
            // Dijalankan di thread latar belakang milik FCM (batas ~20 detik).
            if (UpdateChecker.check(applicationContext).ok) UpdateChecker.notifyIfNeeded(applicationContext)
            return
        }
        val title = data["title"] ?: message.notification?.title
        val body = data["body"] ?: message.notification?.body
        if (!title.isNullOrEmpty() || !body.isNullOrEmpty()) PushManager.show(this, title ?: "DLMS Mini Equalizer", body ?: "")
    }
}

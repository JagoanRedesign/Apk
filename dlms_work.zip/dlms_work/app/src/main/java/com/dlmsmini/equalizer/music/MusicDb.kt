package com.dlmsmini.equalizer.music

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class PlaylistInfo(val id: Long, val name: String, val count: Int, val thumb: String)

/** Perpustakaan lagu lokal + cache lirik (SQLite). Semua fungsi blocking: panggil dari thread latar. */
class MusicDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "dlms_music.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tracks(id TEXT PRIMARY KEY, title TEXT, artist TEXT, album TEXT, duration INTEGER, " +
                "thumb TEXT, official INTEGER, source INTEGER, uri TEXT, added_at INTEGER)"
        )
        createPlaylistTables(db)
        db.execSQL(
            "CREATE TABLE lyrics(track_id TEXT PRIMARY KEY, lrclib_id INTEGER, title TEXT, artist TEXT, album TEXT, " +
                "duration INTEGER, instrumental INTEGER, synced TEXT, plain TEXT, manual INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createPlaylistTables(db)
    }

    private fun createPlaylistTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS playlists(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, created_at INTEGER)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS playlist_tracks(playlist_id INTEGER, track_id TEXT, position INTEGER, title TEXT, artist TEXT, " +
                "album TEXT, duration INTEGER, thumb TEXT, official INTEGER, source INTEGER, uri TEXT, PRIMARY KEY(playlist_id, track_id))"
        )
    }

    // ---------- playlist ----------

    fun createPlaylist(name: String): Long {
        val cv = ContentValues().apply { put("name", name); put("created_at", System.currentTimeMillis()) }
        return writableDatabase.insert("playlists", null, cv)
    }

    fun renamePlaylist(id: Long, name: String) {
        writableDatabase.update("playlists", ContentValues().apply { put("name", name) }, "id=?", arrayOf(id.toString()))
    }

    fun deletePlaylist(id: Long) {
        writableDatabase.delete("playlist_tracks", "playlist_id=?", arrayOf(id.toString()))
        writableDatabase.delete("playlists", "id=?", arrayOf(id.toString()))
    }

    fun playlists(): List<PlaylistInfo> {
        val out = ArrayList<PlaylistInfo>()
        readableDatabase.query("playlists", null, null, null, null, null, "created_at DESC").use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(c.getColumnIndexOrThrow("id"))
                var count = 0
                var thumb = ""
                readableDatabase.query("playlist_tracks", arrayOf("thumb"), "playlist_id=?", arrayOf(id.toString()), null, null, "position ASC").use { t ->
                    count = t.count
                    if (t.moveToFirst()) thumb = t.getString(0) ?: ""
                }
                out.add(PlaylistInfo(id, c.getString(c.getColumnIndexOrThrow("name")) ?: "", count, thumb))
            }
        }
        return out
    }

    fun playlistTracks(id: Long): List<Track> {
        val out = ArrayList<Track>()
        readableDatabase.query("playlist_tracks", null, "playlist_id=?", arrayOf(id.toString()), null, null, "position ASC").use { c ->
            while (c.moveToNext()) {
                val snap = Track(
                    id = c.getString(c.getColumnIndexOrThrow("track_id")),
                    title = c.getString(c.getColumnIndexOrThrow("title")) ?: "",
                    artist = c.getString(c.getColumnIndexOrThrow("artist")) ?: "",
                    album = c.getString(c.getColumnIndexOrThrow("album")) ?: "",
                    durationSec = c.getInt(c.getColumnIndexOrThrow("duration")),
                    thumb = c.getString(c.getColumnIndexOrThrow("thumb")) ?: "",
                    official = c.getInt(c.getColumnIndexOrThrow("official")) == 1,
                    source = c.getInt(c.getColumnIndexOrThrow("source")),
                    uri = c.getString(c.getColumnIndexOrThrow("uri"))
                )
                // Bila lagunya sudah diunduh, pakai berkas lokal.
                val known = get(snap.id)
                out.add(if (known != null && known.source != Track.SRC_STREAM) known else snap)
            }
        }
        return out
    }

    fun addToPlaylist(playlistId: Long, t: Track) {
        val next = readableDatabase.rawQuery("SELECT COALESCE(MAX(position),-1)+1 FROM playlist_tracks WHERE playlist_id=?", arrayOf(playlistId.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
        val cv = ContentValues().apply {
            put("playlist_id", playlistId); put("track_id", t.id); put("position", next)
            put("title", t.title); put("artist", t.artist); put("album", t.album); put("duration", t.durationSec)
            put("thumb", t.thumb); put("official", if (t.official) 1 else 0); put("source", t.source); put("uri", t.uri)
        }
        writableDatabase.insertWithOnConflict("playlist_tracks", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    /** Menambah banyak lagu sekaligus dalam satu transaksi (jauh lebih cepat daripada satu per satu). */
    fun addAllToPlaylist(playlistId: Long, tracks: List<Track>) {
        val w = writableDatabase
        w.beginTransaction()
        try {
            tracks.forEach { addToPlaylist(playlistId, it) }
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: String) {
        writableDatabase.delete("playlist_tracks", "playlist_id=? AND track_id=?", arrayOf(playlistId.toString(), trackId))
    }

    // ---------- lagu ----------

    fun upsert(t: Track) {
        val old = get(t.id)
        val cv = ContentValues().apply {
            put("id", t.id); put("title", t.title); put("artist", t.artist); put("album", t.album)
            put("duration", t.durationSec); put("thumb", t.thumb); put("official", if (t.official) 1 else 0)
            // Lagu yang sudah diunduh tidak boleh turun kembali menjadi "streaming".
            put("source", if (old != null && old.source == Track.SRC_DOWNLOAD && t.source == Track.SRC_STREAM) old.source else t.source)
            put("uri", if (old != null && old.source == Track.SRC_DOWNLOAD && t.source == Track.SRC_STREAM) old.uri else t.uri)
            put("added_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("tracks", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun get(id: String): Track? =
        readableDatabase.query("tracks", null, "id=?", arrayOf(id), null, null, null).use { if (it.moveToFirst()) row(it) else null }

    fun contains(id: String): Boolean = get(id) != null

    fun delete(id: String) {
        writableDatabase.delete("tracks", "id=?", arrayOf(id))
    }

    /** [source] null = semua. [query] mencocokkan judul/artis. Terbaru lebih dulu. */
    fun list(source: Int?, query: String = ""): List<Track> {
        val where = ArrayList<String>()
        val args = ArrayList<String>()
        if (source != null) { where.add("source=?"); args.add(source.toString()) }
        if (query.isNotBlank()) { where.add("(title LIKE ? OR artist LIKE ?)"); args.add("%$query%"); args.add("%$query%") }
        val c = readableDatabase.query(
            "tracks", null, if (where.isEmpty()) null else where.joinToString(" AND "),
            if (args.isEmpty()) null else args.toTypedArray(), null, null, "added_at DESC"
        )
        return c.use { cur -> val out = ArrayList<Track>(); while (cur.moveToNext()) out.add(row(cur)); out }
    }

    fun replaceDeviceTracks(list: List<Track>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("tracks", "source=?", arrayOf(Track.SRC_DEVICE.toString()))
            for (t in list) {
                val cv = ContentValues().apply {
                    put("id", t.id); put("title", t.title); put("artist", t.artist); put("album", t.album)
                    put("duration", t.durationSec); put("thumb", t.thumb); put("official", 0)
                    put("source", Track.SRC_DEVICE); put("uri", t.uri); put("added_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("tracks", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun row(c: Cursor) = Track(
        id = c.getString(c.getColumnIndexOrThrow("id")),
        title = c.getString(c.getColumnIndexOrThrow("title")) ?: "",
        artist = c.getString(c.getColumnIndexOrThrow("artist")) ?: "",
        album = c.getString(c.getColumnIndexOrThrow("album")) ?: "",
        durationSec = c.getInt(c.getColumnIndexOrThrow("duration")),
        thumb = c.getString(c.getColumnIndexOrThrow("thumb")) ?: "",
        official = c.getInt(c.getColumnIndexOrThrow("official")) == 1,
        source = c.getInt(c.getColumnIndexOrThrow("source")),
        uri = c.getString(c.getColumnIndexOrThrow("uri"))
    )

    // ---------- lirik ----------

    fun saveLyrics(trackId: String, l: LyricsCandidate, manual: Boolean) {
        val cv = ContentValues().apply {
            put("track_id", trackId); put("lrclib_id", l.id); put("title", l.title); put("artist", l.artist)
            put("album", l.album); put("duration", l.durationSec); put("instrumental", if (l.instrumental) 1 else 0)
            put("synced", l.synced); put("plain", l.plain); put("manual", if (manual) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("lyrics", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getLyrics(trackId: String): LyricsCandidate? =
        readableDatabase.query("lyrics", null, "track_id=?", arrayOf(trackId), null, null, null).use {
            if (!it.moveToFirst()) null else LyricsCandidate(
                id = it.getLong(it.getColumnIndexOrThrow("lrclib_id")),
                title = it.getString(it.getColumnIndexOrThrow("title")) ?: "",
                artist = it.getString(it.getColumnIndexOrThrow("artist")) ?: "",
                album = it.getString(it.getColumnIndexOrThrow("album")) ?: "",
                durationSec = it.getInt(it.getColumnIndexOrThrow("duration")),
                instrumental = it.getInt(it.getColumnIndexOrThrow("instrumental")) == 1,
                synced = it.getString(it.getColumnIndexOrThrow("synced")),
                plain = it.getString(it.getColumnIndexOrThrow("plain"))
            )
        }

    fun clearLyrics(trackId: String) {
        writableDatabase.delete("lyrics", "track_id=?", arrayOf(trackId))
    }

    companion object {
        @Volatile private var inst: MusicDb? = null
        fun get(ctx: Context): MusicDb = inst ?: synchronized(this) { inst ?: MusicDb(ctx).also { inst = it } }
    }
}

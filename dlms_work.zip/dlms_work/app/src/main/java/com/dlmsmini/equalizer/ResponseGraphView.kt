package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

/** Grafik respons frekuensi 20 Hz – 20 kHz (sumbu log) dengan kurva dan titik band yang dapat digeser. */
class ResponseGraphView(context: Context) : View(context) {

    class Curve(val color: Int, val values: FloatArray, val width: Float = 2f, val fill: Boolean = false)
    class Handle(val index: Int, val freqHz: Float, val gainDb: Float, val color: Int, val selected: Boolean, val enabled: Boolean)

    var dbMin = -18f
    var dbMax = 18f
    var dbLines: FloatArray = floatArrayOf(-12f, -6f, 0f, 6f, 12f)

    /** (indeks, frekuensi, gain, selesai) — dipanggil saat titik digeser. */
    var onHandleDrag: ((Int, Float, Float, Boolean) -> Unit)? = null
    var onHandleSelect: ((Int) -> Unit)? = null

    private var curves: List<Curve> = emptyList()
    private var handles: List<Handle> = emptyList()
    private var dragging = -1

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x223B82C5; strokeWidth = 1f }
    private val zero = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x553B82C5; strokeWidth = 1.5f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF7D8FAE); textSize = d(9f) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFFFFFFFF); textSize = d(10f); textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val path = Path()

    private val padL get() = d(30f)
    private val padR get() = d(8f)
    private val padT get() = d(8f)
    private val padB get() = d(16f)

    fun setCurves(list: List<Curve>) { curves = list; invalidate() }
    fun setHandles(list: List<Handle>) { handles = list; invalidate() }

    private fun hzToX(hz: Float): Float {
        val w = width - padL - padR
        return padL + (ln(hz.coerceIn(FMIN, FMAX) / FMIN) / ln(FMAX / FMIN)) * w
    }

    private fun xToHz(x: Float): Float {
        val w = width - padL - padR
        val t = ((x - padL) / w).coerceIn(0f, 1f)
        return (FMIN * (FMAX / FMIN).pow(t))
    }

    private fun dbToY(db: Float): Float {
        val h = height - padT - padB
        return padT + (1f - (db.coerceIn(dbMin, dbMax) - dbMin) / (dbMax - dbMin)) * h
    }

    private fun yToDb(y: Float): Float {
        val h = height - padT - padB
        return dbMin + (1f - ((y - padT) / h).coerceIn(0f, 1f)) * (dbMax - dbMin)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val right = width - padR
        val bottom = height - padB
        for (db in dbLines) {
            val y = dbToY(db)
            canvas.drawLine(padL, y, right, y, if (db == 0f) zero else grid)
            val label = (if (db > 0f) "+" else "") + db.toInt()
            canvas.drawText(label, d(2f), y + d(3f), txt)
        }
        val marks = floatArrayOf(20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f)
        val names = arrayOf("20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k")
        for (i in marks.indices) {
            val x = hzToX(marks[i])
            canvas.drawLine(x, padT, x, bottom, grid)
            val tw = txt.measureText(names[i])
            canvas.drawText(names[i], (x - tw / 2f).coerceIn(padL - d(6f), width - tw), height - d(3f), txt)
        }
        for (c in curves) {
            val n = c.values.size
            if (n < 2) continue
            path.reset()
            for (i in 0 until n) {
                val hz = FMIN * (FMAX / FMIN).pow(i.toFloat() / (n - 1))
                val x = hzToX(hz)
                val y = dbToY(c.values[i])
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            if (c.fill) {
                val fp = Path(path)
                fp.lineTo(right, dbToY(0f))
                fp.lineTo(padL, dbToY(0f))
                fp.close()
                fillP.color = (c.color and 0x00FFFFFF) or 0x30000000
                canvas.drawPath(fp, fillP)
            }
            line.color = c.color
            line.strokeWidth = d(c.width)
            canvas.drawPath(path, line)
        }
        for (h in handles) {
            val x = hzToX(h.freqHz)
            val y = dbToY(h.gainDb)
            val r = if (h.selected) d(11f) else d(9f)
            dot.style = Paint.Style.FILL
            dot.color = if (h.enabled) h.color else Pal.c(0xFF4A5568)
            canvas.drawCircle(x, y, r, dot)
            if (h.selected) {
                dot.style = Paint.Style.STROKE
                dot.strokeWidth = d(2f)
                dot.color = Pal.c(0xFFFFFFFF)
                canvas.drawCircle(x, y, r + d(2f), dot)
            }
            canvas.drawText((h.index + 1).toString(), x, y + d(3.5f), dotText)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best = -1
                var bestD = d(30f)
                for (h in handles) {
                    val dist = abs(hzToX(h.freqHz) - e.x) + abs(dbToY(h.gainDb) - e.y)
                    if (dist < bestD) { bestD = dist; best = h.index }
                }
                if (best < 0) return false
                dragging = best
                parent?.requestDisallowInterceptTouchEvent(true)
                onHandleSelect?.invoke(best)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging >= 0) onHandleDrag?.invoke(dragging, xToHz(e.x), yToDb(e.y), false)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging >= 0) {
                    onHandleDrag?.invoke(dragging, xToHz(e.x), yToDb(e.y), true)
                    dragging = -1
                }
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    companion object {
        private const val FMIN = 20f
        private const val FMAX = 20000f
        const val POINTS = 240
        val FREQS: DoubleArray = DspMath.logSpace(POINTS)
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Panel master: tombol ON/OFF audio, indikator "efek benar-benar aktif", dan perangkat audio saat ini. */
class MasterStrip(
    ctx: Context,
    initial: MasterSettings,
    private val onToggle: (Boolean) -> Unit,
    private val onOpenDiagnostics: () -> Unit
) {
    val view: LinearLayout = Ui.panelCard(ctx, 12)
    private val sw: Switch
    private val indicator: TextView
    private val detail: TextView
    private var suppress = false

    init {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sw = Switch(ctx).apply {
            text = "MASTER"
            textSize = 12f
            setTextColor(Pal.c(0xFFEAF0FF))
            isChecked = initial.on
            setOnCheckedChangeListener { _, checked -> if (!suppress) onToggle(checked) }
        }
        row.addView(sw, LinearLayout.LayoutParams(0, -2, 1f))
        indicator = Ui.label(ctx, "● MENYIAPKAN", 11f, Pal.MUTED, true).apply {
            isClickable = true
            setOnClickListener { onOpenDiagnostics() }
            setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6))
        }
        row.addView(indicator)
        view.addView(row)
        detail = Ui.label(ctx, "", 10f, Pal.MUTED).apply {
            isClickable = true
            setOnClickListener { onOpenDiagnostics() }
            setPadding(0, Ui.dp(ctx, 4), 0, 0)
        }
        view.addView(detail)
    }

    fun update(master: MasterSettings, ind: Indicator?, routeLabel: String, extra: String = "") {
        if (sw.isChecked != master.on) {
            suppress = true
            sw.isChecked = master.on
            suppress = false
        }
        if (ind != null) {
            indicator.text = "● " + ind.text
            indicator.setTextColor(
                when (ind.level) {
                    Level.OK -> Pal.c(0xFF7BE3B0)
                    Level.PARTIAL, Level.WAIT -> Pal.c(0xFFFFB86B)
                    Level.FAIL -> Pal.c(0xFFFF6B6B)
                    Level.OFF -> Pal.c(0xFF8294B2)
                }
            )
        }
        val failed = ind?.details?.filter { it.state != FxState.ACTIVE }.orEmpty()
        val bits = mutableListOf<String>()
        if (routeLabel.isNotEmpty()) bits.add("Output: $routeLabel")
        if (failed.isNotEmpty()) bits.add("Gagal: " + failed.joinToString(", ") { it.name })
        if (extra.isNotEmpty()) bits.add(extra)
        detail.text = bits.joinToString(" • ").ifEmpty { "Ketuk untuk diagnostik" }
    }
}

package com.dlmsmini.equalizer

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/**
 * Piped is a federated community service. Instances may be offline or rate-limited;
 * this client keeps the instance configurable and does not promise unlimited results.
 */
object MusicNetwork {
    private val instances = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.leptons.xyz",
        "https://pipedapi.nosebs.ru"
    )
    @Volatile var instance: String = instances.first()

    private fun request(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 18000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "DLMS-Mini-Music/1.0 (Android)")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Piped HTTP $code")
            return body
        } finally { c.disconnect() }
    }

    fun search(query: String, nextPage: String? = null): MusicPage {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val path = if (nextPage.isNullOrBlank()) {
            "$instance/search?q=$encoded&filter=music_songs"
        } else {
            val token = URLEncoder.encode(nextPage, "UTF-8")
            "$instance/nextpage/search?nextpage=$token"
        }
        val root = JSONObject(request(path))
        val arr = root.optJSONArray("items") ?: JSONArray()
        val tracks = ArrayList<MusicTrack>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val type = o.optString("type")
            if (type.isNotEmpty() && type != "stream") continue
            val watch = o.optString("url")
            val id = extractId(watch, o.optString("id"))
            if (id.isBlank()) continue
            val title = o.optString("title").trim()
            if (title.isBlank()) continue
            val uploader = o.optString("uploaderName").ifBlank { o.optString("uploader") }
            val verified = o.optBoolean("uploaderVerified", false)
            val official = verified || uploader.contains(" - Topic", true) ||
                uploader.contains("official", true)
            tracks += MusicTrack(
                id = id,
                title = title,
                artist = uploader.ifBlank { "Artis tidak diketahui" },
                durationSeconds = o.optLong("duration", 0L),
                thumbnail = o.optString("thumbnail"),
                watchUrl = "https://www.youtube.com/watch?v=$id",
                official = official
            )
        }
        // Official/verified artist channels are shown before other uploads.
        val sorted = tracks.sortedByDescending { it.official }
        val next = root.optString("nextpage").takeIf { it.isNotBlank() && it != "null" }
        return MusicPage(sorted, next)
    }

    private fun extractId(url: String, fallback: String): String {
        if (fallback.isNotBlank() && fallback != "null") return fallback
        return try {
            val uri = java.net.URI(if (url.startsWith("http")) url else "https://www.youtube.com$url")
            val query = uri.rawQuery.orEmpty().split("&").firstOrNull { it.startsWith("v=") }
            query?.substringAfter("v=")?.substringBefore("&") ?: uri.path.substringAfterLast("/")
        } catch (_: Exception) { "" }
    }

    fun rotateInstance() {
        val index = instances.indexOf(instance).let { if (it < 0) 0 else it }
        instance = instances[(index + 1) % instances.size]
    }

    fun lyricsSearch(query: String): List<LyricsCandidate> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val conn = (URL("https://lrclib.net/api/search?q=$encoded").openConnection() as HttpURLConnection)
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("User-Agent", "DLMS Mini Music/1.0 (https://github.com/JagoanRedesign/Apk)")
        try {
            if (conn.responseCode == 429) throw IllegalStateException("LRCLIB membatasi permintaan. Coba lagi nanti.")
            if (conn.responseCode !in 200..299) throw IllegalStateException("LRCLIB HTTP ${conn.responseCode}")
            val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            return (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                LyricsCandidate(
                    o.optLong("id"), o.optString("trackName"), o.optString("artistName"),
                    o.optString("albumName"), o.optInt("duration"),
                    o.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" },
                    o.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                )
            }
        } finally { conn.disconnect() }
    }
}

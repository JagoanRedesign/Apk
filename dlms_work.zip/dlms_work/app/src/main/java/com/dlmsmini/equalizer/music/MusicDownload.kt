package com.dlmsmini.equalizer.music

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.dlmsmini.equalizer.DiagLog
import com.dlmsmini.equalizer.R
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

enum class DlState { QUEUED, RUNNING, DONE, FAILED, CANCELED }

class DownloadJob(
    val id: Int,
    val track: Track,
    val option: AudioOption,
    val embedCover: Boolean,
    val embedLyrics: Boolean,
    val syncedLyrics: Boolean
) {
    @Volatile var state = DlState.QUEUED
    @Volatile var progress = 0
    @Volatile var message = "Menunggu antrean"
    @Volatile var cancel = false
}

/** Antrean unduhan yang dibagi antara UI dan [MusicDownloadService] (satu proses). */
object DownloadCenter {
    val jobs = CopyOnWriteArrayList<DownloadJob>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val nextId = AtomicInteger(1)

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun changed() { main.post { listeners.forEach { it() } } }

    fun enqueue(ctx: Context, track: Track, option: AudioOption, cover: Boolean, lyrics: Boolean, synced: Boolean): DownloadJob {
        val job = DownloadJob(nextId.getAndIncrement(), track, option, cover, lyrics, synced)
        jobs.add(0, job)
        changed()
        ContextCompat.startForegroundService(ctx.applicationContext, Intent(ctx.applicationContext, MusicDownloadService::class.java))
        return job
    }

    @Synchronized
    fun nextQueued(): DownloadJob? = jobs.lastOrNull { it.state == DlState.QUEUED && !it.cancel }

    fun clearFinished() {
        jobs.removeAll { it.state == DlState.DONE || it.state == DlState.FAILED || it.state == DlState.CANCELED }
        changed()
    }
}

class MusicDownloadService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val pending = AtomicInteger(0)
    private val main = Handler(Looper.getMainLooper())
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Unduhan musik", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = notification("Menyiapkan unduhan…", 0, true)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIF_ID, n)
        pending.incrementAndGet()
        executor.execute {
            try {
                while (true) {
                    val job = DownloadCenter.nextQueued() ?: break
                    process(job)
                }
            } finally {
                if (pending.decrementAndGet() == 0) main.post { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun notification(text: String, progress: Int, indeterminate: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MusicActivity::class.java).putExtra(MusicActivity.EXTRA_TAB, 3),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Mengunduh musik")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(open)
            .setProgress(100, progress, indeterminate)
            .build()
    }

    private fun update(job: DownloadJob, msg: String, progress: Int) {
        job.message = msg
        job.progress = progress
        DownloadCenter.changed()
        nm.notify(NOTIF_ID, notification("${job.track.title} — $msg", progress, false))
    }

    private fun process(job: DownloadJob) {
        val ctx = applicationContext
        job.state = DlState.RUNNING
        val dir = File(cacheDir, "dl").apply { mkdirs() }
        val raw = File(dir, "raw_${job.id}.${job.option.suffix}")
        val fin = File(dir, "fin_${job.id}.${job.option.suffix}")
        try {
            update(job, "Mengunduh…", 0)
            downloadWithRetry(job, raw)
            if (job.cancel) throw InterruptedException()

            var work = raw
            var note = ""
            if (job.option.suffix == "m4a") {
                update(job, "Merapikan wadah M4A…", 90)
                if (M4aRemux.remux(raw, fin)) work = fin else note = " (wadah DASH dipertahankan)"
            }

            // Lirik (dicari dulu agar tersimpan di perpustakaan walau tidak disematkan).
            var lyricsText: String? = null
            if (job.embedLyrics) {
                update(job, "Mengambil lirik…", 93)
                lyricsText = try {
                    LrcLib.lyricsFor(ctx, job.track)?.let { LrcLib.textForEmbed(it, job.syncedLyrics) }
                } catch (e: Exception) { null }
            }

            // Sampul: selalu disimpan ke penyimpanan aplikasi untuk tampilan perpustakaan; disematkan bila diminta.
            update(job, "Mengambil sampul…", 95)
            val coverBytes = fetchCover(job.track)
            var coverPath = ""
            if (coverBytes != null) {
                val f = File(File(filesDir, "covers").apply { mkdirs() }, "${job.track.id}.jpg")
                try { f.writeBytes(coverBytes); coverPath = f.toURI().toString() } catch (_: Exception) {}
            }

            if (job.option.canEmbed) {
                update(job, "Menanam tag…", 97)
                val ok = Mp4Tagger.write(
                    work,
                    Mp4Tagger.Meta(
                        job.track.title, job.track.artist, job.track.album.ifBlank { null },
                        if (job.embedLyrics) lyricsText else null,
                        if (job.embedCover) coverBytes else null
                    )
                )
                if (!ok) note += " (tag gagal ditanam)"
            } else if (job.embedCover || job.embedLyrics) {
                note += " (format Opus: sampul/lirik tidak disematkan, tetap tersedia di aplikasi)"
            }

            update(job, "Menyimpan…", 99)
            val name = safeName("${job.track.artist} - ${job.track.title}") + "." + job.option.suffix
            val uri = MediaPublisher.publish(ctx, work, name, job.option.mime, job.track)
            MusicDb.get(ctx).upsert(
                job.track.copy(
                    source = Track.SRC_DOWNLOAD, uri = uri,
                    thumb = if (coverPath.isNotEmpty()) coverPath else job.track.thumb
                )
            )
            job.state = DlState.DONE
            job.progress = 100
            job.message = "Selesai$note"
        } catch (e: InterruptedException) {
            job.state = DlState.CANCELED
            job.message = "Dibatalkan"
        } catch (e: Exception) {
            DiagLog.log("Musik: unduhan ${job.track.id} gagal: ${e.message}")
            job.state = DlState.FAILED
            job.message = "Gagal: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            raw.delete()
            fin.delete()
            DownloadCenter.changed()
        }
    }

    // ---------- unduh bertahap (Range) ----------

    private fun downloadWithRetry(job: DownloadJob, out: File) {
        var url = job.option.url
        var retried = false
        while (true) {
            try {
                downloadChunks(url, out, job)
                return
            } catch (e: Http.HttpError) {
                if ((e.code == 403 || e.code == 410) && !retried) {
                    retried = true
                    // URL kedaluwarsa: ekstrak ulang dan cocokkan pilihan yang sama.
                    val fresh = StreamResolver.options(job.track.id, force = true)
                    url = (fresh.firstOrNull { it.key == job.option.key } ?: fresh.first()).url
                } else throw e
            }
        }
    }

    private fun downloadChunks(url: String, out: File, job: DownloadJob) {
        val ua = StreamResolver.userAgentFor(url)
        var pos = 0L
        var total = -1L
        FileOutputStream(out).use { fos ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                if (job.cancel) throw InterruptedException()
                val c = Http.open(url, ua, 20000, "bytes=$pos-${pos + CHUNK - 1}")
                var got = 0L
                try {
                    val code = c.responseCode
                    if (code >= 400) throw Http.HttpError(code, "HTTP $code")
                    if (code == 200) {
                        // Server mengabaikan Range: ambil seluruh isi.
                        total = c.contentLengthLong
                        pos = 0
                        fos.channel.truncate(0)
                        fos.channel.position(0)
                    } else {
                        val cr = c.getHeaderField("Content-Range") // bytes a-b/total
                        total = cr?.substringAfter('/')?.toLongOrNull() ?: total
                    }
                    c.inputStream.use { ins ->
                        while (true) {
                            if (job.cancel) throw InterruptedException()
                            val n = ins.read(buf)
                            if (n < 0) break
                            fos.write(buf, 0, n)
                            got += n
                            pos += n
                            if (total > 0) {
                                val pct = (pos * 90 / total).toInt().coerceIn(0, 90)
                                if (pct != job.progress) update(job, "Mengunduh… ${pos / 1024} KB", pct)
                            }
                        }
                    }
                    if (code == 200) return
                    if (got == 0L) throw IOException("Respons kosong")
                } finally {
                    c.disconnect()
                }
                if (total in 1..pos) return
                if (total <= 0 && got < CHUNK) return
            }
        }
    }

    // ---------- sampul ----------

    private fun fetchCover(t: Track): ByteArray? {
        val urls = ArrayList<String>()
        if (!t.id.startsWith("local:")) {
            urls.add("https://i.ytimg.com/vi/${t.id}/maxresdefault.jpg")
            urls.add("https://i.ytimg.com/vi/${t.id}/sddefault.jpg")
        }
        if (t.thumb.startsWith("http")) urls.add(t.thumb)
        urls.add("https://i.ytimg.com/vi/${t.id}/hqdefault.jpg")
        for (u in urls) {
            try {
                val raw = Http.getBytes(u, NpDownloader.UA_FIREFOX, 12000)
                val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: continue
                // Sampul Topic: seni persegi di tengah bingkai 16:9/4:3 → potong tengah menjadi persegi.
                val side = minOf(bmp.width, bmp.height)
                if (side < 100) continue
                var sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                if (side > 1000) sq = Bitmap.createScaledBitmap(sq, 1000, 1000, true)
                val o = ByteArrayOutputStream()
                sq.compress(Bitmap.CompressFormat.JPEG, 92, o)
                return o.toByteArray()
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").replace(Regex("\\s+"), " ").trim().take(120).ifBlank { "lagu" }

    companion object {
        private const val CH = "dlms_music_dl"
        private const val NOTIF_ID = 7301
        private const val CHUNK = 10L * 1024 * 1024
    }
}

/** Menyimpan berkas hasil unduhan ke Music/DLMS (MediaStore di Android 10+, folder aplikasi di Android 9). */
object MediaPublisher {
    fun publish(ctx: Context, file: File, displayName: String, mime: String, t: Track): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val r = ctx.contentResolver
            val cv = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Audio.Media.MIME_TYPE, mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/DLMS")
                put(MediaStore.Audio.Media.TITLE, t.title)
                put(MediaStore.Audio.Media.ARTIST, t.artist)
                if (t.album.isNotBlank()) put(MediaStore.Audio.Media.ALBUM, t.album)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val uri = r.insert(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), cv)
                ?: throw IOException("Gagal membuat berkas di MediaStore")
            try {
                (r.openOutputStream(uri) ?: throw IOException("Gagal membuka berkas tujuan")).use { o ->
                    file.inputStream().use { it.copyTo(o) }
                }
                r.update(uri, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                try { r.delete(uri, null, null) } catch (_: Exception) {}
                throw e
            }
            return uri.toString()
        }
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "DLMS").apply { mkdirs() }
        var dest = File(dir, displayName)
        var n = 1
        while (dest.exists()) dest = File(dir, displayName.substringBeforeLast('.') + " (${n++})." + displayName.substringAfterLast('.'))
        file.copyTo(dest, overwrite = false)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
        return Uri.fromFile(dest).toString()
    }

    fun delete(ctx: Context, uriString: String) {
        try {
            val u = Uri.parse(uriString)
            if (u.scheme == "content") ctx.contentResolver.delete(u, null, null)
            else if (u.scheme == "file") File(u.path ?: return).delete()
        } catch (_: Exception) {
        }
    }
}

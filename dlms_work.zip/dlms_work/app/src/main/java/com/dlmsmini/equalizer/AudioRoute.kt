package com.dlmsmini.equalizer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper

/** Jenis keluaran audio yang sedang dipakai pemutar media. */
enum class RouteKind { SPEAKER, WIRED, BLUETOOTH, USB, HDMI, OTHER, UNKNOWN }

class AudioRoute(val kind: RouteKind, val label: String, val name: String) {
    val signature: String get() = "$kind|$label|$name"

    companion object {
        val UNKNOWN = AudioRoute(RouteKind.UNKNOWN, "Tidak diketahui", "")
    }
}

/** Mendeteksi keluaran audio aktif (speaker, headset kabel, Bluetooth, USB, HDMI). */
object RouteDetector {

    fun kindOf(type: Int): RouteKind = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> RouteKind.SPEAKER
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL -> RouteKind.WIRED
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_HEARING_AID, TYPE_BLE_HEADSET, TYPE_BLE_SPEAKER, TYPE_BLE_BROADCAST -> RouteKind.BLUETOOTH
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> RouteKind.USB
        AudioDeviceInfo.TYPE_HDMI, AudioDeviceInfo.TYPE_HDMI_ARC -> RouteKind.HDMI
        else -> RouteKind.OTHER
    }

    // Konstanta API 31/33 ditulis sebagai angka agar aman di semua versi Android.
    private const val TYPE_BLE_HEADSET = 26
    private const val TYPE_BLE_SPEAKER = 27
    private const val TYPE_BLE_BROADCAST = 30

    fun labelOf(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Speaker ponsel"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Headset kabel"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Headphone kabel"
        AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL -> "Line out"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth (A2DP)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth (SCO)"
        AudioDeviceInfo.TYPE_HEARING_AID -> "Alat bantu dengar"
        TYPE_BLE_HEADSET, TYPE_BLE_SPEAKER, TYPE_BLE_BROADCAST -> "Bluetooth LE Audio"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> "Audio USB"
        AudioDeviceInfo.TYPE_HDMI, AudioDeviceInfo.TYPE_HDMI_ARC -> "HDMI"
        else -> "Perangkat audio lain"
    }

    private fun rank(kind: RouteKind): Int = when (kind) {
        RouteKind.BLUETOOTH -> 0
        RouteKind.USB -> 1
        RouteKind.WIRED -> 2
        RouteKind.HDMI -> 3
        RouteKind.SPEAKER -> 4
        else -> 5
    }

    private fun toRoute(d: AudioDeviceInfo): AudioRoute {
        val name = try { d.productName?.toString().orEmpty() } catch (_: Exception) { "" }
        return AudioRoute(kindOf(d.type), labelOf(d.type), name)
    }

    /** Keluaran yang dipakai media saat ini. Android 13+ bertanya langsung ke sistem; di bawahnya memakai prioritas. */
    fun current(ctx: Context): AudioRoute {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 33) {
                val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build()
                val routed = am.getAudioDevicesForAttributes(attrs)
                if (routed.isNotEmpty()) return toRoute(routed.minBy { rank(kindOf(it.type)) })
            }
            val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.isSink }
            val best = outs.minByOrNull { rank(kindOf(it.type)) }
            if (best != null) toRoute(best) else AudioRoute.UNKNOWN
        } catch (_: Exception) {
            AudioRoute.UNKNOWN
        }
    }
}

/**
 * Memantau perangkat audio yang tersambung/terlepas. Perubahan dikumpulkan (debounce) lalu [onChange]
 * dipanggil di thread utama dengan rute baru dan penanda apakah rute benar-benar berubah.
 */
class AudioDeviceMonitor(private val ctx: Context, private val onChange: (AudioRoute, Boolean) -> Unit) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private var last: String? = null
    private var registered = false

    private val update = Runnable {
        val r = RouteDetector.current(ctx)
        val changed = last != null && last != r.signature
        last = r.signature
        onChange(r, changed)
    }

    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = schedule()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = schedule()
    }

    private fun schedule() {
        handler.removeCallbacks(update)
        handler.postDelayed(update, 500)
    }

    fun start() {
        if (registered) return
        try {
            am.registerAudioDeviceCallback(callback, handler)
            registered = true
        } catch (_: Exception) {
        }
        handler.post(update)
    }

    fun stop() {
        handler.removeCallbacks(update)
        if (registered) {
            try { am.unregisterAudioDeviceCallback(callback) } catch (_: Exception) {}
            registered = false
        }
    }
}

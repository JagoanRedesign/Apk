package com.dlmsmini.equalizer.music

import android.content.Context
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.dlmsmini.equalizer.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.playlist.PlaylistInfo as NpPlaylistInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Menyimpan sekumpulan lagu (antrean, hasil Mix) sebagai playlist baru atau menambahkannya ke playlist yang ada. */
object PlaylistSaver {
    fun defaultQueueName(): String =
        "Antrean " + SimpleDateFormat("d MMM HH:mm", Locale("id", "ID")).format(Date())

    /** Dialog pilihan: playlist baru atau playlist yang sudah ada. */
    fun save(act: AppCompatActivity, scope: CoroutineScope, tracks: List<Track>, defaultName: String, onDone: (() -> Unit)? = null) {
        if (tracks.isEmpty()) {
            Toast.makeText(act, "Tidak ada lagu untuk disimpan", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            val list = withContext(Dispatchers.IO) { MusicDb.get(act.applicationContext).playlists() }
            val labels = (listOf("＋ Playlist baru…") + list.map { "${it.name} (${it.count})" }).toTypedArray()
            AlertDialog.Builder(act)
                .setTitle("Simpan ${tracks.size} lagu ke…")
                .setItems(labels) { _, i ->
                    if (i == 0) askName(act, scope, tracks, defaultName, onDone)
                    else write(act, scope, list[i - 1].id, list[i - 1].name, tracks, onDone)
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun askName(act: AppCompatActivity, scope: CoroutineScope, tracks: List<Track>, defaultName: String, onDone: (() -> Unit)?) {
        val et = EditText(act).apply { setText(defaultName); setSelection(text.length); hint = "Nama playlist"; setSingleLine() }
        val wrap = FrameLayout(act).apply { setPadding(Ui.dp(act, 20), Ui.dp(act, 8), Ui.dp(act, 20), 0); addView(et) }
        AlertDialog.Builder(act).setTitle("Playlist baru").setView(wrap)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isNotEmpty()) write(act, scope, null, name, tracks, onDone)
            }.show()
    }

    /** Menulis ke playlist [id] (atau membuat baru bila null). Lagu ganda dilewati. */
    fun write(act: AppCompatActivity, scope: CoroutineScope, id: Long?, name: String, tracks: List<Track>, onDone: (() -> Unit)? = null) {
        scope.launch {
            val n = withContext(Dispatchers.IO) { writeBlocking(act.applicationContext, id, name, tracks) }
            Toast.makeText(act, "$n lagu disimpan ke “$name”", Toast.LENGTH_SHORT).show()
            onDone?.invoke()
        }
    }

    /** Blocking. Mengembalikan jumlah lagu unik yang ditulis. */
    fun writeBlocking(ctx: Context, id: Long?, name: String, tracks: List<Track>): Int {
        val db = MusicDb.get(ctx)
        val pid = id ?: db.createPlaylist(name)
        val unique = tracks.distinctBy { it.id }
        db.addAllToPlaylist(pid, unique)
        return unique.size
    }

    /** Membuat playlist baru dan mengembalikan ID-nya (blocking). */
    fun createWith(ctx: Context, name: String, tracks: List<Track>): Long {
        val db = MusicDb.get(ctx)
        val pid = db.createPlaylist(name)
        db.addAllToPlaylist(pid, tracks.distinctBy { it.id })
        return pid
    }
}

/** Impor playlist YouTube dari tautan lewat NewPipeExtractor (lokal di perangkat). */
object PlaylistImport {
    class Imported(val name: String, val tracks: List<Track>)

    private val listRe = Regex("[?&]list=([A-Za-z0-9_-]+)")
    private val videoRe = Regex("[?&]v=([A-Za-z0-9_-]{11})")
    private val hostRe = Regex("(youtube\\.com|youtu\\.be)", RegexOption.IGNORE_CASE)

    /** Tautan YouTube yang memuat parameter list= diubah ke bentuk baku; selain itu null. */
    fun normalize(raw: String): String? {
        val s = raw.trim()
        if (!hostRe.containsMatchIn(s)) return null
        val list = listRe.find(s)?.groupValues?.get(1) ?: return null
        if (list == "WL" || list == "LL") return null // daftar pribadi akun, tidak bisa diambil
        if (list.startsWith("RD")) {
            // Mix YouTube hanya bisa diambil lewat tautan tontonan.
            val v = videoRe.find(s)?.groupValues?.get(1) ?: list.removePrefix("RD").take(11)
            if (v.length != 11) return null
            return "https://www.youtube.com/watch?v=$v&list=$list"
        }
        return "https://www.youtube.com/playlist?list=$list"
    }

    /** Blocking. [onProgress] dipanggil dengan jumlah lagu yang sudah terkumpul. */
    fun fetch(url: String, limit: Int = 500, onProgress: (Int) -> Unit = {}, cancelled: () -> Boolean = { false }): Imported {
        val service = NewPipeBridge.service()
        val info = NpPlaylistInfo.getInfo(service, url)
        val out = ArrayList<Track>()
        val seen = HashSet<String>()
        fun add(items: List<org.schabi.newpipe.extractor.InfoItem>) {
            for (item in items) {
                val t = MixBuilder.toTrack(item, 1L, Long.MAX_VALUE) ?: continue // lewati video terhapus/pribadi
                if (seen.add(t.id)) out.add(t)
            }
            onProgress(out.size)
        }
        add(info.relatedItems)
        var page = info.nextPage
        while (page != null && out.size < limit && !cancelled()) {
            val more = NpPlaylistInfo.getMoreItems(service, url, page)
            add(more.items)
            page = more.nextPage
        }
        val name = info.name?.takeIf { it.isNotBlank() } ?: "Playlist YouTube"
        return Imported(name, out.take(limit))
    }
}

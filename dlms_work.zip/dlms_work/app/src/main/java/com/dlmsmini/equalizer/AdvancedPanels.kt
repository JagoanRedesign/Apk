package com.dlmsmini.equalizer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.widget.CheckBox
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

private val BAND_COLORS = intArrayOf(
    0xFFFF7A59.toInt(), 0xFFFFC857.toInt(), 0xFF35D6A5.toInt(), 0xFF2BD8FF.toInt(), 0xFF5B8CFF.toInt(),
    0xFFB07CFF.toInt(), 0xFFFF6FB5.toInt(), 0xFF9BE15D.toInt(), 0xFFFFA24D.toInt(), 0xFF7FDBFF.toInt()
)

/** Slider berlabel yang bisa menyetel ulang nilainya dan melapor saat selesai digeser. */
private class LabeledSlider(ctx: Context, parent: LinearLayout, title: String, val spec: Spec,
                            val onLive: (Float) -> Unit, val onDone: () -> Unit) {
    private val value = Ui.label(ctx, "", 13f, Pal.CYAN, true)
    private val titleView = Ui.label(ctx, title, 14f, 0xFFFFFFFF.toInt())
    private val bar = SeekBar(ctx)
    private val head = LinearLayout(ctx)
    private var quiet = false

    init {
        head.orientation = LinearLayout.HORIZONTAL
        head.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 12), Ui.dp(ctx, 4), 0)
        head.addView(titleView, Ui.weighted())
        head.addView(value)
        val tint = ColorStateList.valueOf(0xFF00CFFF.toInt())
        bar.max = spec.steps
        bar.progressTintList = tint
        bar.thumbTintList = tint
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = spec.toValue(p)
                value.text = spec.format(v)
                if (fromUser && !quiet) onLive(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onDone() }
        })
        parent.addView(head)
        parent.addView(bar, LinearLayout.LayoutParams(-1, -2))
    }

    fun set(v: Float) {
        quiet = true
        bar.progress = spec.toProgress(v)
        value.text = spec.format(v)
        quiet = false
    }

    fun setEnabledLook(on: Boolean) {
        val a = if (on) 1f else 0.4f
        head.alpha = a
        bar.alpha = a
        bar.isEnabled = on
    }
}

/**
 * Parametric EQ 2.0: hingga 10 band; tiap band punya tipe filter, frekuensi, gain, dan Q. Grafik menampilkan respons
 * gabungan (kurva ideal biquad); titik band dapat digeser langsung. [onChange] dipanggil dengan (pengaturan, selesai).
 */
class PeqPanel(
    private val ctx: Context,
    host: LinearLayout,
    initial: PeqSettings,
    private val onChange: (PeqSettings, Boolean) -> Unit
) {
    private var s = initial
    private var sel = 0
    private val graph = ResponseGraphView(ctx)
    private val bandRow = LinearLayout(ctx)
    private val typeRow = LinearLayout(ctx)
    private val note = Ui.label(ctx, "", 10f, 0xFFFFB86B.toInt(), true)
    private val enable: CheckBox
    private val bandEnable: CheckBox
    private val sFreq: LabeledSlider
    private val sGain: LabeledSlider
    private val sQ: LabeledSlider
    private var quiet = false

    init {
        val card = Ui.panelCard(ctx, 12)
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        enable = CheckBox(ctx).apply {
            text = "Parametric EQ aktif"; textSize = 15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = ColorStateList.valueOf(0xFF00CFFF.toInt())
            isChecked = s.on
            setOnCheckedChangeListener { _, c -> if (!quiet) { s = s.copy(on = c); push(true) } }
        }
        top.addView(enable, Ui.weighted())
        val reset = Ui.chip(ctx, "RESET")
        reset.setOnClickListener {
            s = s.copy(bands = PeqSpec.defaultBands()); sel = 0; refreshAll(); push(true)
        }
        top.addView(reset)
        card.addView(top)

        graph.dbMin = -18f; graph.dbMax = 18f
        card.addView(graph, LinearLayout.LayoutParams(-1, Ui.dp(ctx, 200)).apply { topMargin = Ui.dp(ctx, 6) })
        graph.onHandleSelect = { i -> sel = i; refreshEditor(); refreshBandChips() }
        graph.onHandleDrag = { i, hz, db, done ->
            val b = s.bands.getOrNull(i)
            if (b != null) {
                val nb = PeqSpec.clampBand(b.copy(freqHz = hz, gainDb = if (b.type.usesGain) roundHalf(db) else b.gainDb))
                setBand(i, nb)
                refreshEditor()
                push(done)
            }
        }

        card.addView(Ui.label(ctx, "Band (ketuk untuk memilih, atau geser titik di grafik)", 10f, Pal.MUTED).apply {
            setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 8), 0, Ui.dp(ctx, 4))
        })
        card.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(bandRow) })

        bandEnable = CheckBox(ctx).apply {
            text = "Band ini aktif"; textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = ColorStateList.valueOf(0xFF00CFFF.toInt())
            setOnCheckedChangeListener { _, c ->
                if (!quiet) { cur()?.let { setBand(sel, it.copy(enabled = c)); refreshAll(); push(true) } }
            }
        }
        card.addView(bandEnable, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 6) })
        card.addView(Ui.label(ctx, "Tipe filter", 12f, Pal.MUTED).apply { setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 6), 0, Ui.dp(ctx, 4)) })
        card.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(typeRow) })

        sFreq = LabeledSlider(ctx, card, "Frequency", PeqSpec.freqSlider,
            { p -> cur()?.let { setBand(sel, it.copy(freqHz = PeqSpec.posToHz(p))); push(false); refreshGraph() } },
            { push(true) })
        sGain = LabeledSlider(ctx, card, "Gain", PeqSpec.gain,
            { v -> cur()?.let { setBand(sel, it.copy(gainDb = v)); push(false); refreshGraph() } },
            { push(true) })
        sQ = LabeledSlider(ctx, card, "Q factor", PeqSpec.q,
            { v -> cur()?.let { setBand(sel, it.copy(q = v)); push(false); refreshGraph() } },
            { push(true) })

        val actions = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val add = Ui.pill(ctx, "+ TAMBAH BAND").apply { textSize = 12f; setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 11), Ui.dp(ctx, 6), Ui.dp(ctx, 11)) }
        add.setOnClickListener {
            if (s.bands.size < PeqSpec.MAX_BANDS) {
                s = s.copy(bands = s.bands + PeqBand(true, PeqType.PEAK, 1000f, 0f, 1f))
                sel = s.bands.size - 1
                refreshAll(); push(true)
            }
        }
        val del = Ui.pill(ctx, "HAPUS BAND").apply { textSize = 12f; setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 11), Ui.dp(ctx, 6), Ui.dp(ctx, 11)) }
        del.setOnClickListener {
            if (s.bands.isNotEmpty()) {
                s = s.copy(bands = s.bands.filterIndexed { i, _ -> i != sel })
                sel = sel.coerceAtMost(s.bands.size - 1).coerceAtLeast(0)
                refreshAll(); push(true)
            }
        }
        actions.addView(add, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(Ui.dp(ctx, 3), Ui.dp(ctx, 12), Ui.dp(ctx, 3), 0) })
        actions.addView(del, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(Ui.dp(ctx, 3), Ui.dp(ctx, 12), Ui.dp(ctx, 3), 0) })
        card.addView(actions)

        card.addView(Ui.label(ctx,
            "Grafik = respons ideal filter. Engine DynamicsProcessing menerapkannya per pita ≈ 1/6 oktaf (magnitudo saja, tanpa fase), " +
                "jadi Q tinggi (> 5) akan terdengar lebih lebar dari grafik.", 10f, Pal.MUTED).apply {
            setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 10), Ui.dp(ctx, 3), 0); setLineSpacing(0f, 1.1f)
        })
        note.visibility = android.view.View.GONE
        card.addView(note)
        host.addView(card, LinearLayout.LayoutParams(-1, -2))
        refreshAll()
    }

    private fun roundHalf(v: Float): Float = Math.round(v * 2f) / 2f

    private fun cur(): PeqBand? = s.bands.getOrNull(sel)

    private fun setBand(i: Int, b: PeqBand) {
        s = s.copy(bands = s.bands.mapIndexed { idx, old -> if (idx == i) b else old })
    }

    private fun push(done: Boolean) {
        refreshGraph()
        onChange(s, done)
    }

    /** Muat ulang dari pengaturan luar (mis. preset/pulihkan). */
    fun set(newSettings: PeqSettings) {
        s = newSettings
        sel = sel.coerceAtMost(s.bands.size - 1).coerceAtLeast(0)
        refreshAll()
    }

    /** Tampilkan peringatan bila perangkat tidak mendukung. */
    fun setSupport(supported: Boolean, active: Boolean) {
        if (active && !supported) {
            note.text = "Perangkat menolak Post-EQ rapat — Parametric EQ tidak dapat diterapkan (lihat Diagnostik)."
            note.visibility = android.view.View.VISIBLE
        } else note.visibility = android.view.View.GONE
    }

    private fun refreshAll() {
        quiet = true
        enable.isChecked = s.on
        quiet = false
        refreshBandChips()
        refreshTypeChips()
        refreshEditor()
        refreshGraph()
    }

    private fun refreshBandChips() {
        bandRow.removeAllViews()
        s.bands.forEachIndexed { i, b ->
            val chip = Ui.chip(ctx, "${i + 1}  ${PeqSpec.formatHz(b.freqHz)}", i == sel)
            chip.setOnClickListener { sel = i; refreshBandChips(); refreshTypeChips(); refreshEditor(); refreshGraph() }
            if (!b.enabled) chip.alpha = 0.5f
            bandRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Ui.dp(ctx, 5) })
        }
    }

    private fun refreshTypeChips() {
        typeRow.removeAllViews()
        val b = cur()
        for (t in PeqType.values()) {
            val chip = Ui.chip(ctx, t.label, b?.type == t)
            chip.setOnClickListener {
                cur()?.let { old ->
                    setBand(sel, old.copy(type = t))
                    refreshTypeChips(); refreshEditor(); push(true)
                }
            }
            typeRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Ui.dp(ctx, 5) })
        }
    }

    private fun refreshEditor() {
        val b = cur()
        quiet = true
        bandEnable.isChecked = b?.enabled ?: false
        quiet = false
        bandEnable.isEnabled = b != null
        if (b != null) {
            sFreq.set(PeqSpec.hzToPos(b.freqHz))
            sGain.set(b.gainDb)
            sQ.set(b.q)
            sGain.setEnabledLook(b.type.usesGain)
        }
    }

    private fun refreshGraph() {
        val freqs = ResponseGraphView.FREQS
        val curves = ArrayList<ResponseGraphView.Curve>()
        val b = cur()
        if (b != null && b.enabled) {
            curves.add(ResponseGraphView.Curve(0x66FFFFFF, DspMath.bandCurveDb(b, freqs), 1.2f))
        }
        val total = DspMath.peqCurveDb(s.bands, freqs)
        curves.add(ResponseGraphView.Curve(if (s.on) 0xFF45C5FF.toInt() else 0xFF5A6B85.toInt(), total, 2.4f, true))
        graph.setCurves(curves)
        graph.setHandles(s.bands.mapIndexed { i, band ->
            ResponseGraphView.Handle(i, band.freqHz, if (band.type.usesGain) band.gainDb else 0f,
                BAND_COLORS[i % BAND_COLORS.size], i == sel, band.enabled && s.on)
        })
    }
}

/**
 * Crossover 2-Way: low-pass (jalur LOW), high-pass (jalur HIGH), frekuensi, slope 12/24/36/48 dB/okt, gain LOW/HIGH,
 * dan tukar kanal. Ini pembagian perangkat lunak ke kiri/kanan, bukan crossover hardware dengan dua amplifier fisik.
 */
class CrossoverPanel(
    private val ctx: Context,
    host: LinearLayout,
    initial: CrossoverSettings,
    initialSwap: Boolean,
    private val onChange: (CrossoverSettings, Boolean, Boolean) -> Unit
) {
    private var x = initial
    private var swap = initialSwap
    private val graph = ResponseGraphView(ctx)
    private val slopeRow = LinearLayout(ctx)
    private val info = Ui.label(ctx, "", 11f, 0xFF7BE3B0.toInt(), true)
    private val sFreq: LabeledSlider
    private val sLow: LabeledSlider
    private val sHigh: LabeledSlider
    private val lpf: CheckBox
    private val hpf: CheckBox
    private val swapCb: CheckBox
    private var quiet = false

    init {
        val card = Ui.panelCard(ctx, 12)
        card.addView(Ui.label(ctx, "Crossover 2-Way", 16f, 0xFFFFFFFF.toInt(), true))
        card.addView(Ui.label(ctx,
            "Aktif bila mode 2-Way dipilih di header. Kiri membawa LOW (low-pass), kanan membawa HIGH (high-pass). " +
                "Sumber stereo tidak dijumlahkan menjadi mono, dan fase/polaritas tidak dapat diatur lewat DynamicsProcessing.",
            10f, Pal.MUTED).apply { setPadding(0, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 4)); setLineSpacing(0f, 1.1f) })
        info.setPadding(0, Ui.dp(ctx, 2), 0, Ui.dp(ctx, 4))
        card.addView(info)

        graph.dbMin = -48f; graph.dbMax = 12f
        graph.dbLines = floatArrayOf(-36f, -24f, -12f, -6f, 0f, 6f)
        card.addView(graph, LinearLayout.LayoutParams(-1, Ui.dp(ctx, 190)))

        sFreq = LabeledSlider(ctx, card, "Frekuensi crossover",
            Spec(0f, Store.XO_STEPS.toFloat(), 1f, 0, "") { p -> "${Store.crossoverFromProgress(p.toInt())} Hz" },
            { p -> x = x.copy(freqHz = Store.crossoverFromProgress(p.toInt())); push(false) },
            { push(true) })

        card.addView(Ui.label(ctx, "Slope", 12f, Pal.MUTED).apply { setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 12), 0, Ui.dp(ctx, 4)) })
        card.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(slopeRow) })

        lpf = check(card, "Low-pass filter (jalur LOW)") { c -> x = x.copy(lpfOn = c); push(true) }
        hpf = check(card, "High-pass filter (jalur HIGH)") { c -> x = x.copy(hpfOn = c); push(true) }
        sLow = LabeledSlider(ctx, card, "Gain LOW", CrossoverSpec.gain,
            { v -> x = x.copy(lowGainDb = v); push(false) }, { push(true) })
        sHigh = LabeledSlider(ctx, card, "Gain HIGH", CrossoverSpec.gain,
            { v -> x = x.copy(highGainDb = v); push(false) }, { push(true) })
        swapCb = check(card, "Tukar LOW/HIGH (kiri = HIGH, kanan = LOW)") { c -> swap = c; push(true) }

        card.addView(Ui.label(ctx, "Phase / polaritas: tidak tersedia pada engine ini (DynamicsProcessing hanya mengatur magnitudo).",
            10f, 0xFFFFB86B.toInt()).apply { setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 10), Ui.dp(ctx, 3), 0) })
        host.addView(card, LinearLayout.LayoutParams(-1, -2))
        refreshAll()
    }

    private fun check(card: LinearLayout, title: String, onUser: (Boolean) -> Unit): CheckBox {
        val cb = CheckBox(ctx).apply {
            text = title; textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = ColorStateList.valueOf(0xFF00CFFF.toInt())
            setOnCheckedChangeListener { _, c -> if (!quiet) onUser(c) }
        }
        card.addView(cb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 6) })
        return cb
    }

    private fun push(done: Boolean) {
        refreshGraph()
        onChange(x, swap, done)
    }

    fun set(newX: CrossoverSettings, newSwap: Boolean) {
        x = newX
        swap = newSwap
        refreshAll()
    }

    /** Teks status dari layanan (mode, kanal, dukungan slope). */
    fun setInfo(text: String) { info.text = text }

    private fun refreshAll() {
        quiet = true
        sFreq.set(Store.progressFromCrossover(x.freqHz).toFloat())
        sLow.set(x.lowGainDb)
        sHigh.set(x.highGainDb)
        lpf.isChecked = x.lpfOn
        hpf.isChecked = x.hpfOn
        swapCb.isChecked = swap
        quiet = false
        slopeRow.removeAllViews()
        for (sl in CrossoverSpec.SLOPES) {
            val chip = Ui.chip(ctx, "$sl dB/okt", x.slopeDbOct == sl)
            chip.setOnClickListener { x = x.copy(slopeDbOct = sl); refreshAll(); push(true) }
            slopeRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Ui.dp(ctx, 5) })
        }
        refreshGraph()
    }

    private fun refreshGraph() {
        val f = ResponseGraphView.FREQS
        val fc = x.freqHz.toDouble()
        val low = FloatArray(f.size) { i ->
            ((if (x.lpfOn) DspMath.crossoverDb(f[i], fc, x.order, true) else 0.0) + x.lowGainDb).toFloat().coerceAtLeast(-60f)
        }
        val high = FloatArray(f.size) { i ->
            ((if (x.hpfOn) DspMath.crossoverDb(f[i], fc, x.order, false) else 0.0) + x.highGainDb).toFloat().coerceAtLeast(-60f)
        }
        graph.setCurves(listOf(
            ResponseGraphView.Curve(0xFFFF7A59.toInt(), if (swap) high else low, 2.2f),
            ResponseGraphView.Curve(0xFFB07CFF.toInt(), if (swap) low else high, 2.2f)
        ))
        graph.setHandles(emptyList())
    }
}

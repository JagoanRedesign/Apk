package com.dlmsmini.equalizer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.roundToInt

/** Penyimpanan Parametric EQ: saklar (peq_on) dan daftar band sebagai JSON (peq_json). */
object PeqStore {
    const val KEY_ON = "peq_on"
    const val KEY_JSON = "peq_json"

    fun load(ctx: Context): PeqSettings {
        val p = Store.prefs(ctx)
        val bands = bandsFromJson(p.getString(KEY_JSON, null)) ?: PeqSpec.defaultBands()
        return PeqSettings(p.getBoolean(KEY_ON, false), bands)
    }

    fun save(ctx: Context, s: PeqSettings) {
        Store.prefs(ctx).edit()
            .putBoolean(KEY_ON, s.on)
            .putString(KEY_JSON, bandsToArray(s.bands).toString())
            .apply()
    }

    private fun r2(f: Float): Double = (f * 100.0).roundToInt() / 100.0

    fun bandsToArray(bands: List<PeqBand>): JSONArray {
        val a = JSONArray()
        bands.take(PeqSpec.MAX_BANDS).forEach { b ->
            a.put(
                JSONObject()
                    .put("e", b.enabled)
                    .put("t", b.type.name)
                    .put("f", r2(b.freqHz))
                    .put("g", r2(b.gainDb))
                    .put("q", r2(b.q))
            )
        }
        return a
    }

    /** null bila teks bukan JSON daftar band yang valid (pemanggil memakai bawaan). */
    fun bandsFromJson(raw: String?): List<PeqBand>? {
        if (raw.isNullOrBlank()) return null
        return try {
            bandsFromArray(JSONArray(raw))
        } catch (_: Exception) {
            null
        }
    }

    fun bandsFromArray(a: JSONArray): List<PeqBand>? {
        return try {
            val out = ArrayList<PeqBand>()
            for (i in 0 until minOf(a.length(), PeqSpec.MAX_BANDS)) {
                val o = a.getJSONObject(i)
                val type = PeqType.values().firstOrNull { it.name == o.optString("t") } ?: PeqType.PEAK
                out.add(
                    PeqSpec.clampBand(
                        PeqBand(
                            enabled = o.optBoolean("e", true),
                            type = type,
                            freqHz = o.optDouble("f", 1000.0).toFloat(),
                            gainDb = o.optDouble("g", 0.0).toFloat(),
                            q = o.optDouble("q", 1.0).toFloat()
                        )
                    )
                )
            }
            out
        } catch (_: Exception) {
            null
        }
    }

    // ---------- teks untuk export/import preset: "P1;PEAK/1000/3/1.2/1;LOW_SHELF/80/4/0.7/1" ----------

    private fun num(f: Float): String =
        String.format(Locale.US, "%.2f", f).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    fun toText(s: PeqSettings): String {
        val sb = StringBuilder("P").append(if (s.on) "1" else "0")
        s.bands.take(PeqSpec.MAX_BANDS).forEach { b ->
            sb.append(';').append(b.type.name).append('/').append(num(b.freqHz)).append('/')
                .append(num(b.gainDb)).append('/').append(num(b.q)).append('/').append(if (b.enabled) "1" else "0")
        }
        return sb.toString()
    }

    fun fromText(field: String): PeqSettings? {
        val parts = field.substring(1).split(';')
        if (parts.isEmpty()) return null
        val on = when (parts[0].trim()) { "1" -> true; "0" -> false; else -> return null }
        val bands = ArrayList<PeqBand>()
        for (raw in parts.drop(1)) {
            if (raw.isBlank()) continue
            val f = raw.split('/')
            if (f.size != 5) return null
            val type = PeqType.values().firstOrNull { it.name == f[0].trim() } ?: return null
            val freq = f[1].trim().toFloatOrNull() ?: return null
            val gain = f[2].trim().toFloatOrNull() ?: return null
            val q = f[3].trim().toFloatOrNull() ?: return null
            val en = when (f[4].trim()) { "1" -> true; "0" -> false; else -> return null }
            if (freq < PeqSpec.MIN_HZ || freq > PeqSpec.MAX_HZ) return null
            if (gain < PeqSpec.gain.min || gain > PeqSpec.gain.max) return null
            if (q < PeqSpec.q.min || q > PeqSpec.q.max) return null
            bands.add(PeqBand(en, type, freq, gain, q))
            if (bands.size > PeqSpec.MAX_BANDS) return null
        }
        return PeqSettings(on, bands)
    }
}

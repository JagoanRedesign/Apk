package com.dlmsmini.equalizer

import android.app.Application
import android.app.NotificationManager
import android.content.res.Configuration

/** Application: menyiapkan tema sedini mungkin (sebelum Activity pertama dibuat). */
class DlmsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Pal.init(this)
        // Notifikasi push (FCM) sudah dihapus: bersihkan saluran notifikasi lamanya dari versi sebelumnya.
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).deleteNotificationChannel("dlms_push")
        } catch (_: Exception) {
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Mode gelap sistem / palet dinamis berubah: warna hasil terjemahan harus dihitung ulang.
        Pal.clearCache()
    }
}

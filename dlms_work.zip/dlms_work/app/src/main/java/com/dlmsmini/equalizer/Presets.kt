package com.dlmsmini.equalizer

/** Preset bawaan: kurva EQ (10 band), limiter, dan semua efek. */
class BuiltInPreset(
    val name: String,
    val values: IntArray,
    val limiter: LimiterSettings,
    val effects: EffectSettings
)

object BuiltInPresets {
    private val limiterOn = LimiterSettings(true, 1f, 60f, 10f, -2f, 0f)
    private val limiterOff = LimiterSettings()

    val all: List<BuiltInPreset> = listOf(
        // Flat = kembali ke dasar: EQ rata, limiter mati, semua efek mati.
        BuiltInPreset("Flat", intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0), limiterOff, EffectSettings()),
        BuiltInPreset(
            "Pop", intArrayOf(4, 2, 0, -2, -2, 2, 4, 4, 2, 2), limiterOff,
            EffectSettings(virtOn = true, virtPct = 30, loudOn = true, loudDb = 2f)
        ),
        BuiltInPreset(
            "Rock", intArrayOf(6, 4, 2, 0, -2, 2, 4, 6, 6, 6), limiterOn,
            EffectSettings(
                virtOn = true, virtPct = 40,
                mbcOn = true, mbcThresholdDb = -20f, mbcRatio = 2.5f, mbcAttackMs = 10f, mbcReleaseMs = 150f, mbcMakeupDb = 2f
            )
        ),
        BuiltInPreset(
            "Jazz", intArrayOf(4, 2, 0, 2, -2, -2, 0, 2, 4, 4), limiterOff,
            EffectSettings(reverbPreset = 2, toneOn = true, toneMidDb = 1f)
        ),
        BuiltInPreset(
            "Bass Boost", intArrayOf(10, 8, 6, 4, 2, 0, 0, 0, 0, 0), limiterOn,
            EffectSettings(preampDb = -2f, bassOn = true, bassPct = 60)
        ),
        BuiltInPreset(
            "Vocal", intArrayOf(-4, -2, 0, 2, 6, 8, 6, 4, 0, -2), limiterOff,
            EffectSettings(
                toneOn = true, toneMidDb = 2f,
                mbcOn = true, mbcThresholdDb = -24f, mbcRatio = 2f, mbcAttackMs = 15f, mbcReleaseMs = 200f, mbcMakeupDb = 1f
            )
        ),
        BuiltInPreset(
            "Dangdut", intArrayOf(4, 8, 6, 2, -4, 4, 8, 6, 4, 0), limiterOn,
            EffectSettings(bassOn = true, bassPct = 40, loudOn = true, loudDb = 3f)
        ),
        // Nilai hingga 44 (= +22 dB) membutuhkan mode Kekuatan Penuh; di mode normal dipotong ke ±12 dB.
        BuiltInPreset(
            "Horeg Clarity", intArrayOf(44, 44, 36, 20, -8, 24, 32, 28, 20, 12), limiterOn,
            EffectSettings(
                preampDb = -3f,
                bassOn = true, bassPct = 70,
                loudOn = true, loudDb = 4f,
                mbcOn = true, mbcThresholdDb = -18f, mbcRatio = 4f, mbcAttackMs = 5f, mbcReleaseMs = 120f, mbcMakeupDb = 3f
            )
        )
    )

    val names: List<String> get() = all.map { it.name }

    fun find(name: String): BuiltInPreset? = all.firstOrNull { it.name == name }
}

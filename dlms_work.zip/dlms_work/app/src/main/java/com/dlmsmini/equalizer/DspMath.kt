package com.dlmsmini.equalizer

import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// ===================================================================================================
// Parametric EQ 2.0 — model
// ===================================================================================================

enum class PeqType(val label: String, val usesGain: Boolean) {
    PEAK("Peak", true),
    LOW_SHELF("Low shelf", true),
    HIGH_SHELF("High shelf", true),
    LOW_PASS("Low-pass", false),
    HIGH_PASS("High-pass", false),
    NOTCH("Notch", false),
    BAND_PASS("Band-pass", false)
}

data class PeqBand(
    val enabled: Boolean = true,
    val type: PeqType = PeqType.PEAK,
    val freqHz: Float = 1000f,
    val gainDb: Float = 0f,
    val q: Float = 1f
) {
    /** True bila band ini benar-benar mengubah respons (band tanpa gain dan tipe berbasis gain = datar). */
    val isActive: Boolean
        get() {
            if (!enabled) return false
            return if (type.usesGain) abs(gainDb) > 0.01f else true
        }
}

data class PeqSettings(
    val on: Boolean = false,
    val bands: List<PeqBand> = PeqSpec.defaultBands()
) {
    val active: Boolean get() = on && bands.any { it.isActive }
}

object PeqSpec {
    const val MIN_HZ = 20f
    const val MAX_HZ = 20000f
    const val MAX_BANDS = 10
    const val FREQ_STEPS = 300

    val gain = Spec(-18f, 18f, 0.5f, 1, " dB")
    val q = Spec(0.3f, 8f, 0.1f, 1, "")

    fun hzToPos(hz: Float): Float {
        val v = hz.coerceIn(MIN_HZ, MAX_HZ).toDouble()
        return (ln(v / MIN_HZ) / ln((MAX_HZ / MIN_HZ).toDouble()) * FREQ_STEPS).toFloat()
    }

    fun posToHz(pos: Float): Float {
        val p = pos.coerceIn(0f, FREQ_STEPS.toFloat()).toDouble()
        return (MIN_HZ * (MAX_HZ / MIN_HZ).toDouble().pow(p / FREQ_STEPS)).toFloat().coerceIn(MIN_HZ, MAX_HZ)
    }

    /** Slider frekuensi memakai posisi logaritmik 0..FREQ_STEPS; teks diformat sebagai Hz/kHz. */
    val freqSlider = Spec(0f, FREQ_STEPS.toFloat(), 1f, 0, "") { p -> formatHz(posToHz(p)) }

    fun formatHz(hz: Float): String = when {
        hz >= 10000f -> String.format(Locale.US, "%.1f kHz", hz / 1000f)
        hz >= 1000f -> String.format(Locale.US, "%.2f kHz", hz / 1000f)
        hz >= 100f -> String.format(Locale.US, "%.0f Hz", hz)
        else -> String.format(Locale.US, "%.1f Hz", hz)
    }

    fun defaultBands(): List<PeqBand> = listOf(
        PeqBand(true, PeqType.LOW_SHELF, 80f, 0f, 0.7f),
        PeqBand(true, PeqType.PEAK, 250f, 0f, 1.0f),
        PeqBand(true, PeqType.PEAK, 1000f, 0f, 1.0f),
        PeqBand(true, PeqType.PEAK, 3500f, 0f, 1.0f),
        PeqBand(true, PeqType.HIGH_SHELF, 10000f, 0f, 0.7f)
    )

    fun clampBand(b: PeqBand): PeqBand = b.copy(
        freqHz = b.freqHz.coerceIn(MIN_HZ, MAX_HZ),
        gainDb = gain.clamp(b.gainDb),
        q = q.clamp(b.q)
    )
}

// ===================================================================================================
// Crossover 2-Way — model
// ===================================================================================================

data class CrossoverSettings(
    val freqHz: Int = Store.DEFAULT_CROSSOVER,
    /** Kemiringan (dB per oktaf): 12, 24, 36, atau 48. */
    val slopeDbOct: Int = 24,
    val lowGainDb: Float = 0f,
    val highGainDb: Float = 0f,
    /** Low-pass pada jalur LOW. */
    val lpfOn: Boolean = true,
    /** High-pass pada jalur HIGH. */
    val hpfOn: Boolean = true
) {
    val order: Int get() = (slopeDbOct / 6).coerceIn(2, 8)
}

object CrossoverSpec {
    val SLOPES = intArrayOf(12, 24, 36, 48)
    val gain = Spec(-12f, 12f, 0.5f, 1, " dB")
}

// ===================================================================================================
// Matematika filter (murni, tanpa Android — dapat diuji di JVM)
// ===================================================================================================

object DspMath {
    const val FS = 48000.0

    class Biquad(val b0: Double, val b1: Double, val b2: Double, val a1: Double, val a2: Double)

    /** Koefisien biquad RBJ (Audio EQ Cookbook). Gain hanya dipakai tipe PEAK/SHELF. */
    fun biquad(type: PeqType, f0: Double, gainDb: Double, q: Double): Biquad {
        val f = f0.coerceIn(10.0, FS * 0.49)
        val qq = q.coerceIn(0.1, 20.0)
        val w0 = 2.0 * PI * f / FS
        val cw = cos(w0)
        val alpha = sin(w0) / (2.0 * qq)
        val a = 10.0.pow(gainDb / 40.0)
        // Urutan: b0, b1, b2, a0, a1, a2
        val c: DoubleArray = when (type) {
            PeqType.PEAK -> doubleArrayOf(
                1.0 + alpha * a, -2.0 * cw, 1.0 - alpha * a,
                1.0 + alpha / a, -2.0 * cw, 1.0 - alpha / a
            )
            PeqType.LOW_SHELF -> {
                val s = 2.0 * sqrt(a) * alpha
                doubleArrayOf(
                    a * ((a + 1.0) - (a - 1.0) * cw + s),
                    2.0 * a * ((a - 1.0) - (a + 1.0) * cw),
                    a * ((a + 1.0) - (a - 1.0) * cw - s),
                    (a + 1.0) + (a - 1.0) * cw + s,
                    -2.0 * ((a - 1.0) + (a + 1.0) * cw),
                    (a + 1.0) + (a - 1.0) * cw - s
                )
            }
            PeqType.HIGH_SHELF -> {
                val s = 2.0 * sqrt(a) * alpha
                doubleArrayOf(
                    a * ((a + 1.0) + (a - 1.0) * cw + s),
                    -2.0 * a * ((a - 1.0) + (a + 1.0) * cw),
                    a * ((a + 1.0) + (a - 1.0) * cw - s),
                    (a + 1.0) - (a - 1.0) * cw + s,
                    2.0 * ((a - 1.0) - (a + 1.0) * cw),
                    (a + 1.0) - (a - 1.0) * cw - s
                )
            }
            PeqType.LOW_PASS -> doubleArrayOf(
                (1.0 - cw) / 2.0, 1.0 - cw, (1.0 - cw) / 2.0,
                1.0 + alpha, -2.0 * cw, 1.0 - alpha
            )
            PeqType.HIGH_PASS -> doubleArrayOf(
                (1.0 + cw) / 2.0, -(1.0 + cw), (1.0 + cw) / 2.0,
                1.0 + alpha, -2.0 * cw, 1.0 - alpha
            )
            PeqType.NOTCH -> doubleArrayOf(
                1.0, -2.0 * cw, 1.0,
                1.0 + alpha, -2.0 * cw, 1.0 - alpha
            )
            PeqType.BAND_PASS -> doubleArrayOf(
                alpha, 0.0, -alpha,
                1.0 + alpha, -2.0 * cw, 1.0 - alpha
            )
        }
        val a0 = c[3]
        return Biquad(c[0] / a0, c[1] / a0, c[2] / a0, c[4] / a0, c[5] / a0)
    }

    fun magnitudeDb(bq: Biquad, f: Double): Double {
        val w = 2.0 * PI * f / FS
        val c1 = cos(w)
        val s1 = sin(w)
        val c2 = cos(2.0 * w)
        val s2 = sin(2.0 * w)
        val nr = bq.b0 + bq.b1 * c1 + bq.b2 * c2
        val ni = -(bq.b1 * s1 + bq.b2 * s2)
        val dr = 1.0 + bq.a1 * c1 + bq.a2 * c2
        val di = -(bq.a1 * s1 + bq.a2 * s2)
        val num = nr * nr + ni * ni
        val den = dr * dr + di * di
        return 10.0 * log10(max(num, 1e-30) / max(den, 1e-30))
    }

    private fun bandBiquad(b: PeqBand): Biquad =
        biquad(b.type, b.freqHz.toDouble(), if (b.type.usesGain) b.gainDb.toDouble() else 0.0, b.q.toDouble())

    /** Respons gabungan (dB) semua band aktif pada frekuensi [freqs]. */
    fun peqCurveDb(bands: List<PeqBand>, freqs: DoubleArray): FloatArray {
        val filters = bands.filter { it.isActive }.map { bandBiquad(it) }
        return FloatArray(freqs.size) { i ->
            var s = 0.0
            for (bq in filters) s += magnitudeDb(bq, freqs[i])
            s.toFloat()
        }
    }

    /** Respons satu band saja (untuk menggambar kurva band terpilih). */
    fun bandCurveDb(band: PeqBand, freqs: DoubleArray): FloatArray {
        val bq = bandBiquad(band)
        return FloatArray(freqs.size) { magnitudeDb(bq, freqs[it]).toFloat() }
    }

    /**
     * Respons crossover Linkwitz-Riley orde N (N = 2, 4, 6, 8 → 12/24/36/48 dB per oktaf; -6 dB pada titik pisah).
     * LR_N = Butterworth_(N/2) dikuadratkan, sehingga |LP| = 1/(1+x) dan |HP| = x/(1+x) dengan x = (f/fc)^N.
     * Jumlah magnitudo LOW + HIGH selalu 1 (datar).
     */
    fun crossoverDb(f: Double, fc: Double, order: Int, low: Boolean): Double {
        val x = (f / fc).pow(order.toDouble())
        val mag = if (low) 1.0 / (1.0 + x) else x / (1.0 + x)
        return 20.0 * log10(max(mag, 1e-9))
    }

    /** Post-EQ "tone" 3 band: <250 Hz, 250-4000 Hz, >4000 Hz (sama dengan implementasi 3 band lama). */
    fun toneDb(f: Double, lowDb: Float, midDb: Float, highDb: Float): Double =
        if (f < 250.0) lowDb.toDouble() else if (f < 4000.0) midDb.toDouble() else highDb.toDouble()

    fun logSpace(n: Int, fMin: Double = 20.0, fMax: Double = 20000.0): DoubleArray =
        DoubleArray(n) { i -> fMin * (fMax / fMin).pow(i.toDouble() / (n - 1)) }
}

// ===================================================================================================
// Grid pita untuk stage Post-EQ DynamicsProcessing
// ===================================================================================================

/**
 * Susunan pita rapat (geometris 20 Hz - 22 kHz) untuk stage Post-EQ. Tiap pita DynamicsProcessing dibatasi oleh
 * frekuensi potong atas ([edgeHz]); gainnya dihitung dari rata-rata respons target di dalam pita.
 * Resolusi 64 pita ≈ 1/6,3 oktaf: cukup untuk crossover, tone, dan parametric EQ dengan Q sedang.
 */
class FilterGrid(val count: Int) {
    val edgeHz = FloatArray(count)
    private val loHz = DoubleArray(count)
    private val hiHz = DoubleArray(count)

    init {
        val ratio = 22000.0 / 20.0
        for (i in 0 until count) {
            val hi = if (i == count - 1) 22000.0 else 20.0 * ratio.pow((i + 1).toDouble() / count)
            val lo = if (i == 0) 15.0 else hiHz[i - 1]
            hiHz[i] = hi
            loHz[i] = lo
            edgeHz[i] = hi.toFloat()
        }
    }

    /** Tiga titik uji (geometris) di dalam pita ke-[i]. */
    fun samples(i: Int): DoubleArray {
        val lo = loHz[i]
        val r = hiHz[i] / lo
        return doubleArrayOf(lo * r.pow(1.0 / 6.0), lo * r.pow(3.0 / 6.0), lo * r.pow(5.0 / 6.0))
    }

    fun centerHz(i: Int): Double = sqrt(loHz[i] * hiHz[i])
}

class ResponseTargets(val left: FloatArray, val right: FloatArray, val peakBoostDb: Float)

object FilterSynth {
    const val CAP_DB = 24f

    /**
     * Gabungkan Post-EQ tone + Parametric EQ + crossover menjadi gain per pita untuk kanal kiri dan kanan.
     * [xo] != null → kanal LOW (kiri, atau kanan bila [swap]) mendapat low-pass, kanal HIGH mendapat high-pass.
     */
    fun build(
        grid: FilterGrid, fx: EffectSettings, peq: PeqSettings,
        xo: CrossoverSettings?, swap: Boolean, floorDb: Float
    ): ResponseTargets {
        val n = grid.count
        val left = FloatArray(n)
        val right = FloatArray(n)
        val filters = if (peq.active) peq.bands.filter { it.isActive } else emptyList()
        val biquads = filters.map { b ->
            DspMath.biquad(b.type, b.freqHz.toDouble(), if (b.type.usesGain) b.gainDb.toDouble() else 0.0, b.q.toDouble())
        }
        var peak = 0f
        for (i in 0 until n) {
            val pts = grid.samples(i)
            var common = 0.0
            var lowSum = 0.0
            var highSum = 0.0
            for (f in pts) {
                var c = 0.0
                if (fx.toneOn) c += DspMath.toneDb(f, fx.toneLowDb, fx.toneMidDb, fx.toneHighDb)
                for (bq in biquads) c += DspMath.magnitudeDb(bq, f)
                common += c
                if (xo != null) {
                    val fc = xo.freqHz.toDouble()
                    lowSum += (if (xo.lpfOn) DspMath.crossoverDb(f, fc, xo.order, true) else 0.0) + xo.lowGainDb
                    highSum += (if (xo.hpfOn) DspMath.crossoverDb(f, fc, xo.order, false) else 0.0) + xo.highGainDb
                }
            }
            val k = pts.size.toDouble()
            val base = common / k
            if (xo == null) {
                val v = clampGain(base, floorDb)
                left[i] = v
                right[i] = v
            } else {
                val low = clampGain(base + lowSum / k, floorDb)
                val high = clampGain(base + highSum / k, floorDb)
                left[i] = if (swap) high else low
                right[i] = if (swap) low else high
            }
            peak = max(peak, max(left[i], right[i]))
        }
        return ResponseTargets(left, right, peak)
    }

    private fun clampGain(v: Double, floorDb: Float): Float = v.toFloat().coerceIn(floorDb, CAP_DB)
}

// ===================================================================================================
// Meter level & perkiraan gain reduction limiter
// ===================================================================================================

object Meter {
    const val FLOOR_DB = -90f

    class Reading(val peakDb: Float, val rmsDb: Float, val clipped: Boolean)

    fun db(x: Float): Float = if (x <= 3e-5f) FLOOR_DB else 20f * log10(x)

    /** Level dari gelombang 8-bit tak bertanda Visualizer (128 = senyap). */
    fun readWave8(data: ByteArray): Reading {
        if (data.isEmpty()) return Reading(FLOOR_DB, FLOOR_DB, false)
        var peak = 0f
        var sum = 0.0
        var hits = 0
        for (b in data) {
            val v = ((b.toInt() and 0xFF) - 128) / 128f
            val a = abs(v)
            if (a > peak) peak = a
            if (a >= 0.985f) hits++
            sum += (v * v).toDouble()
        }
        val rms = sqrt(sum / data.size).toFloat()
        return Reading(db(peak), db(rms), hits >= 2)
    }

    /**
     * Perkiraan (masukan, gain reduction) limiter dari puncak KELUARAN terukur (dBFS, setelah limiter + post-gain).
     * Memakai kurva statis limiter: di atas threshold T, keluaran = T + (masukan - T) / ratio. Dibalik:
     * masukan = T + (keluaran - T) * ratio. Ini ESTIMASI — DynamicsProcessing tidak menyediakan pembacaan
     * gain reduction, dan Android tidak membuka sinyal sebelum efek untuk sesi global.
     */
    fun limiterEstimate(outPeakDb: Float, lim: LimiterSettings): Pair<Float, Float> {
        val pre = outPeakDb - lim.postGainDb
        if (pre <= lim.thresholdDb) return Pair(pre, 0f)
        val input = min(lim.thresholdDb + (pre - lim.thresholdDb) * lim.ratio, 24f)
        val gr = (input - pre).coerceIn(0f, 24f)
        return Pair(input, gr)
    }
}

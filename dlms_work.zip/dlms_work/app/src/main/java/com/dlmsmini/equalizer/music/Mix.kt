package com.dlmsmini.equalizer.music

import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.session.MediaController
import com.dlmsmini.equalizer.DiagLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException

/**
 * Mix lagu: daftar putar otomatis dari lagu yang sedang diputar, disusun dari rekomendasi terkait YouTube
 * dan lagu lain dari artis yang sama, diselang-seling supaya tidak monoton. Semuanya lewat NewPipeExtractor (lokal).
 */
object MixBuilder {
    private val idRe = Regex("[?&]v=([\\w-]{11})")

    private fun toTrack(item: InfoItem): Track? {
        if (item !is StreamInfoItem) return null
        val id = idRe.find(item.url)?.groupValues?.get(1) ?: return null
        val dur = item.duration
        if (dur < 60L || dur > 1200L) return null // buang Shorts dan video panjang
        val score = OfficialRank.score(item.name, item.uploaderName ?: "", item.isUploaderVerified, false, "")
        return Track(
            id = id,
            title = TitleClean.title(item.name).ifBlank { item.name },
            artist = TitleClean.artist(item.uploaderName ?: ""),
            durationSec = dur.toInt(),
            thumb = item.thumbnails.maxByOrNull { it.height }?.url ?: "",
            official = OfficialRank.isOfficial(score)
        )
    }

    /** Blocking: panggil dari thread latar. [exclude] = ID lagu yang tidak boleh muncul (mis. yang sudah di antrean). */
    fun build(seed: Track, exclude: Set<String>, limit: Int = 30): List<Track> {
        val service = NewPipeBridge.service()
        val related = ArrayList<Track>()
        if (seed.isStream && !seed.id.contains(':')) {
            try {
                val info = StreamInfo.getInfo(service, "https://www.youtube.com/watch?v=${seed.id}")
                info.relatedItems.forEach { toTrack(it)?.let(related::add) }
            } catch (e: Exception) {
                DiagLog.log("Mix: lagu terkait gagal: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        val sameArtist = ArrayList<Track>()
        val artist = TitleClean.artist(seed.artist)
        if (artist.isNotBlank()) {
            try {
                val qh = service.searchQHFactory.fromQuery(artist, listOf("music_songs"), "")
                SearchInfo.getInfo(service, qh).relatedItems.forEach { toTrack(it)?.let(sameArtist::add) }
            } catch (e: Exception) {
                DiagLog.log("Mix: lagu artis gagal: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
        // Selang-seling: rekomendasi terkait, lagu artis, dan seterusnya. Judul yang sama (unggahan ganda) dibuang.
        val out = ArrayList<Track>()
        val ids = HashSet<String>(exclude).apply { add(seed.id) }
        val titles = HashSet<String>().apply { add(seed.title.lowercase()) }
        var i = 0
        while (out.size < limit && (i < related.size || i < sameArtist.size)) {
            for (src in listOf(related, sameArtist)) {
                val t = src.getOrNull(i) ?: continue
                if (out.size >= limit) break
                if (t.id in ids || !titles.add(t.title.lowercase())) continue
                ids.add(t.id)
                out.add(t)
            }
            i++
        }
        if (out.isEmpty()) throw IOException("Tidak ada lagu untuk mix")
        return out
    }
}

object MixUi {
    /** Dialog Mix untuk lagu yang sedang diputar: ganti antrean berikutnya atau tambahkan di akhir. */
    fun start(act: AppCompatActivity, scope: CoroutineScope, c: MediaController, onDone: () -> Unit = {}) {
        val item = c.currentMediaItem
        if (item == null) {
            Toast.makeText(act, "Putar lagu dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val seed = item.toTrack()
        AlertDialog.Builder(act)
            .setTitle("Mix dari “${seed.title}”")
            .setMessage("Lagu serupa dari rekomendasi YouTube dan artis yang sama, diacak selang-seling.")
            .setPositiveButton("Ganti antrean berikutnya") { _, _ -> run(act, scope, c, seed, true, onDone) }
            .setNeutralButton("Tambah ke antrean") { _, _ -> run(act, scope, c, seed, false, onDone) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun run(act: AppCompatActivity, scope: CoroutineScope, c: MediaController, seed: Track, replace: Boolean, onDone: () -> Unit) {
        Toast.makeText(act, "Membuat mix…", Toast.LENGTH_SHORT).show()
        scope.launch {
            // Saat mengganti, lagu di antrean berikutnya boleh muncul lagi; saat menambah, jangan duplikat.
            val exclude = HashSet<String>()
            if (!replace) for (i in 0 until c.mediaItemCount) exclude.add(c.getMediaItemAt(i).mediaId)
            val r = withContext(Dispatchers.IO) { runCatching { MixBuilder.build(seed, exclude) } }
            val mix = r.getOrNull()
            if (mix == null) {
                Toast.makeText(act, "Gagal membuat mix: ${r.exceptionOrNull()?.message ?: "periksa koneksi"}", Toast.LENGTH_LONG).show()
                return@launch
            }
            if (c.currentMediaItem?.mediaId != seed.id) {
                Toast.makeText(act, "Lagu sudah berganti, mix dibatalkan", Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (replace) {
                val from = c.currentMediaItemIndex + 1
                if (from < c.mediaItemCount) c.removeMediaItems(from, c.mediaItemCount)
            }
            c.addMediaItems(mix.map { it.toMediaItem() })
            Toast.makeText(act, "${mix.size} lagu masuk antrean", Toast.LENGTH_SHORT).show()
            onDone()
        }
    }
}

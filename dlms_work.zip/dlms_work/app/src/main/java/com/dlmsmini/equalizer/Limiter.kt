package com.dlmsmini.equalizer

import java.util.Locale
import kotlin.math.roundToInt

/** Parameter limiter (satuan nyata: ms, rasio, dB). */
data class LimiterSettings(
    val enabled: Boolean = false,
    val attackMs: Float = 1f,
    val releaseMs: Float = 60f,
    val ratio: Float = 10f,
    val thresholdDb: Float = -2f,
    val postGainDb: Float = 0f
)

/** Rentang & format tampilan untuk satu slider. */
class Spec(val min: Float, val max: Float, val step: Float, private val decimals: Int, private val unit: String) {
    val steps: Int = ((max - min) / step).roundToInt()
    fun toValue(progress: Int): Float = (min + progress * step).coerceIn(min, max)
    fun toProgress(v: Float): Int = ((v - min) / step).roundToInt().coerceIn(0, steps)
    fun format(v: Float): String {
        val sign = if (min < 0f && v > 0f) "+" else ""
        return sign + String.format(Locale.US, "%.${decimals}f", v) + unit
    }
}

object LimiterSpec {
    val attack = Spec(0.5f, 100f, 0.5f, 1, " ms")
    val release = Spec(5f, 1000f, 5f, 0, " ms")
    val ratio = Spec(1f, 20f, 0.5f, 1, ":1")
    val threshold = Spec(-60f, 0f, 0.5f, 1, " dB")
    val postGain = Spec(-12f, 12f, 0.5f, 1, " dB")
}

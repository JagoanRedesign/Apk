package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Kelola aplikasi pemutar yang terdeteksi oleh Mode Sesi Aplikasi. */
class AppsActivity : AppCompatActivity() {
    private val bg = 0xFF1B1B1D.toInt()
    private val cardBg = 0xFF343437.toInt()
    private val titleColor = 0xFFE6E1E9.toInt()
    private val descColor = 0xFFCAC4D0.toInt()
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        })
        bar.addView(Ui.label(this, "Aplikasi terdeteksi", 26f, titleColor))
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        pkg
    }

    private fun render() {
        list.removeAllViews()
        list.addView(Ui.label(this,
            "Aplikasi muncul di sini setelah memutar musik saat Mode Sesi Aplikasi aktif. " +
                "Matikan saklar untuk mengecualikan aplikasi dari equalizer.",
            14f, descColor).apply { setPadding(dp(8), dp(4), dp(8), dp(12)); setLineSpacing(0f, 1.1f) })

        val apps = AppStore.detected(this).sortedBy { appLabel(it).lowercase() }
        if (apps.isEmpty()) {
            list.addView(Ui.label(this,
                "Belum ada aplikasi terdeteksi.\n\nTips:\n• Aktifkan Mode Sesi Aplikasi di Pengaturan\n" +
                    "• Buka DLMS Mini Equalizer sebelum membuka aplikasi musik\n" +
                    "• Tekan putar/jeda di aplikasi musik untuk memicu deteksi",
                15f, descColor).apply {
                background = Ui.rounded(this@AppsActivity, cardBg, 18)
                setPadding(dp(22), dp(18), dp(22), dp(18))
                setLineSpacing(0f, 1.15f)
            })
            return
        }

        val active = EqualizerService.activePackages
        apps.forEach { pkg ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Ui.rounded(this@AppsActivity, cardBg, 18)
                setPadding(dp(18), dp(14), dp(18), dp(14))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
            }
            val icon = ImageView(this).apply {
                try { setImageDrawable(packageManager.getApplicationIcon(pkg)) }
                catch (_: Exception) { setImageResource(android.R.drawable.sym_def_app_icon) }
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(14) })
            val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            text.addView(Ui.label(this, appLabel(pkg), 17f, titleColor, true))
            text.addView(Ui.label(this, pkg, 12f, descColor))
            if (pkg in active) text.addView(Ui.label(this, "● sedang diproses", 12f, Pal.CYAN, true))
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
            val sw = Switch(this).apply {
                isChecked = AppStore.isEnabled(this@AppsActivity, pkg)
                setOnCheckedChangeListener { _, on -> AppStore.setEnabled(this@AppsActivity, pkg, on) }
            }
            row.addView(sw)
            row.setOnClickListener { sw.toggle() }
            list.addView(row)
        }

        val clear = Ui.pill(this, "HAPUS DAFTAR").apply { textSize = 12f }
        clear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Hapus daftar")
                .setMessage("Daftar aplikasi terdeteksi dan pengecualiannya akan dihapus. Aplikasi akan terdeteksi lagi saat memutar musik.")
                .setPositiveButton("Hapus") { _, _ -> AppStore.clear(this); render() }
                .setNegativeButton("Batal", null)
                .show()
        }
        list.addView(clear, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
    }
}

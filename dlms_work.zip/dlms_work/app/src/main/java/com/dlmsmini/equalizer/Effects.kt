package com.dlmsmini.equalizer

import kotlin.math.log10

/** Semua efek tambahan di luar EQ dan limiter. */
data class EffectSettings(
    // Pre-amp, balance, mute per kanal
    val preampDb: Float = 0f,
    val balance: Int = 0,               // -100 (kiri penuh) .. 100 (kanan penuh)
    val muteLeft: Boolean = false,
    val muteRight: Boolean = false,
    val volumeLeft: Int = 100,
    val volumeRight: Int = 100,
    // Efek sistem
    val bassOn: Boolean = false,
    val bassPct: Int = 50,
    val virtOn: Boolean = false,
    val virtPct: Int = 50,
    val loudOn: Boolean = false,
    val loudDb: Float = 4f,
    val reverbPreset: Int = 0,          // 0 = mati
    // Kompresor multiband (3 band: <250 Hz, 250-3000 Hz, >3000 Hz)
    val mbcOn: Boolean = false,
    val mbcThresholdDb: Float = -24f,
    val mbcRatio: Float = 3f,
    val mbcAttackMs: Float = 10f,
    val mbcReleaseMs: Float = 150f,
    val mbcMakeupDb: Float = 2f,
    // Post-EQ (tone 3 band: <250 Hz, 250-4000 Hz, >4000 Hz)
    val toneOn: Boolean = false,
    val toneLowDb: Float = 0f,
    val toneMidDb: Float = 0f,
    val toneHighDb: Float = 0f
) {
    private fun attenuationDb(percent: Int): Float {
        val f = 1f - percent / 100f
        return if (f <= 0.001f) -80f else (20.0 * log10(f.toDouble())).toFloat()
    }

    /** Gain masukan (dB) untuk kanal kiri dan kanan: pre-amp + balance + mute. */
    fun channelGainsDb(): Pair<Float, Float> {
        val left = if (muteLeft || volumeLeft <= 0) -80f else preampDb + attenuationDb(100 - volumeLeft) + (if (balance > 0) attenuationDb(balance) else 0f)
        val right = if (muteRight || volumeRight <= 0) -80f else preampDb + attenuationDb(100 - volumeRight) + (if (balance < 0) attenuationDb(-balance) else 0f)
        return Pair(left, right)
    }

    /** True bila ada efek yang harus diproses oleh DynamicsProcessing. */
    val needsDsp: Boolean
        get() = preampDb != 0f || balance != 0 || muteLeft || muteRight || volumeLeft != 100 || volumeRight != 100 || mbcOn || toneOn
}

object FxSpec {
    val preamp = Spec(-12f, 12f, 0.5f, 1, " dB")
    val balance = Spec(-100f, 100f, 5f, 0, "") { v ->
        when {
            v < 0f -> "L ${(-v).toInt()}"
            v > 0f -> "R ${v.toInt()}"
            else -> "Tengah"
        }
    }
    val strength = Spec(0f, 100f, 5f, 0, " %")
    val loud = Spec(0f, 12f, 0.5f, 1, " dB")
    val mbcThreshold = Spec(-60f, 0f, 1f, 0, " dB")
    val mbcRatio = Spec(1f, 10f, 0.5f, 1, ":1")
    val mbcAttack = Spec(1f, 100f, 1f, 0, " ms")
    val mbcRelease = Spec(10f, 1000f, 10f, 0, " ms")
    val mbcMakeup = Spec(0f, 12f, 0.5f, 1, " dB")
    val tone = Spec(-12f, 12f, 0.5f, 1, " dB")

    val REVERB_NAMES = listOf("Mati", "Small Room", "Medium Room", "Large Room", "Medium Hall", "Large Hall", "Plate")
}

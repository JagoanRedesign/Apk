package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Kurva transfer Dynamic Limiter / Comp: sumbu X = level masuk (dB), sumbu Y = level keluar (dB).
 * Titik kuning = threshold (geser kiri/kanan), titik hijau = ratio (geser naik/turun).
 */
class LimiterCurveView(context: Context) : View(context) {

    var thresholdDb = -2f
        private set
    var ratio = 10f
        private set

    /** (thresholdDb, ratio, selesai) — dipanggil saat titik digeser. */
    var onChange: ((Float, Float, Boolean) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    private val cCyan = Pal.c(0xFF00E5FF)
    private val cGreen = Pal.c(0xFF2EE59D)
    private val cYellow = Pal.c(0xFFFFC94D)
    private val cBg = Pal.c(0xFF0B1120)
    private val cGrid = Pal.c(0xFF1B2640)
    private val cText = Pal.c(0xFFC9D6EE)

    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cBg; style = Paint.Style.FILL }
    private val gridP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cGrid; strokeWidth = d(1f) }
    private val axisTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = cText; textSize = d(12f); typeface = Typeface.DEFAULT
    }
    private val curveP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = cCyan; style = Paint.Style.STROKE; strokeWidth = d(3.5f)
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dashP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = d(1.6f)
        pathEffect = DashPathEffect(floatArrayOf(d(5f), d(4f)), 0f)
    }
    private val curveThin = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF00E5FF); style = Paint.Style.STROKE; strokeWidth = d(1.4f) }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d(2f) }
    private val tagFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = cBg; style = Paint.Style.FILL }
    private val tagStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d(2f) }
    private val tagTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = d(13f); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val path = Path()
    private val fillPath = Path()
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()

    private val padL get() = d(54f)
    private val padR get() = d(14f)
    private val padT get() = d(38f)
    private val padB get() = d(32f)
    private val pw get() = width - padL - padR
    private val ph get() = height - padT - padB

    private fun xOf(inDb: Float) = padL + (inDb - MIN_DB) / (MAX_DB - MIN_DB) * pw
    private fun yOf(outDb: Float) = padT + (MAX_DB - outDb) / (MAX_DB - MIN_DB) * ph
    private fun inOf(x: Float) = MIN_DB + (x - padL) / pw * (MAX_DB - MIN_DB)
    private fun outOf(y: Float) = MAX_DB - (y - padT) / ph * (MAX_DB - MIN_DB)

    private fun outAtZero(): Float = thresholdDb + (0f - thresholdDb) / ratio

    fun setParams(thresholdDb: Float, ratio: Float) {
        if (dragging != NONE) return
        this.thresholdDb = thresholdDb.coerceIn(MIN_DB, MAX_DB)
        this.ratio = ratio.coerceIn(1f, 20f)
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = if (MeasureSpec.getMode(heightSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(heightSpec)
        else (w * 0.9f).toInt().coerceIn(d(240f).toInt(), d(380f).toInt())
        setMeasuredDimension(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, d(14f), d(14f), bgP)

        // grid + label sumbu tiap 12 dB
        var v = MIN_DB
        while (v <= MAX_DB + 0.1f) {
            val gx = xOf(v); val gy = yOf(v)
            canvas.drawLine(gx, padT, gx, padT + ph, gridP)
            canvas.drawLine(padL, gy, padL + pw, gy, gridP)
            axisTxt.textAlign = Paint.Align.CENTER
            canvas.drawText(fmtAxis(v) + (if (v >= MAX_DB - 0.1f) " dB" else ""), gx, padT + ph + d(22f), axisTxt)
            axisTxt.textAlign = Paint.Align.RIGHT
            canvas.drawText(fmtAxis(v) + (if (v <= MIN_DB + 0.1f) " dB" else ""), padL - d(8f), gy + d(4f), axisTxt)
            v += 12f
        }

        val thr = thresholdDb
        val tx = xOf(thr); val ty = yOf(thr)
        val rx = xOf(0f); val ry = yOf(outAtZero())

        // area di bawah kurva sesudah threshold + garis threshold putus-putus vertikal
        fillPath.reset()
        fillPath.moveTo(tx, ty); fillPath.lineTo(rx, ry); fillPath.lineTo(rx, padT + ph); fillPath.lineTo(tx, padT + ph); fillPath.close()
        fillP.shader = LinearGradient(0f, padT, 0f, padT + ph, (cCyan and 0x00FFFFFF) or (0x40 shl 24), (cCyan and 0x00FFFFFF) or (0x05 shl 24), Shader.TileMode.CLAMP)
        canvas.drawPath(fillPath, fillP)
        dashP.color = cCyan
        canvas.drawLine(tx, ty, tx, padT + ph, dashP)

        // kurva
        path.reset()
        path.moveTo(xOf(MIN_DB), yOf(MIN_DB))
        path.lineTo(tx, ty)
        path.lineTo(rx, ry)
        canvas.drawPath(path, curveP)

        // Tooltip threshold di atas titik (geser ke kiri bila tidak muat).
        val thrText = String.format(Locale.US, "Threshold : %.1f dB", thr)
        val thw = tagTxt.measureText(thrText) + d(28f)
        val th = d(34f)
        val tagLeft = (tx - thw / 2f).coerceIn(padL, width - d(6f) - thw)
        val tagTop = (ty - d(24f) - th).coerceAtLeast(d(4f))
        dashP.color = cCyan
        canvas.drawLine(tagLeft + thw * 0.3f, tagTop + th, tx, ty, curveThin)
        drawTag(canvas, thrText, cCyan, tagLeft, tagTop, thw, th, Pal.c(0xFFFFFFFF))

        // Tooltip ratio hanya saat titik ratio sedang digeser.
        if (dragging == RATIO) {
            val rt = String.format(Locale.US, "Ratio : %.1f:1", ratio)
            val rw = tagTxt.measureText(rt) + d(28f)
            drawTag(canvas, rt, cGreen, (rx - rw - d(16f)).coerceAtLeast(padL), (ry + d(18f)).coerceAtMost(padT + ph - th), rw, th, Pal.c(0xFFFFFFFF))
        }

        drawHandle(canvas, rx, ry, cGreen, small = true)
        drawHandle(canvas, tx, ty, cCyan, small = false)
    }

    private fun drawLeader(c: Canvas, color: Int, x1: Float, y1: Float, x2: Float, y2: Float, hx: Float, hy: Float) {
        dashP.color = color
        path.reset()
        path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(hx, hy)
        c.drawPath(path, dashP)
    }

    private fun drawTag(c: Canvas, text: String, color: Int, left: Float, top: Float, w: Float, h: Float, textColor: Int = color) {
        rect.set(left, top, left + w, top + h)
        tagStroke.color = color
        c.drawRoundRect(rect, d(10f), d(10f), tagFill)
        c.drawRoundRect(rect, d(10f), d(10f), tagStroke)
        tagTxt.color = textColor
        tagTxt.textAlign = Paint.Align.CENTER
        val fm = tagTxt.fontMetrics
        c.drawText(text, left + w / 2f, top + h / 2f - (fm.ascent + fm.descent) / 2f, tagTxt)
    }

    private fun drawHandle(c: Canvas, x: Float, y: Float, color: Int, small: Boolean) {
        // Cahaya lembut, lalu titik pucat bergaris warna seperti pada desain.
        dotP.color = (color and 0x00FFFFFF) or (0x33 shl 24)
        c.drawCircle(x, y, d(if (small) 11f else 15f), dotP)
        dotP.color = Pal.c(0xFFD6ECFF)
        ringP.color = color
        c.drawCircle(x, y, d(if (small) 5f else 8f), dotP)
        c.drawCircle(x, y, d(if (small) 5f else 8f), ringP)
    }

    private fun fmtAxis(v: Float): String {
        val n = v.roundToInt()
        return if (n == 0) "0" else "-${abs(n)}"
    }

    // ---------- sentuhan ----------
    private var dragging = NONE

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dT = hypot(e.x - xOf(thresholdDb), e.y - yOf(thresholdDb))
                val dR = hypot(e.x - xOf(0f), e.y - yOf(outAtZero()))
                val reach = d(36f)
                dragging = when {
                    dT > reach && dR > reach -> NONE
                    dT <= dR -> THRESH
                    else -> RATIO
                }
                if (dragging == NONE) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                update(e.x, e.y, false)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                update(e.x, e.y, true)
                dragging = NONE
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun update(x: Float, y: Float, done: Boolean) {
        when (dragging) {
            THRESH -> {
                val t = ((inOf(x) * 2f).roundToInt() / 2f).coerceIn(MIN_DB, MAX_DB)
                thresholdDb = t
            }
            RATIO -> {
                val thr = thresholdDb
                if (thr < -0.5f) {
                    val out = outOf(y).coerceIn(thr, 0f)
                    val denom = 1f - out / thr
                    val r = if (denom <= 0.0001f) 20f else 1f / denom
                    ratio = ((r * 2f).roundToInt() / 2f).coerceIn(1f, 20f)
                }
            }
        }
        invalidate()
        onChange?.invoke(thresholdDb, ratio, done)
    }

    private companion object {
        const val MIN_DB = -60f
        const val MAX_DB = 0f
        const val NONE = 0
        const val THRESH = 1
        const val RATIO = 2
    }
}

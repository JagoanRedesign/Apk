package com.dlmsmini.equalizer

import android.content.SharedPreferences
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Susunan frekuensi untuk satu pilihan jumlah band. */
class BandLayout(val count: Int, val labels: Array<String>, val centerHz: IntArray) {
    /** Batas atas tiap band (titik tengah geometris ke band berikutnya) untuk filter DynamicsProcessing. */
    val edgeHz: FloatArray = FloatArray(count) { i ->
        if (i == count - 1) 22000f else sqrt(centerHz[i].toDouble() * centerHz[i + 1]).toFloat()
    }
}

/**
 * Pilihan pita equalizer: 5, 10, 13, dan 21 band.
 * 21 band bersifat "hibrida": bass ringkas (4 band), menengah-tinggi dirapatkan.
 * Nilai selalu dalam satuan 0,5 dB.
 */
object Bands {
    val COUNTS = intArrayOf(5, 10, 13, 21)
    const val DEFAULT = 10

    private val layouts = mapOf(
        5 to BandLayout(
            5, arrayOf("60", "250", "1K", "4K", "16K"),
            intArrayOf(60, 250, 1000, 4000, 16000)
        ),
        10 to BandLayout(
            10, arrayOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"),
            intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        ),
        13 to BandLayout(
            13, arrayOf("31", "62", "125", "250", "500", "1K", "2K", "3K", "4K", "6K", "8K", "12K", "16K"),
            intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 3000, 4000, 6000, 8000, 12000, 16000)
        ),
        21 to BandLayout(
            21,
            arrayOf(
                "31", "63", "125", "250", "400", "630", "800", "1K", "1.2K", "1.6K", "2K",
                "2.5K", "3.1K", "4K", "5K", "6.3K", "8K", "10K", "12K", "16K", "20K"
            ),
            intArrayOf(
                31, 63, 125, 250, 400, 630, 800, 1000, 1250, 1600, 2000,
                2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000, 20000
            )
        )
    )

    /** Batas frekuensi efektif crossover: tepi atas band terakhir yang masuk kelompok LOW. */
    fun crossoverEdge(layout: BandLayout, hz: Int): Int {
        val low = layout.centerHz.count { it < hz }
        return if (low == 0) layout.centerHz.first() else layout.edgeHz[low - 1].roundToInt()
    }

    fun isValid(n: Int): Boolean = n in COUNTS

    fun forCount(n: Int): BandLayout = layouts[n] ?: layouts.getValue(DEFAULT)

    /** Kunci penyimpanan. 10 band memakai kunci lama ("band_i") agar pengaturan lama tetap terbaca. */
    fun key(n: Int, i: Int): String = if (n == DEFAULT) "band_$i" else "band_${n}_$i"

    fun load(prefs: SharedPreferences, n: Int): IntArray =
        IntArray(n) { prefs.getInt(key(n, it), 0).coerceIn(-PresetCodec.LIMIT, PresetCodec.LIMIT) }

    /** Ubah kurva ke susunan band lain dengan interpolasi linear pada skala frekuensi logaritmik. */
    fun resample(src: IntArray, to: BandLayout): IntArray {
        if (src.size == to.count) return src.copyOf()
        val from = forCount(src.size)
        if (from.count != src.size) return IntArray(to.count)
        fun lg(hz: Int) = ln(hz.toDouble())
        return IntArray(to.count) { j ->
            val f = to.centerHz[j]
            when {
                f <= from.centerHz.first() -> src.first()
                f >= from.centerHz.last() -> src.last()
                else -> {
                    var i = 0
                    while (i < from.count - 2 && from.centerHz[i + 1] <= f) i++
                    val t = (lg(f) - lg(from.centerHz[i])) / (lg(from.centerHz[i + 1]) - lg(from.centerHz[i]))
                    (src[i] + t * (src[i + 1] - src[i])).roundToInt()
                }
            }
        }
    }

    /** Ganti jumlah band: kurva aktif disesuaikan lalu disimpan, dan jumlah band baru dicatat. */
    fun switchLayout(prefs: SharedPreferences, from: Int, to: Int) {
        val converted = resample(load(prefs, from), forCount(to))
        val e = prefs.edit()
        converted.forEachIndexed { i, v -> e.putInt(key(to, i), v) }
        e.putInt(Store.KEY_BANDS, to)
        e.apply()
    }
}

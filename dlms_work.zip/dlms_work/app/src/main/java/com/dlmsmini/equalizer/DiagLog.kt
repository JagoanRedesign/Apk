package com.dlmsmini.equalizer

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Catatan kejadian ringkas (perangkat audio berganti, efek diterapkan ulang, penolakan sistem) untuk layar Diagnostik. */
object DiagLog {
    private const val MAX = 80
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun log(message: String) {
        lines.addLast(fmt.format(Date()) + "  " + message)
        while (lines.size > MAX) lines.removeFirst()
    }

    @Synchronized
    fun snapshot(): List<String> = lines.toList()

    @Synchronized
    fun clear() = lines.clear()
}

package com.dlmsmini.equalizer

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Penanganan khusus vendor. Banyak ROM menghentikan layanan latar belakang atau menimpa efek audio global
 * dengan mesin audio milik pabrikan (Dolby, SoundAlive, dll.). Pengaturannya tidak bisa diubah oleh aplikasi;
 * yang bisa dilakukan: mengenali vendor, menjelaskan langkah yang tepat, dan membuka layar pengaturan terkait.
 */
object VendorGuide {
    enum class Family(val title: String) {
        XIAOMI("Xiaomi / Redmi / POCO (MIUI / HyperOS)"),
        SAMSUNG("Samsung (One UI)"),
        HUAWEI("Huawei / Honor"),
        OPPO("OPPO / realme / OnePlus (ColorOS / OxygenOS)"),
        VIVO("vivo / iQOO (Funtouch / OriginOS)"),
        TRANSSION("Tecno / Infinix / itel (HiOS / XOS)"),
        ASUS("ASUS"),
        OTHER("Android standar / vendor lain")
    }

    fun family(): Family {
        val m = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        return when {
            "xiaomi" in m || "redmi" in m || "poco" in m -> Family.XIAOMI
            "samsung" in m -> Family.SAMSUNG
            "huawei" in m || "honor" in m -> Family.HUAWEI
            "oppo" in m || "realme" in m || "oneplus" in m -> Family.OPPO
            "vivo" in m || "iqoo" in m -> Family.VIVO
            "tecno" in m || "infinix" in m || "itel" in m || "transsion" in m -> Family.TRANSSION
            "asus" in m -> Family.ASUS
            else -> Family.OTHER
        }
    }

    /** Langkah agar layanan latar belakang tidak dimatikan. */
    fun backgroundTips(): List<String> = when (family()) {
        Family.XIAOMI -> listOf(
            "Pengaturan › Aplikasi › Kelola aplikasi › DLMS Mini Equalizer › Mulai otomatis: AKTIFKAN.",
            "Hemat baterai: pilih \"Tanpa batasan\".",
            "Di layar Recent, tahan kartu aplikasi lalu pilih ikon gembok agar tidak dibersihkan."
        )
        Family.SAMSUNG -> listOf(
            "Pengaturan › Baterai › Batas penggunaan di latar belakang: keluarkan aplikasi dari \"Aplikasi tidur\" dan \"Aplikasi tidur mendalam\".",
            "Tambahkan ke \"Aplikasi yang tidak pernah tidur\".",
            "Pengaturan › Aplikasi › DLMS Mini Equalizer › Baterai: pilih \"Tidak dibatasi\"."
        )
        Family.HUAWEI -> listOf(
            "Pengaturan › Aplikasi › Peluncuran aplikasi › DLMS Mini Equalizer: pilih \"Kelola manual\", aktifkan Peluncuran otomatis, Peluncuran sekunder, dan Berjalan di latar belakang."
        )
        Family.OPPO -> listOf(
            "Pengaturan › Aplikasi › DLMS Mini Equalizer › Penggunaan baterai: izinkan aktivitas latar belakang.",
            "Aktifkan \"Luncurkan otomatis\" / \"Auto-launch\" untuk aplikasi ini.",
            "Di layar Recent, tarik kartu aplikasi ke bawah (kunci) agar tidak dibersihkan."
        )
        Family.VIVO -> listOf(
            "Pengaturan › Baterai › Konsumsi daya latar belakang: pilih \"Izinkan konsumsi daya tinggi\" untuk DLMS Mini Equalizer.",
            "Aktifkan \"Mulai otomatis\" di Manajer aplikasi / iManager."
        )
        Family.TRANSSION -> listOf(
            "Phone Master / Manajer ponsel › Manajemen mulai otomatis: aktifkan aplikasi ini.",
            "Baterai: pilih \"Tanpa pembatasan\" untuk aplikasi ini."
        )
        Family.ASUS -> listOf(
            "Pengaturan › Baterai › Optimalisasi baterai: pilih \"Tidak dioptimalkan\" untuk aplikasi ini.",
            "Mobile Manager › Mulai otomatis: aktifkan."
        )
        Family.OTHER -> listOf(
            "Pengaturan › Aplikasi › DLMS Mini Equalizer › Baterai: pilih \"Tidak dibatasi\" / \"Unrestricted\".",
            "Jangan menutup paksa aplikasi lewat \"Hentikan paksa\"; itu menghentikan layanan."
        )
    }

    /** Catatan khusus bila efek audio global ditimpa atau dibatasi vendor. */
    fun audioTips(): List<String> = when (family()) {
        Family.SAMSUNG -> listOf(
            "Matikan Dolby Atmos dan \"Adapt Sound\" / SoundAlive (Pengaturan › Suara dan getaran › Kualitas suara dan efek); mesin Samsung dapat menimpa efek global.",
            "Bila efek global tidak terasa, aktifkan Mode Sesi Aplikasi di Pengaturan."
        )
        Family.XIAOMI -> listOf(
            "Matikan \"Dolby Atmos\" / \"Efek suara Mi\" (Pengaturan › Suara dan getaran) saat memakai equalizer ini.",
            "HyperOS dapat menolak efek global; coba Mode Sesi Aplikasi."
        )
        Family.OPPO -> listOf(
            "Matikan Dolby Atmos / \"Efek audio\" bawaan (Pengaturan › Suara dan getaran) agar tidak bentrok.",
            "ColorOS 13+ sering hanya menerima efek per sesi: gunakan Mode Sesi Aplikasi."
        )
        Family.VIVO -> listOf(
            "Matikan Hi-Fi / \"Efek audio\" bawaan vivo bila efek tidak terdengar.",
            "Gunakan Mode Sesi Aplikasi bila efek global ditolak."
        )
        Family.HUAWEI -> listOf(
            "Matikan Histen / Huawei Sound saat memakai equalizer ini.",
            "Gunakan Mode Sesi Aplikasi bila efek global tidak berpengaruh."
        )
        else -> listOf(
            "Matikan efek audio bawaan ponsel (Dolby, DTS, \"Peningkat suara\") bila efek tidak terdengar.",
            "Gunakan Mode Sesi Aplikasi bila efek global ditolak."
        )
    }

    private fun comp(pkg: String, cls: String) = Intent().setComponent(ComponentName(pkg, cls))

    private fun autostartIntents(): List<Intent> = when (family()) {
        Family.XIAOMI -> listOf(comp("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))
        Family.HUAWEI -> listOf(
            comp("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            comp("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")
        )
        Family.OPPO -> listOf(
            comp("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            comp("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            comp("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")
        )
        Family.VIVO -> listOf(
            comp("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            comp("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")
        )
        Family.SAMSUNG -> listOf(comp("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"))
        Family.ASUS -> listOf(comp("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"))
        Family.TRANSSION -> listOf(comp("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"))
        Family.OTHER -> emptyList()
    }

    /** Buka layar mulai-otomatis vendor (jika ada), jika tidak buka info aplikasi. Mengembalikan true bila layar vendor terbuka. */
    fun openAutostart(ctx: Context): Boolean {
        for (i in autostartIntents()) {
            try {
                if (i.resolveActivity(ctx.packageManager) != null) {
                    ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return true
                }
            } catch (_: Exception) {
            }
        }
        openAppInfo(ctx)
        return false
    }

    fun openAppInfo(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    fun openBatterySettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            openAppInfo(ctx)
        }
    }
}

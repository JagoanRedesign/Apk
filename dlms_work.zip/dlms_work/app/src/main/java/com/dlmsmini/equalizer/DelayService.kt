package com.dlmsmini.equalizer

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Delay DSP sungguhan.
 *
 * Android tidak memberi aplikasi akses ke buffer audio pemutar lain lewat AudioEffect, jadi pemrosesan dilakukan lewat
 * AudioPlaybackCapture (Android 10+): audio pemutar ditangkap -> DelayDsp (buffer audio sendiri) -> diputar lewat AudioTrack.
 *
 * Batasan platform yang jujur:
 *  - Suara asli tetap diputar sistem pada level normal dan tidak dapat dibisukan oleh aplikasi. Karena itu yang dikeluarkan
 *    ke AudioTrack adalah jalur gema (Wet) + salinan Dry yang diproses (disarankan 0%).
 *  - Ada latensi jalur capture-playback; DelayDsp mengompensasinya, tetapi waktu delay < latensi tidak dapat dicapai.
 *  - Aplikasi yang menolak penangkapan audio (DRM / allowAudioPlaybackCapture=false) tidak ikut diproses.
 *  - Butuh izin RECORD_AUDIO + persetujuan MediaProjection setiap kali dinyalakan (aturan Android 14+).
 */
class DelayService : Service() {

    companion object {
        const val ACTION_START = "com.dlmsmini.equalizer.action.DELAY_START"
        private const val EXTRA_CODE = "projection_code"
        private const val EXTRA_DATA = "projection_data"
        private const val CHANNEL_ID = "dlms_delay"
        private const val NOTIF_ID = 4102
        const val SAMPLE_RATE = 48000
        private const val CHUNK_FRAMES = 480 // 10 ms

        @Volatile var running = false
            private set
        @Volatile var settings = DelaySettings()
        @Volatile var masterOn = true
        @Volatile var latencyMs = 0
            private set
        @Volatile var lastError: String? = null
            private set
        @Volatile var onState: (() -> Unit)? = null

        val supported: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            val i = Intent(ctx, DelayService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, DelayService::class.java)) } catch (_: Exception) {}
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var worker: Any? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START || !supported) {
            // Restart otomatis oleh sistem tidak membawa token MediaProjection: tidak bisa dilanjutkan.
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        if (!startFg()) {
            fail("Android menolak foreground service untuk Delay")
            return START_NOT_STICKY
        }
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<Intent>(EXTRA_DATA)
        }
        if (data == null) {
            fail("Izin tangkap audio tidak lengkap")
            return START_NOT_STICKY
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            fail("Izin rekam audio belum diberikan")
            return START_NOT_STICKY
        }
        if (worker != null) return START_NOT_STICKY
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            if (mp == null) {
                fail("MediaProjection tidak tersedia")
                return START_NOT_STICKY
            }
            projection = mp
            // Android 14+ mewajibkan callback terdaftar sebelum menangkap.
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post { if (!stopping) fail("Penangkapan audio dihentikan sistem") }
                }
            }, handler)
            val cfg = buildCaptureConfig(mp)
            if (cfg == null) {
                fail("Perangkat tidak mendukung pengecualian suara aplikasi ini (mencegah umpan balik)")
                return START_NOT_STICKY
            }
            val w = Worker(cfg)
            worker = w
            running = true
            lastError = null
            DiagLog.log("Delay DSP dimulai")
            w.start()
            onState?.invoke()
        } catch (t: Throwable) {
            fail("Gagal memulai capture: " + (t.message ?: t.javaClass.simpleName))
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ---------- foreground ----------

    private fun startFg(): Boolean = try {
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        true
    } catch (e: Exception) {
        DiagLog.log("Foreground Delay ditolak: ${e.javaClass.simpleName} ${e.message ?: ""}")
        false
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Delay DSP", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Aktif selama efek Delay memproses audio"
            setShowBadge(false)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 10,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val s = settings
        val text = "Delay ${s.timeMs} ms • umpan balik ${s.feedbackPct}%" +
            if (latencyMs > 0) " • latensi ≈ $latencyMs ms" else ""
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("DLMS Delay aktif")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    // ---------- capture ----------

    /**
     * Tangkap USAGE_MEDIA/GAME/UNKNOWN dari semua aplikasi KECUALI aplikasi ini sendiri. Pengecualian UID wajib:
     * tanpanya keluaran AudioTrack kita ikut tertangkap dan menimbulkan gema tak berujung.
     */
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun buildCaptureConfig(mp: MediaProjection): AudioPlaybackCaptureConfiguration? {
        val uid = Process.myUid()
        try {
            return AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .excludeUid(uid)
                .build()
        } catch (_: Throwable) {
        }
        return try {
            AudioPlaybackCaptureConfiguration.Builder(mp).excludeUid(uid).build()
        } catch (_: Throwable) {
            null
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private inner class Worker(private val cfg: AudioPlaybackCaptureConfiguration) : Thread("dlms-delay") {
        @Volatile var alive = true

        override fun run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            var rec: AudioRecord? = null
            var track: AudioTrack? = null
            try {
                val fs = SAMPLE_RATE
                val inFmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(fs)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
                val outFmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(fs)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                val minRec = AudioRecord.getMinBufferSize(fs, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val minTrk = AudioTrack.getMinBufferSize(fs, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val chunkBytes = CHUNK_FRAMES * 4
                rec = AudioRecord.Builder()
                    .setAudioFormat(inFmt)
                    .setBufferSizeInBytes(maxOf(minRec, chunkBytes * 2))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build()
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("AudioRecord gagal diinisialisasi")
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    )
                    .setAudioFormat(outFmt)
                    .setBufferSizeInBytes(maxOf(minTrk, chunkBytes * 2))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build()

                val recMs = rec.bufferSizeInFrames * 1000 / fs
                val trkMs = track.bufferSizeInFrames * 1000 / fs
                latencyMs = (CHUNK_FRAMES * 1000 / fs) + recMs / 2 + trkMs / 2 + 20
                handler.post { updateNotification(); onState?.invoke() }

                val dsp = DelayDsp(fs)
                val inBuf = ShortArray(CHUNK_FRAMES * 2)
                val outBuf = ShortArray(CHUNK_FRAMES * 2)
                val aL = FloatArray(CHUNK_FRAMES)
                val aR = FloatArray(CHUNK_FRAMES)
                val oL = FloatArray(CHUNK_FRAMES)
                val oR = FloatArray(CHUNK_FRAMES)
                var wasIdle = false

                rec.startRecording()
                track.play()
                while (alive) {
                    val n = rec.read(inBuf, 0, inBuf.size, AudioRecord.READ_BLOCKING)
                    if (n < 0) throw IllegalStateException("AudioRecord.read error $n")
                    if (n == 0) continue
                    val frames = n / 2
                    val s = settings
                    if (!masterOn || !s.enabled) {
                        // Master OFF / dijeda: keluarkan senyap dan kosongkan buffer gema agar tidak ada sisa saat nyala lagi.
                        if (!wasIdle) { dsp.reset(); wasIdle = true }
                        java.util.Arrays.fill(outBuf, 0, frames * 2, 0)
                    } else {
                        wasIdle = false
                        for (i in 0 until frames) {
                            aL[i] = inBuf[i * 2] / 32768f
                            aR[i] = inBuf[i * 2 + 1] / 32768f
                        }
                        dsp.process(aL, aR, oL, oR, frames, s, latencyMs.toFloat())
                        for (i in 0 until frames) {
                            outBuf[i * 2] = toShort(oL[i])
                            outBuf[i * 2 + 1] = toShort(oR[i])
                        }
                    }
                    val w = track.write(outBuf, 0, frames * 2, AudioTrack.WRITE_BLOCKING)
                    if (w < 0) throw IllegalStateException("AudioTrack.write error $w")
                }
            } catch (t: Throwable) {
                if (alive) {
                    val msg = "Delay berhenti: " + (t.message ?: t.javaClass.simpleName)
                    handler.post { fail(msg) }
                }
            } finally {
                try { rec?.stop() } catch (_: Throwable) {}
                try { rec?.release() } catch (_: Throwable) {}
                try { track?.stop() } catch (_: Throwable) {}
                try { track?.release() } catch (_: Throwable) {}
            }
        }

        private fun toShort(v: Float): Short {
            val x = (v * 32767f)
            return (if (x > 32767f) 32767f else if (x < -32768f) -32768f else x).toInt().toShort()
        }
    }

    private fun updateNotification() {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    // ---------- berhenti ----------

    private fun fail(message: String) {
        lastError = message
        DiagLog.log(message)
        Store.setDelayOn(this, false)
        settings = settings.copy(enabled = false)
        shutdown()
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
        onState?.invoke()
    }

    private fun shutdown() {
        if (stopping) return
        stopping = true
        (worker as? Worker)?.let {
            it.alive = false
            try { it.join(1500) } catch (_: InterruptedException) {}
        }
        worker = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        if (running) DiagLog.log("Delay DSP dihentikan")
        running = false
        latencyMs = 0
        handler.removeCallbacksAndMessages(null)
        onState?.invoke()
    }
}

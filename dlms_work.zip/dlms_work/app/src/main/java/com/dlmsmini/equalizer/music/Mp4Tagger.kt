package com.dlmsmini.equalizer.music

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer

/**
 * Penulis tag M4A/MP4 (judul, artis, album, lirik, sampul) tanpa pustaka luar.
 * Menulis atom moov/udta/meta/ilst. Mendukung berkas biasa (moov di depan atau di belakang mdat)
 * dan berkas fragmented (DASH): offset stco/co64 digeser bila moov berada sebelum mdat.
 */
object Mp4Tagger {
    private val CONTAINERS = setOf("moov", "trak", "mdia", "minf", "stbl")
    private val LATIN1 = Charsets.ISO_8859_1

    class Meta(val title: String?, val artist: String?, val album: String?, val lyrics: String?, val cover: ByteArray?)

    private class Box(val type: String, val pos: Long, val size: Long, val hdr: Int)

    private fun box(type: String, payload: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(payload.size + 8)
        DataOutputStream(o).apply { writeInt(payload.size + 8); write(type.toByteArray(LATIN1)); write(payload) }
        return o.toByteArray()
    }

    private fun dataAtom(flags: Int, payload: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        DataOutputStream(o).apply { writeInt(flags); writeInt(0); write(payload) }
        return box("data", o.toByteArray())
    }

    private fun item(type: String, flags: Int, payload: ByteArray) = box(type, dataAtom(flags, payload))

    private fun buildUdta(m: Meta): ByteArray {
        val items = ByteArrayOutputStream()
        if (!m.title.isNullOrBlank()) items.write(item("\u00A9nam", 1, m.title.toByteArray(Charsets.UTF_8)))
        if (!m.artist.isNullOrBlank()) {
            items.write(item("\u00A9ART", 1, m.artist.toByteArray(Charsets.UTF_8)))
            items.write(item("aART", 1, m.artist.toByteArray(Charsets.UTF_8)))
        }
        if (!m.album.isNullOrBlank()) items.write(item("\u00A9alb", 1, m.album.toByteArray(Charsets.UTF_8)))
        if (!m.lyrics.isNullOrBlank()) items.write(item("\u00A9lyr", 1, m.lyrics.toByteArray(Charsets.UTF_8)))
        val cover = m.cover
        if (cover != null && cover.isNotEmpty()) {
            val png = cover.size > 4 && cover[0] == 0x89.toByte() && cover[1] == 'P'.code.toByte()
            items.write(item("covr", if (png) 14 else 13, cover))
        }
        val hdlrBody = ByteArrayOutputStream().apply {
            write(ByteArray(8)); write("mdir".toByteArray(LATIN1)); write("appl".toByteArray(LATIN1)); write(ByteArray(9))
        }.toByteArray()
        val metaBody = ByteArrayOutputStream().apply {
            write(ByteArray(4)); write(box("hdlr", hdlrBody)); write(box("ilst", items.toByteArray()))
        }.toByteArray()
        return box("udta", box("meta", metaBody))
    }

    private fun topBoxes(raf: RandomAccessFile): List<Box> {
        val out = ArrayList<Box>()
        val len = raf.length()
        var p = 0L
        val tb = ByteArray(4)
        while (p + 8 <= len) {
            raf.seek(p)
            var size = raf.readInt().toLong() and 0xFFFFFFFFL
            raf.readFully(tb)
            var hdr = 8
            if (size == 1L) { size = raf.readLong(); hdr = 16 } else if (size == 0L) size = len - p
            if (size < hdr || p + size > len) break
            out.add(Box(String(tb, LATIN1), p, size, hdr))
            p += size
        }
        return out
    }

    private fun shiftOffsets(buf: ByteArray, start: Int, end: Int, delta: Long) {
        val bb = ByteBuffer.wrap(buf)
        var p = start
        while (p + 8 <= end) {
            var size = bb.getInt(p).toLong() and 0xFFFFFFFFL
            val type = String(buf, p + 4, 4, LATIN1)
            var hdr = 8
            if (size == 1L) { size = bb.getLong(p + 8); hdr = 16 } else if (size == 0L) size = (end - p).toLong()
            if (size < hdr || p + size > end) break
            when {
                type in CONTAINERS -> shiftOffsets(buf, p + hdr, (p + size).toInt(), delta)
                type == "stco" -> {
                    val n = bb.getInt(p + 12)
                    for (i in 0 until n) {
                        val o = p + 16 + 4 * i
                        bb.putInt(o, ((bb.getInt(o).toLong() and 0xFFFFFFFFL) + delta).toInt())
                    }
                }
                type == "co64" -> {
                    val n = bb.getInt(p + 12)
                    for (i in 0 until n) {
                        val o = p + 16 + 8 * i
                        bb.putLong(o, bb.getLong(o) + delta)
                    }
                }
            }
            p += size.toInt()
        }
    }

    /** Menulis tag ke [file] (diganti di tempat). Mengembalikan false bila struktur tidak dikenali; berkas asli tidak rusak. */
    fun write(file: File, meta: Meta): Boolean {
        val tmp = File(file.parentFile, file.name + ".tag")
        try {
            RandomAccessFile(file, "r").use { raf ->
                val top = topBoxes(raf)
                val moov = top.firstOrNull { it.type == "moov" } ?: return false
                if (moov.size > 64L * 1024 * 1024) return false
                val old = ByteArray(moov.size.toInt())
                raf.seek(moov.pos)
                raf.readFully(old)

                // Anak-anak moov lama kecuali udta, lalu udta baru.
                val body = ByteArrayOutputStream()
                val bbOld = ByteBuffer.wrap(old)
                var p = moov.hdr
                while (p + 8 <= old.size) {
                    var size = bbOld.getInt(p).toLong() and 0xFFFFFFFFL
                    val type = String(old, p + 4, 4, LATIN1)
                    if (size == 1L) size = bbOld.getLong(p + 8) else if (size == 0L) size = (old.size - p).toLong()
                    if (size < 8 || p + size > old.size) break
                    if (type != "udta") body.write(old, p, size.toInt())
                    p += size.toInt()
                }
                body.write(buildUdta(meta))
                val newMoov = box("moov", body.toByteArray())

                val fragmented = top.any { it.type == "moof" }
                val moovBeforeMdat = top.any { it.type == "mdat" && it.pos > moov.pos }
                val delta = newMoov.size.toLong() - moov.size
                if (moovBeforeMdat && !fragmented && delta != 0L) shiftOffsets(newMoov, 8, newMoov.size, delta)

                FileOutputStream(tmp).use { out ->
                    copyRange(raf, 0, moov.pos, out)
                    out.write(newMoov)
                    copyRange(raf, moov.pos + moov.size, raf.length(), out)
                }
            }
            if (!file.delete()) { tmp.delete(); return false }
            return tmp.renameTo(file)
        } catch (e: Exception) {
            tmp.delete()
            return false
        }
    }

    private fun copyRange(raf: RandomAccessFile, from: Long, to: Long, out: FileOutputStream) {
        val buf = ByteArray(64 * 1024)
        var left = to - from
        raf.seek(from)
        while (left > 0) {
            val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) break
            out.write(buf, 0, n)
            left -= n
        }
    }
}

/**
 * Remux M4A DASH (fragmented) dari YouTube menjadi M4A biasa lewat MediaExtractor + MediaMuxer,
 * supaya durasi, pencarian posisi, dan tag terbaca benar di semua pemutar. Tanpa transcoding (kualitas tetap).
 */
object M4aRemux {
    fun remux(src: File, dst: File): Boolean {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(src.absolutePath)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return false
            ex.selectTrack(track)
            mux = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = mux.addTrack(fmt)
            mux.start()
            started = true
            val buf = ByteBuffer.allocate(1 shl 18)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val key = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                info.set(0, n, ex.sampleTime, if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                mux.writeSampleData(outTrack, buf, info)
                ex.advance()
            }
            mux.stop()
            started = false
            return dst.length() > 0
        } catch (e: Exception) {
            dst.delete()
            return false
        } finally {
            try { if (started) mux?.stop() } catch (_: Exception) {}
            try { mux?.release() } catch (_: Exception) {}
            ex.release()
        }
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Warna & tema aplikasi.
 *
 * Seluruh warna di kode ditulis untuk tema GELAP. Fungsi [c] menerjemahkannya sesuai tema aktif:
 *  - Gelap            : warna dipakai apa adanya.
 *  - Terang           : permukaan gelap dan teks terang dibalik kecerahannya (HSL), warna aksen dipertajam agar terbaca.
 *  - Warna dinamis    : (Android 12+) permukaan/teks diambil dari palet netral sistem dan aksen biru/cyan dari palet aksen
 *                       sistem (Material You), sedangkan warna bermakna (hijau OK, oranye peringatan, merah) dibiarkan.
 * Pilihan tema ada di Setelan › Tampilan. [version] naik setiap pilihan berubah agar layar yang terbuka bisa dibuat ulang.
 */
object Pal {
    private var app: Context? = null
    @Volatile private var themeMode = Store.THEME_SYSTEM
    @Volatile private var dynamicOn = false
    @Volatile var version = 0
        private set
    private val cache = HashMap<Long, Int>()

    /** Dipanggil sekali dari [DlmsApp.onCreate]. */
    fun init(ctx: Context) {
        app = ctx.applicationContext
        reload()
    }

    /** Baca ulang pilihan tema dari penyimpanan dan terapkan ke AppCompat (widget bawaan & dialog). */
    fun reload() {
        val a = app ?: return
        val p = Store.prefs(a)
        themeMode = p.getInt(Store.KEY_THEME, Store.THEME_SYSTEM).coerceIn(Store.THEME_SYSTEM, Store.THEME_DARK)
        dynamicOn = p.getBoolean(Store.KEY_DYNAMIC, false) && dynamicSupported
        clearCache()
        version++
        AppCompatDelegate.setDefaultNightMode(
            when (themeMode) {
                Store.THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                Store.THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    @Synchronized
    fun clearCache() { cache.clear() }

    /** Warna dinamis Material You tersedia mulai Android 12. */
    val dynamicSupported: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    val dynamic: Boolean get() = dynamicOn

    /** True bila tampilan sedang terang (pilihan pengguna, atau ikut sistem). */
    val light: Boolean
        get() = when (themeMode) {
            Store.THEME_LIGHT -> true
            Store.THEME_DARK -> false
            else -> {
                val ui = app?.resources?.configuration?.uiMode ?: Configuration.UI_MODE_NIGHT_YES
                (ui and Configuration.UI_MODE_NIGHT_MASK) != Configuration.UI_MODE_NIGHT_YES
            }
        }

    // Warna dasar (tema gelap) — dipetakan lewat c().
    val BG: Int get() = c(0xFF080B12)
    val PANEL: Int get() = c(0xFF111827)
    val PANEL_STROKE: Int get() = c(0xFF263B5D)
    val ACCENT: Int get() = c(0xFF27B5FF)
    val CYAN: Int get() = c(0xFF45C5FF)
    val TEXT: Int get() = c(0xFFEAF0FF)
    val MUTED: Int get() = c(0xFF9DAFC9)

    /** Terjemahkan warna tema-gelap [v] (ARGB) ke tema yang sedang aktif. Alpha dipertahankan. */
    fun c(v: Long): Int {
        val argb = v.toInt()
        val isLight = light
        val isDyn = dynamicOn
        if (!isLight && !isDyn) return argb
        val key = (argb.toLong() and 0xFFFFFFFFL) or (if (isLight) 1L shl 32 else 0L) or (if (isDyn) 1L shl 33 else 0L)
        synchronized(this) { cache[key]?.let { return it } }
        val out = convert(argb, isLight, isDyn)
        synchronized(this) { cache[key] = out }
        return out
    }

    private const val K_TEXT = 0     // hampir putih: teks di atas permukaan gelap
    private const val K_SURFACE = 1  // gelap: latar, kartu, garis
    private const val K_NEUTRAL = 2  // abu/kebiruan pudar: teks sekunder, ikon
    private const val K_ACCENT = 3   // jenuh: aksen dan warna bermakna

    private fun convert(argb: Int, isLight: Boolean, isDyn: Boolean): Int {
        val alpha = argb ushr 24
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(argb, hsl)
        val h = hsl[0]
        var s = hsl[1]
        var l = hsl[2]
        val kind = when {
            l >= 0.85f -> K_TEXT
            l <= 0.28f -> K_SURFACE
            s < 0.40f -> K_NEUTRAL
            else -> K_ACCENT
        }
        val blueAccent = kind == K_ACCENT && h in 165f..255f
        if (isLight) {
            when (kind) {
                K_TEXT, K_NEUTRAL -> l = 1f - l
                K_SURFACE -> { l = 1f - l; s *= 0.55f }
                else -> l = min(l, 0.45f)
            }
        } else if (isDyn && blueAccent) {
            l = max(l, 0.70f) // aksen pastel di atas permukaan gelap
        }
        val rgb = if (isDyn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (blueAccent) tone(ACCENT1, l) else if (kind != K_ACCENT) tone(NEUTRAL2, l) else 0
        } else 0
        val finalRgb = if (rgb != 0) rgb else ColorUtils.HSLToColor(floatArrayOf(h, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f)))
        return (alpha shl 24) or (finalRgb and 0xFFFFFF)
    }

    private val TONES = intArrayOf(0, 10, 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000)

    private fun tone(ids: IntArray, lightness: Float): Int {
        val a = app ?: return 0
        val want = (1f - lightness.coerceIn(0f, 1f)) * 1000f
        var best = 0
        for (i in TONES.indices) if (abs(TONES[i] - want) < abs(TONES[best] - want)) best = i
        return try { ContextCompat.getColor(a, ids[best]) } catch (_: Throwable) { 0 }
    }

    // Palet sistem Android 12+ (android.R.color.system_*). Nilai konstanta ini disisipkan saat kompilasi.
    private val ACCENT1 = intArrayOf(
        android.R.color.system_accent1_0,
        android.R.color.system_accent1_10,
        android.R.color.system_accent1_50,
        android.R.color.system_accent1_100,
        android.R.color.system_accent1_200,
        android.R.color.system_accent1_300,
        android.R.color.system_accent1_400,
        android.R.color.system_accent1_500,
        android.R.color.system_accent1_600,
        android.R.color.system_accent1_700,
        android.R.color.system_accent1_800,
        android.R.color.system_accent1_900,
        android.R.color.system_accent1_1000
    )
    private val NEUTRAL2 = intArrayOf(
        android.R.color.system_neutral2_0,
        android.R.color.system_neutral2_10,
        android.R.color.system_neutral2_50,
        android.R.color.system_neutral2_100,
        android.R.color.system_neutral2_200,
        android.R.color.system_neutral2_300,
        android.R.color.system_neutral2_400,
        android.R.color.system_neutral2_500,
        android.R.color.system_neutral2_600,
        android.R.color.system_neutral2_700,
        android.R.color.system_neutral2_800,
        android.R.color.system_neutral2_900,
        android.R.color.system_neutral2_1000
    )
}

package com.dlmsmini.equalizer

import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.Localization
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Runs NewPipeExtractor on-device. The downloader is intentionally small and uses
 * HttpURLConnection so no third-party HTTP stack is required by the app.
 */
object NewPipeAudioResolver {
    @Volatile private var initialized = false

    @Synchronized private fun init() {
        if (initialized) return
        NewPipe.init(object : Downloader() {
            override fun execute(request: Request): Response {
                val c = (URL(request.url()).openConnection() as HttpURLConnection)
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.requestMethod = request.httpMethod()
                request.headers().forEach { (key, values) ->
                    values.forEach { c.addRequestProperty(key, it) }
                }
                val data = request.dataToSend()
                if (data != null) {
                    c.doOutput = true
                    c.outputStream.use { it.write(data) }
                }
                val code = c.responseCode
                val body = try {
                    (if (code in 200..299) c.inputStream else c.errorStream)
                        ?.bufferedReader()?.use { it.readText() }.orEmpty()
                } catch (_: Exception) { "" }
                val headers = c.headerFields.filterKeys { it != null }
                    .mapValues { it.value ?: emptyList() }
                val response = Response(code, c.responseMessage, headers, body, c.url.toString())
                c.disconnect()
                return response
            }
        }, Localization("en", "US"))
        initialized = true
    }

    data class AudioChoice(val url: String, val bitrate: Int, val format: String, val suffix: String)

    fun extract(youtubeUrl: String): List<AudioChoice> {
        init()
        val extractor = ServiceList.YouTube.getStreamExtractor(youtubeUrl)
        extractor.fetchPage()
        return extractor.audioStreams
            .filter { it.isUrl && it.content.startsWith("http") }
            .map { AudioChoice(it.content, it.averageBitrate, it.format?.name ?: "Audio", it.format?.suffix ?: "audio") }
            .sortedByDescending { it.bitrate }
    }
}

package com.dlmsmini.equalizer.music

import com.dlmsmini.equalizer.DiagLog
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.StreamingService
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/** Implementasi [Downloader] NewPipeExtractor di atas HttpURLConnection. */
object NpDownloader : Downloader() {
    const val UA_FIREFOX = "Mozilla/5.0 (Windows NT 10.0; rv:140.0) Gecko/20100101 Firefox/140.0"

    override fun execute(request: Request): Response {
        val conn = URL(request.url()).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 25000
            conn.instanceFollowRedirects = true
            conn.requestMethod = request.httpMethod()
            var hasUa = false
            for ((k, values) in request.headers()) {
                if (k.equals("User-Agent", true)) hasUa = true
                values.forEachIndexed { i, v -> if (i == 0) conn.setRequestProperty(k, v) else conn.addRequestProperty(k, v) }
            }
            if (!hasUa) conn.setRequestProperty("User-Agent", UA_FIREFOX)
            val body = request.dataToSend()
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            if (code == 429) throw ReCaptchaException("reCaptcha Challenge requested", request.url())
            val raw = (if (code >= 400) conn.errorStream else conn.inputStream)
            val text = if (raw == null) "" else {
                val s = if ("gzip".equals(conn.contentEncoding, true)) GZIPInputStream(raw) else raw
                val out = ByteArrayOutputStream()
                s.use { it.copyTo(out) }
                out.toString("UTF-8")
            }
            val headers = HashMap<String, List<String>>()
            for ((k, v) in conn.headerFields) if (k != null) headers[k] = v
            return Response(code, conn.responseMessage ?: "", headers, text, conn.url.toString())
        } finally {
            conn.disconnect()
        }
    }
}

object NewPipeBridge {
    private var ready = false

    @Synchronized
    fun service(): StreamingService {
        if (!ready) {
            NewPipe.init(NpDownloader, Localization("id", "ID"), ContentCountry("ID"))
            ready = true
        }
        return ServiceList.YouTube
    }
}

/** Satu pilihan kualitas audio hasil ekstraksi. */
class AudioOption(
    val url: String,
    val suffix: String,      // m4a / webm
    val mime: String,
    val bitrateKbps: Int
) {
    /** Hanya M4A (AAC) yang bisa ditanami sampul & lirik oleh penulis tag bawaan. */
    val canEmbed: Boolean get() = suffix == "m4a"
    val codecName: String get() = if (suffix == "m4a") "AAC" else "Opus"
    val label: String get() = "${suffix.uppercase()} • $codecName • $bitrateKbps kbps"
    val key: String get() = "$suffix-$bitrateKbps"
}

/** Mengekstrak URL audio YouTube lewat NewPipeExtractor (lokal di perangkat) dan menyimpannya sementara. */
object StreamResolver {
    private class Cached(val opts: List<AudioOption>, val expiresAt: Long)

    private val cache = object : LinkedHashMap<String, Cached>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Cached>?): Boolean = size > 40
    }
    private val EXPIRE = Regex("[?&]expire=(\\d+)")

    fun invalidate(videoId: String) = synchronized(cache) { cache.remove(videoId); Unit }

    /** Blocking: panggil dari thread latar. */
    fun options(videoId: String, force: Boolean = false): List<AudioOption> {
        if (!force) synchronized(cache) {
            val c = cache[videoId]
            if (c != null && c.expiresAt > System.currentTimeMillis()) return c.opts
        }
        val info = try {
            StreamInfo.getInfo(NewPipeBridge.service(), "https://www.youtube.com/watch?v=$videoId")
        } catch (e: Throwable) {
            DiagLog.log("Musik: ekstraksi $videoId gagal: ${e.javaClass.simpleName}: ${e.message}")
            throw IOException("Ekstraksi gagal: ${e.message ?: e.javaClass.simpleName}", e)
        }
        val list = ArrayList<AudioOption>()
        val seen = HashSet<String>()
        for (s: AudioStream in info.audioStreams) {
            if (!s.isUrl || s.deliveryMethod != DeliveryMethod.PROGRESSIVE_HTTP) continue
            val t = s.audioTrackType
            if (t != null && t.name != "ORIGINAL") continue // lewati trek dubbing / deskriptif
            val fmt = s.format ?: continue
            var kbps = s.averageBitrate
            if (kbps > 1000) kbps /= 1000
            if (kbps <= 0) continue
            val suffix = if (fmt.suffix.equals("m4a", true) || fmt.suffix.equals("mp4", true)) "m4a" else "webm"
            val o = AudioOption(s.content, suffix, if (suffix == "m4a") "audio/mp4" else "audio/webm", kbps)
            if (seen.add(o.key)) list.add(o)
        }
        if (list.isEmpty()) throw IOException("Tidak ada stream audio yang dapat diputar")
        list.sortWith(compareByDescending<AudioOption> { it.bitrateKbps }.thenBy { if (it.suffix == "m4a") 0 else 1 })
        val expireSec = list.firstOrNull()?.let { EXPIRE.find(it.url)?.groupValues?.get(1)?.toLongOrNull() }
        val exp = if (expireSec != null) expireSec * 1000L - 10 * 60_000L else System.currentTimeMillis() + 4 * 3600_000L
        synchronized(cache) { cache[videoId] = Cached(list, exp) }
        return list
    }

    /** Pilih stream untuk pemutaran sesuai pengaturan kualitas. */
    fun pick(opts: List<AudioOption>, quality: Int): AudioOption = when (quality) {
        MusicPrefs.Q_LOW -> opts.minByOrNull { it.bitrateKbps } ?: opts.first()
        MusicPrefs.Q_STANDARD -> opts.minByOrNull { Math.abs(it.bitrateKbps - 128) } ?: opts.first()
        else -> opts.first()
    }

    /** User-Agent yang cocok dengan klien YouTube yang menerbitkan URL (parameter c=). */
    fun userAgentFor(url: String): String = when {
        url.contains("c=IOS") -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        url.contains("c=ANDROID_VR") -> "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
        url.contains("c=ANDROID") -> "com.google.android.youtube/19.28.35 (Linux; U; Android 15; GB) gzip"
        else -> NpDownloader.UA_FIREFOX
    }
}

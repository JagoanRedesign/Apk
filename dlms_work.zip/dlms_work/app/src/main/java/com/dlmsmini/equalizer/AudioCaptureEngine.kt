package com.dlmsmini.equalizer

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AudioEffect
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow

/** AudioPlaybackCapture copies eligible app audio. It cannot mute/replace the source app's original stream. */
class AudioCaptureEngine(
    context: Context,
    resultCode: Int,
    data: Intent,
    private val onStatus: (String) -> Unit
) {
    private val app = context.applicationContext
    private val projection: MediaProjection
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private val running = AtomicBoolean(false)
    @Volatile private var gains = IntArray(10)
    @Volatile private var eqOn = true
    @Volatile private var limiterOn = false
    @Volatile private var attackMs = 10
    @Volatile private var releaseMs = 100
    @Volatile private var ratio = 20
    @Volatile private var thresholdDb = -3
    @Volatile private var postGainDb = 0
    private val sampleRate = 48000
    private val centers = doubleArrayOf(31.0,62.0,125.0,250.0,500.0,1000.0,2000.0,4000.0,8000.0,16000.0)
    private val z1 = DoubleArray(10); private val z2 = DoubleArray(10)
    private val a0 = DoubleArray(10); private val a1 = DoubleArray(10); private val a2 = DoubleArray(10); private val b1 = DoubleArray(10); private val b2 = DoubleArray(10)
    private var envelope = 0.0

    init {
        if (Build.VERSION.SDK_INT < 29) throw IllegalStateException("AudioPlaybackCapture memerlukan Android 10 atau lebih baru")
        val manager = app.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data) ?: throw IllegalStateException("MediaProjection tidak tersedia")
        projection.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stop() } }, android.os.Handler(app.mainLooper))
    }

    fun setParameters(bands: IntArray, eq: Boolean, limiter: Boolean, attack: Int, release: Int, ratioValue: Int, threshold: Int, postGain: Int) {
        gains = bands.copyOf(); eqOn = eq; limiterOn = limiter; attackMs = attack; releaseMs = release; ratio = ratioValue; thresholdDb = threshold; postGainDb = postGain
        updateCoefficients()
    }

    @Synchronized private fun updateCoefficients() {
        for (i in 0 until 10) {
            val a = 10.0.pow((gains[i] / 2.0) / 40.0)
            val w0 = 2.0 * PI * centers[i].coerceAtMost(18000.0) / sampleRate
            val alpha = kotlin.math.sin(w0) / (2.0 * 1.0)
            val cos = kotlin.math.cos(w0)
            val norm = 1.0 + alpha / a
            a0[i] = (1.0 + alpha * a) / norm; a1[i] = (-2.0 * cos) / norm; a2[i] = (1.0 - alpha * a) / norm
            b1[i] = (-2.0 * cos) / norm; b2[i] = (1.0 - alpha / a) / norm
        }
    }

    fun start() {
        if (!running.compareAndSet(false, true)) return
        try {
            val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val config = android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
            val minIn = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val bufferBytes = (minIn.coerceAtLeast(4096) * 2)
            recorder = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(bufferBytes).setAudioPlaybackCaptureConfig(config).build()
            val outFormat = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(outFormat).setBufferSizeInBytes(minOut.coerceAtLeast(8192) * 2).setTransferMode(AudioTrack.MODE_STREAM).build()
            recorder?.startRecording(); track?.play()
            Thread({ loop() }, "dlms-audio-capture").apply { isDaemon = true; start() }
        } catch (e: Exception) { running.set(false); release(); throw e }
    }

    private fun loop() {
        val pcm = ShortArray(2048)
        while (running.get()) {
            val count = recorder?.read(pcm, 0, pcm.size) ?: -1
            if (count <= 0) { if (count < 0) onStatus("capture error $count"); continue }
            val out = ShortArray(count)
            val localGains = gains.copyOf()
            val atk = exp(-1.0 / (sampleRate * attackMs.coerceAtLeast(1) / 1000.0))
            val rel = exp(-1.0 / (sampleRate * releaseMs.coerceAtLeast(1) / 1000.0))
            val post = 10.0.pow(postGainDb / 20.0)
            for (n in 0 until count) {
                var x = pcm[n] / 32768.0
                if (eqOn) {
                    for (band in 0 until 10) {
                        val y = a0[band] * x + z1[band]
                        z1[band] = a1[band] * x - b1[band] * y + z2[band]
                        z2[band] = a2[band] * x - b2[band] * y
                        x = y
                    }
                }
                if (limiterOn) {
                    val absX = kotlin.math.abs(x)
                    envelope = if (absX > envelope) atk * envelope + (1.0 - atk) * absX else rel * envelope + (1.0 - rel) * absX
                    val threshold = 10.0.pow(thresholdDb / 20.0)
                    if (envelope > threshold && envelope > 0.0) {
                        val overDb = 20.0 * kotlin.math.log10(envelope / threshold)
                        val reductionDb = overDb * (1.0 - 1.0 / ratio.coerceAtLeast(1))
                        x *= 10.0.pow(-reductionDb / 20.0)
                    }
                }
                x *= post
                out[n] = (x.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
            }
            track?.write(out, 0, count, AudioTrack.WRITE_BLOCKING)
        }
    }

    fun stop() { if (running.getAndSet(false)) { try { recorder?.stop() } catch (_: Exception) {} }; release() }
    @Synchronized private fun release() {
        try { recorder?.release() } catch (_: Exception) {}; recorder = null
        try { track?.pause(); track?.flush(); track?.release() } catch (_: Exception) {}; track = null
        try { projection.stop() } catch (_: Exception) {}
    }
}

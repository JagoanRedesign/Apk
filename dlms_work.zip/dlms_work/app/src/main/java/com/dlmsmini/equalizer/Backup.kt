package com.dlmsmini.equalizer

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

/**
 * Backup & restore seluruh pengaturan: EQ, limiter, efek, volume, master, preset kustom, riwayat, pengaturan aplikasi.
 * Format: JSON teks "DLMS-BACKUP" dengan tipe nilai tersimpan (b/i/l/f/s), dapat disimpan ke berkas atau disalin.
 */
object Backup {
    const val FORMAT = "DLMS-BACKUP"
    const val VERSION = 1
    private const val MAX_CHARS = 2_000_000

    class Result(val ok: Boolean, val restored: Int, val skipped: Int, val message: String)

    fun export(ctx: Context): String {
        val p = Store.prefs(ctx)
        val data = JSONObject()
        for ((k, v) in p.all) {
            if (!Store.isBackupKey(k) || v == null) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is String -> o.put("t", "s").put("v", v)
                else -> continue
            }
            data.put(k, o)
        }
        val version = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "-" } catch (_: Exception) { "-" }
        return JSONObject()
            .put("format", FORMAT)
            .put("version", VERSION)
            .put("app", "DLMS Mini Equalizer $version")
            .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("created", System.currentTimeMillis())
            .put("prefs", data)
            .toString(1)
    }

    fun restore(ctx: Context, text: String): Result {
        if (text.length > MAX_CHARS) return Result(false, 0, 0, "Berkas terlalu besar")
        val root = try { JSONObject(text.trim()) } catch (_: Exception) {
            return Result(false, 0, 0, "Bukan berkas backup yang valid")
        }
        if (root.optString("format") != FORMAT) return Result(false, 0, 0, "Bukan berkas backup DLMS")
        if (root.optInt("version", 0) > VERSION) return Result(false, 0, 0, "Backup dibuat oleh versi aplikasi yang lebih baru")
        val data = root.optJSONObject("prefs") ?: return Result(false, 0, 0, "Isi backup kosong")

        val p = Store.prefs(ctx)
        val e = p.edit()
        // Pulihkan = ganti penuh.
        p.all.keys.filter { Store.isBackupKey(it) }.forEach { e.remove(it) }
        var ok = 0
        var skipped = 0
        val keys = data.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val o = data.optJSONObject(k)
            if (o == null || !Store.isBackupKey(k)) { skipped++; continue }
            try {
                when (o.getString("t")) {
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "l" -> e.putLong(k, o.getLong("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> {
                        val sv = o.getString("v")
                        // Kunci JSON harus bisa diparse bila bertipe daftar/objek; nilai rusak dilewati.
                        if (k == Store.KEY_PRESET_HISTORY) JSONArray(sv)
                        e.putString(k, sv)
                    }
                    else -> { skipped++; continue }
                }
                ok++
            } catch (_: Exception) {
                skipped++
            }
        }
        e.commit()
        return Result(true, ok, skipped, "Dipulihkan $ok pengaturan" + if (skipped > 0) " ($skipped dilewati)" else "")
    }
}

package com.dlmsmini.equalizer.music

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Satu kandidat lirik dari LRCLIB (https://lrclib.net). */
data class LyricsCandidate(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationSec: Int,
    val instrumental: Boolean,
    val synced: String?,
    val plain: String?
) {
    val hasSynced: Boolean get() = !synced.isNullOrBlank()
    val hasText: Boolean get() = hasSynced || !plain.isNullOrBlank()
}

class LrcLine(val timeMs: Long, val text: String)

object LrcParser {
    private val STAMP = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    /** Mengurai teks LRC. Baris tanpa cap waktu (mis. [ar:...]) diabaikan. Hasil terurut menurut waktu. */
    fun parse(lrc: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (raw in lrc.lines()) {
            val stamps = STAMP.findAll(raw).toList()
            if (stamps.isEmpty()) continue
            val text = raw.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out.add(LrcLine(min * 60_000 + sec * 1000 + ms, text))
            }
        }
        out.sortBy { it.timeMs }
        return out
    }

    /** Indeks baris yang sedang dinyanyikan pada [posMs]; -1 bila belum mulai. */
    fun indexAt(lines: List<LrcLine>, posMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }
}

/** Klien LRCLIB + cache di basis data. Semua fungsi blocking. */
object LrcLib {
    private const val BASE = "https://lrclib.net/api"
    private const val TOLERANCE_SEC = 6

    private fun parse(o: JSONObject) = LyricsCandidate(
        id = o.optLong("id"),
        title = o.optString("trackName"),
        artist = o.optString("artistName"),
        album = o.optString("albumName"),
        durationSec = Math.round(o.optDouble("duration", 0.0)).toInt(),
        instrumental = o.optBoolean("instrumental", false),
        synced = if (o.isNull("syncedLyrics")) null else o.optString("syncedLyrics").ifBlank { null },
        plain = if (o.isNull("plainLyrics")) null else o.optString("plainLyrics").ifBlank { null }
    )

    private fun searchRaw(query: String): List<LyricsCandidate> {
        val arr = JSONArray(Http.get(query, timeoutMs = 12000))
        val out = ArrayList<LyricsCandidate>()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(parse(it)) }
        return out
    }

    /** Pencarian bebas (untuk dialog pencarian manual). */
    fun search(q: String): List<LyricsCandidate> = searchRaw("$BASE/search?q=${q.enc()}")

    /** Kandidat awal untuk sebuah lagu: pencarian terstruktur, lalu bebas. */
    fun candidatesFor(t: Track): List<LyricsCandidate> {
        val (title, artist) = TitleClean.forLyrics(t.title, t.artist)
        val a = try { searchRaw("$BASE/search?track_name=${title.enc()}&artist_name=${artist.enc()}") } catch (_: Exception) { emptyList() }
        if (a.isNotEmpty()) return a
        return try { search("$title $artist") } catch (_: Exception) { emptyList() }
    }

    /** Pilih kandidat yang durasinya cocok; utamakan yang bertimestamp. Null bila tidak ada yang meyakinkan. */
    fun pickBest(cands: List<LyricsCandidate>, durationSec: Int): LyricsCandidate? {
        val usable = cands.filter { it.hasText || it.instrumental }
        val near = if (durationSec > 0) usable.filter { abs(it.durationSec - durationSec) <= TOLERANCE_SEC } else usable
        return near.sortedWith(
            compareByDescending<LyricsCandidate> { it.hasSynced }
                .thenBy { if (durationSec > 0) abs(it.durationSec - durationSec) else 0 }
        ).firstOrNull()
    }

    /** Lirik untuk lagu: dari cache (termasuk pilihan manual), atau otomatis dari LRCLIB lalu disimpan. */
    fun lyricsFor(ctx: Context, t: Track): LyricsCandidate? {
        val db = MusicDb.get(ctx)
        db.getLyrics(t.id)?.let { return it }
        val best = pickBest(candidatesFor(t), t.durationSec) ?: return null
        db.saveLyrics(t.id, best, manual = false)
        return best
    }

    fun choose(ctx: Context, t: Track, c: LyricsCandidate) = MusicDb.get(ctx).saveLyrics(t.id, c, manual = true)

    /** Teks yang akan ditanam ke berkas audio. */
    fun textForEmbed(c: LyricsCandidate, preferSynced: Boolean): String? =
        if (preferSynced && c.hasSynced) c.synced else (c.plain ?: c.synced?.let { stripStamps(it) })

    fun stripStamps(lrc: String): String =
        LrcParser.parse(lrc).joinToString("\n") { it.text }
}

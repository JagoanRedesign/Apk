package com.dlmsmini.equalizer.music

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Pemutar penuh: sampul, kontrol, seek, lirik tersinkron, simpan & unduh. */
class NowPlayingActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var current: Track? = null
    private var lyricsJob: Job? = null
    private var dragging = false

    private lateinit var cover: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var seek: SeekBar
    private lateinit var posText: TextView
    private lateinit var durText: TextView
    private lateinit var play: TextView
    private lateinit var shuffle: TextView
    private lateinit var repeat: TextView
    private lateinit var save: TextView
    private lateinit var lyrics: LyricsPanel

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { sync() }
    }

    private val tick = object : Runnable {
        override fun run() {
            controller?.let { c ->
                val dur = if (c.duration > 0) c.duration else (current?.durationSec ?: 0) * 1000L
                if (!dragging && dur > 0) {
                    seek.progress = (c.currentPosition * 1000 / dur).toInt().coerceIn(0, 1000)
                    posText.text = fmtTime((c.currentPosition / 1000).toInt())
                }
                durText.text = fmtTime((dur / 1000).toInt())
                lyrics.update(c.currentPosition)
            }
            handler.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.BG) }
        Ui.fitSystemBars(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Icons.view(this, Icons.DOWN, 18f, Pal.TEXT, "Tutup").apply { setOnClickListener { finish() } })
        top.addView(Ui.label(this, "Sedang diputar", 14f, Pal.MUTED, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        save = Icons.view(this, Icons.HEART, 18f, Pal.MUTED, "Simpan").apply { setOnClickListener { toggleSave() } }
        top.addView(save)
        top.addView(Icons.view(this, Icons.MIX, 18f, Pal.CYAN, "Mix").apply { setOnClickListener { controller?.let { c -> MixUi.start(this@NowPlayingActivity, scope, c) } } })
        top.addView(Icons.view(this, Icons.QUEUE, 18f, Pal.TEXT, "Antrean").apply { setOnClickListener { startActivity(android.content.Intent(this@NowPlayingActivity, QueueActivity::class.java)) } })
        top.addView(Icons.view(this, Icons.DOWNLOAD, 18f, Pal.TEXT, "Unduh").apply { setOnClickListener { download() } })
        root.addView(top)

        val info = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@NowPlayingActivity, 16), Ui.dp(this@NowPlayingActivity, 6), Ui.dp(this@NowPlayingActivity, 16), Ui.dp(this@NowPlayingActivity, 6)) }
        cover = Img.cover(this, 84, 12)
        info.addView(cover)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@NowPlayingActivity, 14), 0, 0, 0) }
        title = Ui.label(this, "", 18f, Pal.TEXT, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        artist = Ui.label(this, "", 14f, Pal.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(title); col.addView(artist)
        info.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(info)

        // Lirik mengisi sisa ruang.
        val lyricsHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@NowPlayingActivity, 16), 0, Ui.dp(this@NowPlayingActivity, 8), 0) }
        lyricsHead.addView(Ui.label(this, "LIRIK", 12f, Pal.CYAN, true), LinearLayout.LayoutParams(0, -2, 1f))
        lyricsHead.addView(Ui.chip(this, "Cari lirik").apply { setOnClickListener { pickLyrics() } })
        root.addView(lyricsHead)
        lyrics = LyricsPanel(this).apply { onSeek = { ms -> controller?.seekTo(ms) } }
        root.addView(lyrics, LinearLayout.LayoutParams(-1, 0, 1f))

        // Seek + kontrol.
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@NowPlayingActivity, 16), 0, Ui.dp(this@NowPlayingActivity, 16), 0) }
        posText = Ui.label(this, "0:00", 12f, Pal.MUTED)
        durText = Ui.label(this, "0:00", 12f, Pal.MUTED)
        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val dur = controller?.duration ?: 0L
                        posText.text = fmtTime((dur * p / 1000 / 1000).toInt())
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    controller?.let { c -> if (c.duration > 0) c.seekTo(c.duration * (s?.progress ?: 0) / 1000) }
                    dragging = false
                }
            })
        }
        bar.addView(posText)
        bar.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(durText)
        root.addView(bar)

        val ctl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, Ui.dp(this@NowPlayingActivity, 4), 0, Ui.dp(this@NowPlayingActivity, 12)) }
        shuffle = Icons.view(this, Icons.SHUFFLE, 18f, Pal.MUTED, "Acak").apply { setOnClickListener { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } } }
        play = Icons.view(this, Icons.PLAY, 28f, Pal.CYAN, "Putar/Jeda").apply {
            setPadding(Ui.dp(this@NowPlayingActivity, 22), Ui.dp(this@NowPlayingActivity, 16), Ui.dp(this@NowPlayingActivity, 22), Ui.dp(this@NowPlayingActivity, 16))
            setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        }
        repeat = Icons.view(this, Icons.REPEAT, 18f, Pal.MUTED, "Ulangi").apply {
            setOnClickListener {
                controller?.let {
                    it.repeatMode = when (it.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }
            }
        }
        ctl.addView(shuffle)
        ctl.addView(Icons.view(this, Icons.PREV, 22f, Pal.TEXT, "Sebelumnya").apply { setOnClickListener { controller?.seekToPrevious() } })
        ctl.addView(play)
        ctl.addView(Icons.view(this, Icons.NEXT, 22f, Pal.TEXT, "Berikutnya").apply { setOnClickListener { controller?.seekToNext() } })
        ctl.addView(repeat)
        root.addView(ctl)
        setContentView(root)
        lyrics.message("Belum ada lagu yang diputar")
    }

    override fun onStart() {
        super.onStart()
        MusicClient.get(this) { c ->
            controller = c
            c.addListener(listener)
            sync()
        }
        handler.post(tick)
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        controller?.removeListener(listener)
        controller = null
        super.onStop()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun sync() {
        val c = controller ?: return
        play.text = if (c.isPlaying) Icons.PAUSE else Icons.PLAY
        shuffle.setTextColor(if (c.shuffleModeEnabled) Pal.CYAN else Pal.MUTED)
        repeat.setTextColor(if (c.repeatMode != Player.REPEAT_MODE_OFF) Pal.CYAN else Pal.MUTED)
        repeat.text = Icons.REPEAT
        val item = c.currentMediaItem
        if (item == null) { current = null; return }
        val t = item.toTrack()
        if (t.id == current?.id) return
        current = t
        title.text = t.title
        artist.text = t.artist
        Img.load(cover, t.thumb, 200)
        seek.progress = 0
        refreshSaveIcon(t)
        loadLyrics(t)
    }

    private fun refreshSaveIcon(t: Track) {
        scope.launch {
            val inLib = withContext(Dispatchers.IO) { MusicDb.get(applicationContext).contains(t.id) }
            if (current?.id == t.id) save.setTextColor(if (inLib) Pal.CYAN else Pal.MUTED)
        }
    }

    private fun toggleSave() {
        val t = current ?: return
        scope.launch {
            val added = withContext(Dispatchers.IO) {
                val db = MusicDb.get(applicationContext)
                if (db.contains(t.id)) { if (t.source == Track.SRC_STREAM) db.delete(t.id); false } else { db.upsert(t); true }
            }
            Toast.makeText(this@NowPlayingActivity, if (added) "Disimpan ke perpustakaan" else "Dihapus dari perpustakaan", Toast.LENGTH_SHORT).show()
            refreshSaveIcon(t)
        }
    }

    private fun download() {
        val t = current ?: return
        if (t.source != Track.SRC_STREAM) { Toast.makeText(this, "Lagu ini sudah ada di perangkat", Toast.LENGTH_SHORT).show(); return }
        DownloadDialog.show(this, scope, t)
    }

    private fun pickLyrics() {
        val t = current ?: return
        LyricsPicker.show(this, scope, t) { showLyrics(it) }
    }

    private fun loadLyrics(t: Track) {
        lyricsJob?.cancel()
        lyrics.message("Memuat lirik…")
        lyricsJob = scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { LrcLib.lyricsFor(applicationContext, t) } }
            if (current?.id != t.id) return@launch
            val c = r.getOrNull()
            if (c == null) lyrics.message(if (r.isFailure) "Gagal memuat lirik (periksa koneksi)" else "Lirik tidak ditemukan.\nKetuk “Cari lirik” untuk memilih manual.")
            else showLyrics(c)
        }
    }

    private fun showLyrics(c: LyricsCandidate) {
        when {
            c.instrumental -> lyrics.message("♪ Instrumental")
            c.hasSynced -> lyrics.synced(LrcParser.parse(c.synced!!))
            !c.plain.isNullOrBlank() -> lyrics.plain(c.plain)
            else -> lyrics.message("Lirik kosong")
        }
    }
}

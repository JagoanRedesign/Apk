package com.dlmsmini.equalizer.music

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Layar musik: Cari (hasil tanpa batas), Perpustakaan, Unduhan, plus mini-player. */
class MusicActivity : AppCompatActivity() {
    companion object { const val EXTRA_TAB = "tab" }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var rv: RecyclerView
    private lateinit var input: EditText
    private lateinit var adapter: MusicAdapter
    private val tabViews = ArrayList<TextView>()

    private var tab = 0
    private var session: SearchSession? = null
    private var searchJob: Job? = null
    private val results = ArrayList<Track>()
    private var videoLinkRaw: String? = null

    // Riwayat & saran pencarian, plus cache hasil supaya pencarian berulang langsung tampil.
    private var suggestOn = false
    private var suggestJob: Job? = null
    private var onlineSug: List<String> = emptyList()
    private val sugCache = HashMap<String, List<String>>()
    private class CachedSearch(val results: List<Track>, val session: SearchSession, val at: Long)
    private val searchCache = object : LinkedHashMap<String, CachedSearch>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedSearch>?): Boolean = size > 8
    }
    private var searching = false
    private var searchError: String? = null

    private var playlists: List<PlaylistInfo> = emptyList()
    private var openPl: PlaylistInfo? = null
    private var plTracks: List<Track> = emptyList()

    private var libFilter = 0
    private var library: List<Track> = emptyList()

    // mini-player
    private lateinit var mini: LinearLayout
    private lateinit var miniCover: android.widget.ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniPlay: TextView
    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { syncMini() }
    }
    private val dlListener: () -> Unit = { if (tab == 3) render() }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scanDevice() else Toast.makeText(this, "Izin baca audio ditolak", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NewPipeBridge.warmUp()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.BG) }
        Ui.fitSystemBars(root)
        root.addView(buildHeader())
        root.addView(buildSearchRow())
        root.addView(buildTabs())

        adapter = MusicAdapter(
            onTrack = { t -> onTrackClick(t) },
            onMore = { t, anchor -> showMenu(t, anchor) },
            onCancel = { j -> j.cancel = true; if (j.state == DlState.QUEUED) j.state = DlState.CANCELED; DownloadCenter.changed() }
        )
        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MusicActivity)
            adapter = this@MusicActivity.adapter
            clipToPadding = false
            isFocusableInTouchMode = true
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) {
                    if (tab != 0 || suggestOn || dy <= 0) return
                    val lm = r.layoutManager as LinearLayoutManager
                    if (lm.findLastVisibleItemPosition() >= this@MusicActivity.adapter.itemCount - 6) loadMore()
                }
            })
        }
        root.addView(FrameLayout(this).apply { addView(rv, FrameLayout.LayoutParams(-1, -1)) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildMini())
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (suggestOn) dismissSuggest()
                else if (tab == 2 && openPl != null) { openPl = null; render() }
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        tab = intent.getIntExtra(EXTRA_TAB, 0).coerceIn(0, 3)
        updateTabs()
        render()
        if (tab == 1) loadLibrary()
        if (tab == 2) loadPlaylists()
    }

    override fun onStart() {
        super.onStart()
        DownloadCenter.addListener(dlListener)
        MusicClient.get(this) { c ->
            controller = c
            c.addListener(playerListener)
            syncMini()
        }
    }

    override fun onStop() {
        DownloadCenter.removeListener(dlListener)
        controller?.removeListener(playerListener)
        controller = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1) loadLibrary()
        if (tab == 2) loadPlaylists()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---------- bagian atas ----------

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 4), 0) }
        h.addView(Icons.view(this, Icons.BACK, 18f, Pal.TEXT, "Kembali").apply { setOnClickListener { finish() } })
        h.addView(Ui.label(this, "Musik", 20f, Pal.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(Icons.view(this, Icons.GEAR, 18f, Pal.MUTED, "Pengaturan musik").apply { setOnClickListener { MusicSettingsDialog.show(this@MusicActivity) } })
        return h
    }

    private fun buildSearchRow(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@MusicActivity, 12), Ui.dp(this@MusicActivity, 8), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 4)) }
        input = EditText(this).apply {
            hint = "Cari lagu, artis…"
            setHintTextColor(Pal.MUTED)
            setTextColor(Pal.TEXT)
            textSize = 15f
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = Ui.rounded(this@MusicActivity, Pal.PANEL, 16, Pal.PANEL_STROKE)
            setPadding(Ui.dp(this@MusicActivity, 14), Ui.dp(this@MusicActivity, 10), Ui.dp(this@MusicActivity, 14), Ui.dp(this@MusicActivity, 10))
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { startSearch(text.toString()); true } else false }
            setOnFocusChangeListener { _, has ->
                suggestOn = has && tab == 0
                if (suggestOn) refreshSuggestions() else render()
            }
            setOnClickListener { if (!suggestOn && tab == 0) { suggestOn = true; refreshSuggestions() } }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) { if (suggestOn) refreshSuggestions() }
            })
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Icons.view(this, Icons.SEARCH, 18f, Pal.CYAN, "Cari").apply { setOnClickListener { startSearch(input.text.toString()) } })
        return row
    }

    private fun buildTabs(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(this@MusicActivity, 12), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 12), Ui.dp(this@MusicActivity, 4)) }
        listOf("Cari", "Pustaka", "Playlist", "Unduhan").forEachIndexed { i, name ->
            val chip = Ui.chip(this, name, i == 0)
            chip.setOnClickListener { tab = i; updateTabs(); if (i == 1) loadLibrary() else if (i == 2) loadPlaylists() else render() }
            tabViews.add(chip)
            row.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(this@MusicActivity, 6) })
        }
        return row
    }

    private fun updateTabs() { tabViews.forEachIndexed { i, v -> Ui.setChipSelected(v, i == tab) } }

    private fun buildMini(): View {
        mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(this@MusicActivity, Pal.PANEL, 0, Pal.PANEL_STROKE)
            setPadding(Ui.dp(this@MusicActivity, 10), Ui.dp(this@MusicActivity, 8), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 8))
            visibility = View.GONE
            setOnClickListener { startActivity(android.content.Intent(this@MusicActivity, NowPlayingActivity::class.java)) }
        }
        miniCover = Img.cover(this, 44)
        mini.addView(miniCover)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@MusicActivity, 10), 0, Ui.dp(this@MusicActivity, 6), 0) }
        miniTitle = Ui.label(this, "", 14f, Pal.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        miniSub = Ui.label(this, "", 12f, Pal.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(miniTitle); col.addView(miniSub)
        mini.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = Icons.view(this, Icons.PLAY, 20f, Pal.TEXT, "Putar/Jeda").apply { setOnClickListener { controller?.let { c -> if (c.isPlaying) c.pause() else c.play() } } }
        mini.addView(miniPlay)
        mini.addView(Icons.view(this, Icons.NEXT, 18f, Pal.TEXT, "Berikutnya").apply { setOnClickListener { controller?.seekToNext() } })
        return mini
    }

    private fun syncMini() {
        val c = controller ?: return
        val item: MediaItem? = c.currentMediaItem
        if (item == null) { mini.visibility = View.GONE; adapter.setPlaying(null); return }
        mini.visibility = View.VISIBLE
        val t = item.toTrack()
        miniTitle.text = t.title
        miniSub.text = t.artist
        Img.load(miniCover, t.thumb, 96)
        miniPlay.text = if (c.isPlaying) Icons.PAUSE else Icons.PLAY
        adapter.setPlaying(t.id)
    }

    // ---------- pencarian ----------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun startSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        // Tautan playlist YouTube yang ditempel di kolom cari: tawarkan impor, bukan dicari sebagai teks.
        if (PlaylistImport.normalize(query) != null) {
            dismissSuggest()
            showImportDialog(query)
            return
        }
        // Tautan video YouTube: tampilkan videonya di urutan pertama, disusul lagu terkait.
        VideoLink.extractId(query)?.let { id -> searchVideoLink(id, query); return }
        videoLinkRaw = null
        dismissSuggest()
        MusicPrefs.setLastQuery(this, query)
        MusicPrefs.addSearchHistory(this, query)
        tab = 0
        updateTabs()
        searchJob?.cancel()
        searchError = null
        searching = false
        // Pencarian yang sama dalam 10 menit terakhir: tampilkan langsung dari cache.
        val hit = searchCache[query.lowercase()]
        if (hit != null && System.currentTimeMillis() - hit.at < 10 * 60_000L) {
            results.clear()
            results.addAll(hit.results)
            session = hit.session
            render()
            rv.scrollToPosition(0)
            return
        }
        results.clear()
        session = SearchSession(applicationContext, query)
        loadMore()
    }

    private fun searchVideoLink(videoId: String, raw: String) {
        dismissSuggest()
        videoLinkRaw = raw
        tab = 0
        updateTabs()
        searchJob?.cancel()
        results.clear()
        searchError = null
        val s = SearchSession(applicationContext, raw).also { it.markDone() }
        session = s
        searching = true
        render()
        searchJob = scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { VideoLink.fetch(videoId) } }
            if (s !== session) return@launch
            searching = false
            r.onSuccess { results.addAll(it); searchError = null }
                .onFailure { searchError = "Video tidak ditemukan atau tidak bisa dibuka (${it.message ?: "periksa koneksi"})" }
            render()
            rv.scrollToPosition(0)
        }
    }

    // ---------- saran pencarian ----------

    private fun dismissSuggest() {
        suggestOn = false
        hideKeyboard()
        rv.requestFocus()
    }

    private fun refreshSuggestions() {
        suggestJob?.cancel()
        val q = input.text.toString().trim()
        if (q.length < 2) { onlineSug = emptyList(); render(); return }
        sugCache[q.lowercase()]?.let { onlineSug = it; render(); return }
        render() // riwayat langsung tampil, saran online menyusul
        suggestJob = scope.launch {
            delay(250)
            val r = withContext(Dispatchers.IO) {
                runCatching { NewPipeBridge.service().suggestionExtractor.suggestionList(q) }.getOrNull()
            } ?: return@launch
            sugCache[q.lowercase()] = r
            if (suggestOn && input.text.toString().trim() == q) { onlineSug = r; render() }
        }
    }

    private fun renderSuggestions(rows: ArrayList<Row>) {
        val q = input.text.toString().trim()
        val hist = MusicPrefs.searchHistory(this)
        val h = if (q.isEmpty()) hist.take(12) else hist.filter { it.contains(q, ignoreCase = true) && !it.equals(q, ignoreCase = true) }.take(5)
        if (q.isEmpty() && h.isNotEmpty()) {
            rows.add(Row.Chips(listOf("Hapus semua riwayat" to { MusicPrefs.clearSearchHistory(this); render() })))
        }
        h.forEach { t ->
            rows.add(Row.Suggest(t, true, { input.setText(t); startSearch(t) }, { fillInput(t) }, { MusicPrefs.removeSearchHistory(this, t); render() }))
        }
        val seen = h.map { it.lowercase() }.toHashSet()
        onlineSug.filter { seen.add(it.lowercase()) }.take(8).forEach { t ->
            rows.add(Row.Suggest(t, false, { input.setText(t); startSearch(t) }, { fillInput(t) }, null))
        }
        if (rows.none { it is Row.Suggest }) {
            rows.add(Row.Info(if (q.isEmpty()) "Belum ada riwayat pencarian." else "Ketuk ikon cari untuk mencari “$q”"))
        } else {
            rows.add(Row.Info("Tahan sebuah saran untuk memasukkannya ke kolom cari tanpa mencari."))
        }
    }

    private fun fillInput(t: String) {
        input.setText(t)
        input.setSelection(t.length)
    }

    private fun loadMore() {
        val s = session ?: return
        if (searching || s.exhausted) return
        searching = true
        render()
        searchJob = scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { s.loadMore() } }
            if (s !== session) return@launch
            searching = false
            r.onSuccess {
                results.addAll(it); searchError = null
                if (results.isNotEmpty()) {
                    val key = s.query.lowercase()
                    searchCache[key] = CachedSearch(ArrayList(results), s, searchCache[key]?.at ?: System.currentTimeMillis())
                }
            }.onFailure { searchError = it.message ?: "Gagal mencari" }
            render()
        }
    }

    // ---------- perpustakaan ----------

    private fun loadLibrary() {
        scope.launch {
            val src = when (libFilter) { 1 -> Track.SRC_DOWNLOAD; 2 -> Track.SRC_STREAM; 3 -> Track.SRC_DEVICE; else -> null }
            library = withContext(Dispatchers.IO) { MusicDb.get(applicationContext).list(src) }
            if (tab == 1) render()
        }
    }

    private fun scanDevice() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(perm)
            return
        }
        Toast.makeText(this, "Memindai musik di perangkat…", Toast.LENGTH_SHORT).show()
        scope.launch {
            val n = withContext(Dispatchers.IO) {
                val found = ArrayList<Track>()
                val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION
                )
                try {
                    contentResolver.query(coll, proj, "${MediaStore.Audio.Media.IS_MUSIC}=1 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
                        while (c.moveToNext()) {
                            val id = c.getLong(0)
                            val uri = ContentUris.withAppendedId(coll, id).toString()
                            val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: ""
                            found.add(
                                Track(
                                    id = "local:$id", title = c.getString(1) ?: "Tanpa judul", artist = artist, album = c.getString(3) ?: "",
                                    durationSec = (c.getLong(4) / 1000).toInt(), thumb = uri, source = Track.SRC_DEVICE, uri = uri
                                )
                            )
                        }
                    }
                } catch (_: Exception) {
                }
                MusicDb.get(applicationContext).replaceDeviceTracks(found)
                found.size
            }
            Toast.makeText(this@MusicActivity, "$n lagu ditemukan", Toast.LENGTH_SHORT).show()
            libFilter = 3
            loadLibrary()
        }
    }

    // ---------- tampilan daftar ----------

    private fun render() {
        val rows = ArrayList<Row>()
        if (tab != 0) suggestOn = false
        when (tab) {
            0 -> if (suggestOn) renderSuggestions(rows) else {
                results.forEach { rows.add(Row.TrackRow(it)) }
                val s = session
                when {
                    s == null -> rows.add(Row.Info("Ketik judul lagu atau nama artis, atau tempel tautan video YouTube, lalu cari.\nHasil resmi (YouTube Music, kanal Topic/VEVO) ditampilkan lebih dulu dan dimuat terus saat menggulir."))
                    searchError != null -> rows.add(Row.Info("${searchError}\nKetuk untuk mencoba lagi") { searchError = null; val v = videoLinkRaw; if (v != null) startSearch(v) else loadMore() })
                    searching -> rows.add(Row.Loading)
                    results.isEmpty() && s.exhausted -> rows.add(Row.Info("Tidak ada hasil untuk “${s.query}”"))
                    s.exhausted -> rows.add(Row.Info("— akhir hasil —"))
                }
            }
            1 -> {
                rows.add(Row.Filters(libFilter, { libFilter = it; loadLibrary() }, { scanDevice() }))
                library.forEach { rows.add(Row.TrackRow(it)) }
                if (library.isEmpty()) rows.add(Row.Info("Perpustakaan kosong.\nSimpan lagu lewat menu ⋮ di hasil pencarian, unduh, atau pindai musik di perangkat."))
            }
            2 -> renderPlaylists(rows)
            else -> {
                DownloadCenter.jobs.forEach { rows.add(Row.Job(it)) }
                if (DownloadCenter.jobs.isEmpty()) rows.add(Row.Info("Belum ada unduhan."))
                else rows.add(Row.Info("Bersihkan yang selesai") { DownloadCenter.clearFinished() })
            }
        }
        adapter.submit(rows)
    }

    // ---------- playlist ----------

    private fun loadPlaylists() {
        scope.launch {
            val db = MusicDb.get(applicationContext)
            val pid = openPl?.id
            val (all, tracks) = withContext(Dispatchers.IO) { db.playlists() to (if (pid != null) db.playlistTracks(pid) else emptyList()) }
            playlists = all
            plTracks = tracks
            openPl = if (pid != null) all.firstOrNull { it.id == pid } else null
            if (tab == 2) render()
        }
    }

    private fun renderPlaylists(rows: ArrayList<Row>) {
        val pl = openPl
        if (pl == null) {
            rows.add(Row.Chips(listOf("＋ Playlist baru" to { promptPlaylistName(null, null) }, "Impor dari tautan" to { showImportDialog(null) })))
            playlists.forEach { p -> rows.add(Row.Playlist(p, { openPl = p; plTracks = emptyList(); loadPlaylists() }, { v -> playlistMenu(p, v) })) }
            if (playlists.isEmpty()) rows.add(Row.Info("Belum ada playlist.\nBuat playlist baru, impor dari tautan YouTube, atau simpan antrean dari layar Antrean."))
        } else {
            rows.add(
                Row.Chips(
                    listOf(
                        "‹ Semua" to { openPl = null; render() },
                        "▶ Putar" to { playOpen(false) },
                        "⤮ Acak" to { playOpen(true) },
                        "Ganti nama" to { promptPlaylistName(pl, null) },
                        "Hapus" to { confirmDeletePlaylist(pl) }
                    )
                )
            )
            rows.add(Row.Info("${pl.name} • ${plTracks.size} lagu"))
            plTracks.forEach { rows.add(Row.TrackRow(it)) }
            if (plTracks.isEmpty()) rows.add(Row.Info("Playlist kosong. Tambahkan lagu dari hasil pencarian atau perpustakaan."))
        }
    }

    private fun showImportDialog(prefill: String?) {
        val clip = try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString()
        } catch (_: Exception) {
            null
        }
        val init = prefill ?: clip?.takeIf { PlaylistImport.normalize(it) != null } ?: ""
        val et = EditText(this).apply { setText(init); hint = "Tempel tautan playlist YouTube"; setSingleLine() }
        val wrap = FrameLayout(this).apply { setPadding(Ui.dp(this@MusicActivity, 20), Ui.dp(this@MusicActivity, 8), Ui.dp(this@MusicActivity, 20), 0); addView(et) }
        AlertDialog.Builder(this).setTitle("Impor dari tautan YouTube").setView(wrap)
            .setMessage("Tempel tautan playlist (youtube.com/playlist?list=… atau tautan video yang memuat list=…). Playlist biasa maksimal 500 lagu, Mix YouTube maksimal ${PlaylistImport.MIX_LIMIT} lagu. Playlist pribadi tidak bisa diimpor.")
            .setNeutralButton("Hanya video ini") { _, _ ->
                val raw = et.text.toString()
                val id = VideoLink.extractId(raw)
                if (id != null) searchVideoLink(id, raw) else Toast.makeText(this, "Tidak ada tautan video di sini", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .setPositiveButton("Impor") { _, _ ->
                val url = PlaylistImport.normalize(et.text.toString())
                if (url == null) Toast.makeText(this, "Tautan playlist tidak dikenali", Toast.LENGTH_LONG).show() else runImport(url)
            }.show()
    }

    private fun runImport(url: String) {
        val holder = arrayOfNulls<Job>(1)
        val dlg = AlertDialog.Builder(this).setTitle("Mengimpor playlist").setMessage("Mengambil daftar lagu…")
            .setCancelable(false)
            .setNegativeButton("Batal") { d, _ -> holder[0]?.cancel(); d.dismiss() }
            .show()
        holder[0] = scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    PlaylistImport.fetch(url, onProgress = { n -> runOnUiThread { dlg.setMessage("$n lagu ditemukan…") } }, cancelled = { !isActive })
                }
            }
            dlg.dismiss()
            val imp = r.getOrNull()
            if (imp == null) {
                Toast.makeText(this@MusicActivity, "Gagal mengimpor: ${r.exceptionOrNull()?.message ?: "periksa koneksi atau playlist pribadi"}", Toast.LENGTH_LONG).show()
                return@launch
            }
            if (imp.tracks.isEmpty()) {
                Toast.makeText(this@MusicActivity, "Playlist kosong atau tidak bisa dibaca", Toast.LENGTH_LONG).show()
                return@launch
            }
            val id = withContext(Dispatchers.IO) { PlaylistSaver.createWith(applicationContext, imp.name, imp.tracks) }
            val capNote = if (imp.mix && imp.capped) " (batas Mix ${PlaylistImport.MIX_LIMIT} lagu)" else ""
            Toast.makeText(this@MusicActivity, "${imp.tracks.size} lagu diimpor ke “${imp.name}”$capNote", Toast.LENGTH_SHORT).show()
            tab = 2
            updateTabs()
            openPl = PlaylistInfo(id, imp.name, imp.tracks.size, "")
            plTracks = emptyList()
            loadPlaylists()
        }
    }

    private fun playOpen(shuffle: Boolean) {
        if (plTracks.isEmpty()) return
        MusicClient.play(this, if (shuffle) plTracks.shuffled() else plTracks, 0)
    }

    private fun promptPlaylistName(existing: PlaylistInfo?, addTrack: Track?) {
        val et = EditText(this).apply { setText(existing?.name ?: ""); hint = "Nama playlist"; setSingleLine() }
        val wrap = FrameLayout(this).apply { setPadding(Ui.dp(this@MusicActivity, 20), Ui.dp(this@MusicActivity, 8), Ui.dp(this@MusicActivity, 20), 0); addView(et) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "Playlist baru" else "Ganti nama playlist").setView(wrap)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                scope.launch {
                    val db = MusicDb.get(applicationContext)
                    withContext(Dispatchers.IO) {
                        if (existing == null) { val id = db.createPlaylist(name); if (addTrack != null) db.addToPlaylist(id, addTrack) }
                        else db.renamePlaylist(existing.id, name)
                    }
                    if (existing == null && addTrack != null) Toast.makeText(this@MusicActivity, "Ditambahkan ke “$name”", Toast.LENGTH_SHORT).show()
                    loadPlaylists()
                }
            }.show()
    }

    private fun confirmDeletePlaylist(p: PlaylistInfo) {
        AlertDialog.Builder(this).setTitle("Hapus playlist?").setMessage("“${p.name}” akan dihapus (lagunya tidak ikut terhapus).")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                scope.launch {
                    withContext(Dispatchers.IO) { MusicDb.get(applicationContext).deletePlaylist(p.id) }
                    if (openPl?.id == p.id) openPl = null
                    loadPlaylists()
                }
            }.show()
    }

    private fun playlistMenu(p: PlaylistInfo, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Putar"); pm.menu.add(0, 2, 1, "Acak"); pm.menu.add(0, 3, 2, "Ganti nama"); pm.menu.add(0, 4, 3, "Hapus")
        pm.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                1, 2 -> scope.launch {
                    val list = withContext(Dispatchers.IO) { MusicDb.get(applicationContext).playlistTracks(p.id) }
                    if (list.isNotEmpty()) MusicClient.play(this@MusicActivity, if (m.itemId == 2) list.shuffled() else list, 0)
                }
                3 -> promptPlaylistName(p, null)
                4 -> confirmDeletePlaylist(p)
            }
            true
        }
        pm.show()
    }

    private fun pickPlaylist(t: Track) {
        scope.launch {
            val list = withContext(Dispatchers.IO) { MusicDb.get(applicationContext).playlists() }
            val names = list.map { "${it.name} (${it.count})" } + "＋ Playlist baru…"
            AlertDialog.Builder(this@MusicActivity).setTitle("Tambah ke playlist")
                .setItems(names.toTypedArray()) { _, i ->
                    if (i == list.size) promptPlaylistName(null, t)
                    else scope.launch {
                        withContext(Dispatchers.IO) { MusicDb.get(applicationContext).addToPlaylist(list[i].id, t) }
                        Toast.makeText(this@MusicActivity, "Ditambahkan ke “${list[i].name}”", Toast.LENGTH_SHORT).show()
                        if (tab == 2) loadPlaylists()
                    }
                }.show()
        }
    }

    // ---------- aksi ----------

    private fun onTrackClick(t: Track) {
        val list: List<Track> = when (tab) { 0 -> results; 2 -> plTracks; else -> library }
        val idx = list.indexOfFirst { it.id == t.id }
        if (idx < 0) { MusicClient.play(this, listOf(t), 0); return }
        // Antrean = daftar yang sedang tampil, mulai dari lagu yang diketuk.
        MusicClient.play(this, list, idx)
    }

    private fun showMenu(t: Track, anchor: View) {
        val db = MusicDb.get(applicationContext)
        scope.launch {
            val inLib = withContext(Dispatchers.IO) { db.contains(t.id) }
            val pm = PopupMenu(this@MusicActivity, anchor)
            pm.menu.add(0, 1, 0, "Putar berikutnya")
            pm.menu.add(0, 2, 1, "Tambah ke antrean")
            if (t.source != Track.SRC_DEVICE) pm.menu.add(0, 3, 2, if (inLib) "Hapus dari perpustakaan" else "Simpan ke perpustakaan")
            if (t.source == Track.SRC_STREAM) pm.menu.add(0, 4, 3, "Unduh…")
            if (t.source == Track.SRC_DOWNLOAD) pm.menu.add(0, 5, 4, "Hapus berkas unduhan")
            pm.menu.add(0, 6, 5, "Cari lirik…")
            pm.menu.add(0, 7, 6, "Tambah ke playlist…")
            val inOpenPl = tab == 2 && openPl != null
            if (inOpenPl) pm.menu.add(0, 8, 7, "Hapus dari playlist")
            pm.setOnMenuItemClickListener { m ->
                when (m.itemId) {
                    1 -> MusicClient.playNext(this@MusicActivity, t)
                    2 -> MusicClient.enqueue(this@MusicActivity, t)
                    3 -> scope.launch {
                        val added = withContext(Dispatchers.IO) { if (inLib) { db.delete(t.id); false } else { db.upsert(t); true } }
                        Toast.makeText(this@MusicActivity, if (added) "Disimpan ke perpustakaan" else "Dihapus dari perpustakaan", Toast.LENGTH_SHORT).show()
                        if (tab == 1) loadLibrary()
                    }
                    4 -> DownloadDialog.show(this@MusicActivity, scope, t)
                    5 -> scope.launch {
                        withContext(Dispatchers.IO) { t.uri?.let { MediaPublisher.delete(applicationContext, it) }; db.delete(t.id) }
                        if (tab == 1) loadLibrary()
                    }
                    7 -> pickPlaylist(t)
                    8 -> scope.launch {
                        val pid = openPl?.id
                        if (pid != null) withContext(Dispatchers.IO) { db.removeFromPlaylist(pid, t.id) }
                        loadPlaylists()
                    }
                    6 -> LyricsPicker.show(this@MusicActivity, scope, t) { Toast.makeText(this@MusicActivity, "Lirik dipilih", Toast.LENGTH_SHORT).show() }
                }
                true
            }
            pm.show()
        }
    }
}

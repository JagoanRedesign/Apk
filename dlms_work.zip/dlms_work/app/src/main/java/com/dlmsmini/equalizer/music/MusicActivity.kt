package com.dlmsmini.equalizer.music

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Layar musik: Cari (hasil tanpa batas), Perpustakaan, Unduhan, plus mini-player. */
class MusicActivity : AppCompatActivity() {
    companion object { const val EXTRA_TAB = "tab" }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var rv: RecyclerView
    private lateinit var input: EditText
    private lateinit var adapter: MusicAdapter
    private val tabViews = ArrayList<TextView>()

    private var tab = 0
    private var session: SearchSession? = null
    private var searchJob: Job? = null
    private val results = ArrayList<Track>()
    private var searching = false
    private var searchError: String? = null

    private var libFilter = 0
    private var library: List<Track> = emptyList()

    // mini-player
    private lateinit var mini: LinearLayout
    private lateinit var miniCover: android.widget.ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniPlay: TextView
    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { syncMini() }
    }
    private val dlListener: () -> Unit = { if (tab == 2) render() }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scanDevice() else Toast.makeText(this, "Izin baca audio ditolak", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.BG) }
        Ui.fitSystemBars(root)
        root.addView(buildHeader())
        root.addView(buildSearchRow())
        root.addView(buildTabs())

        adapter = MusicAdapter(
            onTrack = { t -> onTrackClick(t) },
            onMore = { t, anchor -> showMenu(t, anchor) },
            onCancel = { j -> j.cancel = true; if (j.state == DlState.QUEUED) j.state = DlState.CANCELED; DownloadCenter.changed() }
        )
        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MusicActivity)
            adapter = this@MusicActivity.adapter
            clipToPadding = false
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(r: RecyclerView, dx: Int, dy: Int) {
                    if (tab != 0 || dy <= 0) return
                    val lm = r.layoutManager as LinearLayoutManager
                    if (lm.findLastVisibleItemPosition() >= this@MusicActivity.adapter.itemCount - 6) loadMore()
                }
            })
        }
        root.addView(FrameLayout(this).apply { addView(rv, FrameLayout.LayoutParams(-1, -1)) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildMini())
        setContentView(root)

        tab = intent.getIntExtra(EXTRA_TAB, 0).coerceIn(0, 2)
        val last = MusicPrefs.lastQuery(this)
        if (last.isNotBlank()) input.setText(last)
        updateTabs()
        render()
        if (tab == 1) loadLibrary()
    }

    override fun onStart() {
        super.onStart()
        DownloadCenter.addListener(dlListener)
        MusicClient.get(this) { c ->
            controller = c
            c.addListener(playerListener)
            syncMini()
        }
    }

    override fun onStop() {
        DownloadCenter.removeListener(dlListener)
        controller?.removeListener(playerListener)
        controller = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1) loadLibrary()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ---------- bagian atas ----------

    private fun buildHeader(): View {
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 4), 0) }
        h.addView(Icons.view(this, Icons.BACK, 18f, Pal.TEXT, "Kembali").apply { setOnClickListener { finish() } })
        h.addView(Ui.label(this, "Musik", 20f, Pal.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(Icons.view(this, Icons.GEAR, 18f, Pal.MUTED, "Pengaturan musik").apply { setOnClickListener { MusicSettingsDialog.show(this@MusicActivity) } })
        return h
    }

    private fun buildSearchRow(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@MusicActivity, 12), Ui.dp(this@MusicActivity, 8), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 4)) }
        input = EditText(this).apply {
            hint = "Cari lagu, artis…"
            setHintTextColor(Pal.MUTED)
            setTextColor(Pal.TEXT)
            textSize = 15f
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = Ui.rounded(this@MusicActivity, Pal.PANEL, 16, Pal.PANEL_STROKE)
            setPadding(Ui.dp(this@MusicActivity, 14), Ui.dp(this@MusicActivity, 10), Ui.dp(this@MusicActivity, 14), Ui.dp(this@MusicActivity, 10))
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { startSearch(text.toString()); true } else false }
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Icons.view(this, Icons.SEARCH, 18f, Pal.CYAN, "Cari").apply { setOnClickListener { startSearch(input.text.toString()) } })
        return row
    }

    private fun buildTabs(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(this@MusicActivity, 12), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 12), Ui.dp(this@MusicActivity, 4)) }
        listOf("Cari", "Perpustakaan", "Unduhan").forEachIndexed { i, name ->
            val chip = Ui.chip(this, name, i == 0)
            chip.setOnClickListener { tab = i; updateTabs(); if (i == 1) loadLibrary() else render() }
            tabViews.add(chip)
            row.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(this@MusicActivity, 8) })
        }
        return row
    }

    private fun updateTabs() { tabViews.forEachIndexed { i, v -> Ui.setChipSelected(v, i == tab) } }

    private fun buildMini(): View {
        mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(this@MusicActivity, Pal.PANEL, 0, Pal.PANEL_STROKE)
            setPadding(Ui.dp(this@MusicActivity, 10), Ui.dp(this@MusicActivity, 8), Ui.dp(this@MusicActivity, 4), Ui.dp(this@MusicActivity, 8))
            visibility = View.GONE
            setOnClickListener { startActivity(android.content.Intent(this@MusicActivity, NowPlayingActivity::class.java)) }
        }
        miniCover = Img.cover(this, 44)
        mini.addView(miniCover)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@MusicActivity, 10), 0, Ui.dp(this@MusicActivity, 6), 0) }
        miniTitle = Ui.label(this, "", 14f, Pal.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        miniSub = Ui.label(this, "", 12f, Pal.MUTED).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(miniTitle); col.addView(miniSub)
        mini.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = Icons.view(this, Icons.PLAY, 20f, Pal.TEXT, "Putar/Jeda").apply { setOnClickListener { controller?.let { c -> if (c.isPlaying) c.pause() else c.play() } } }
        mini.addView(miniPlay)
        mini.addView(Icons.view(this, Icons.NEXT, 18f, Pal.TEXT, "Berikutnya").apply { setOnClickListener { controller?.seekToNext() } })
        return mini
    }

    private fun syncMini() {
        val c = controller ?: return
        val item: MediaItem? = c.currentMediaItem
        if (item == null) { mini.visibility = View.GONE; adapter.setPlaying(null); return }
        mini.visibility = View.VISIBLE
        val t = item.toTrack()
        miniTitle.text = t.title
        miniSub.text = t.artist
        Img.load(miniCover, t.thumb, 96)
        miniPlay.text = if (c.isPlaying) Icons.PAUSE else Icons.PLAY
        adapter.setPlaying(t.id)
    }

    // ---------- pencarian ----------

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun startSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        hideKeyboard()
        MusicPrefs.setLastQuery(this, query)
        tab = 0
        updateTabs()
        searchJob?.cancel()
        results.clear()
        searchError = null
        session = SearchSession(applicationContext, query)
        searching = false
        loadMore()
    }

    private fun loadMore() {
        val s = session ?: return
        if (searching || s.exhausted) return
        searching = true
        render()
        searchJob = scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { s.loadMore() } }
            if (s !== session) return@launch
            searching = false
            r.onSuccess { results.addAll(it); searchError = null }.onFailure { searchError = it.message ?: "Gagal mencari" }
            render()
        }
    }

    // ---------- perpustakaan ----------

    private fun loadLibrary() {
        scope.launch {
            val src = when (libFilter) { 1 -> Track.SRC_DOWNLOAD; 2 -> Track.SRC_STREAM; 3 -> Track.SRC_DEVICE; else -> null }
            library = withContext(Dispatchers.IO) { MusicDb.get(applicationContext).list(src) }
            if (tab == 1) render()
        }
    }

    private fun scanDevice() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(perm)
            return
        }
        Toast.makeText(this, "Memindai musik di perangkat…", Toast.LENGTH_SHORT).show()
        scope.launch {
            val n = withContext(Dispatchers.IO) {
                val found = ArrayList<Track>()
                val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION
                )
                try {
                    contentResolver.query(coll, proj, "${MediaStore.Audio.Media.IS_MUSIC}=1 AND ${MediaStore.Audio.Media.DURATION}>30000", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
                        while (c.moveToNext()) {
                            val id = c.getLong(0)
                            val uri = ContentUris.withAppendedId(coll, id).toString()
                            val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: ""
                            found.add(
                                Track(
                                    id = "local:$id", title = c.getString(1) ?: "Tanpa judul", artist = artist, album = c.getString(3) ?: "",
                                    durationSec = (c.getLong(4) / 1000).toInt(), thumb = uri, source = Track.SRC_DEVICE, uri = uri
                                )
                            )
                        }
                    }
                } catch (_: Exception) {
                }
                MusicDb.get(applicationContext).replaceDeviceTracks(found)
                found.size
            }
            Toast.makeText(this@MusicActivity, "$n lagu ditemukan", Toast.LENGTH_SHORT).show()
            libFilter = 3
            loadLibrary()
        }
    }

    // ---------- tampilan daftar ----------

    private fun render() {
        val rows = ArrayList<Row>()
        when (tab) {
            0 -> {
                results.forEach { rows.add(Row.TrackRow(it)) }
                val s = session
                when {
                    s == null -> rows.add(Row.Info("Ketik judul lagu atau nama artis, lalu cari.\nHasil resmi (YouTube Music, kanal Topic/VEVO) ditampilkan lebih dulu dan dimuat terus saat menggulir."))
                    searchError != null -> rows.add(Row.Info("${searchError}\nKetuk untuk mencoba lagi") { searchError = null; loadMore() })
                    searching -> rows.add(Row.Loading)
                    results.isEmpty() && s.exhausted -> rows.add(Row.Info("Tidak ada hasil untuk “${s.query}”"))
                    s.exhausted -> rows.add(Row.Info("— akhir hasil —"))
                }
            }
            1 -> {
                rows.add(Row.Filters(libFilter, { libFilter = it; loadLibrary() }, { scanDevice() }))
                library.forEach { rows.add(Row.TrackRow(it)) }
                if (library.isEmpty()) rows.add(Row.Info("Perpustakaan kosong.\nSimpan lagu lewat menu ⋮ di hasil pencarian, unduh, atau pindai musik di perangkat."))
            }
            else -> {
                DownloadCenter.jobs.forEach { rows.add(Row.Job(it)) }
                if (DownloadCenter.jobs.isEmpty()) rows.add(Row.Info("Belum ada unduhan."))
                else rows.add(Row.Info("Bersihkan yang selesai") { DownloadCenter.clearFinished() })
            }
        }
        adapter.submit(rows)
    }

    // ---------- aksi ----------

    private fun onTrackClick(t: Track) {
        val list: List<Track> = if (tab == 0) results else library
        val idx = list.indexOfFirst { it.id == t.id }
        if (idx < 0) { MusicClient.play(this, listOf(t), 0); return }
        // Antrean = daftar yang sedang tampil, mulai dari lagu yang diketuk.
        MusicClient.play(this, list, idx)
    }

    private fun showMenu(t: Track, anchor: View) {
        val db = MusicDb.get(applicationContext)
        scope.launch {
            val inLib = withContext(Dispatchers.IO) { db.contains(t.id) }
            val pm = PopupMenu(this@MusicActivity, anchor)
            pm.menu.add(0, 1, 0, "Putar berikutnya")
            pm.menu.add(0, 2, 1, "Tambah ke antrean")
            if (t.source != Track.SRC_DEVICE) pm.menu.add(0, 3, 2, if (inLib) "Hapus dari perpustakaan" else "Simpan ke perpustakaan")
            if (t.source == Track.SRC_STREAM) pm.menu.add(0, 4, 3, "Unduh…")
            if (t.source == Track.SRC_DOWNLOAD) pm.menu.add(0, 5, 4, "Hapus berkas unduhan")
            pm.menu.add(0, 6, 5, "Cari lirik…")
            pm.setOnMenuItemClickListener { m ->
                when (m.itemId) {
                    1 -> MusicClient.playNext(this@MusicActivity, t)
                    2 -> MusicClient.enqueue(this@MusicActivity, t)
                    3 -> scope.launch {
                        val added = withContext(Dispatchers.IO) { if (inLib) { db.delete(t.id); false } else { db.upsert(t); true } }
                        Toast.makeText(this@MusicActivity, if (added) "Disimpan ke perpustakaan" else "Dihapus dari perpustakaan", Toast.LENGTH_SHORT).show()
                        if (tab == 1) loadLibrary()
                    }
                    4 -> DownloadDialog.show(this@MusicActivity, scope, t)
                    5 -> scope.launch {
                        withContext(Dispatchers.IO) { t.uri?.let { MediaPublisher.delete(applicationContext, it) }; db.delete(t.id) }
                        if (tab == 1) loadLibrary()
                    }
                    6 -> LyricsPicker.show(this@MusicActivity, scope, t) { Toast.makeText(this@MusicActivity, "Lirik dipilih", Toast.LENGTH_SHORT).show() }
                }
                true
            }
            pm.show()
        }
    }
}

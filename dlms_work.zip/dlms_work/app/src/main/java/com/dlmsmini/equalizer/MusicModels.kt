package com.dlmsmini.equalizer

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val durationSeconds: Long,
    val thumbnail: String,
    val watchUrl: String,
    val official: Boolean = false
) {
    fun durationLabel(): String {
        val m = durationSeconds / 60
        val s = durationSeconds % 60
        return "%d:%02d".format(m, s)
    }
}

data class MusicPage(
    val items: List<MusicTrack>,
    val nextPage: String?
)

data class LyricsCandidate(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Int,
    val plain: String?,
    val synced: String?
)

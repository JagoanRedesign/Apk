package com.dlmsmini.equalizer.music

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import com.dlmsmini.equalizer.DiagLog
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** ID sesi audio milik pemutar ini; dibaca EqualizerService agar equalizer aplikasi ikut memproses musik di sini. */
object MusicSessions {
    val ids: MutableSet<Int> = ConcurrentHashMap.newKeySet()
}

/**
 * Pemutar musik: ExoPlayer di dalam MediaSessionService (notifikasi media, layar kunci, Bluetooth).
 * Lagu streaming memakai URI "ytm:<videoId>" yang diselesaikan saat dimuat lewat NewPipeExtractor.
 */
class MusicService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private var effectSession = C.AUDIO_SESSION_ID_UNSET
    private val retried = HashSet<String>()

    override fun onCreate() {
        super.onCreate()
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(NpDownloader.UA_FIREFOX)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(25000)
        val resolving = ResolvingDataSource.Factory(DefaultDataSource.Factory(this, http), YtmResolver(applicationContext))
        // Delay kanal khusus pemutar ini: prosesor dipasang di AudioSink milik ExoPlayer ini saja.
        MusicDelay.load(applicationContext)
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink =
                DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf<AudioProcessor>(MusicDelay.processor))
                    .build()
        }
        val exo = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(resolving))
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        exo.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = switchEffectSession(audioSessionId)

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                // Ulangi OPEN agar EqualizerService yang baru menyala tetap menangkap sesi ini.
                if (isPlaying) openEffects(exo.audioSessionId)
            }

            override fun onPlayerError(error: PlaybackException) {
                val id = exo.currentMediaItem?.mediaId
                val cause = error.cause
                DiagLog.log("Musik: galat pemutaran $id: ${error.errorCodeName}")
                // URL googlevideo kedaluwarsa (403/410): ekstrak ulang sekali lalu coba lagi.
                if (id != null && cause is HttpDataSource.InvalidResponseCodeException &&
                    (cause.responseCode == 403 || cause.responseCode == 410) && retried.add(id)
                ) {
                    StreamResolver.invalidate(id)
                    exo.prepare()
                    return
                }
                if (exo.hasNextMediaItem()) { exo.seekToNextMediaItem(); exo.prepare() }
            }

            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) retried.clear()
                prefetchNext(exo)
                ensureUpcoming(exo)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { prefetchNext(exo); ensureUpcoming(exo) }
                // Antrean sudah habis dan lagu terakhir selesai: lanjutkan dengan mix otomatis bila belum ada.
                if (state == Player.STATE_ENDED) ensureUpcoming(exo)
            }
        })
        player = exo
        switchEffectSession(exo.audioSessionId)
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, NowPlayingActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        session = MediaSession.Builder(this, exo).setSessionActivity(open).build()
    }

    private val main = Handler(Looper.getMainLooper())
    private var autoMixBusy = false
    private val videoIdRe = Regex("[\\w-]{11}")

    /**
     * Putar otomatis: bila antrean tinggal satu lagu (atau sudah habis), buat mix dari lagu yang sedang diputar
     * (lagu terkait + artis yang sama) dan tambahkan ke akhir antrean supaya musik tidak berhenti.
     */
    private fun ensureUpcoming(exo: ExoPlayer) {
        if (autoMixBusy || !MusicPrefs.autoMix(this)) return
        if (exo.repeatMode != Player.REPEAT_MODE_OFF) return
        val count = exo.mediaItemCount
        val ended = exo.playbackState == Player.STATE_ENDED
        val low = if (exo.shuffleModeEnabled) !exo.hasNextMediaItem() else exo.currentMediaItemIndex >= count - 2
        if (count == 0 || !(low || ended)) return
        val item = exo.currentMediaItem ?: return
        val seed = item.toTrack()
        if (!videoIdRe.matches(seed.id)) return // lagu perangkat: tidak diperpanjang dari YouTube
        autoMixBusy = true
        val ids = HashSet<String>().apply { for (i in 0 until count) add(exo.getMediaItemAt(i).mediaId) }
        Thread {
            val mix = try {
                MixBuilder.build(seed, ids, 20)
            } catch (e: Exception) {
                DiagLog.log("Mix otomatis gagal: ${e.javaClass.simpleName}: ${e.message}")
                emptyList()
            }
            main.post {
                autoMixBusy = false
                val p = player ?: return@post
                if (mix.isEmpty()) return@post
                val firstNew = p.mediaItemCount
                p.addMediaItems(mix.map { it.toMediaItem() })
                if (p.playbackState == Player.STATE_ENDED) {
                    p.seekTo(firstNew, 0L)
                    p.prepare()
                    p.play()
                }
            }
        }.apply { isDaemon = true }.start()
    }

    /** Ekstrak URL lagu berikutnya di latar supaya pindah lagu tidak menunggu. */
    private fun prefetchNext(exo: ExoPlayer) {
        val i = exo.nextMediaItemIndex
        if (i == C.INDEX_UNSET) return
        val item = exo.getMediaItemAt(i)
        if (item.localConfiguration?.uri?.scheme == "ytm") StreamResolver.prefetch(item.mediaId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        closeEffects(effectSession)
        session?.release()
        session = null
        player?.release()
        player = null
        super.onDestroy()
    }

    // ---------- integrasi equalizer aplikasi ----------

    private fun switchEffectSession(newId: Int) {
        if (newId == effectSession) return
        closeEffects(effectSession)
        effectSession = newId
        openEffects(newId)
    }

    private fun openEffects(id: Int) {
        if (id == C.AUDIO_SESSION_ID_UNSET || id <= 0) return
        MusicSessions.ids.add(id)
        sendBroadcast(
            Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, id)
                .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
        )
    }

    private fun closeEffects(id: Int) {
        if (id == C.AUDIO_SESSION_ID_UNSET || id <= 0) return
        MusicSessions.ids.remove(id)
        sendBroadcast(
            Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
                .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, id)
                .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
        )
    }
}

/** Mengubah "ytm:<id>" menjadi URL audio sebenarnya (blocking di thread pemuat ExoPlayer). */
private class YtmResolver(private val ctx: Context) : ResolvingDataSource.Resolver {
    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val uri = dataSpec.uri
        if (uri.scheme != "ytm") return dataSpec
        val id = uri.schemeSpecificPart
        val opts = try {
            StreamResolver.options(id)
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException(e.message, e)
        }
        val chosen = StreamResolver.pick(opts, MusicPrefs.streamQuality(ctx))
        return dataSpec.withUri(Uri.parse(chosen.url))
    }
}

/** Sambungan MediaController ke [MusicService] yang dipakai semua layar musik. */
object MusicClient {
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private val waiting = ArrayList<(MediaController) -> Unit>()

    fun get(ctx: Context, cb: (MediaController) -> Unit) {
        val c = controller
        if (c != null && c.isConnected) { cb(c); return }
        if (c != null) { controller = null; future = null }
        waiting.add(cb)
        if (future != null) return
        val app = ctx.applicationContext
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        future = f
        f.addListener({
            try {
                val mc = f.get()
                controller = mc
                val w = ArrayList(waiting)
                waiting.clear()
                w.forEach { it(mc) }
            } catch (e: Exception) {
                future = null
                waiting.clear()
                DiagLog.log("Musik: gagal tersambung ke pemutar: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(app))
    }

    /** Putar [tracks] mulai dari [index] (antrean diganti). */
    fun play(ctx: Context, tracks: List<Track>, index: Int) {
        if (tracks.isEmpty()) return
        get(ctx) { c ->
            c.setMediaItems(tracks.map { it.toMediaItem() }, index.coerceIn(0, tracks.size - 1), 0L)
            c.prepare()
            c.play()
        }
    }

    fun playNext(ctx: Context, t: Track) = get(ctx) { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(t.toMediaItem()); c.prepare(); c.play() }
        else c.addMediaItem(c.currentMediaItemIndex + 1, t.toMediaItem())
    }

    fun enqueue(ctx: Context, t: Track) = get(ctx) { c ->
        if (c.mediaItemCount == 0) { c.setMediaItem(t.toMediaItem()); c.prepare(); c.play() }
        else c.addMediaItem(t.toMediaItem())
    }
}

package com.dlmsmini.equalizer

import android.Manifest
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.util.concurrent.Executors

class MusicActivity : AppCompatActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var results: LinearLayout
    private lateinit var search: EditText
    private lateinit var status: TextView
    private var nextPage: String? = null
    private var query = ""
    private var loading = false
    private var currentTrack: MusicTrack? = null
    private var currentLyrics: LyricsCandidate? = null
    private val seen = HashSet<String>()

    private val bg = 0xFF0B1019.toInt()
    private val panel = 0xFF151F2E.toInt()
    private val accent = 0xFF28AFFF.toInt()
    private val white = 0xFFF1F5FA.toInt()
    private val muted = 0xFF9BAABD.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadLibraryIfPermitted()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 14f, color: Int = white) =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = label("‹", 32f).apply { setPadding(0, 0, dp(14), 0); setOnClickListener { finish() } }
        header.addView(back)
        val title = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title.addView(label("DLMS MUSIC", 20f))
        title.addView(label("Streaming • Library • Lyrics", 11f, muted))
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val instance = label("PIPED", 11f, accent).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener {
                MusicNetwork.rotateInstance()
                text = "PIPED ✓"
                Toast.makeText(this@MusicActivity, "Instans: ${MusicNetwork.instance}", Toast.LENGTH_LONG).show()
            }
        }
        header.addView(instance)
        root.addView(header)

        search = EditText(this).apply {
            hint = "Cari lagu, artis, atau album"
            setSingleLine(true)
            setTextColor(white); setHintTextColor(muted)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(panel)
        }
        val searchRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(search, LinearLayout.LayoutParams(0, dp(50), 1f))
            val go = Button(this@MusicActivity).apply {
                text = "Cari"; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
                setOnClickListener { startSearch() }
            }
            addView(go)
        }
        val searchBox = LinearLayout(this).apply { setPadding(0, dp(14), 0, dp(8)); addView(searchRow) }
        root.addView(searchBox)

        val tabs = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) }
        listOf("Lagu online", "Lokal", "Lirik").forEachIndexed { index, name ->
            val b = Button(this).apply {
                text = name; textSize = 11f
                setOnClickListener {
                    when (index) {
                        0 -> startSearch()
                        1 -> loadLocalLibrary()
                        2 -> searchLyricsManually()
                    }
                }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(tabs)

        status = label("Cari musik melalui Piped. Hasil dimuat bertahap.", 12f, muted)
        root.addView(status)
        val scroller = ScrollView(this).apply { isFillViewport = true }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(18)) }
        scroller.addView(results)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        scroller.setOnScrollChangeListener { v: View, _, scrollY, _, oldY ->
            val child = scroller.getChildAt(0)
            if (child != null && scrollY > oldY && scrollY + scroller.height >= child.height - dp(220)) {
                loadNextPage()
            }
        }
        setContentView(root)
    }

    private fun startSearch() {
        val q = search.text.toString().trim()
        if (q.isBlank()) { search.error = "Masukkan judul atau artis"; return }
        query = q
        nextPage = null
        seen.clear()
        results.removeAllViews()
        loadPage(null)
    }

    private fun loadNextPage() {
        if (loading || nextPage.isNullOrBlank() || query.isBlank()) return
        loadPage(nextPage)
    }

    private fun loadPage(token: String?) {
        if (loading) return
        loading = true
        status.text = "Memuat hasil…"
        io.execute {
            try {
                val page = MusicNetwork.search(query, token)
                runOnUiThread {
                    page.items.forEach { track -> if (seen.add(track.id)) addTrackRow(track) }
                    nextPage = page.nextPage
                    status.text = if (page.items.isEmpty()) "Tidak ada hasil pada halaman ini."
                    else "${seen.size} hasil • gulir ke bawah untuk memuat berikutnya"
                    if (nextPage.isNullOrBlank()) status.append(" • Tidak ada halaman lanjutan")
                    loading = false
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading = false
                    status.text = "Pencarian gagal: ${e.message ?: "koneksi bermasalah"}"
                    val retry = Button(this@MusicActivity).apply { text = "Coba instans lain"; setOnClickListener {
                        MusicNetwork.rotateInstance(); loadPage(token)
                    } }
                    results.addView(retry)
                }
            }
        }
    }

    private fun addTrackRow(track: MusicTrack) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setBackgroundColor(panel)
        }
        val main = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val icon = label("♫", 25f, accent).apply { gravity = Gravity.CENTER; setBackgroundColor(0xFF202D40.toInt()) }
        main.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        text.addView(label(track.title, 14f))
        text.addView(label(track.artist + if (track.official) "  ✓ RESMI" else "", 11f, muted))
        text.addView(label(track.durationLabel(), 10f, muted))
        main.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        val play = Button(this).apply { text = "▶"; setOnClickListener { playTrack(track) } }
        main.addView(play)
        card.addView(main)
        val actions = LinearLayout(this).apply { gravity = Gravity.END }
        val lyrics = Button(this).apply { text = "Lirik"; setOnClickListener { currentTrack = track; searchLyricsFor(track) } }
        val download = Button(this).apply { text = "Unduh"; setOnClickListener { currentTrack = track; downloadTrack(track) } }
        actions.addView(lyrics); actions.addView(download)
        card.addView(actions)
        results.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun playTrack(track: MusicTrack) {
        currentTrack = track
        status.text = "Ekstraksi audio di perangkat: ${track.title}"
        io.execute {
            try {
                val streams = NewPipeAudioResolver.extract(track.watchUrl)
                val choice = streams.firstOrNull() ?: throw IllegalStateException("Tidak ada stream audio yang tersedia.")
                runOnUiThread {
                    val intent = Intent(this, MusicPlaybackService::class.java).apply {
                        action = MusicPlaybackService.ACTION_PLAY
                        putExtra(MusicPlaybackService.EXTRA_URL, choice.url)
                        putExtra(MusicPlaybackService.EXTRA_TITLE, track.title)
                        putExtra(MusicPlaybackService.EXTRA_ARTIST, track.artist)
                    }
                    ContextCompat.startForegroundService(this, intent)
                    status.text = "Memutar: ${track.title} • ${choice.bitrate.coerceAtLeast(0)} kbps"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal mengekstrak audio: ${e.message ?: "stream tidak tersedia"}" }
            }
        }
    }

    private fun searchLyricsFor(track: MusicTrack) {
        val q = "${track.title} ${track.artist}"
        status.text = "Mencari kandidat lirik…"
        io.execute {
            try {
                val candidates = MusicNetwork.lyricsSearch(q)
                runOnUiThread {
                    if (candidates.isEmpty()) { status.text = "Kandidat lirik tidak ditemukan."; return@runOnUiThread }
                    val labels = candidates.map { "${it.title} — ${it.artist}" }.toTypedArray()
                    AlertDialog.Builder(this).setTitle("Pilih kandidat lirik")
                        .setItems(labels) { _, which -> showLyrics(candidates[which]) }
                        .setNegativeButton("Batal", null).show()
                    status.text = "${candidates.size} kandidat ditemukan"
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Pencarian lirik gagal: ${e.message}" }
            }
        }
    }

    private fun searchLyricsManually() {
        val q = search.text.toString().trim()
        if (q.isBlank()) { search.error = "Masukkan judul/artis untuk mencari lirik"; return }
        status.text = "Mencari kandidat LRCLIB…"
        io.execute {
            try {
                val candidates = MusicNetwork.lyricsSearch(q)
                runOnUiThread {
                    if (candidates.isEmpty()) { status.text = "Lirik tidak ditemukan"; return@runOnUiThread }
                    AlertDialog.Builder(this).setTitle("Pilih kandidat")
                        .setItems(candidates.map { "${it.title} — ${it.artist}" }.toTypedArray()) { _, which ->
                            showLyrics(candidates[which])
                        }.setNegativeButton("Batal", null).show()
                }
            } catch (e: Exception) { runOnUiThread { status.text = "LRCLIB: ${e.message}" } }
        }
    }

    private fun showLyrics(candidate: LyricsCandidate) {
        currentLyrics = candidate
        val text = candidate.synced ?: candidate.plain ?: "Lirik kosong"
        AlertDialog.Builder(this).setTitle("${candidate.title}\n${candidate.artist}")
            .setMessage(text).setPositiveButton("Tutup", null)
            .setNeutralButton("Salin") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Lyrics", text))
                Toast.makeText(this, "Lirik disalin", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun downloadTrack(track: MusicTrack) {
        status.text = "Mengambil pilihan kualitas…"
        io.execute {
            try {
                val streams = NewPipeAudioResolver.extract(track.watchUrl)
                runOnUiThread {
                    if (streams.isEmpty()) { status.text = "Stream audio tidak tersedia"; return@runOnUiThread }
                    val labels = streams.map { "${it.bitrate.coerceAtLeast(0)} kbps • ${it.format}" }.toTypedArray()
                    AlertDialog.Builder(this).setTitle("Pilih kualitas unduhan")
                        .setItems(labels) { _, which ->
                            val selected = streams[which]
                            AlertDialog.Builder(this)
                                .setTitle("Unduh audio")
                                .setMessage("Kualitas: ${selected.bitrate.coerceAtLeast(0)} kbps • ${selected.format}\\n\\nAudio akan disimpan ke folder Music/DLMS Music. Penanaman sampul dan lirik ke tag berkas belum diaktifkan pada build ini.")
                                .setPositiveButton("Unduh") { _, _ -> enqueueDownload(track, selected.url, selected.suffix) }
                                .setNegativeButton("Batal", null).show()
                        }.setNegativeButton("Batal", null).show()
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Ekstraksi gagal: ${e.message}" } }
        }
    }

    private fun enqueueDownload(track: MusicTrack, url: String, suffix: String) {
        try {
            val request = android.app.DownloadManager.Request(Uri.parse(url))
                .setTitle(track.title)
                .setDescription("DLMS Music • ${track.artist}")
                .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_MUSIC, "DLMS Music/${safeName(track.title)}.${suffix.lowercase().ifBlank { "audio" }}")
            val dm = getSystemService(DOWNLOAD_SERVICE) as android.app.DownloadManager
            dm.enqueue(request)
            status.text = "Unduhan dimulai. Berkas disimpan ke Music/DLMS Music."
        } catch (e: Exception) { status.text = "Unduhan gagal: ${e.message}" }
    }

    private fun safeName(name: String) = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(90)

    private fun loadLibraryIfPermitted() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadLocalLibrary()
        } else requestPermissions(arrayOf(permission), 501)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadLocalLibrary()
    }

    private fun loadLocalLibrary() {
        results.removeAllViews()
        status.text = "Memindai musik lokal…"
        io.execute {
            val tracks = mutableListOf<Pair<String, Uri>>()
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val title = c.getString(titleCol).orEmpty()
                    val artist = c.getString(artistCol).orEmpty()
                    tracks += "$title\n$artist" to ContentUris.withAppendedId(collection, id)
                }
            }
            runOnUiThread {
                status.text = "${tracks.size} lagu lokal ditemukan"
                tracks.forEach { (name, uri) ->
                    val row = Button(this).apply {
                        text = "♫  $name"
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            val intent = Intent(this@MusicActivity, MusicPlaybackService::class.java).apply {
                                action = MusicPlaybackService.ACTION_PLAY
                                putExtra(MusicPlaybackService.EXTRA_URL, uri.toString())
                                putExtra(MusicPlaybackService.EXTRA_TITLE, name.substringBefore("\n"))
                                putExtra(MusicPlaybackService.EXTRA_ARTIST, name.substringAfter("\n"))
                            }
                            ContextCompat.startForegroundService(this@MusicActivity, intent)
                        }
                    }
                    results.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
                }
            }
        }
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }
}

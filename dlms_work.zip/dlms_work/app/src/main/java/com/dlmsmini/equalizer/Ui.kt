package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Helper UI bersama (UI dibangun lewat kode, tanpa file layout XML). */

internal fun c(v: Long): Int = v.toInt()

internal fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

internal fun Context.rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

internal fun Context.label(value: String, size: Float = 13f, tint: Int = c(0xFFCACAD2), bold: Boolean = false): TextView =
    TextView(this).apply {
        text = value
        textSize = size
        setTextColor(tint)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

internal fun Context.makeCard(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(14), dp(14), dp(14), dp(14))
    background = rounded(c(0xFF111827), 18, c(0xFF263B5D))
}

internal fun Context.sectionTitle(parent: LinearLayout, title: String): TextView {
    val t = label(title, 14f, c(0xFFE7E7ED), true)
    t.setPadding(dp(2), dp(22), dp(2), dp(10))
    parent.addView(t)
    return t
}

package com.dlmsmini.equalizer

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.roundToInt

/** Helper UI kecil yang dipakai bersama oleh semua layar. */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).roundToInt()

    fun rounded(ctx: Context, color: Int, radius: Int, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, radius).toFloat()
            if (strokeColor != 0) setStroke(dp(ctx, 1), strokeColor)
        }

    fun label(
        ctx: Context,
        value: String,
        size: Float = 13f,
        tint: Int = 0xFFCACAD2.toInt(),
        bold: Boolean = false
    ): TextView = TextView(ctx).apply {
        text = value
        textSize = size
        setTextColor(tint)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    /** Tombol bergaya "pill" hitam seperti dialog Import presets. */
    fun pill(ctx: Context, caption: String): TextView = TextView(ctx).apply {
        text = caption
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(ctx, 0xFF000000.toInt(), 22, 0xFF2A2A2E.toInt())
        setPadding(dp(ctx, 8), dp(ctx, 16), dp(ctx, 8), dp(ctx, 16))
        isClickable = true
        isFocusable = true
    }

    fun setPillEnabled(v: TextView, enabled: Boolean) {
        v.isEnabled = enabled
        v.setTextColor(if (enabled) 0xFFFFFFFF.toInt() else 0xFF6E6E73.toInt())
    }

    fun weighted(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, -2, 1f)

    /**
     * Android 15 (targetSdk 35) memaksa tampilan edge-to-edge: konten harus memberi ruang untuk status bar,
     * navigation bar, dan cutout. Dipanggil sebelum setContentView pada setiap layar.
     */
    fun fitSystemBars(root: View) {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    fun panelCard(ctx: Context, pad: Int = 14): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(ctx, Pal.PANEL, 18, Pal.PANEL_STROKE)
        setPadding(dp(ctx, pad), dp(ctx, pad), dp(ctx, pad), dp(ctx, pad))
    }

    fun addCard(parent: LinearLayout, card: View, top: Int = 10) {
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(parent.context, top) })
    }

    fun sectionTitle(ctx: Context, parent: LinearLayout, title: String) {
        val t = label(ctx, title, 14f, 0xFFE7E7ED.toInt(), true)
        t.setPadding(dp(ctx, 2), dp(ctx, 22), dp(ctx, 2), dp(ctx, 10))
        parent.addView(t)
    }

    /** Slider berlabel. Mengembalikan fungsi penyegar yang memuat ulang nilai dari [get]. */
    fun slider(
        ctx: Context, card: LinearLayout, title: String, spec: Spec,
        get: () -> Float, onUser: (Float) -> Unit, onStop: (() -> Unit)? = null
    ): () -> Unit {
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(ctx, 4), dp(ctx, 12), dp(ctx, 4), 0)
        }
        head.addView(label(ctx, title, 14f, 0xFFFFFFFF.toInt()), weighted())
        val valueText = label(ctx, spec.format(get()), 13f, Pal.CYAN, true)
        head.addView(valueText)
        val tint = ColorStateList.valueOf(0xFF00CFFF.toInt())
        val bar = SeekBar(ctx).apply {
            max = spec.steps
            progress = spec.toProgress(get())
            progressTintList = tint
            thumbTintList = tint
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = spec.toValue(p)
                    valueText.text = spec.format(v)
                    if (fromUser) onUser(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { onStop?.invoke() }
            })
        }
        card.addView(head)
        card.addView(bar, LinearLayout.LayoutParams(-1, -2))
        return {
            bar.progress = spec.toProgress(get())
            valueText.text = spec.format(get())
        }
    }

    /** Kotak centang. Mengembalikan fungsi penyegar (tanpa memicu callback). */
    fun check(ctx: Context, card: LinearLayout, title: String, get: () -> Boolean, onUser: (Boolean) -> Unit): () -> Unit {
        var suppress = false
        val cb = CheckBox(ctx).apply {
            text = title; textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            buttonTintList = ColorStateList.valueOf(0xFF00CFFF.toInt())
            isChecked = get()
        }
        cb.setOnCheckedChangeListener { _, checked -> if (!suppress) onUser(checked) }
        card.addView(cb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 4) })
        return {
            suppress = true
            cb.isChecked = get()
            suppress = false
        }
    }

    /** Chip kecil untuk pilihan cepat (mode spectrum, preset delay, riwayat preset). */
    fun chip(ctx: Context, text: String, selected: Boolean = false): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 11f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (selected) 0xFFFFFFFF.toInt() else 0xFFB9C7E0.toInt())
        background = rounded(ctx, if (selected) 0xFF17304A.toInt() else 0xFF1B2638.toInt(), 12, if (selected) 0xFF45C5FF.toInt() else 0xFF304968.toInt())
        setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
        isClickable = true
        isFocusable = true
    }

    fun setChipSelected(v: TextView, selected: Boolean) {
        val ctx = v.context
        v.setTextColor(if (selected) 0xFFFFFFFF.toInt() else 0xFFB9C7E0.toInt())
        v.background = rounded(ctx, if (selected) 0xFF17304A.toInt() else 0xFF1B2638.toInt(), 12, if (selected) 0xFF45C5FF.toInt() else 0xFF304968.toInt())
    }
}

/** Warna utama aplikasi. */
object Pal {
    val BG = 0xFF080B12.toInt()
    val PANEL = 0xFF111827.toInt()
    val PANEL_STROKE = 0xFF263B5D.toInt()
    val ACCENT = 0xFF27B5FF.toInt()
    val CYAN = 0xFF45C5FF.toInt()
    val TEXT = 0xFFEAF0FF.toInt()
    val MUTED = 0xFF9DAFC9.toInt()
}

package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Helper UI kecil yang dipakai bersama oleh semua layar. */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).roundToInt()

    fun rounded(ctx: Context, color: Int, radius: Int, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, radius).toFloat()
            if (strokeColor != 0) setStroke(dp(ctx, 1), strokeColor)
        }

    fun label(
        ctx: Context,
        value: String,
        size: Float = 13f,
        tint: Int = 0xFFCACAD2.toInt(),
        bold: Boolean = false
    ): TextView = TextView(ctx).apply {
        text = value
        textSize = size
        setTextColor(tint)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    /** Tombol bergaya "pill" hitam seperti dialog Import presets. */
    fun pill(ctx: Context, caption: String): TextView = TextView(ctx).apply {
        text = caption
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(0xFFFFFFFF.toInt())
        background = rounded(ctx, 0xFF000000.toInt(), 22, 0xFF2A2A2E.toInt())
        setPadding(dp(ctx, 8), dp(ctx, 16), dp(ctx, 8), dp(ctx, 16))
        isClickable = true
        isFocusable = true
    }

    fun setPillEnabled(v: TextView, enabled: Boolean) {
        v.isEnabled = enabled
        v.setTextColor(if (enabled) 0xFFFFFFFF.toInt() else 0xFF6E6E73.toInt())
    }

    fun weighted(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, -2, 1f)
}

/** Warna utama aplikasi. */
object Pal {
    val BG = 0xFF080B12.toInt()
    val PANEL = 0xFF111827.toInt()
    val PANEL_STROKE = 0xFF263B5D.toInt()
    val ACCENT = 0xFF27B5FF.toInt()
    val CYAN = 0xFF45C5FF.toInt()
    val TEXT = 0xFFEAF0FF.toInt()
    val MUTED = 0xFF9DAFC9.toInt()
}

package com.dlmsmini.equalizer

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.roundToInt

/** Helper UI kecil yang dipakai bersama oleh semua layar. */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).roundToInt()

    fun rounded(ctx: Context, color: Int, radius: Int, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, radius).toFloat()
            if (strokeColor != 0) setStroke(dp(ctx, 1), strokeColor)
        }

    fun label(
        ctx: Context,
        value: String,
        size: Float = 13f,
        tint: Int = Pal.c(0xFFCACAD2),
        bold: Boolean = false
    ): TextView = TextView(ctx).apply {
        text = value
        textSize = size
        setTextColor(tint)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    /** Tombol bergaya "pill" hitam seperti dialog Import presets. */
    fun pill(ctx: Context, caption: String): TextView = TextView(ctx).apply {
        text = caption
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(Pal.c(0xFFFFFFFF))
        background = rounded(ctx, Pal.c(0xFF000000), 22, Pal.c(0xFF2A2A2E))
        setPadding(dp(ctx, 8), dp(ctx, 16), dp(ctx, 8), dp(ctx, 16))
        isClickable = true
        isFocusable = true
    }

    fun setPillEnabled(v: TextView, enabled: Boolean) {
        v.isEnabled = enabled
        v.setTextColor(if (enabled) Pal.c(0xFFFFFFFF) else Pal.c(0xFF6E6E73))
    }

    fun weighted(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, -2, 1f)

    /**
     * Android 15 (targetSdk 35) memaksa tampilan edge-to-edge: konten harus memberi ruang untuk status bar,
     * navigation bar, dan cutout. Dipanggil sebelum setContentView pada setiap layar.
     */
    fun fitSystemBars(root: View) {
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        // Ikon status bar/navigasi gelap di tema terang, terang di tema gelap. Dilakukan saat view terpasang ke jendela
        // (mengakses decorView sebelum setContentView akan mengganggu AppCompat).
        root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) { applyWindowTheme(v) }
            override fun onViewDetachedFromWindow(v: View) {}
        })
    }

    private fun applyWindowTheme(v: View) {
        var c: Context = v.context
        while (c is ContextWrapper && c !is Activity) c = c.baseContext
        val w = (c as? Activity)?.window ?: return
        val light = Pal.light
        WindowCompat.getInsetsController(w, w.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
        if (Build.VERSION.SDK_INT < 35) {
            @Suppress("DEPRECATION") run {
                w.statusBarColor = Pal.BG
                w.navigationBarColor = Pal.BG
            }
        }
    }

    fun panelCard(ctx: Context, pad: Int = 14): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(ctx, Pal.PANEL, 18, Pal.PANEL_STROKE)
        setPadding(dp(ctx, pad), dp(ctx, pad), dp(ctx, pad), dp(ctx, pad))
    }

    fun addCard(parent: LinearLayout, card: View, top: Int = 10) {
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(parent.context, top) })
    }

    fun sectionTitle(ctx: Context, parent: LinearLayout, title: String) {
        val t = label(ctx, title, 14f, Pal.c(0xFFE7E7ED), true)
        t.setPadding(dp(ctx, 2), dp(ctx, 22), dp(ctx, 2), dp(ctx, 10))
        parent.addView(t)
    }

    /** Slider berlabel. Mengembalikan fungsi penyegar yang memuat ulang nilai dari [get]. */
    fun slider(
        ctx: Context, card: LinearLayout, title: String, spec: Spec,
        get: () -> Float, onUser: (Float) -> Unit, onStop: (() -> Unit)? = null
    ): () -> Unit {
        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(ctx, 4), dp(ctx, 12), dp(ctx, 4), 0)
        }
        head.addView(label(ctx, title, 14f, Pal.c(0xFFFFFFFF)), weighted())
        val valueText = label(ctx, spec.format(get()), 13f, Pal.CYAN, true)
        head.addView(valueText)
        val tint = ColorStateList.valueOf(Pal.c(0xFF00CFFF))
        val bar = SeekBar(ctx).apply {
            max = spec.steps
            progress = spec.toProgress(get())
            progressTintList = tint
            thumbTintList = tint
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = spec.toValue(p)
                    valueText.text = spec.format(v)
                    if (fromUser) onUser(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { onStop?.invoke() }
            })
        }
        card.addView(head)
        card.addView(bar, LinearLayout.LayoutParams(-1, -2))
        return {
            bar.progress = spec.toProgress(get())
            valueText.text = spec.format(get())
        }
    }

    /** Kotak centang. Mengembalikan fungsi penyegar (tanpa memicu callback). */
    fun check(ctx: Context, card: LinearLayout, title: String, get: () -> Boolean, onUser: (Boolean) -> Unit): () -> Unit {
        var suppress = false
        val cb = CheckBox(ctx).apply {
            text = title; textSize = 15f
            setTextColor(Pal.c(0xFFFFFFFF))
            buttonTintList = ColorStateList.valueOf(Pal.c(0xFF00CFFF))
            isChecked = get()
        }
        cb.setOnCheckedChangeListener { _, checked -> if (!suppress) onUser(checked) }
        card.addView(cb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 4) })
        return {
            suppress = true
            cb.isChecked = get()
            suppress = false
        }
    }

    /** Chip kecil untuk pilihan cepat (mode spectrum, riwayat preset). */
    fun chip(ctx: Context, text: String, selected: Boolean = false): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 11f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (selected) Pal.c(0xFFFFFFFF) else Pal.c(0xFFB9C7E0))
        background = rounded(ctx, if (selected) Pal.c(0xFF17304A) else Pal.c(0xFF1B2638), 12, if (selected) Pal.c(0xFF45C5FF) else Pal.c(0xFF304968))
        setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
        isClickable = true
        isFocusable = true
    }

    fun setChipSelected(v: TextView, selected: Boolean) {
        val ctx = v.context
        v.setTextColor(if (selected) Pal.c(0xFFFFFFFF) else Pal.c(0xFFB9C7E0))
        v.background = rounded(ctx, if (selected) Pal.c(0xFF17304A) else Pal.c(0xFF1B2638), 12, if (selected) Pal.c(0xFF45C5FF) else Pal.c(0xFF304968))
    }
}

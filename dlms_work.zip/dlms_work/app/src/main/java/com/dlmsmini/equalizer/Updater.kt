package com.dlmsmini.equalizer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Konfigurasi pembaruan. GANTI [URL] dengan alamat HTTPS berkas update.json milik Anda
 * (mis. https://raw.githubusercontent.com/PEMILIK/REPO/main/update.json). Format ada di update.json pada proyek ini.
 */
object UpdateConfig {
    const val URL = "https://raw.githubusercontent.com/GANTI-PEMILIK/GANTI-REPO/main/update.json"
    const val INTERVAL_HOURS = 6L
    const val MIN_UI_CHECK_MS = 60 * 60 * 1000L

    val configured: Boolean get() = !URL.contains("GANTI-")
}

/** Keadaan pembaruan hasil pemeriksaan terakhir, dibandingkan dengan versi yang terpasang SEKARANG. */
class UpdateState(
    val installedCode: Int, val latestCode: Int, val latestName: String, val minCode: Int,
    val url: String, val notes: String, val message: String
) {
    /** Wajib: versi terpasang di bawah versi minimum yang diizinkan. */
    val forced: Boolean get() = installedCode < minCode
    val available: Boolean get() = latestCode > installedCode || forced
}

class CheckResult(val ok: Boolean, val error: String? = null)

object UpdateChecker {
    private const val P_LATEST = "upd_latest"
    private const val P_NAME = "upd_name"
    private const val P_MIN = "upd_min"
    private const val P_URL = "upd_url"
    private const val P_NOTES = "upd_notes"
    private const val P_MSG = "upd_msg"
    private const val P_CHECKED = "upd_checked_at"
    private const val P_NOTIFIED = "upd_notified_code"
    private const val P_NOTIFIED_AT = "upd_notified_at"
    const val P_SKIPPED = "upd_skipped"

    fun installedCode(ctx: Context): Int = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode.toInt()
    } catch (_: Exception) { 0 }

    fun installedName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "-"
    } catch (_: Exception) { "-" }

    /** Hasil terakhir dari cache; null bila belum pernah berhasil memeriksa. */
    fun state(ctx: Context): UpdateState? {
        val p = Store.prefs(ctx)
        val latest = p.getInt(P_LATEST, 0)
        if (latest == 0) return null
        return UpdateState(
            installedCode(ctx), latest, p.getString(P_NAME, "") ?: "", p.getInt(P_MIN, 0),
            p.getString(P_URL, "") ?: "", p.getString(P_NOTES, "") ?: "", p.getString(P_MSG, "") ?: ""
        )
    }

    fun dueForCheck(ctx: Context): Boolean =
        System.currentTimeMillis() - Store.prefs(ctx).getLong(P_CHECKED, 0L) > UpdateConfig.MIN_UI_CHECK_MS

    /** Unduh update.json dan simpan ke cache. BLOKIR: panggil dari thread latar belakang. */
    fun check(ctx: Context): CheckResult {
        if (!UpdateConfig.configured) return CheckResult(false, "Alamat pembaruan belum diatur (UpdateConfig.URL)")
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(UpdateConfig.URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "DLMS-Mini-Equalizer/" + installedName(ctx))
                setRequestProperty("Cache-Control", "no-cache")
            }
            if (conn.responseCode != 200) return CheckResult(false, "Server membalas ${conn.responseCode}")
            val text = conn.inputStream.use { it.readBytes().take(65536).toByteArray().toString(Charsets.UTF_8) }
            val o = JSONObject(text)
            val latest = o.getInt("versionCode")
            val min = o.optInt("minVersionCode", 0)
            val url = o.optString("apkUrl", "")
            if (url.isNotEmpty() && !url.startsWith("https://")) return CheckResult(false, "apkUrl harus HTTPS")
            Store.prefs(ctx).edit()
                .putInt(P_LATEST, latest)
                .putString(P_NAME, o.optString("versionName", ""))
                .putInt(P_MIN, min)
                .putString(P_URL, url)
                .putString(P_NOTES, o.optString("notes", ""))
                .putString(P_MSG, o.optString("message", ""))
                .putLong(P_CHECKED, System.currentTimeMillis())
                .apply()
            CheckResult(true)
        } catch (e: Exception) {
            CheckResult(false, "Gagal memeriksa pembaruan: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            conn?.disconnect()
        }
    }

    /** Buka tautan unduhan APK di peramban/pengelola unduhan. */
    fun openDownload(ctx: Context, st: UpdateState): Boolean {
        if (!st.url.startsWith("https://")) return false
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(st.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (_: Exception) { false }
    }

    fun skip(ctx: Context, code: Int) {
        Store.prefs(ctx).edit().putInt(P_SKIPPED, code).apply()
    }

    fun skipped(ctx: Context): Int = Store.prefs(ctx).getInt(P_SKIPPED, 0)

    // ---------- notifikasi ----------

    private const val CHANNEL = "dlms_update"
    private const val NOTIF_ID = 4201

    /** Kirim notifikasi bila ada pembaruan. Opsional: sekali per versi. Wajib: diulang tiap 24 jam. */
    fun notifyIfNeeded(ctx: Context) {
        val st = state(ctx) ?: return
        if (!st.available) return
        val p = Store.prefs(ctx)
        val now = System.currentTimeMillis()
        val same = p.getInt(P_NOTIFIED, 0) == st.latestCode
        if (same && (!st.forced || now - p.getLong(P_NOTIFIED_AT, 0L) < 24L * 3600_000L)) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Pembaruan aplikasi", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Pemberitahuan versi baru DLMS Mini Equalizer"
            }
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            ctx, 20,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val title = if (st.forced) "Pembaruan wajib tersedia" else "Pembaruan tersedia"
        val name = if (st.latestName.isNotEmpty()) st.latestName else st.latestCode.toString()
        val text = if (st.forced) "Versi $name wajib dipasang agar aplikasi dapat dipakai." else "Versi $name siap diunduh."
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (st.notes.isNotEmpty()) text + "\n" + st.notes else text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(if (st.forced) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
        if (st.url.startsWith("https://")) {
            val dl = PendingIntent.getActivity(ctx, 21, Intent(Intent.ACTION_VIEW, Uri.parse(st.url)), flags)
            b.addAction(0, "Unduh", dl)
        }
        try {
            nm.notify(NOTIF_ID, b.build())
            p.edit().putInt(P_NOTIFIED, st.latestCode).putLong(P_NOTIFIED_AT, now).apply()
        } catch (_: Exception) {
        }
    }
}

/** Pemeriksa berkala di latar belakang (WorkManager): aplikasi memeriksa sendiri tiap beberapa jam. */
class UpdateWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val app = applicationContext
        if (!Store.prefs(app).getBoolean(Store.KEY_UPDATE_NOTIF, true)) return Result.success()
        val r = UpdateChecker.check(app)
        if (r.ok) UpdateChecker.notifyIfNeeded(app)
        return Result.success()
    }
}

object UpdateScheduler {
    private const val NAME = "dlms_update_check"

    fun apply(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (!UpdateConfig.configured || !Store.prefs(ctx).getBoolean(Store.KEY_UPDATE_NOTIF, true)) {
            wm.cancelUniqueWork(NAME)
            return
        }
        val req = PeriodicWorkRequest.Builder(UpdateWorker::class.java, UpdateConfig.INTERVAL_HOURS, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

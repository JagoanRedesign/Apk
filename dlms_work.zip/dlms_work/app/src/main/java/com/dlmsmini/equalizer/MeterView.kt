package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import java.util.Locale
import kotlin.math.exp
import kotlin.math.max

/**
 * Meter IN / OUT / GR untuk limiter.
 *  - OUT : puncak & RMS TERUKUR dari Visualizer (akhir rantai efek, setelah limiter).
 *  - IN  : ESTIMASI level sebelum limiter, dibalik dari kurva limiter (threshold/ratio/post-gain).
 *  - GR  : ESTIMASI gain reduction (dB). Android tidak menyediakan pembacaan GR dari DynamicsProcessing.
 */
class MeterView(context: Context) : View(context) {

    @Volatile private var outPeak = Meter.FLOOR_DB
    @Volatile private var outRms = Meter.FLOOR_DB
    @Volatile private var inEst = Meter.FLOOR_DB
    @Volatile private var grEst = 0f
    @Volatile private var clipUntil = 0L
    @Volatile private var lastData = 0L
    @Volatile private var limiterOn = false

    private var dOut = Meter.FLOOR_DB
    private var dIn = Meter.FLOOR_DB
    private var dGr = 0f
    private var pOut = Meter.FLOOR_DB
    private var pIn = Meter.FLOOR_DB
    private var pOutAt = 0L
    private var pInAt = 0L
    private var lastFrame = 0L

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = d(10f); isFakeBoldText = true; color = 0xFF9DAFC9.toInt() }
    private val value = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = d(10f); color = 0xFFEAF0FF.toInt(); textAlign = Paint.Align.RIGHT }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); strokeWidth = d(2f) }
    private val badge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF4D4D.toInt() }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = d(9f); textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val rect = RectF()

    /** [lim] = limiter yang berlaku, atau null bila limiter tidak aktif (IN = OUT, GR = 0). */
    fun submit(reading: Meter.Reading, lim: LimiterSettings?) {
        outPeak = reading.peakDb
        outRms = reading.rmsDb
        limiterOn = lim != null
        if (lim != null) {
            val est = Meter.limiterEstimate(reading.peakDb, lim)
            inEst = est.first
            grEst = est.second
        } else {
            inEst = reading.peakDb
            grEst = 0f
        }
        val now = SystemClock.uptimeMillis()
        if (reading.clipped) clipUntil = now + 900
        lastData = now
        postInvalidateOnAnimation()
    }

    fun clear() {
        outPeak = Meter.FLOOR_DB; outRms = Meter.FLOOR_DB; inEst = Meter.FLOOR_DB; grEst = 0f
        postInvalidateOnAnimation()
    }

    private fun follow(cur: Float, goal: Float, dt: Float): Float =
        if (goal >= cur) goal else max(goal, cur - 40f * dt)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.1f)
        lastFrame = now
        val fresh = now - lastData < 1500
        val goalOut = if (fresh) outPeak else Meter.FLOOR_DB
        val goalIn = if (fresh) inEst else Meter.FLOOR_DB
        val goalGr = if (fresh) grEst else 0f
        dOut = follow(dOut, goalOut, dt)
        dIn = follow(dIn, goalIn, dt)
        dGr = if (goalGr >= dGr) goalGr else max(goalGr, dGr - 30f * dt)
        if (dOut >= pOut) { pOut = dOut; pOutAt = now } else if (now - pOutAt > 1200) pOut = max(dOut, pOut - 20f * dt)
        if (dIn >= pIn) { pIn = dIn; pInAt = now } else if (now - pInAt > 1200) pIn = max(dIn, pIn - 20f * dt)

        val rowH = height / 3f
        val left = d(34f)
        val right = width - d(64f)
        drawRow(canvas, 0, rowH, left, right, "IN*", dIn, pIn, false)
        drawRow(canvas, 1, rowH, left, right, "OUT", dOut, pOut, false)
        drawGr(canvas, 2, rowH, left, right)
        if (now < clipUntil) {
            rect.set(width - d(44f), d(2f), width - d(2f), d(16f))
            canvas.drawRoundRect(rect, d(4f), d(4f), badge)
            canvas.drawText("CLIP", rect.centerX(), rect.centerY() + d(3f), badgeText)
        }
        val moving = fresh || dOut > Meter.FLOOR_DB + 1f || dIn > Meter.FLOOR_DB + 1f || dGr > 0.1f || now < clipUntil
        if (moving) postInvalidateOnAnimation() else lastFrame = 0L
    }

    private fun frac(db: Float): Float = ((db - MIN_DB) / (0f - MIN_DB)).coerceIn(0f, 1f)

    private fun drawRow(c: Canvas, row: Int, rowH: Float, left: Float, right: Float, name: String, db: Float, peak: Float, unused: Boolean) {
        val top = row * rowH + rowH * 0.28f
        val h = rowH * 0.44f
        c.drawText(name, d(2f), top + h * 0.85f, label)
        rect.set(left, top, right, top + h)
        c.drawRoundRect(rect, h / 2, h / 2, track)
        val fw = (right - left) * frac(db)
        if (fw > 1f) {
            fill.color = when {
                db > -3f -> 0xFFFF5A5A.toInt()
                db > -12f -> 0xFFFFC857.toInt()
                else -> 0xFF35D6A5.toInt()
            }
            rect.set(left, top, left + fw, top + h)
            c.drawRoundRect(rect, h / 2, h / 2, fill)
        }
        val px = left + (right - left) * frac(peak)
        c.drawLine(px, top - d(1f), px, top + h + d(1f), tick)
        val txt = if (db <= MIN_DB) "-∞ dB" else String.format(Locale.US, "%.1f dB", db)
        c.drawText(txt, width - d(2f), top + h * 0.85f, value)
    }

    private fun drawGr(c: Canvas, row: Int, rowH: Float, left: Float, right: Float) {
        val top = row * rowH + rowH * 0.28f
        val h = rowH * 0.44f
        c.drawText("GR*", d(2f), top + h * 0.85f, label)
        rect.set(left, top, right, top + h)
        c.drawRoundRect(rect, h / 2, h / 2, track)
        val fw = (right - left) * (dGr / GR_MAX).coerceIn(0f, 1f)
        if (fw > 1f) {
            fill.color = 0xFFFF7A59.toInt()
            rect.set(left, top, left + fw, top + h)
            c.drawRoundRect(rect, h / 2, h / 2, fill)
        }
        val txt = if (!limiterOn) "limiter off" else String.format(Locale.US, "-%.1f dB", dGr)
        c.drawText(txt, width - d(2f), top + h * 0.85f, value)
    }

    companion object {
        private const val MIN_DB = -48f
        private const val GR_MAX = 18f
    }
}

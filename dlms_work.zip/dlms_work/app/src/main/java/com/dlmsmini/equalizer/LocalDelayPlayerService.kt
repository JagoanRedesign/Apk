package com.dlmsmini.equalizer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.Process
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Pemutar lokal: decode compressed audio -> DelayDsp -> AudioTrack.
 * Tidak memakai MediaProjection / AudioPlaybackCapture, sehingga tidak menggandakan audio sistem.
 */
class LocalDelayPlayerService : Service() {
    companion object {
    const val ACTION_PLAY = "com.dlmsmini.equalizer.LOCAL_DELAY_PLAY"
    const val ACTION_STOP = "com.dlmsmini.equalizer.LOCAL_DELAY_STOP"
    const val EXTRA_URI = "audio_uri"
    private const val CHANNEL = "dlms_local_player"
    private const val NOTIF = 4201
    @Volatile var playing = false
        private set
    @Volatile var trackName: String = ""
        private set
    @Volatile var settings: DelaySettings = DelaySettings()
    @Volatile var onState: (() -> Unit)? = null
    fun play(ctx: Context, uri: Uri) {
        val i = Intent(ctx, LocalDelayPlayerService::class.java)
            .setAction(ACTION_PLAY).putExtra(EXTRA_URI, uri.toString())
        androidx.core.content.ContextCompat.startForegroundService(ctx, i)
    }
    fun stop(ctx: Context) {
        ctx.startService(Intent(ctx, LocalDelayPlayerService::class.java).setAction(ACTION_STOP))
    }
    }

    private val alive = AtomicBoolean(false)
    @Volatile private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopPlayback(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_PLAY -> {
                val raw = intent.getStringExtra(EXTRA_URI)
                if (raw.isNullOrBlank()) { stopSelf(); return START_NOT_STICKY }
                createChannel()
                try {
                    val n = notification("Memutar file lokal dengan Delay DSP")
                    if (Build.VERSION.SDK_INT >= 29) {
                        ServiceCompat.startForeground(this, NOTIF, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                    } else startForeground(NOTIF, n)
                } catch (t: Throwable) {
                    DiagLog.log("Local player foreground gagal: ${t.message}")
                    stopSelf(); return START_NOT_STICKY
                }
                stopPlayback()
                val uri = Uri.parse(raw)
                trackName = uri.lastPathSegment?.substringAfterLast('/') ?: "Audio lokal"
                alive.set(true)
                playing = true
                worker = Thread({ decodeAndPlay(uri) }, "dlms-local-player").also { it.start() }
                onState?.invoke()
            }
            else -> { stopSelf(); return START_NOT_STICKY }
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Pemutar Lokal DLMS", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(msg: String): Notification {
        val pi = PendingIntent.getActivity(this, 21,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle("DLMS Mini • Pemutar Lokal")
            .setContentText(msg).setContentIntent(pi).setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT).setPriority(NotificationCompat.PRIORITY_LOW).build()
    }

    private fun decodeAndPlay(uri: Uri) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        var extractor: MediaExtractor? = null
        var codec: MediaCodec? = null
        var output: AudioTrack? = null
        var sessionEngine: AudioEngine? = null
        try {
            extractor = MediaExtractor()
            extractor.setDataSource(this, uri, null)
            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { trackIndex = i; inputFormat = f; break }
            }
            if (trackIndex < 0 || inputFormat == null) throw IllegalArgumentException("File tidak memiliki track audio")
            extractor.selectTrack(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var dsp: DelayDsp? = null
            var inL = FloatArray(2048); var inR = FloatArray(2048)
            var outL = FloatArray(2048); var outR = FloatArray(2048)
            var outShort = ShortArray(4096)

            while (alive.get() && !outputDone) {
                if (!inputDone) {
                    val inputId = codec.dequeueInputBuffer(10000)
                    if (inputId >= 0) {
                        val ib = codec.getInputBuffer(inputId)!!
                        val size = extractor.readSampleData(ib, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputId, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputId, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outputId = codec.dequeueOutputBuffer(info, 10000)
                when {
                    outputId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val fmt = codec.outputFormat
                        sampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
                        pcmEncoding = if (Build.VERSION.SDK_INT >= 24 && fmt.containsKey(MediaFormat.KEY_PCM_ENCODING))
                            fmt.getInteger(MediaFormat.KEY_PCM_ENCODING) else AudioFormat.ENCODING_PCM_16BIT
                        if (pcmEncoding != AudioFormat.ENCODING_PCM_16BIT && pcmEncoding != AudioFormat.ENCODING_PCM_FLOAT)
                            throw IllegalStateException("Format PCM decoder tidak didukung")
                        val mask = AudioFormat.CHANNEL_OUT_STEREO
                        val min = AudioTrack.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
                        output = AudioTrack.Builder()
                            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                            .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(mask).build())
                            .setBufferSizeInBytes(maxOf(min, sampleRate / 5 * 4))
                            .setTransferMode(AudioTrack.MODE_STREAM).build()
                        if (output?.state != AudioTrack.STATE_INITIALIZED) throw IllegalStateException("AudioTrack gagal dibuat")
                        output?.play()
                        // Pasang EQ / limiter / efek DLMS ke sesi AudioTrack pemutar lokal.
                        try {
                            val prefs = Store.prefs(this)
                            val bandCount = prefs.getInt(Store.KEY_BANDS, Bands.DEFAULT)
                                .let { if (Bands.isValid(it)) it else Bands.DEFAULT }
                            val halfDb = IntArray(bandCount) { i ->
                                prefs.getInt(Bands.key(bandCount, i), 0)
                                    .coerceIn(-Store.maxHalf(prefs), Store.maxHalf(prefs))
                            }
                            sessionEngine = AudioEngine(output!!.audioSessionId).also { engine ->
                                engine.setMaster(Store.loadMaster(this))
                                engine.setFx(Store.loadEffects(this))
                                engine.setSplit(
                                    prefs.getString(Store.KEY_EQ_MODE, "1WAY") == "2WAY",
                                    Store.loadCrossover(prefs)
                                )
                                engine.configure(
                                    prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD),
                                    prefs.getBoolean(Store.KEY_EQ_ENABLED, true),
                                    halfDb,
                                    Store.loadLimiter(this)
                                )
                            }
                        } catch (fxError: Throwable) {
                            DiagLog.log("Efek sesi pemutar lokal tidak tersedia: ${fxError.message}")
                        }
                        dsp = DelayDsp(sampleRate)
                    }
                    outputId >= 0 -> {
                        val ob = codec.getOutputBuffer(outputId)
                        if (ob != null && info.size > 0 && output != null && dsp != null) {
                            ob.position(info.offset); ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.LITTLE_ENDIAN)
                            val bytesPerSample = if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                            val frameBytes = bytesPerSample * channels
                            val frames = info.size / frameBytes
                            var offset = 0
                            while (offset < frames && alive.get()) {
                                val count = minOf(2048, frames - offset)
                                for (i in 0 until count) {
                                    val l: Float
                                    val r: Float
                                    if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                        l = ob.float.coerceIn(-1f, 1f)
                                        r = if (channels > 1) ob.float.coerceIn(-1f, 1f) else l
                                    } else {
                                        l = ob.short / 32768f
                                        r = if (channels > 1) ob.short / 32768f else l
                                    }
                                    inL[i] = l; inR[i] = r
                                }
                                val cfg = settings
                                // Saat switch Delay OFF, pemutar tetap mengeluarkan audio asli tanpa efek.
                                val effective = if (cfg.enabled) cfg else cfg.copy(
                                    dryPct = 100, wetPct = 0, feedbackPct = 0, tape = false
                                )
                                dsp.process(inL, inR, outL, outR, count, effective, 0f)
                                for (i in 0 until count) {
                                    outShort[i * 2] = toShort(outL[i])
                                    outShort[i * 2 + 1] = toShort(outR[i])
                                }
                                var written = 0
                                while (written < count * 2 && alive.get()) {
                                    val n = output!!.write(outShort, written, count * 2 - written, AudioTrack.WRITE_BLOCKING)
                                    if (n < 0) throw IllegalStateException("AudioTrack write gagal: $n")
                                    written += n
                                }
                                offset += count
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputId, false)
                    }
                }
            }
            // Biarkan ekor gema keluar setelah decoder mencapai akhir file.
            if (alive.get() && output != null && dsp != null) {
                val cfg = settings
                val tailMs = if (cfg.enabled && cfg.wetPct > 0)
                    (cfg.timeMs * if (cfg.stereo && !cfg.pingPong) 1.5f else 1f).toInt() +
                        if (cfg.feedbackPct > 0) 2200 else 100
                else 0
                var remaining = (sampleRate * tailMs / 1000).coerceAtMost(sampleRate * 8)
                while (remaining > 0 && alive.get()) {
                    val count = minOf(2048, remaining)
                    java.util.Arrays.fill(inL, 0, count, 0f)
                    java.util.Arrays.fill(inR, 0, count, 0f)
                    val current = settings
                    val effective = if (current.enabled) current else current.copy(
                        dryPct = 100, wetPct = 0, feedbackPct = 0, tape = false
                    )
                    dsp.process(inL, inR, outL, outR, count, effective, 0f)
                    for (i in 0 until count) {
                        outShort[i * 2] = toShort(outL[i])
                        outShort[i * 2 + 1] = toShort(outR[i])
                    }
                    var written = 0
                    while (written < count * 2 && alive.get()) {
                        val n = output!!.write(outShort, written, count * 2 - written, AudioTrack.WRITE_BLOCKING)
                        if (n < 0) throw IllegalStateException("AudioTrack write gagal saat tail: $n")
                        written += n
                    }
                    remaining -= count
                }
            }
        } catch (t: Throwable) {
            if (alive.get()) DiagLog.log("Pemutar lokal berhenti: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            try { output?.pause(); output?.flush(); output?.stop() } catch (_: Throwable) {}
            try { output?.release() } catch (_: Throwable) {}
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { extractor?.release() } catch (_: Throwable) {}
            try { sessionEngine?.release() } catch (_: Throwable) {}
            alive.set(false); playing = false; worker = null
            onState?.invoke()
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Throwable) {}
            stopSelf()
        }
    }

    private fun toShort(v: Float): Short = (v.coerceIn(-1f, 0.999969f) * 32768f).toInt().toShort()

    private fun stopPlayback() {
        alive.set(false)
        val t = worker
        worker = null
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(1200) } catch (_: InterruptedException) {}
        }
        playing = false
        onState?.invoke()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }
}

package com.dlmsmini.equalizer

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import kotlin.math.roundToInt

/** Ekspor/impor preset sebagai teks (salin & tempel). */
object PresetCodec {
    const val FORMAT = "dlms-mini-presets"

    class Preset(val name: String, val halfDb: IntArray)

    /** Format: {"format":"dlms-mini-presets","version":2,"presets":[{"name":"..","bands_db":[10 angka dB]}]} */
    fun export(list: List<Preset>): String {
        val arr = JSONArray()
        for (p in list) {
            val bands = JSONArray()
            for (v in p.halfDb) bands.put(v / 2.0)
            arr.put(JSONObject().put("name", p.name).put("bands_db", bands))
        }
        return JSONObject().put("format", FORMAT).put("version", 2).put("presets", arr).toString(2)
    }

    /**
     * Terima: objek dengan "presets", satu objek preset, atau array preset.
     * "bands_db" = dB (dibulatkan 0,5 dB); "bands" (lama) = satuan half-dB.
     * Melempar IllegalArgumentException berpesan Indonesia jika tidak valid.
     */
    fun parse(raw: String): List<Preset> {
        val text = raw.trim()
        if (text.isEmpty()) throw IllegalArgumentException("Teks kosong")
        val items = ArrayList<JSONObject>()
        try {
            if (text.startsWith("[")) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
            } else {
                val root = JSONObject(text)
                val list = root.optJSONArray("presets")
                if (list != null) {
                    for (i in 0 until list.length()) items.add(list.getJSONObject(i))
                } else {
                    items.add(root)
                }
            }
        } catch (e: JSONException) {
            throw IllegalArgumentException("Format teks tidak valid (bukan data preset DLMS)")
        }
        if (items.isEmpty()) throw IllegalArgumentException("Tidak ada preset di dalam teks")

        val result = ArrayList<Preset>()
        for ((i, item) in items.withIndex()) {
            val name = item.optString("name", "").trim()
                .replace(Regex("[^\\p{L}\\p{N} _-]"), "").take(28)
                .ifBlank { "Imported ${i + 1}" }
            val db = item.optJSONArray("bands_db")
            val arr = db ?: item.optJSONArray("bands")
                ?: throw IllegalArgumentException("Preset $name tidak memiliki bands_db")
            if (arr.length() != 10) throw IllegalArgumentException("Preset $name harus memiliki 10 band")
            val out = IntArray(10)
            try {
                for (b in 0 until 10) {
                    val num = arr.getDouble(b)
                    out[b] = (if (db != null) num * 2.0 else num).roundToInt().coerceIn(-24, 24)
                }
            } catch (e: JSONException) {
                throw IllegalArgumentException("Preset $name berisi nilai yang bukan angka")
            }
            result.add(Preset(name, out))
        }
        return result
    }
}

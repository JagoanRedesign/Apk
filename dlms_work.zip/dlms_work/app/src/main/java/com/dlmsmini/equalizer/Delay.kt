package com.dlmsmini.equalizer

import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Parameter efek Delay. Semua nilai dalam satuan nyata (ms, persen, Hz). */
data class DelaySettings(
    val enabled: Boolean = false,
    val timeMs: Int = 250,          // 1..1000 ms
    val feedbackPct: Int = 35,      // 0..90 %
    val wetPct: Int = 35,           // 0..100 %
    val dryPct: Int = 0,            // 0..100 %
    val stereo: Boolean = false,    // kiri & kanan punya jalur gema sendiri (kanan 1,5x lebih lambat)
    val pingPong: Boolean = false,  // gema berpindah L -> R -> L ...
    val highCutHz: Int = 8000,      // 1000..20000 Hz, redam frekuensi tinggi di jalur gema
    val lowCutHz: Int = 100,        // 20..1000 Hz, redam frekuensi rendah di jalur gema
    val tape: Boolean = false       // karakter tape: wow/flutter + saturasi lembut
)

object DelaySpec {
    val time = Spec(1f, 1000f, 1f, 0, " ms")
    val feedback = Spec(0f, 90f, 1f, 0, " %")
    val mix = Spec(0f, 100f, 1f, 0, " %")
    val highCut = Spec(1000f, 20000f, 100f, 1, " kHz") { v -> String.format(Locale.US, "%.1f kHz", v / 1000f) }
    val lowCut = Spec(20f, 1000f, 10f, 0, " Hz")
}

class DelayPreset(val name: String, val settings: DelaySettings)

object DelayPresets {
    val all: List<DelayPreset> = listOf(
        DelayPreset("Short Echo", DelaySettings(timeMs = 90, feedbackPct = 25, wetPct = 30, dryPct = 0, highCutHz = 9000, lowCutHz = 150)),
        DelayPreset("Ping Pong", DelaySettings(timeMs = 320, feedbackPct = 45, wetPct = 40, dryPct = 0, stereo = true, pingPong = true, highCutHz = 8000, lowCutHz = 120)),
        DelayPreset("Tape Delay", DelaySettings(timeMs = 380, feedbackPct = 50, wetPct = 38, dryPct = 0, highCutHz = 3500, lowCutHz = 200, tape = true)),
        DelayPreset("Long Echo", DelaySettings(timeMs = 750, feedbackPct = 60, wetPct = 35, dryPct = 0, stereo = true, highCutHz = 6000, lowCutHz = 120))
    )

    /** Terapkan preset tanpa mengubah status aktif/nonaktif. */
    fun applyTo(current: DelaySettings, p: DelayPreset): DelaySettings = p.settings.copy(enabled = current.enabled)

    /** Nama preset yang cocok persis dengan pengaturan saat ini (null bila sudah diubah manual). */
    fun matching(s: DelaySettings): String? =
        all.firstOrNull { it.settings.copy(enabled = s.enabled) == s }?.name
}

/**
 * Mesin Delay DSP internal dengan buffer audio sendiri (ring buffer per kanal).
 *
 * Topologi per sampel:
 *   gema  = baca ring buffer (interpolasi linear, waktu dihaluskan) -> low-pass(High Cut) -> high-pass(Low Cut) [-> saturasi tape]
 *   tulis = masukan + gema * feedback        (mode mono / stereo / ping-pong menentukan rutenya)
 *   keluar = masukan * Dry + gema * Wet
 *
 * Mode:
 *  - Mono      : satu jalur, gema sama di kiri dan kanan.
 *  - Stereo    : dua jalur terpisah; kanan tertunda 1,5x waktu kiri sehingga gema berselang-seling.
 *  - Ping Pong : masukan mono ke jalur kiri, feedback menyilang L -> R -> L ... (mengalahkan Stereo).
 *
 * [latencyMs] dikurangkan dari waktu delay: jalur capture-playback sudah menambah latensi sendiri, sehingga
 * gema tetap jatuh di waktu yang diminta. Waktu yang lebih kecil dari latensi tidak dapat dicapai.
 *
 * Kelas ini murni Kotlin (tanpa API Android) sehingga dapat diuji di JVM.
 */
class DelayDsp(val sampleRate: Int) {
    private val size = (sampleRate * 1.6f).toInt() + 16
    private val bufL = FloatArray(size)
    private val bufR = FloatArray(size)
    private var w = 0
    private var curL = 1f
    private var curR = 1f
    private var fb = 0f
    private var wet = 0f
    private var dry = 0f
    private var primed = false
    private var phaseWow = 0.0
    private var phaseFlutter = 0.0
    private var lastHi = -1
    private var lastLo = -1
    private var lastMode = -1

    private val lpL = Biquad()
    private val lpR = Biquad()
    private val hpL = Biquad()
    private val hpR = Biquad()

    fun reset() {
        bufL.fill(0f); bufR.fill(0f)
        w = 0
        primed = false
        lpL.clear(); lpR.clear(); hpL.clear(); hpR.clear()
        lastMode = -1
    }

    /**
     * Proses [frames] sampel. Larik masukan dan keluaran boleh sama.
     * Dipanggil dari satu thread audio saja.
     */
    fun process(
        inL: FloatArray, inR: FloatArray, outL: FloatArray, outR: FloatArray,
        frames: Int, s: DelaySettings, latencyMs: Float
    ) {
        val fs = sampleRate.toFloat()
        val mode = if (s.pingPong) MODE_PING else if (s.stereo) MODE_STEREO else MODE_MONO
        val tL = s.timeMs.toFloat()
        val tR = if (mode == MODE_STEREO) tL * 1.5f else tL
        val maxD = (size - 8).toFloat()
        val dL = ((tL - latencyMs) * fs / 1000f).coerceIn(1f, maxD)
        val dR = ((tR - latencyMs) * fs / 1000f).coerceIn(1f, maxD)
        val fbT = (s.feedbackPct.coerceIn(0, 90)) / 100f
        val wetT = s.wetPct.coerceIn(0, 100) / 100f
        val dryT = s.dryPct.coerceIn(0, 100) / 100f

        if (!primed) {
            curL = dL; curR = dR
            fb = fbT; wet = wetT; dry = dryT
            primed = true
        }
        if (s.highCutHz != lastHi) {
            val fc = min(s.highCutHz.toFloat(), fs * 0.45f)
            lpL.lowpass(fc, fs); lpR.lowpass(fc, fs)
            lastHi = s.highCutHz
        }
        if (s.lowCutHz != lastLo) {
            val fc = max(s.lowCutHz.toFloat(), 10f)
            hpL.highpass(fc, fs); hpR.highpass(fc, fs)
            lastLo = s.lowCutHz
        }
        if (mode != lastMode) {
            lpL.clear(); lpR.clear(); hpL.clear(); hpR.clear()
            lastMode = mode
        }

        val tape = s.tape
        val wowInc = 2.0 * PI * 0.7 / fs
        val flutInc = 2.0 * PI * 7.3 / fs
        val wowDepth = 0.45f * fs / 1000f      // +-0,45 ms
        val flutDepth = 0.06f * fs / 1000f     // +-0,06 ms
        val slew = 0.002f
        val gs = 0.002f

        for (i in 0 until frames) {
            val xl = inL[i]
            val xr = inR[i]
            fb += (fbT - fb) * gs
            wet += (wetT - wet) * gs
            dry += (dryT - dry) * gs
            curL += (dL - curL) * slew
            curR += (dR - curR) * slew

            var mod = 0f
            if (tape) {
                phaseWow += wowInc; if (phaseWow > TWO_PI) phaseWow -= TWO_PI
                phaseFlutter += flutInc; if (phaseFlutter > TWO_PI) phaseFlutter -= TWO_PI
                mod = (sin(phaseWow) * wowDepth + sin(phaseFlutter) * flutDepth).toFloat()
            }

            val rawL = readFrac(bufL, curL + mod)
            var eL = hpL.process(lpL.process(rawL))
            var eR: Float
            if (mode == MODE_MONO) {
                eR = eL
            } else {
                val rawR = readFrac(bufR, curR + mod * 0.7f)
                eR = hpR.process(lpR.process(rawR))
            }
            if (tape) {
                eL = sat(eL)
                eR = if (mode == MODE_MONO) eL else sat(eR)
            }

            val inMono = 0.5f * (xl + xr)
            val wl: Float
            val wr: Float
            when (mode) {
                MODE_PING -> { wl = inMono + eR * fb; wr = eL * fb }
                MODE_STEREO -> { wl = xl + eL * fb; wr = xr + eR * fb }
                else -> { val e = inMono + eL * fb; wl = e; wr = e }
            }
            bufL[w] = guard(wl)
            bufR[w] = guard(wr)
            w++
            if (w >= size) w = 0

            outL[i] = guard(xl * dry + eL * wet)
            outR[i] = guard(xr * dry + eR * wet)
        }
    }

    private fun readFrac(buf: FloatArray, delaySamples: Float): Float {
        var d = delaySamples
        if (d < 1f) d = 1f
        val maxD = (size - 4).toFloat()
        if (d > maxD) d = maxD
        var pos = w.toDouble() - d
        if (pos < 0.0) pos += size
        val i0 = pos.toInt()
        val frac = (pos - i0).toFloat()
        val i1 = if (i0 + 1 >= size) 0 else i0 + 1
        return buf[i0] + (buf[i1] - buf[i0]) * frac
    }

    private fun sat(x: Float): Float {
        val a = if (x > 3f) 3f else if (x < -3f) -3f else x
        return a * (27f + a * a) / (27f + 9f * a * a)
    }

    private fun guard(v: Float): Float {
        if (v != v) return 0f
        if (v > 4f) return 4f
        if (v < -4f) return -4f
        return if (abs(v) < 1e-18f) 0f else v
    }

    private class Biquad {
        private var b0 = 1f
        private var b1 = 0f
        private var b2 = 0f
        private var a1 = 0f
        private var a2 = 0f
        private var z1 = 0f
        private var z2 = 0f

        fun clear() { z1 = 0f; z2 = 0f }

        fun lowpass(fc: Float, fs: Float) {
            val w0 = 2.0 * PI * fc / fs
            val c = cos(w0).toFloat()
            val alpha = (sin(w0) / (2.0 * Q)).toFloat()
            val a0 = 1f + alpha
            b0 = (1f - c) / 2f / a0
            b1 = (1f - c) / a0
            b2 = b0
            a1 = -2f * c / a0
            a2 = (1f - alpha) / a0
        }

        fun highpass(fc: Float, fs: Float) {
            val w0 = 2.0 * PI * fc / fs
            val c = cos(w0).toFloat()
            val alpha = (sin(w0) / (2.0 * Q)).toFloat()
            val a0 = 1f + alpha
            b0 = (1f + c) / 2f / a0
            b1 = -(1f + c) / a0
            b2 = b0
            a1 = -2f * c / a0
            a2 = (1f - alpha) / a0
        }

        fun process(x: Float): Float {
            val y = b0 * x + z1
            z1 = b1 * x - a1 * y + z2
            z2 = b2 * x - a2 * y
            return y
        }

        companion object { const val Q = 0.70710678 }
    }

    companion object {
        private const val MODE_MONO = 0
        private const val MODE_STEREO = 1
        private const val MODE_PING = 2
        private const val TWO_PI = 2.0 * PI
    }
}

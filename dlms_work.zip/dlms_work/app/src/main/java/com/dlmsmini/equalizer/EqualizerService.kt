package com.dlmsmini.equalizer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Pemilik semua efek audio. Berjalan sebagai foreground service agar EQ tetap aktif di latar belakang.
 *
 * Dua mode:
 *  - Mix Global : efek dipasang ke sesi 0 (seluruh output audio).
 *  - Mode Sesi Aplikasi: efek dipasang per sesi audio pemutar musik, berdasarkan broadcast
 *    OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION yang dikirim pemutar (mis. YouTube Music, Spotify).
 */
class EqualizerService : Service() {

    companion object {
        const val ACTION_STOP = "com.dlmsmini.equalizer.action.STOP"
        private const val CHANNEL_ID = "dlms_background"
        private const val NOTIF_ID = 4101
        private const val MAX_SESSIONS = 8

        @Volatile var activePackages: Set<String> = emptySet()
            private set

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, EqualizerService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    inner class LocalBinder : Binder() {
        val service: EqualizerService get() = this@EqualizerService
    }

    private class SessionEntry(val pkg: String, val engine: AudioEngine)

    private val binder = LocalBinder()
    private val handler = Handler(Looper.getMainLooper())
    private var values = IntArray(Bands.DEFAULT)
    private var eqOn = true
    private var limiter = LimiterSettings()
    private var pipeline = Store.PIPE_STANDARD
    private var sessionMode = false
    private var stabilize = true
    private var twoWay = false
    private var crossover = Store.DEFAULT_CROSSOVER
    private var fgActive = false
    private var receiverRegistered = false

    private val global = AudioEngine(0)
    private val sessions = LinkedHashMap<Int, SessionEntry>()
    private var globalStatus = ""

    /** Dipanggil (di thread utama) saat status atau sesi berubah. */
    var onChanged: (() -> Unit)? = null

    var status: String = "Menyiapkan audio…"
        private set

    val isSessionMode: Boolean get() = sessionMode
    val sessionCount: Int get() = sessions.size
    val sessionPackages: List<String> get() = sessions.values.map { it.pkg }.distinct()
    val limiterAvailable: Boolean
        get() = if (sessionMode) Build.VERSION.SDK_INT >= Build.VERSION_CODES.P else global.limiterAvailable

    /** Sesi audio yang cocok untuk Visualizer: 0 (global), id sesi terbaru, atau -1 bila belum ada. */
    fun visualizerSession(): Int = if (!sessionMode) 0 else (sessions.keys.lastOrNull() ?: -1)

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when {
            key == null -> reload()
            key == Store.KEY_SESSION_MODE || key == Store.KEY_PIPELINE || key == Store.KEY_BANDS || key == Store.KEY_CROSSOVER -> reload()
            key == Store.KEY_BG -> {
                if (!Store.prefs(this).getBoolean(Store.KEY_BG, true)) stopFg()
            }
            key.startsWith("app_on_") -> dropDisabledSessions()
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR_BAD_VALUE)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) ?: "unknown"
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> onSessionOpen(id, pkg)
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> onSessionClose(id)
            }
        }
    }

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        createChannel()
        Store.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        try {
            ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
            receiverRegistered = true
        } catch (_: Exception) {
        }
        reload()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopFg()
            return START_NOT_STICKY
        }
        startFg()
        if (!Store.prefs(this).getBoolean(Store.KEY_BG, true)) {
            stopFg()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        clearSessions()
        global.release()
        onChanged = null
        activePackages = emptySet()
        super.onDestroy()
    }

    // ---------- foreground ----------

    private fun startFg() {
        try {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
            fgActive = true
        } catch (_: Exception) {
            fgActive = false
        }
    }

    private fun stopFg() {
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        fgActive = false
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Equalizer latar belakang", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Menjaga efek equalizer tetap aktif saat aplikasi ditutup"
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, EqualizerService::class.java).setAction(ACTION_STOP), flags
        )
        val text = if (sessionMode) {
            if (sessions.isEmpty()) "Mode Sesi Aplikasi • menunggu pemutar musik"
            else "Mode Sesi Aplikasi • ${sessions.size} sesi aktif"
        } else {
            "Mix Global • EQ ${if (eqOn) "aktif" else "nonaktif"}" + if (limiter.enabled) " • Limiter aktif" else ""
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("DLMS Mini Equalizer")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Matikan", stop)
            .build()
    }

    private fun updateNotification() {
        if (!fgActive) return
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    // ---------- konfigurasi ----------

    /** Baca ulang semua pengaturan dari penyimpanan dan terapkan ke efek. */
    fun reload() {
        val p = Store.prefs(this)
        val bands = p.getInt(Store.KEY_BANDS, Bands.DEFAULT).let { if (Bands.isValid(it)) it else Bands.DEFAULT }
        values = Bands.load(p, bands)
        eqOn = p.getBoolean(Store.KEY_EQ_ENABLED, true)
        limiter = Store.loadLimiter(this)
        stabilize = p.getBoolean(Store.KEY_STABILIZE, true)
        twoWay = p.getString(Store.KEY_EQ_MODE, "1WAY") == "2WAY"
        crossover = p.getInt(Store.KEY_CROSSOVER, Store.DEFAULT_CROSSOVER)
        pipeline = p.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
        val newMode = p.getBoolean(Store.KEY_SESSION_MODE, false)
        if (newMode != sessionMode) {
            sessionMode = newMode
            clearSessions()
            global.release()
            if (sessionMode) scheduleStabilize()
        }
        applyAll()
    }

    fun updateEq(on: Boolean, halfDb: IntArray) {
        eqOn = on
        if (halfDb.size != values.size) {
            // Jumlah band berubah: bangun ulang efek dengan susunan baru.
            values = halfDb.copyOf()
            applyAll()
            return
        }
        for (i in values.indices) values[i] = halfDb[i]
        if (sessionMode) sessions.values.forEach { it.engine.updateEq(eqOn, values) }
        else global.updateEq(eqOn, values)
        updateNotification()
    }

    fun updateLimiter(lim: LimiterSettings, on: Boolean) {
        limiter = lim
        eqOn = on
        if (sessionMode) sessions.values.forEach { it.engine.updateLimiter(limiter, eqOn) }
        else global.updateLimiter(limiter, eqOn)
        updateNotification()
    }

    private fun applyAll() {
        if (sessionMode) {
            sessions.values.forEach {
                it.engine.setSplit(twoWay, crossover)
                it.engine.configure(pipeline, eqOn, values, limiter)
            }
            refreshStatus(notify = false)
        } else {
            global.setSplit(twoWay, crossover)
            globalStatus = global.configure(pipeline, eqOn, values, limiter)
            status = globalStatus
        }
        publishActive()
        updateNotification()
        onChanged?.invoke()
    }

    private fun refreshStatus(notify: Boolean = true) {
        status = if (sessionMode) {
            if (sessions.isEmpty()) "Status: Mode Sesi Aplikasi aktif • menunggu pemutar musik"
            else "Status: Mode Sesi Aplikasi • ${sessions.size} sesi (${sessionPackages.joinToString(", ") { shortName(it) }})"
        } else globalStatus
        if (notify) {
            publishActive()
            updateNotification()
            onChanged?.invoke()
        }
    }

    private fun shortName(pkg: String): String = pkg.substringAfterLast('.')

    private fun publishActive() {
        activePackages = sessions.values.map { it.pkg }.toSet()
    }

    // ---------- sesi aplikasi ----------

    private fun onSessionOpen(id: Int, pkg: String) {
        if (!sessionMode || id <= 0 || pkg == packageName) return
        AppStore.add(this, pkg)
        if (!AppStore.isEnabled(this, pkg)) return
        if (sessions.containsKey(id)) return
        val engine = AudioEngine(id)
        engine.setSplit(twoWay, crossover)
        engine.configure(pipeline, eqOn, values, limiter)
        if (!engine.isActive) {
            engine.release()
            return
        }
        while (sessions.size >= MAX_SESSIONS) {
            val oldest = sessions.keys.first()
            sessions.remove(oldest)?.engine?.release()
        }
        sessions[id] = SessionEntry(pkg, engine)
        refreshStatus()
    }

    private fun onSessionClose(id: Int) {
        val entry = sessions.remove(id) ?: return
        entry.engine.release()
        refreshStatus()
    }

    private fun dropDisabledSessions() {
        val gone = sessions.filter { !AppStore.isEnabled(this, it.value.pkg) }.keys.toList()
        if (gone.isEmpty()) return
        gone.forEach { sessions.remove(it)?.engine?.release() }
        refreshStatus()
    }

    private fun clearSessions() {
        sessions.values.forEach { it.engine.release() }
        sessions.clear()
        publishActive()
    }

    /**
     * Bila musik sudah berputar sebelum layanan dimulai, pemutar tidak mengirim ulang sesinya.
     * Lewati satu lagu agar pemutar membuat sesi baru sehingga Mode Sesi Aplikasi langsung terkunci.
     */
    private fun scheduleStabilize() {
        if (!stabilize) return
        handler.postDelayed({
            if (sessionMode && sessions.isEmpty()) {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                if (am.isMusicActive) {
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT))
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_NEXT))
                }
            }
        }, 2500)
    }
}

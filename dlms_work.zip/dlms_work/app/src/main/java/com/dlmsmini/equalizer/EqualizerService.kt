package com.dlmsmini.equalizer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.media.audiofx.AudioEffect
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

enum class Level { OFF, OK, PARTIAL, FAIL, WAIT }

/** Ringkasan "apakah efek benar-benar aktif" untuk ditampilkan di layar utama. */
class Indicator(val level: Level, val text: String, val details: List<EffectStatus>)

/**
 * Pemilik semua efek audio. Berjalan sebagai foreground service agar EQ tetap aktif di latar belakang.
 *
 * Dua mode:
 *  - Mix Global : efek dipasang ke sesi 0 (seluruh output audio).
 *  - Mode Sesi Aplikasi: efek dipasang per sesi audio pemutar musik, berdasarkan broadcast
 *    OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION yang dikirim pemutar (mis. YouTube Music, Spotify).
 *
 * Penyesuaian Android terbaru:
 *  - Tipe foreground service mediaPlayback + izin FOREGROUND_SERVICE_MEDIA_PLAYBACK (Android 14+).
 *  - Penolakan start foreground dari latar belakang (Android 12+) ditangkap; layanan tidak menggantung sebagai
 *    service latar biasa, dan alasannya dicatat ([lastFgError]) untuk layar Diagnostik.
 *  - Notifikasi bisa disembunyikan pengguna (Android 13+) tanpa mematikan layanan.
 *  - Perangkat audio berganti (Bluetooth/kabel/speaker) memicu penerapan ulang efek, karena sebagian ROM
 *    menjatuhkan efek global saat rute berpindah.
 */
class EqualizerService : Service() {

    companion object {
        const val ACTION_STOP = "com.dlmsmini.equalizer.action.STOP"
        const val ACTION_TOGGLE_MASTER = "com.dlmsmini.equalizer.action.TOGGLE_MASTER"
        private const val CHANNEL_ID = "dlms_background"
        private const val NOTIF_ID = 4101
        private const val MAX_SESSIONS = 8
        private const val WATCHDOG_MS = 5000L

        @Volatile var activePackages: Set<String> = emptySet()
            private set

        /** Alasan terakhir sistem menolak foreground service (null bila normal). */
        @Volatile var lastFgError: String? = null
            private set

        /** Mengembalikan false bila sistem menolak memulai layanan (mis. dari latar belakang). */
        fun start(ctx: Context): Boolean = try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, EqualizerService::class.java))
            true
        } catch (e: Exception) {
            lastFgError = e.javaClass.simpleName + ": " + (e.message ?: "")
            DiagLog.log("Start layanan ditolak: $lastFgError")
            false
        }
    }

    inner class LocalBinder : Binder() {
        val service: EqualizerService get() = this@EqualizerService
    }

    private class SessionEntry(val pkg: String, val engine: AudioEngine)

    private val binder = LocalBinder()
    private val handler = Handler(Looper.getMainLooper())
    private var values = IntArray(Bands.DEFAULT)
    private var valuesR = IntArray(Bands.DEFAULT)
    private var chSplit = false
    private var eqOn = true
    private var limiter = LimiterSettings()
    private var pipeline = Store.PIPE_STANDARD
    private var sessionMode = false
    private var stabilize = true
    private var twoWay = false
    private var fx = EffectSettings()
    private var master = MasterSettings()
    private var xo = CrossoverSettings()
    private var peq = PeqSettings()
    private var swapXo = false
    private var fgActive = false
    private var receiverRegistered = false
    private var monitor: AudioDeviceMonitor? = null

    private val global = AudioEngine(0).also { g -> g.onHealthEvent = { r -> scheduleVerify(r) } }
    private val sessions = LinkedHashMap<Int, SessionEntry>()
    private var globalStatus = ""

    private val eqThrottle = Throttle(handler, 30) {
        engines().forEach {
            it.setChannelEq(chSplit, valuesR)
            it.updateEq(eqOn, values)
        }
        updateNotification()
    }
    private val fxThrottle = Throttle(handler, 40) { engines().forEach { it.updateFx(fx, eqOn) } }
    private val limThrottle = Throttle(handler, 40) { engines().forEach { it.updateLimiter(limiter, eqOn) } }
    private val peqThrottle = Throttle(handler, 40) { engines().forEach { it.updatePeq(peq) } }
    private val xoThrottle = Throttle(handler, 40) { engines().forEach { it.updateCrossover(xo, swapXo) } }
    private var playbackCb: AudioManager.AudioPlaybackCallback? = null

    private val verifyRunnable = Runnable { verifyAll("terjadwal") }
    private val stage2 = Runnable { verifyAll("pasca-rute 1") }
    private val stage3 = Runnable { verifyAll("pasca-rute 2") }
    private val watchdog = object : Runnable {
        override fun run() {
            verifyAll("pengawas", quiet = true)
            handler.postDelayed(this, WATCHDOG_MS)
        }
    }

    /** Dipanggil (di thread utama) saat status, sesi, atau perangkat audio berubah. */
    var onChanged: (() -> Unit)? = null

    var status: String = "Menyiapkan audio…"
        private set

    var route: AudioRoute = AudioRoute.UNKNOWN
        private set

    val isSessionMode: Boolean get() = sessionMode
    val sessionCount: Int get() = sessions.size
    val sessionPackages: List<String> get() = sessions.values.map { it.pkg }.distinct()
    val masterOn: Boolean get() = master.on
    /** Limiter yang sedang benar-benar berlaku (milik pengguna atau pengaman), untuk meter; null bila tidak aktif. */
    fun limiterSnapshot(): LimiterSettings? {
        for (e in engines()) {
            val l = e.effectiveLimiterSnapshot()
            if (l != null) return l
        }
        return null
    }

    /** True bila Post-EQ rapat tersedia (Parametric EQ & slope crossover dapat diatur). */
    val peqSupported: Boolean get() = engines().any { it.gridSupported }

    /** True bila EQ kiri/kanan terpisah benar-benar diterapkan per kanal (bukan rata-rata). */
    val channelEqActive: Boolean get() = engines().any { it.channelEqActive }

    /** True bila ada efek yang kendalinya direbut berulang kali oleh aplikasi/efek lain. */
    val contested: Boolean get() = engines().any { it.contested }

    val limiterReadbackNote: String get() = engines().map { it.limiterReadbackNote() }.firstOrNull { it.isNotEmpty() }.orEmpty()

    val limiterAvailable: Boolean
        get() = if (sessionMode) Build.VERSION.SDK_INT >= Build.VERSION_CODES.P else global.limiterAvailable

    /** Mode 2-Way yang sungguh-sungguh diterapkan (lihat AudioEngine.SPLIT_*). */
    val splitMode: Int
        get() = if (sessionMode) (sessions.values.firstOrNull()?.engine?.split ?: AudioEngine.SPLIT_NONE) else global.split

    val safetyLimiterActive: Boolean
        get() = engines().any { it.safetyLimiterActive }

    /** Sesi audio yang cocok untuk Visualizer: 0 (global), id sesi terbaru, atau -1 bila belum ada. */
    fun visualizerSession(): Int = if (!sessionMode) 0 else (sessions.keys.lastOrNull() ?: -1)

    private fun engines(): List<AudioEngine> =
        if (sessionMode) sessions.values.map { it.engine } else listOf(global)

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when {
            key == null -> reload()
            key == Store.KEY_SESSION_MODE || key == Store.KEY_PIPELINE || key == Store.KEY_BANDS ||
                key == Store.KEY_MASTER || key == Store.KEY_EQ_LIMIT ||
                key == Store.KEY_CLIP_MODE || key == Store.KEY_CH_SPLIT -> reload()
            key == Store.KEY_BG -> {
                if (!Store.prefs(this).getBoolean(Store.KEY_BG, true)) stopFg()
            }
            key.startsWith("app_on_") -> dropDisabledSessions()
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR_BAD_VALUE)
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) ?: "unknown"
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> onSessionOpen(id, pkg)
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> onSessionClose(id)
            }
        }
    }

    private val rebuildRunnable = Runnable { rebuildAll("perangkat audio berganti") }

    private fun scheduleVerify(reason: String, delay: Long = 400) {
        DiagLog.log("Pemeriksaan efek dijadwalkan: $reason")
        handler.removeCallbacks(verifyRunnable)
        handler.postDelayed(verifyRunnable, delay)
    }

    /** Periksa kendali, status enable, dan parameter tiap mesin; pulihkan bila perlu. */
    private fun verifyAll(reason: String, quiet: Boolean = false) {
        if (!master.on) return
        var changed = false
        for (e in engines()) if (e.verifyAndRepair() != Health.OK) changed = true
        if (changed) {
            DiagLog.log("Pemeriksaan efek ($reason): efek dipulihkan/dikoreksi")
            if (!sessionMode) {
                globalStatus = global.describeNow()
                status = globalStatus
            }
            updateNotification()
            onChanged?.invoke()
        } else if (!quiet) {
            DiagLog.log("Pemeriksaan efek ($reason): semua sehat")
        }
    }

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        createChannel()
        Store.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        try {
            ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
            receiverRegistered = true
        } catch (_: Exception) {
        }
        reload()
        monitor = AudioDeviceMonitor(this) { r, changed -> onRoute(r, changed) }.also { it.start() }
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val cb = object : AudioManager.AudioPlaybackCallback() {
                override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) {
                    scheduleVerify("pemutaran berubah", 1200)
                }
            }
            am.registerAudioPlaybackCallback(cb, handler)
            playbackCb = cb
        } catch (_: Throwable) {
        }
        handler.postDelayed(watchdog, WATCHDOG_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopFg()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_MASTER -> {
                val p = Store.prefs(this)
                p.edit().putBoolean(Store.KEY_MASTER, !p.getBoolean(Store.KEY_MASTER, true)).apply()
                // prefListener -> reload() memperbarui efek dan notifikasi.
                if (!fgActive) startFg()
                return START_STICKY
            }
        }
        if (!startFg()) {
            // Android 12+ melarang start foreground dari latar belakang (mis. restart sticky). Jangan menggantung
            // sebagai service latar biasa yang akan dimatikan sistem; selama Activity terikat, efek tetap bekerja.
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Store.prefs(this).getBoolean(Store.KEY_BG, true)) {
            stopFg()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        listOf(eqThrottle, fxThrottle, limThrottle, peqThrottle, xoThrottle).forEach { it.cancel() }
        try { playbackCb?.let { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).unregisterAudioPlaybackCallback(it) } } catch (_: Throwable) {}
        playbackCb = null
        monitor?.stop()
        monitor = null
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        clearSessions()
        global.release()
        onChanged = null
        activePackages = emptySet()
        super.onDestroy()
    }

    // ---------- foreground ----------

    private fun startFg(): Boolean {
        return try {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
            fgActive = true
            lastFgError = null
            true
        } catch (e: Exception) {
            fgActive = false
            lastFgError = e.javaClass.simpleName + ": " + (e.message ?: "")
            DiagLog.log("Foreground service ditolak sistem: $lastFgError")
            false
        }
    }

    private fun stopFg() {
        try { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        fgActive = false
        stopSelf()
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Equalizer latar belakang", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Menjaga efek equalizer tetap aktif saat aplikasi ditutup"
            setShowBadge(false)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, EqualizerService::class.java).setAction(ACTION_STOP), flags
        )
        val toggle = PendingIntent.getService(
            this, 2, Intent(this, EqualizerService::class.java).setAction(ACTION_TOGGLE_MASTER), flags
        )
        val routeText = if (route.kind != RouteKind.UNKNOWN) " • ${route.label}" else ""
        val text = when {
            !master.on -> "Master OFF • semua efek dilewati$routeText"
            sessionMode && sessions.isEmpty() -> "Mode Sesi Aplikasi • menunggu pemutar musik$routeText"
            sessionMode -> "Mode Sesi Aplikasi • ${sessions.size} sesi aktif$routeText"
            else -> "Mix Global • EQ ${if (eqOn) "aktif" else "nonaktif"}" +
                (if (limiter.enabled) " • Limiter aktif" else "") + routeText
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("DLMS Mini Equalizer")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, if (master.on) "Master OFF" else "Master ON", toggle)
            .addAction(0, "Matikan", stop)
            .build()
    }

    private fun updateNotification() {
        if (!fgActive) return
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    // ---------- perangkat audio ----------

    private fun onRoute(r: AudioRoute, changed: Boolean) {
        route = r
        if (changed) {
            DiagLog.log("Perangkat audio berganti: ${r.label}" + if (r.name.isNotEmpty()) " (${r.name})" else "")
            // Beri waktu rute Bluetooth/kabel mapan, lalu pasang ulang efek.
            handler.removeCallbacks(rebuildRunnable)
            handler.removeCallbacks(stage2)
            handler.removeCallbacks(stage3)
            handler.postDelayed(rebuildRunnable, 700)
            // Bluetooth sering baru mapan beberapa detik kemudian: periksa lagi dan pulihkan bila efek hilang.
            handler.postDelayed(stage2, 3000)
            handler.postDelayed(stage3, 7000)
        }
        updateNotification()
        onChanged?.invoke()
    }

    /** Lepas dan bangun ulang semua efek (rute berganti, atau diminta manual dari layar Diagnostik). */
    fun rebuildAll(reason: String) {
        DiagLog.log("Efek diterapkan ulang ($reason)")
        engines().forEach { it.resetContest() }
        global.release()
        sessions.values.forEach { it.engine.release() }
        applyAll()
        val ind = indicator()
        DiagLog.log("Verifikasi: ${ind.text}")
    }

    // ---------- konfigurasi ----------

    /** Baca ulang semua pengaturan dari penyimpanan dan terapkan ke efek. */
    fun reload() {
        val p = Store.prefs(this)
        val bands = p.getInt(Store.KEY_BANDS, Bands.DEFAULT).let { if (Bands.isValid(it)) it else Bands.DEFAULT }
        val maxHalf = Store.maxHalf(p)
        values = Bands.load(p, bands).also { arr -> for (i in arr.indices) arr[i] = arr[i].coerceIn(-maxHalf, maxHalf) }
        valuesR = Bands.loadR(p, bands).also { arr -> for (i in arr.indices) arr[i] = arr[i].coerceIn(-maxHalf, maxHalf) }
        chSplit = p.getBoolean(Store.KEY_CH_SPLIT, false)
        eqOn = p.getBoolean(Store.KEY_EQ_ENABLED, true)
        limiter = Store.loadLimiter(this)
        stabilize = p.getBoolean(Store.KEY_STABILIZE, true)
        twoWay = p.getString(Store.KEY_EQ_MODE, "1WAY") == "2WAY"
        xo = Store.loadCrossoverSettings(p)
        peq = PeqStore.load(this)
        swapXo = p.getBoolean(Store.KEY_XO_SWAP, false)
        fx = Store.loadEffects(this)
        master = Store.loadMaster(this)
        pipeline = p.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
        val newMode = p.getBoolean(Store.KEY_SESSION_MODE, false)
        if (newMode != sessionMode) {
            sessionMode = newMode
            clearSessions()
            global.release()
            if (sessionMode) scheduleStabilize()
        }
        applyAll()
    }

    /**
     * Kurva EQ berubah. [right] dan [split] opsional: tanpa keduanya, mode kanal yang tersimpan tetap dipakai.
     * [split] = true: kanal kiri memakai [halfDb] dan kanal kanan memakai [right] (butuh DynamicsProcessing).
     */
    fun updateEq(on: Boolean, halfDb: IntArray, right: IntArray? = null, split: Boolean = chSplit) {
        eqOn = on
        val splitChanged = split != chSplit
        chSplit = split
        if (halfDb.size != values.size) {
            // Jumlah band berubah: bangun ulang efek dengan susunan baru.
            values = halfDb.copyOf()
            valuesR = if (right != null && right.size == halfDb.size) right.copyOf() else halfDb.copyOf()
            applyAll()
            return
        }
        for (i in values.indices) values[i] = halfDb[i]
        if (right != null && right.size == valuesR.size) for (i in valuesR.indices) valuesR[i] = right[i]
        if (splitChanged) {
            // Pindah antara stereo dan L/R terpisah dapat mengganti pipeline (Equalizer sistem <-> DynamicsProcessing).
            if (master.on) applyAll() else updateNotification()
            return
        }
        if (master.on) eqThrottle.fire() else updateNotification()
    }

    /** Terapkan efek tambahan (balance, bass, virtualizer, loudness, reverb, kompresor, tone). */
    fun updateEffects(f: EffectSettings) {
        fx = f
        if (master.on) fxThrottle.fire()
    }

    /** Parametric EQ berubah. */
    fun updatePeq(p: PeqSettings) {
        peq = p
        if (master.on) peqThrottle.fire()
    }

    /** Crossover 2-Way berubah (frekuensi, slope, LPF/HPF, gain, tukar). */
    fun updateCrossover(x: CrossoverSettings, swap: Boolean) {
        xo = x
        swapXo = swap
        if (master.on) xoThrottle.fire()
    }

    /** Master ON/OFF, volume L/R, atau mode proteksi clipping berubah. */
    fun updateMaster(m: MasterSettings) {
        val wasOn = master.on
        master = m
        if (wasOn != m.on) {
            applyAll()
            return
        }
        if (m.on) engines().forEach { it.updateMaster(m) }
        onChanged?.invoke()
    }

    /** Nama efek yang tidak berhasil diterapkan oleh perangkat. */
    fun fxIssues(): Set<String> =
        if (sessionMode) sessions.values.flatMap { it.engine.issues }.toSet() else global.issues

    fun updateLimiter(lim: LimiterSettings, on: Boolean) {
        limiter = lim
        eqOn = on
        if (master.on) limThrottle.fire()
        updateNotification()
    }

    /** Verifikasi efek yang diminta: dibuat, dikuasai aplikasi ini, dan menyala. */
    fun indicator(): Indicator {
        if (!master.on) return Indicator(Level.OFF, "MASTER OFF", emptyList())
        if (sessionMode && sessions.isEmpty()) return Indicator(Level.WAIT, "MENUNGGU PEMUTAR", emptyList())
        val all = engines().flatMap { it.statuses() }
        if (all.isEmpty()) return Indicator(Level.OFF, "TANPA EFEK", all)
        val ok = all.count { it.state == FxState.ACTIVE }
        return when {
            ok == all.size -> Indicator(Level.OK, "EFEK AKTIF ($ok/${all.size})", all)
            ok == 0 -> Indicator(Level.FAIL, "EFEK TIDAK AKTIF", all)
            else -> Indicator(Level.PARTIAL, "SEBAGIAN AKTIF ($ok/${all.size})", all)
        }
    }

    private fun applyAll() {
        if (!master.on) {
            // Master OFF: lepas semua efek agar audio melewati sistem tanpa pemrosesan sama sekali.
            global.release()
            sessions.values.forEach { it.engine.release() }
            status = "Status: Master OFF — semua efek dilewati"
            publishActive()
            updateNotification()
            onChanged?.invoke()
            return
        }
        if (sessionMode) {
            sessions.values.forEach {
                it.engine.setSplit(twoWay, xo, swapXo)
                it.engine.setPeq(peq)
                it.engine.setFx(fx)
                it.engine.setMaster(master)
                it.engine.setChannelEq(chSplit, valuesR)
                it.engine.configure(pipeline, eqOn, values, limiter)
            }
            refreshStatus(notify = false)
        } else {
            global.setSplit(twoWay, xo, swapXo)
            global.setPeq(peq)
            global.setFx(fx)
            global.setMaster(master)
            global.setChannelEq(chSplit, valuesR)
            globalStatus = global.configure(pipeline, eqOn, values, limiter)
            status = globalStatus
        }
        publishActive()
        updateNotification()
        onChanged?.invoke()
    }

    private fun refreshStatus(notify: Boolean = true) {
        status = when {
            !master.on -> "Status: Master OFF — semua efek dilewati"
            sessionMode && sessions.isEmpty() -> "Status: Mode Sesi Aplikasi aktif • menunggu pemutar musik"
            sessionMode -> "Status: Mode Sesi Aplikasi • ${sessions.size} sesi (${sessionPackages.joinToString(", ") { shortName(it) }})"
            else -> globalStatus
        }
        if (notify) {
            publishActive()
            updateNotification()
            onChanged?.invoke()
        }
    }

    private fun shortName(pkg: String): String = pkg.substringAfterLast('.')

    private fun publishActive() {
        activePackages = sessions.values.map { it.pkg }.toSet()
    }

    // ---------- sesi aplikasi ----------

    private fun onSessionOpen(id: Int, pkg: String) {
        if (!sessionMode || id <= 0 || pkg == packageName) return
        AppStore.add(this, pkg)
        if (!AppStore.isEnabled(this, pkg)) return
        if (sessions.containsKey(id)) return
        val engine = AudioEngine(id).also { it.onHealthEvent = { r -> scheduleVerify(r) } }
        if (master.on) {
            engine.setSplit(twoWay, xo, swapXo)
            engine.setPeq(peq)
            engine.setFx(fx)
            engine.setMaster(master)
            engine.setChannelEq(chSplit, valuesR)
            engine.configure(pipeline, eqOn, values, limiter)
            if (!engine.isActive) {
                engine.release()
                DiagLog.log("Sesi $pkg ($id): efek tidak dapat dipasang")
                return
            }
        }
        while (sessions.size >= MAX_SESSIONS) {
            val oldest = sessions.keys.first()
            sessions.remove(oldest)?.engine?.release()
        }
        sessions[id] = SessionEntry(pkg, engine)
        refreshStatus()
    }

    private fun onSessionClose(id: Int) {
        val entry = sessions.remove(id) ?: return
        entry.engine.release()
        refreshStatus()
    }

    private fun dropDisabledSessions() {
        val gone = sessions.filter { !AppStore.isEnabled(this, it.value.pkg) }.keys.toList()
        if (gone.isEmpty()) return
        gone.forEach { sessions.remove(it)?.engine?.release() }
        refreshStatus()
    }

    private fun clearSessions() {
        sessions.values.forEach { it.engine.release() }
        sessions.clear()
        publishActive()
    }

    /**
     * Bila musik sudah berputar sebelum layanan dimulai, pemutar tidak mengirim ulang sesinya.
     * Lewati satu lagu agar pemutar membuat sesi baru sehingga Mode Sesi Aplikasi langsung terkunci.
     */
    private fun scheduleStabilize() {
        if (!stabilize) return
        handler.postDelayed({
            if (sessionMode && sessions.isEmpty()) {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                if (am.isMusicActive) {
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT))
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_NEXT))
                }
            }
        }, 2500)
    }
}

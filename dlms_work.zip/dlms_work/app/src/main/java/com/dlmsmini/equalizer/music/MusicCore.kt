package com.dlmsmini.equalizer.music

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.dlmsmini.equalizer.Store
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

/** Satu lagu. [id] = ID video YouTube (11 karakter) untuk lagu streaming, atau "local:<id>" untuk lagu di perangkat. */
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationSec: Int = 0,
    val thumb: String = "",
    val official: Boolean = false,
    val source: Int = SRC_STREAM,
    val uri: String? = null
) {
    /** True bila harus diputar lewat streaming YouTube (belum ada berkas lokal). */
    val isStream: Boolean get() = uri == null

    companion object {
        const val SRC_STREAM = 0   // disimpan di perpustakaan, diputar lewat streaming
        const val SRC_DOWNLOAD = 1 // sudah diunduh
        const val SRC_DEVICE = 2   // hasil pemindaian musik perangkat
        const val EXTRA_DURATION = "dlms_duration"
        const val EXTRA_OFFICIAL = "dlms_official"
    }
}

fun Track.toMediaItem(): MediaItem {
    val playUri = if (uri != null) Uri.parse(uri) else Uri.parse("ytm:$id")
    val extras = Bundle().apply {
        putInt(Track.EXTRA_DURATION, durationSec)
        putBoolean(Track.EXTRA_OFFICIAL, official)
    }
    val md = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setAlbumTitle(album.ifBlank { null })
        .setExtras(extras)
    if (thumb.isNotBlank()) md.setArtworkUri(Uri.parse(thumb))
    return MediaItem.Builder().setMediaId(id).setUri(playUri).setMediaMetadata(md.build()).build()
}

fun MediaItem.toTrack(): Track {
    val m = mediaMetadata
    val ex = m.extras
    val u = localConfiguration?.uri?.toString()
    return Track(
        id = mediaId,
        title = m.title?.toString() ?: "",
        artist = m.artist?.toString() ?: "",
        album = m.albumTitle?.toString() ?: "",
        durationSec = ex?.getInt(Track.EXTRA_DURATION, 0) ?: 0,
        thumb = m.artworkUri?.toString() ?: "",
        official = ex?.getBoolean(Track.EXTRA_OFFICIAL, false) ?: false,
        source = if (u != null && !u.startsWith("ytm:")) Track.SRC_DOWNLOAD else Track.SRC_STREAM,
        uri = if (u != null && !u.startsWith("ytm:")) u else null
    )
}

fun fmtTime(sec: Int): String {
    val s = sec.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, r) else "%d:%02d".format(m, r)
}

fun String.enc(): String = URLEncoder.encode(this, "UTF-8")

/** HTTP sederhana (HttpURLConnection) dipakai Piped, LRCLIB, dan pengunduh. */
object Http {
    const val UA_APP = "DLMSMiniEqualizer/3.9 (https://github.com/JagoanRedesign/Apk)"

    class HttpError(val code: Int, message: String) : IOException(message)

    fun open(url: String, ua: String = UA_APP, timeoutMs: Int = 15000, range: String? = null): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs + 10000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept", "*/*")
        if (range != null) c.setRequestProperty("Range", range)
        return c
    }

    /** GET teks (JSON). Melempar [HttpError] untuk status >= 400. */
    fun get(url: String, ua: String = UA_APP, timeoutMs: Int = 15000): String {
        val c = open(url, ua, timeoutMs)
        try {
            val code = c.responseCode
            if (code >= 400) throw HttpError(code, "HTTP $code")
            val raw = c.inputStream
            val stream = if ("gzip".equals(c.contentEncoding, true)) GZIPInputStream(raw) else raw
            val out = ByteArrayOutputStream()
            stream.use { it.copyTo(out) }
            return out.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }

    fun getBytes(url: String, ua: String = UA_APP, timeoutMs: Int = 15000, maxBytes: Int = 8_000_000): ByteArray {
        val c = open(url, ua, timeoutMs)
        try {
            val code = c.responseCode
            if (code >= 400) throw HttpError(code, "HTTP $code")
            val out = ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > maxBytes) throw IOException("Terlalu besar")
                }
            }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }
}

/** Pengaturan musik (disimpan di SharedPreferences yang sama dengan pengaturan lain). */
object MusicPrefs {
    const val Q_HIGH = 0
    const val Q_STANDARD = 1
    const val Q_LOW = 2

    private fun p(ctx: Context) = Store.prefs(ctx)

    fun streamQuality(ctx: Context): Int = p(ctx).getInt("music_stream_q", Q_HIGH).coerceIn(Q_HIGH, Q_LOW)
    fun setStreamQuality(ctx: Context, v: Int) = p(ctx).edit().putInt("music_stream_q", v).apply()

    fun autoMix(ctx: Context): Boolean = p(ctx).getBoolean("music_auto_mix", true)
    fun setAutoMix(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("music_auto_mix", v).apply()

    // Delay pemutar musik: per kanal dalam persepuluh milidetik, plus suhu udara untuk hitungan jarak.
    fun delayLeft10(ctx: Context): Int = p(ctx).getInt("music_delay_l", 0).coerceIn(0, 1000)
    fun setDelayLeft10(ctx: Context, v: Int) = p(ctx).edit().putInt("music_delay_l", v).apply()
    fun delayRight10(ctx: Context): Int = p(ctx).getInt("music_delay_r", 0).coerceIn(0, 1000)
    fun setDelayRight10(ctx: Context, v: Int) = p(ctx).edit().putInt("music_delay_r", v).apply()
    fun delayTemp(ctx: Context): Int = p(ctx).getInt("music_delay_temp", 28).coerceIn(0, 50)
    fun setDelayTemp(ctx: Context, v: Int) = p(ctx).edit().putInt("music_delay_temp", v).apply()

    fun customPiped(ctx: Context): String = p(ctx).getString("music_piped_custom", "") ?: ""
    fun setCustomPiped(ctx: Context, v: String) = p(ctx).edit().putString("music_piped_custom", v.trim().trimEnd('/')).apply()

    fun embedCover(ctx: Context): Boolean = p(ctx).getBoolean("music_dl_cover", true)
    fun embedLyrics(ctx: Context): Boolean = p(ctx).getBoolean("music_dl_lyrics", true)
    fun syncedLyrics(ctx: Context): Boolean = p(ctx).getBoolean("music_dl_synced", true)
    fun setDownloadDefaults(ctx: Context, cover: Boolean, lyrics: Boolean, synced: Boolean) =
        p(ctx).edit().putBoolean("music_dl_cover", cover).putBoolean("music_dl_lyrics", lyrics).putBoolean("music_dl_synced", synced).apply()

    // Riwayat pencarian: paling baru di depan, maksimal 30, tanpa duplikat (huruf besar/kecil diabaikan).
    fun searchHistory(ctx: Context): List<String> = try {
        val a = org.json.JSONArray(p(ctx).getString("music_search_history", "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }

    private fun saveHistory(ctx: Context, l: List<String>) =
        p(ctx).edit().putString("music_search_history", org.json.JSONArray(l).toString()).apply()

    fun addSearchHistory(ctx: Context, q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        saveHistory(ctx, (listOf(t) + searchHistory(ctx).filterNot { it.equals(t, ignoreCase = true) }).take(30))
    }

    fun removeSearchHistory(ctx: Context, q: String) = saveHistory(ctx, searchHistory(ctx).filterNot { it.equals(q, ignoreCase = true) })
    fun clearSearchHistory(ctx: Context) = saveHistory(ctx, emptyList())

    fun lastQuery(ctx: Context): String = p(ctx).getString("music_last_query", "") ?: ""
    fun setLastQuery(ctx: Context, q: String) = p(ctx).edit().putString("music_last_query", q).apply()

    // Cache daftar instans Piped.
    fun instancesJson(ctx: Context): String = p(ctx).getString("music_piped_list", "") ?: ""
    fun instancesAt(ctx: Context): Long = p(ctx).getLong("music_piped_list_at", 0L)
    fun saveInstances(ctx: Context, json: String) =
        p(ctx).edit().putString("music_piped_list", json).putLong("music_piped_list_at", System.currentTimeMillis()).apply()
}

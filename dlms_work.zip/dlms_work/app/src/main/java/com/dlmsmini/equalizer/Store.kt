package com.dlmsmini.equalizer

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt

/** Penyimpanan pengaturan (SharedPreferences, terpisah per perangkat seperti versi sebelumnya). */
object Store {
    const val KEY_FULL_POWER = "full_power"
    const val KEY_PIPELINE = "pipeline"
    const val KEY_SPECTRUM = "spectrum_on"
    const val KEY_KEEP_SCREEN = "keep_screen"
    const val KEY_EQ_ENABLED = "eq_enabled"
    const val KEY_EQ_MODE = "eq_mode"
    const val KEY_SESSION_MODE = "session_mode"
    const val KEY_STABILIZE = "stabilize_launch"
    const val KEY_BG = "bg_service"
    const val KEY_BANDS = "eq_bands"
    const val KEY_CROSSOVER = "crossover_hz"
    /** true = tukar: kiri membawa HIGH dan kanan membawa LOW pada mode 2-Way. */
    const val KEY_XO_SWAP = "crossover_swap"
    const val DEFAULT_CROSSOVER = 700
    const val MIN_CROSSOVER = 40
    const val MAX_CROSSOVER = 8000
    const val XO_STEPS = 120

    const val KEY_MASTER = "master_on"
    const val KEY_VOL_L = "vol_l"
    const val KEY_VOL_R = "vol_r"
    const val KEY_EQ_LIMIT = "eq_limit_db"
    const val KEY_CLIP_MODE = "clip_mode"
    const val KEY_SPEC_MODE = "spec_mode"
    const val KEY_SPEC_PEAK = "spec_peak"
    const val KEY_SPEC_SMOOTH = "spec_smooth"
    const val KEY_PRESET_HISTORY = "preset_history"
    const val KEY_TAB = "ui_tab_v3"
    const val KEY_SPEC_FFT = "spec_fft"
    const val KEY_XO_SLOPE = "xo_slope"
    const val KEY_XO_LOW_GAIN = "xo_low_gain"
    const val KEY_XO_HIGH_GAIN = "xo_high_gain"
    const val KEY_XO_LPF = "xo_lpf"
    const val KEY_XO_HPF = "xo_hpf"
    const val KEY_ASKED_NOTIF = "asked_notif"
    const val KEY_UPDATE_NOTIF = "update_notif"
    /** true = EQ kiri/kanan terpisah (kurva kanan di [Bands.keyR]). false = stereo, satu kurva untuk kedua kanal. */
    const val KEY_CH_SPLIT = "eq_ch_split"
    /** Kanal yang sedang diedit di layar utama (0 = kiri, 1 = kanan); hanya berarti bila [KEY_CH_SPLIT] aktif. */
    const val KEY_CH_EDIT = "eq_ch_edit"
    /** Tema: 0 = ikuti sistem, 1 = terang, 2 = gelap. */
    const val KEY_THEME = "ui_theme"
    /** Warna dinamis Material You (Android 12+). */
    const val KEY_DYNAMIC = "ui_dynamic"
    const val THEME_SYSTEM = 0
    const val THEME_LIGHT = 1
    const val THEME_DARK = 2

    const val CLIP_OFF = 0
    const val CLIP_LIMITER = 1
    const val CLIP_HEADROOM = 2

    const val PIPE_STANDARD = 0
    const val PIPE_MAX = 1

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(
            "dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_"),
            Context.MODE_PRIVATE
        )

    /** Batas absolut nilai fader (satuan 0,5 dB): Kekuatan Penuh = 44 (±22 dB), selain itu Batas EQ (3-12 dB). */
    fun maxHalf(p: SharedPreferences): Int =
        if (p.getBoolean(KEY_FULL_POWER, false)) 44 else p.getInt(KEY_EQ_LIMIT, 12).coerceIn(3, 12) * 2

    /** Skala crossover logaritmik 40 Hz - 8 kHz: posisi slider 0..XO_STEPS -> Hz (dibulatkan agar mudah dibaca). */
    fun crossoverFromProgress(p: Int): Int {
        val f = MIN_CROSSOVER * (MAX_CROSSOVER.toDouble() / MIN_CROSSOVER).pow(p.coerceIn(0, XO_STEPS).toDouble() / XO_STEPS)
        val step = if (f < 200) 5 else if (f < 1000) 10 else 50
        return ((f / step).roundToInt() * step).coerceIn(MIN_CROSSOVER, MAX_CROSSOVER)
    }

    fun progressFromCrossover(hz: Int): Int {
        val v = hz.coerceIn(MIN_CROSSOVER, MAX_CROSSOVER).toDouble()
        return (ln(v / MIN_CROSSOVER) / ln(MAX_CROSSOVER.toDouble() / MIN_CROSSOVER) * XO_STEPS).roundToInt().coerceIn(0, XO_STEPS)
    }

    fun loadCrossover(p: SharedPreferences): Int =
        p.getInt(KEY_CROSSOVER, DEFAULT_CROSSOVER).coerceIn(MIN_CROSSOVER, MAX_CROSSOVER)

    fun loadCrossoverSettings(p: SharedPreferences): CrossoverSettings {
        val slope = p.getInt(KEY_XO_SLOPE, 24).let { if (it in CrossoverSpec.SLOPES) it else 24 }
        return CrossoverSettings(
            freqHz = loadCrossover(p),
            slopeDbOct = slope,
            lowGainDb = CrossoverSpec.gain.clamp(p.getFloat(KEY_XO_LOW_GAIN, 0f)),
            highGainDb = CrossoverSpec.gain.clamp(p.getFloat(KEY_XO_HIGH_GAIN, 0f)),
            lpfOn = p.getBoolean(KEY_XO_LPF, true),
            hpfOn = p.getBoolean(KEY_XO_HPF, true)
        )
    }

    fun saveCrossoverSettings(ctx: Context, x: CrossoverSettings) {
        prefs(ctx).edit()
            .putInt(KEY_CROSSOVER, x.freqHz.coerceIn(MIN_CROSSOVER, MAX_CROSSOVER))
            .putInt(KEY_XO_SLOPE, x.slopeDbOct)
            .putFloat(KEY_XO_LOW_GAIN, x.lowGainDb)
            .putFloat(KEY_XO_HIGH_GAIN, x.highGainDb)
            .putBoolean(KEY_XO_LPF, x.lpfOn)
            .putBoolean(KEY_XO_HPF, x.hpfOn)
            .apply()
    }

    fun loadMaster(ctx: Context): MasterSettings {
        val p = prefs(ctx)
        return MasterSettings(
            on = p.getBoolean(KEY_MASTER, true),
            volL = p.getInt(KEY_VOL_L, 100).coerceIn(0, 100),
            volR = p.getInt(KEY_VOL_R, 100).coerceIn(0, 100),
            clipMode = p.getInt(KEY_CLIP_MODE, CLIP_LIMITER).coerceIn(CLIP_OFF, CLIP_HEADROOM)
        )
    }

    fun saveMaster(ctx: Context, m: MasterSettings) {
        prefs(ctx).edit()
            .putBoolean(KEY_MASTER, m.on)
            .putInt(KEY_VOL_L, m.volL)
            .putInt(KEY_VOL_R, m.volR)
            .putInt(KEY_CLIP_MODE, m.clipMode)
            .apply()
    }

    private val KNOWN_KEYS = setOf(
        KEY_FULL_POWER, KEY_PIPELINE, KEY_SPECTRUM, KEY_KEEP_SCREEN, KEY_EQ_ENABLED, KEY_EQ_MODE, KEY_SESSION_MODE,
        KEY_STABILIZE, KEY_BG, KEY_BANDS, KEY_CROSSOVER, KEY_XO_SWAP, KEY_MASTER, KEY_VOL_L, KEY_VOL_R, KEY_EQ_LIMIT, KEY_CLIP_MODE,
        KEY_SPEC_MODE, KEY_SPEC_PEAK, KEY_SPEC_SMOOTH, KEY_SPEC_FFT, KEY_PRESET_HISTORY, KEY_TAB, KEY_ASKED_NOTIF, KEY_UPDATE_NOTIF, KEY_CH_SPLIT, KEY_CH_EDIT, KEY_THEME, KEY_DYNAMIC, "detected_apps"
    )
    private val KNOWN_PREFIXES = listOf("band_", "fx_", "lim_", "custom_", "app_on_", "peq_", "xo_")

    /** Hanya kunci milik aplikasi yang boleh dipulihkan dari berkas backup. */
    fun isBackupKey(key: String): Boolean =
        key in KNOWN_KEYS || KNOWN_PREFIXES.any { key.startsWith(it) }

    fun loadLimiter(ctx: Context): LimiterSettings {
        val p = prefs(ctx)
        val d = LimiterSettings()
        return LimiterSettings(
            enabled = p.getBoolean("lim_enabled", d.enabled),
            attackMs = LimiterSpec.attack.clamp(p.getFloat("lim_attack", d.attackMs)),
            releaseMs = LimiterSpec.release.clamp(p.getFloat("lim_release", d.releaseMs)),
            ratio = LimiterSpec.ratio.clamp(p.getFloat("lim_ratio", d.ratio)),
            thresholdDb = LimiterSpec.threshold.clamp(p.getFloat("lim_threshold", d.thresholdDb)),
            postGainDb = LimiterSpec.postGain.clamp(p.getFloat("lim_postgain", d.postGainDb))
        )
    }

    fun loadEffects(ctx: Context): EffectSettings {
        val p = prefs(ctx)
        val d = EffectSettings()
        return EffectSettings(
            preampDb = FxSpec.preamp.clamp(p.getFloat("fx_preamp", d.preampDb)),
            balance = p.getInt("fx_balance", d.balance).coerceIn(-100, 100),
            muteLeft = p.getBoolean("fx_mute_l", d.muteLeft),
            muteRight = p.getBoolean("fx_mute_r", d.muteRight),
            bassOn = p.getBoolean("fx_bass_on", d.bassOn),
            bassPct = p.getInt("fx_bass_pct", d.bassPct).coerceIn(0, 100),
            virtOn = p.getBoolean("fx_virt_on", d.virtOn),
            virtPct = p.getInt("fx_virt_pct", d.virtPct).coerceIn(0, 100),
            loudOn = p.getBoolean("fx_loud_on", d.loudOn),
            loudDb = FxSpec.loud.clamp(p.getFloat("fx_loud_db", d.loudDb)),
            reverbPreset = p.getInt("fx_reverb", d.reverbPreset).coerceIn(0, FxSpec.REVERB_NAMES.lastIndex),
            mbcOn = p.getBoolean("fx_mbc_on", d.mbcOn),
            mbcThresholdDb = FxSpec.mbcThreshold.clamp(p.getFloat("fx_mbc_thr", d.mbcThresholdDb)),
            mbcRatio = FxSpec.mbcRatio.clamp(p.getFloat("fx_mbc_ratio", d.mbcRatio)),
            mbcAttackMs = FxSpec.mbcAttack.clamp(p.getFloat("fx_mbc_atk", d.mbcAttackMs)),
            mbcReleaseMs = FxSpec.mbcRelease.clamp(p.getFloat("fx_mbc_rel", d.mbcReleaseMs)),
            mbcMakeupDb = FxSpec.mbcMakeup.clamp(p.getFloat("fx_mbc_mkp", d.mbcMakeupDb)),
            toneOn = p.getBoolean("fx_tone_on", d.toneOn),
            toneLowDb = FxSpec.tone.clamp(p.getFloat("fx_tone_low", d.toneLowDb)),
            toneMidDb = FxSpec.tone.clamp(p.getFloat("fx_tone_mid", d.toneMidDb)),
            toneHighDb = FxSpec.tone.clamp(p.getFloat("fx_tone_high", d.toneHighDb))
        )
    }

    fun saveEffects(ctx: Context, f: EffectSettings) {
        prefs(ctx).edit()
            .putFloat("fx_preamp", f.preampDb)
            .putInt("fx_balance", f.balance)
            .putBoolean("fx_mute_l", f.muteLeft)
            .putBoolean("fx_mute_r", f.muteRight)
            .putBoolean("fx_bass_on", f.bassOn)
            .putInt("fx_bass_pct", f.bassPct)
            .putBoolean("fx_virt_on", f.virtOn)
            .putInt("fx_virt_pct", f.virtPct)
            .putBoolean("fx_loud_on", f.loudOn)
            .putFloat("fx_loud_db", f.loudDb)
            .putInt("fx_reverb", f.reverbPreset)
            .putBoolean("fx_mbc_on", f.mbcOn)
            .putFloat("fx_mbc_thr", f.mbcThresholdDb)
            .putFloat("fx_mbc_ratio", f.mbcRatio)
            .putFloat("fx_mbc_atk", f.mbcAttackMs)
            .putFloat("fx_mbc_rel", f.mbcReleaseMs)
            .putFloat("fx_mbc_mkp", f.mbcMakeupDb)
            .putBoolean("fx_tone_on", f.toneOn)
            .putFloat("fx_tone_low", f.toneLowDb)
            .putFloat("fx_tone_mid", f.toneMidDb)
            .putFloat("fx_tone_high", f.toneHighDb)
            .apply()
    }

    fun saveLimiter(ctx: Context, l: LimiterSettings) {
        prefs(ctx).edit()
            .putBoolean("lim_enabled", l.enabled)
            .putFloat("lim_attack", l.attackMs)
            .putFloat("lim_release", l.releaseMs)
            .putFloat("lim_ratio", l.ratio)
            .putFloat("lim_threshold", l.thresholdDb)
            .putFloat("lim_postgain", l.postGainDb)
            .apply()
    }
}

/** Isi preset tersimpan: kurva EQ (5/10/13/15/21/31 band), limiter, dan semua efek (bila ada). */
class SavedPreset(
    val values: IntArray,
    val limiter: LimiterSettings?,
    val effects: EffectSettings? = null,
    val peq: PeqSettings? = null,
    /** Kurva kanal kanan (EQ L/R terpisah); null = preset stereo (kurva yang sama untuk kedua kanal). */
    val valuesR: IntArray? = null
)

/**
 * Preset kustom disimpan sebagai "custom_<nama>" -> JSON:
 *   {"v":[...nilai 0,5 dB...],"l":{limiter},"f":{efek}}
 * Format lama (array angka saja, 10 band) tetap terbaca.
 */
object PresetStore {
    private const val PREFIX = "custom_"

    fun names(ctx: Context): List<String> =
        Store.prefs(ctx).all.keys
            .filter { it.startsWith(PREFIX) }
            .map { it.removePrefix(PREFIX) }
            .sortedBy { it.lowercase(Locale.getDefault()) }

    fun get(ctx: Context, name: String): SavedPreset? {
        return try {
            val raw = Store.prefs(ctx).getString(PREFIX + name, null)?.trim() ?: return null
            if (raw.startsWith("[")) {
                val a = JSONArray(raw)
                if (!Bands.isValid(a.length())) null
                else SavedPreset(IntArray(a.length()) { a.getInt(it) }, null, null)
            } else {
                val o = JSONObject(raw)
                val a = o.getJSONArray("v")
                if (!Bands.isValid(a.length())) return null
                val lim = o.optJSONObject("l")?.let { l ->
                    LimiterSettings(
                        enabled = l.optBoolean("e", false),
                        attackMs = LimiterSpec.attack.clamp(l.optDouble("a", 1.0).toFloat()),
                        releaseMs = LimiterSpec.release.clamp(l.optDouble("r", 60.0).toFloat()),
                        ratio = LimiterSpec.ratio.clamp(l.optDouble("x", 10.0).toFloat()),
                        thresholdDb = LimiterSpec.threshold.clamp(l.optDouble("t", -2.0).toFloat()),
                        postGainDb = LimiterSpec.postGain.clamp(l.optDouble("p", 0.0).toFloat())
                    )
                }
                val fx = o.optJSONObject("f")?.let { fxFromJson(it) }
                val peq = o.optJSONObject("p")?.let { po ->
                    val arr = po.optJSONArray("b")
                    val list = if (arr != null) PeqStore.bandsFromArray(arr) else null
                    if (list != null) PeqSettings(po.optBoolean("on", false), list) else null
                }
                val right = o.optJSONArray("vr")?.let { ra ->
                    if (ra.length() == a.length()) IntArray(ra.length()) { ra.getInt(it) } else null
                }
                SavedPreset(IntArray(a.length()) { a.getInt(it) }, lim, fx, peq, right)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun r2(f: Float): Double = (f * 100.0).roundToInt() / 100.0

    private fun fxToJson(f: EffectSettings): JSONObject = JSONObject()
        .put("pa", r2(f.preampDb)).put("ba", f.balance)
        .put("ml", f.muteLeft).put("mr", f.muteRight)
        .put("bo", f.bassOn).put("bp", f.bassPct)
        .put("vo", f.virtOn).put("vp", f.virtPct)
        .put("lo", f.loudOn).put("ld", r2(f.loudDb))
        .put("rv", f.reverbPreset)
        .put("co", f.mbcOn).put("ct", r2(f.mbcThresholdDb)).put("cr", r2(f.mbcRatio))
        .put("ca", r2(f.mbcAttackMs)).put("cl", r2(f.mbcReleaseMs)).put("cm", r2(f.mbcMakeupDb))
        .put("to", f.toneOn).put("tl", r2(f.toneLowDb)).put("tm", r2(f.toneMidDb)).put("th", r2(f.toneHighDb))

    private fun fxFromJson(o: JSONObject): EffectSettings {
        val d = EffectSettings()
        fun fl(k: String, def: Float, s: Spec) = s.clamp(o.optDouble(k, def.toDouble()).toFloat())
        return EffectSettings(
            preampDb = fl("pa", d.preampDb, FxSpec.preamp),
            balance = o.optInt("ba", d.balance).coerceIn(-100, 100),
            muteLeft = o.optBoolean("ml", d.muteLeft),
            muteRight = o.optBoolean("mr", d.muteRight),
            bassOn = o.optBoolean("bo", d.bassOn),
            bassPct = o.optInt("bp", d.bassPct).coerceIn(0, 100),
            virtOn = o.optBoolean("vo", d.virtOn),
            virtPct = o.optInt("vp", d.virtPct).coerceIn(0, 100),
            loudOn = o.optBoolean("lo", d.loudOn),
            loudDb = fl("ld", d.loudDb, FxSpec.loud),
            reverbPreset = o.optInt("rv", d.reverbPreset).coerceIn(0, FxSpec.REVERB_NAMES.lastIndex),
            mbcOn = o.optBoolean("co", d.mbcOn),
            mbcThresholdDb = fl("ct", d.mbcThresholdDb, FxSpec.mbcThreshold),
            mbcRatio = fl("cr", d.mbcRatio, FxSpec.mbcRatio),
            mbcAttackMs = fl("ca", d.mbcAttackMs, FxSpec.mbcAttack),
            mbcReleaseMs = fl("cl", d.mbcReleaseMs, FxSpec.mbcRelease),
            mbcMakeupDb = fl("cm", d.mbcMakeupDb, FxSpec.mbcMakeup),
            toneOn = o.optBoolean("to", d.toneOn),
            toneLowDb = fl("tl", d.toneLowDb, FxSpec.tone),
            toneMidDb = fl("tm", d.toneMidDb, FxSpec.tone),
            toneHighDb = fl("th", d.toneHighDb, FxSpec.tone)
        )
    }

    fun save(
        ctx: Context, name: String, values: IntArray, limiter: LimiterSettings?, effects: EffectSettings?,
        peq: PeqSettings? = null, valuesR: IntArray? = null
    ) {
        val o = JSONObject().put("v", JSONArray(values.toList()))
        if (valuesR != null && valuesR.size == values.size) o.put("vr", JSONArray(valuesR.toList()))
        if (limiter != null) {
            o.put(
                "l", JSONObject()
                    .put("e", limiter.enabled)
                    .put("a", r2(limiter.attackMs))
                    .put("r", r2(limiter.releaseMs))
                    .put("x", r2(limiter.ratio))
                    .put("t", r2(limiter.thresholdDb))
                    .put("p", r2(limiter.postGainDb))
            )
        }
        if (effects != null) o.put("f", fxToJson(effects))
        if (peq != null) o.put("p", JSONObject().put("on", peq.on).put("b", PeqStore.bandsToArray(peq.bands)))
        Store.prefs(ctx).edit().putString(PREFIX + name, o.toString()).apply()
    }

    fun delete(ctx: Context, name: String) {
        Store.prefs(ctx).edit().remove(PREFIX + name).apply()
    }
}

/**
 * Format teks preset untuk salin & tempel (satu preset per baris):
 *
 *   DLMS-PRESET v5
 *   Nama|0,2,4,0,-2,0,2,4,2,0|L1,1,60,10,-2,0|F0,0,0,0,0,50,0,50,0,4,0,0,-24,3,10,150,2,0,0,0,0
 *
 * Kolom 2: nilai band (5, 10, 13, 15, 21, atau 31 angka, satuan 0,5 dB, -44..44). Untuk preset EQ L/R terpisah,
 * kolom ini adalah kanal KIRI.
 * Kolom opsional (urutan bebas, masing-masing maksimal satu):
 *   L = limiter: L<aktif 0/1>,<attack ms>,<release ms>,<ratio>,<threshold dB>,<post-gain dB>
 *   F = efek (21 nilai): preamp dB, balance, mute kiri, mute kanan, bass aktif, bass %, virtualizer aktif,
 *       virtualizer %, loudness aktif, loudness dB, reverb (0-6), kompresor aktif, threshold, ratio,
 *       attack, release, makeup, tone aktif, tone bass, tone mid, tone treble
 *   P = Parametric EQ: P<aktif 0/1>;<TIPE>/<Hz>/<gain dB>/<Q>/<band aktif 0/1>;... (maks 10 band)
 *   R = kurva kanal KANAN (EQ L/R terpisah): R<angka,angka,...> dengan jumlah angka sama seperti kolom 2
 * Header v1 sampai v4 tetap diterima.
 */
object PresetCodec {
    const val HEADER = "DLMS-PRESET v5"
    private val ACCEPTED = listOf("DLMS-PRESET v1", "DLMS-PRESET v2", "DLMS-PRESET v3", "DLMS-PRESET v4", HEADER)
    const val LIMIT = 44
    const val MAX_NAME = 24
    private const val FX_COUNT = 21

    class Item(
        val name: String,
        val values: IntArray,
        val limiter: LimiterSettings? = null,
        val effects: EffectSettings? = null,
        val peq: PeqSettings? = null,
        val valuesR: IntArray? = null
    )
    class Result(val items: List<Item>, val errors: List<String>)

    fun cleanName(raw: String): String =
        raw.replace('|', ' ').replace('\n', ' ').replace('\r', ' ').trim().take(MAX_NAME).trim()

    private fun num(f: Float): String =
        String.format(Locale.US, "%.2f", f).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    private fun flag(v: Boolean) = if (v) "1" else "0"

    private fun effectsToText(f: EffectSettings): String = listOf(
        num(f.preampDb), f.balance.toString(), flag(f.muteLeft), flag(f.muteRight),
        flag(f.bassOn), f.bassPct.toString(), flag(f.virtOn), f.virtPct.toString(),
        flag(f.loudOn), num(f.loudDb), f.reverbPreset.toString(),
        flag(f.mbcOn), num(f.mbcThresholdDb), num(f.mbcRatio), num(f.mbcAttackMs), num(f.mbcReleaseMs), num(f.mbcMakeupDb),
        flag(f.toneOn), num(f.toneLowDb), num(f.toneMidDb), num(f.toneHighDb)
    ).joinToString(",")

    fun export(items: List<Item>): String {
        val sb = StringBuilder(HEADER)
        items.forEach { it0 ->
            sb.append('\n').append(cleanName(it0.name)).append('|').append(it0.values.joinToString(","))
            it0.limiter?.let { l ->
                sb.append("|L").append(if (l.enabled) "1" else "0")
                    .append(',').append(num(l.attackMs))
                    .append(',').append(num(l.releaseMs))
                    .append(',').append(num(l.ratio))
                    .append(',').append(num(l.thresholdDb))
                    .append(',').append(num(l.postGainDb))
            }
            it0.effects?.let { f -> sb.append("|F").append(effectsToText(f)) }
            it0.peq?.let { pq -> sb.append('|').append(PeqStore.toText(pq)) }
            it0.valuesR?.let { r -> if (r.size == it0.values.size) sb.append("|R").append(r.joinToString(",")) }
        }
        return sb.toString()
    }

    private fun parseLimiter(field: String): LimiterSettings? {
        val p = field.substring(1).split(',').map { it.trim().toFloatOrNull() }
        if (p.size != 6 || p.any { it == null }) return null
        val on = p[0]!!
        if (on != 0f && on != 1f) return null
        fun inRange(v: Float?, s: Spec) = v != null && v >= s.min && v <= s.max
        if (!inRange(p[1], LimiterSpec.attack) || !inRange(p[2], LimiterSpec.release) ||
            !inRange(p[3], LimiterSpec.ratio) || !inRange(p[4], LimiterSpec.threshold) ||
            !inRange(p[5], LimiterSpec.postGain)
        ) return null
        return LimiterSettings(on == 1f, p[1]!!, p[2]!!, p[3]!!, p[4]!!, p[5]!!)
    }

    private fun parseEffects(field: String): EffectSettings? {
        val p = field.substring(1).split(',').map { it.trim().toFloatOrNull() }
        if (p.size != FX_COUNT || p.any { it == null }) return null
        val v = p.map { it!! }
        fun inR(x: Float, s: Spec) = x >= s.min && x <= s.max
        fun isFlag(x: Float) = x == 0f || x == 1f
        fun pct(x: Float) = x >= 0f && x <= 100f
        val ok = inR(v[0], FxSpec.preamp) && v[1] >= -100f && v[1] <= 100f &&
            isFlag(v[2]) && isFlag(v[3]) && isFlag(v[4]) && pct(v[5]) && isFlag(v[6]) && pct(v[7]) &&
            isFlag(v[8]) && inR(v[9], FxSpec.loud) && v[10] >= 0f && v[10] <= FxSpec.REVERB_NAMES.lastIndex.toFloat() &&
            isFlag(v[11]) && inR(v[12], FxSpec.mbcThreshold) && inR(v[13], FxSpec.mbcRatio) &&
            inR(v[14], FxSpec.mbcAttack) && inR(v[15], FxSpec.mbcRelease) && inR(v[16], FxSpec.mbcMakeup) &&
            isFlag(v[17]) && inR(v[18], FxSpec.tone) && inR(v[19], FxSpec.tone) && inR(v[20], FxSpec.tone)
        if (!ok) return null
        return EffectSettings(
            preampDb = v[0], balance = v[1].roundToInt(),
            muteLeft = v[2] == 1f, muteRight = v[3] == 1f,
            bassOn = v[4] == 1f, bassPct = v[5].roundToInt(),
            virtOn = v[6] == 1f, virtPct = v[7].roundToInt(),
            loudOn = v[8] == 1f, loudDb = v[9], reverbPreset = v[10].roundToInt(),
            mbcOn = v[11] == 1f, mbcThresholdDb = v[12], mbcRatio = v[13],
            mbcAttackMs = v[14], mbcReleaseMs = v[15], mbcMakeupDb = v[16],
            toneOn = v[17] == 1f, toneLowDb = v[18], toneMidDb = v[19], toneHighDb = v[20]
        )
    }

    fun parse(text: String): Result {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return Result(emptyList(), emptyList())
        if (ACCEPTED.none { lines[0].equals(it, ignoreCase = true) }) {
            return Result(emptyList(), listOf("Baris pertama harus \"$HEADER\""))
        }
        val items = mutableListOf<Item>()
        val errors = mutableListOf<String>()
        lines.drop(1).forEachIndexed { idx, line ->
            val no = idx + 2
            val parts = line.split('|')
            if (parts.size !in 2..6) { errors.add("Baris $no: format tidak dikenali"); return@forEachIndexed }
            val name = cleanName(parts[0])
            if (name.isEmpty()) { errors.add("Baris $no: nama kosong"); return@forEachIndexed }
            val nums = parts[1].split(',').map { it.trim().toIntOrNull() }
            if (!Bands.isValid(nums.size) || nums.any { it == null || it < -LIMIT || it > LIMIT }) {
                errors.add("Baris $no: harus 5, 10, 13, 15, 21, atau 31 angka antara -$LIMIT dan $LIMIT")
                return@forEachIndexed
            }
            var limiter: LimiterSettings? = null
            var effects: EffectSettings? = null
            var peq: PeqSettings? = null
            var right: IntArray? = null
            var bad: String? = null
            for (extra in parts.drop(2).map { it.trim() }) {
                val tag = extra.firstOrNull()?.uppercaseChar()
                if (tag == 'L' && limiter == null) {
                    limiter = parseLimiter(extra)
                    if (limiter == null) { bad = "data limiter tidak valid"; break }
                } else if (tag == 'F' && effects == null) {
                    effects = parseEffects(extra)
                    if (effects == null) { bad = "data efek tidak valid (harus $FX_COUNT nilai)"; break }
                } else if (tag == 'P' && peq == null) {
                    peq = PeqStore.fromText(extra)
                    if (peq == null) { bad = "data Parametric EQ tidak valid"; break }
                } else if (tag == 'R' && right == null) {
                    val r = extra.substring(1).split(',').map { it.trim().toIntOrNull() }
                    if (r.size != nums.size || r.any { it == null || it < -LIMIT || it > LIMIT }) {
                        bad = "kurva kanal kanan tidak valid (harus ${nums.size} angka antara -$LIMIT dan $LIMIT)"
                        break
                    }
                    right = IntArray(r.size) { r[it]!! }
                } else {
                    bad = "kolom tambahan tidak dikenali"
                    break
                }
            }
            if (bad != null) { errors.add("Baris $no: $bad"); return@forEachIndexed }
            items.add(Item(name, IntArray(nums.size) { nums[it]!! }, limiter, effects, peq, right))
        }
        if (items.isEmpty() && errors.isEmpty()) errors.add("Tidak ada preset di dalam teks")
        return Result(items, errors)
    }
}

/** Daftar aplikasi pemutar yang terdeteksi lewat Mode Sesi Aplikasi. Default: semua diproses. */
object AppStore {
    private const val KEY = "detected_apps"
    private const val ON_PREFIX = "app_on_"

    fun detected(ctx: Context): List<String> = try {
        val a = JSONArray(Store.prefs(ctx).getString(KEY, "[]"))
        List(a.length()) { a.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }

    fun add(ctx: Context, pkg: String) {
        val list = detected(ctx)
        if (pkg !in list) Store.prefs(ctx).edit().putString(KEY, JSONArray(list + pkg).toString()).apply()
    }

    fun isEnabled(ctx: Context, pkg: String): Boolean = Store.prefs(ctx).getBoolean(ON_PREFIX + pkg, true)

    fun setEnabled(ctx: Context, pkg: String, on: Boolean) {
        Store.prefs(ctx).edit().putBoolean(ON_PREFIX + pkg, on).apply()
    }

    fun clear(ctx: Context) {
        val p = Store.prefs(ctx)
        val e = p.edit().remove(KEY)
        p.all.keys.filter { it.startsWith(ON_PREFIX) }.forEach { e.remove(it) }
        e.apply()
    }
}


/** Pengaturan tingkat-perangkat: master ON/OFF, volume kiri/kanan 0-100, mode proteksi clipping. */
data class MasterSettings(
    val on: Boolean = true,
    val volL: Int = 100,
    val volR: Int = 100,
    val clipMode: Int = Store.CLIP_LIMITER
) {
    /** Volume persen (0-100) -> gain dB. 0% = -80 dB (senyap). */
    fun volumeDb(pct: Int): Float =
        if (pct <= 0) -80f else (20.0 * log10(pct.coerceAtMost(100) / 100.0)).toFloat().coerceAtLeast(-80f)

    val volumeActive: Boolean get() = volL != 100 || volR != 100
}

/** Riwayat preset yang terakhir dipakai (maks 8, terbaru di depan). */
object PresetHistory {
    class Entry(val name: String, val custom: Boolean, val time: Long)

    private const val MAX = 8

    fun list(ctx: Context): List<Entry> = try {
        val a = JSONArray(Store.prefs(ctx).getString(Store.KEY_PRESET_HISTORY, "[]"))
        List(a.length()) {
            val o = a.getJSONObject(it)
            Entry(o.getString("n"), o.optBoolean("c", false), o.optLong("t", 0L))
        }
    } catch (_: Exception) {
        emptyList()
    }

    fun record(ctx: Context, name: String, custom: Boolean) {
        val items = list(ctx).filterNot { it.name == name && it.custom == custom }.toMutableList()
        items.add(0, Entry(name, custom, System.currentTimeMillis()))
        val a = JSONArray()
        items.take(MAX).forEach { a.put(JSONObject().put("n", it.name).put("c", it.custom).put("t", it.time)) }
        Store.prefs(ctx).edit().putString(Store.KEY_PRESET_HISTORY, a.toString()).apply()
    }

    fun remove(ctx: Context, name: String, custom: Boolean) {
        val items = list(ctx).filterNot { it.name == name && it.custom == custom }
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("n", it.name).put("c", it.custom).put("t", it.time)) }
        Store.prefs(ctx).edit().putString(Store.KEY_PRESET_HISTORY, a.toString()).apply()
    }

    fun clear(ctx: Context) {
        Store.prefs(ctx).edit().remove(Store.KEY_PRESET_HISTORY).apply()
    }
}

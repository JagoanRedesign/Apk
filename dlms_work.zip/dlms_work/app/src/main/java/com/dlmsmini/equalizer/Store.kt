package com.dlmsmini.equalizer

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import java.util.Locale
import kotlin.math.roundToInt

/** Penyimpanan pengaturan (SharedPreferences, terpisah per perangkat seperti versi sebelumnya). */
object Store {
    const val KEY_FULL_POWER = "full_power"
    const val KEY_PIPELINE = "pipeline"
    const val KEY_SPECTRUM = "spectrum_on"
    const val KEY_KEEP_SCREEN = "keep_screen"
    const val KEY_EQ_ENABLED = "eq_enabled"
    const val KEY_EQ_MODE = "eq_mode"

    const val PIPE_STANDARD = 0
    const val PIPE_MAX = 1

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(
            "dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_"),
            Context.MODE_PRIVATE
        )

    fun loadLimiter(ctx: Context): LimiterSettings {
        val p = prefs(ctx)
        val d = LimiterSettings()
        return LimiterSettings(
            enabled = p.getBoolean("lim_enabled", d.enabled),
            attackMs = p.getFloat("lim_attack", d.attackMs),
            releaseMs = p.getFloat("lim_release", d.releaseMs),
            ratio = p.getFloat("lim_ratio", d.ratio),
            thresholdDb = p.getFloat("lim_threshold", d.thresholdDb),
            postGainDb = p.getFloat("lim_postgain", d.postGainDb)
        )
    }

    fun saveLimiter(ctx: Context, l: LimiterSettings) {
        prefs(ctx).edit()
            .putBoolean("lim_enabled", l.enabled)
            .putFloat("lim_attack", l.attackMs)
            .putFloat("lim_release", l.releaseMs)
            .putFloat("lim_ratio", l.ratio)
            .putFloat("lim_threshold", l.thresholdDb)
            .putFloat("lim_postgain", l.postGainDb)
            .apply()
    }
}

/** Preset kustom: disimpan sebagai "custom_<nama>" -> JSON array 10 angka (satuan 0,5 dB). */
object PresetStore {
    private const val PREFIX = "custom_"

    fun names(ctx: Context): List<String> =
        Store.prefs(ctx).all.keys
            .filter { it.startsWith(PREFIX) }
            .map { it.removePrefix(PREFIX) }
            .sortedBy { it.lowercase(Locale.getDefault()) }

    fun get(ctx: Context, name: String): IntArray? = try {
        val json = JSONArray(Store.prefs(ctx).getString(PREFIX + name, null) ?: return null)
        if (json.length() != PresetCodec.BANDS) null
        else IntArray(PresetCodec.BANDS) { json.getInt(it) }
    } catch (_: Exception) {
        null
    }

    fun save(ctx: Context, name: String, values: IntArray) {
        Store.prefs(ctx).edit().putString(PREFIX + name, JSONArray(values.toList()).toString()).apply()
    }

    fun delete(ctx: Context, name: String) {
        Store.prefs(ctx).edit().remove(PREFIX + name).apply()
    }
}

/**
 * Format teks preset untuk salin & tempel:
 *
 *   DLMS-PRESET v1
 *   Nama Preset|0,2,4,0,-2,0,2,4,2,0
 *
 * Satu preset per baris, 10 angka dipisah koma (satuan 0,5 dB, -44..44).
 */
object PresetCodec {
    const val HEADER = "DLMS-PRESET v1"
    const val BANDS = 10
    const val LIMIT = 44
    const val MAX_NAME = 24

    class Item(val name: String, val values: IntArray)
    class Result(val items: List<Item>, val errors: List<String>)

    fun cleanName(raw: String): String =
        raw.replace('|', ' ').replace('\n', ' ').replace('\r', ' ').trim().take(MAX_NAME).trim()

    fun export(items: List<Item>): String {
        val sb = StringBuilder(HEADER)
        items.forEach { sb.append('\n').append(cleanName(it.name)).append('|').append(it.values.joinToString(",")) }
        return sb.toString()
    }

    fun parse(text: String): Result {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return Result(emptyList(), emptyList())
        if (!lines[0].equals(HEADER, ignoreCase = true)) {
            return Result(emptyList(), listOf("Baris pertama harus \"$HEADER\""))
        }
        val items = mutableListOf<Item>()
        val errors = mutableListOf<String>()
        lines.drop(1).forEachIndexed { idx, line ->
            val no = idx + 2
            val parts = line.split('|')
            if (parts.size != 2) { errors.add("Baris $no: format tidak dikenali"); return@forEachIndexed }
            val name = cleanName(parts[0])
            if (name.isEmpty()) { errors.add("Baris $no: nama kosong"); return@forEachIndexed }
            val nums = parts[1].split(',').map { it.trim().toIntOrNull() }
            if (nums.size != BANDS || nums.any { it == null || it < -LIMIT || it > LIMIT }) {
                errors.add("Baris $no: harus $BANDS angka antara -$LIMIT dan $LIMIT")
                return@forEachIndexed
            }
            items.add(Item(name, IntArray(BANDS) { nums[it]!! }))
        }
        if (items.isEmpty() && errors.isEmpty()) errors.add("Tidak ada preset di dalam teks")
        return Result(items, errors)
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.roundToInt

/** Penyimpanan pengaturan (SharedPreferences, terpisah per perangkat seperti versi sebelumnya). */
object Store {
    const val KEY_FULL_POWER = "full_power"
    const val KEY_PIPELINE = "pipeline"
    const val KEY_SPECTRUM = "spectrum_on"
    const val KEY_KEEP_SCREEN = "keep_screen"
    const val KEY_EQ_ENABLED = "eq_enabled"
    const val KEY_EQ_MODE = "eq_mode"
    const val KEY_SESSION_MODE = "session_mode"
    const val KEY_STABILIZE = "stabilize_launch"
    const val KEY_BG = "bg_service"
    const val KEY_BANDS = "eq_bands"

    const val PIPE_STANDARD = 0
    const val PIPE_MAX = 1

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(
            "dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_"),
            Context.MODE_PRIVATE
        )

    fun loadLimiter(ctx: Context): LimiterSettings {
        val p = prefs(ctx)
        val d = LimiterSettings()
        return LimiterSettings(
            enabled = p.getBoolean("lim_enabled", d.enabled),
            attackMs = p.getFloat("lim_attack", d.attackMs),
            releaseMs = p.getFloat("lim_release", d.releaseMs),
            ratio = p.getFloat("lim_ratio", d.ratio),
            thresholdDb = p.getFloat("lim_threshold", d.thresholdDb),
            postGainDb = p.getFloat("lim_postgain", d.postGainDb)
        )
    }

    fun saveLimiter(ctx: Context, l: LimiterSettings) {
        prefs(ctx).edit()
            .putBoolean("lim_enabled", l.enabled)
            .putFloat("lim_attack", l.attackMs)
            .putFloat("lim_release", l.releaseMs)
            .putFloat("lim_ratio", l.ratio)
            .putFloat("lim_threshold", l.thresholdDb)
            .putFloat("lim_postgain", l.postGainDb)
            .apply()
    }
}

/** Isi preset tersimpan: kurva EQ (5/10/13/21 band) dan, bila ada, pengaturan limiter. */
class SavedPreset(val values: IntArray, val limiter: LimiterSettings?)

/**
 * Preset kustom disimpan sebagai "custom_<nama>" -> JSON:
 *   {"v":[...nilai 0,5 dB...],"l":{"e":aktif,"a":attack,"r":release,"x":ratio,"t":threshold,"p":postgain}}
 * Format lama (array angka saja, 10 band) tetap terbaca.
 */
object PresetStore {
    private const val PREFIX = "custom_"

    fun names(ctx: Context): List<String> =
        Store.prefs(ctx).all.keys
            .filter { it.startsWith(PREFIX) }
            .map { it.removePrefix(PREFIX) }
            .sortedBy { it.lowercase(Locale.getDefault()) }

    fun get(ctx: Context, name: String): SavedPreset? {
        return try {
            val raw = Store.prefs(ctx).getString(PREFIX + name, null)?.trim() ?: return null
            if (raw.startsWith("[")) {
                val a = JSONArray(raw)
                if (!Bands.isValid(a.length())) null
                else SavedPreset(IntArray(a.length()) { a.getInt(it) }, null)
            } else {
                val o = JSONObject(raw)
                val a = o.getJSONArray("v")
                if (!Bands.isValid(a.length())) return null
                val lim = o.optJSONObject("l")?.let { l ->
                    LimiterSettings(
                        enabled = l.optBoolean("e", false),
                        attackMs = LimiterSpec.attack.clamp(l.optDouble("a", 1.0).toFloat()),
                        releaseMs = LimiterSpec.release.clamp(l.optDouble("r", 60.0).toFloat()),
                        ratio = LimiterSpec.ratio.clamp(l.optDouble("x", 10.0).toFloat()),
                        thresholdDb = LimiterSpec.threshold.clamp(l.optDouble("t", -2.0).toFloat()),
                        postGainDb = LimiterSpec.postGain.clamp(l.optDouble("p", 0.0).toFloat())
                    )
                }
                SavedPreset(IntArray(a.length()) { a.getInt(it) }, lim)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun r2(f: Float): Double = (f * 100.0).roundToInt() / 100.0

    fun save(ctx: Context, name: String, values: IntArray, limiter: LimiterSettings?) {
        val o = JSONObject().put("v", JSONArray(values.toList()))
        if (limiter != null) {
            o.put(
                "l", JSONObject()
                    .put("e", limiter.enabled)
                    .put("a", r2(limiter.attackMs))
                    .put("r", r2(limiter.releaseMs))
                    .put("x", r2(limiter.ratio))
                    .put("t", r2(limiter.thresholdDb))
                    .put("p", r2(limiter.postGainDb))
            )
        }
        Store.prefs(ctx).edit().putString(PREFIX + name, o.toString()).apply()
    }

    fun delete(ctx: Context, name: String) {
        Store.prefs(ctx).edit().remove(PREFIX + name).apply()
    }
}

/**
 * Format teks preset untuk salin & tempel (satu preset per baris):
 *
 *   DLMS-PRESET v2
 *   Nama Preset|0,2,4,0,-2,0,2,4,2,0|L1,1,60,10,-2,0
 *
 * Kolom 2: nilai band (5, 10, 13, atau 21 angka, satuan 0,5 dB, -44..44).
 * Kolom 3 (opsional): limiter = L<aktif 0/1>,<attack ms>,<release ms>,<ratio>,<threshold dB>,<post-gain dB>.
 * Header "DLMS-PRESET v1" (10 band, tanpa limiter) tetap diterima.
 */
object PresetCodec {
    const val HEADER = "DLMS-PRESET v2"
    private const val HEADER_V1 = "DLMS-PRESET v1"
    const val LIMIT = 44
    const val MAX_NAME = 24

    class Item(val name: String, val values: IntArray, val limiter: LimiterSettings? = null)
    class Result(val items: List<Item>, val errors: List<String>)

    fun cleanName(raw: String): String =
        raw.replace('|', ' ').replace('\n', ' ').replace('\r', ' ').trim().take(MAX_NAME).trim()

    private fun num(f: Float): String =
        String.format(Locale.US, "%.2f", f).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    fun export(items: List<Item>): String {
        val sb = StringBuilder(HEADER)
        items.forEach { it0 ->
            sb.append('\n').append(cleanName(it0.name)).append('|').append(it0.values.joinToString(","))
            it0.limiter?.let { l ->
                sb.append("|L").append(if (l.enabled) "1" else "0")
                    .append(',').append(num(l.attackMs))
                    .append(',').append(num(l.releaseMs))
                    .append(',').append(num(l.ratio))
                    .append(',').append(num(l.thresholdDb))
                    .append(',').append(num(l.postGainDb))
            }
        }
        return sb.toString()
    }

    private fun parseLimiter(field: String): LimiterSettings? {
        if (field.isEmpty() || (field[0] != 'L' && field[0] != 'l')) return null
        val p = field.substring(1).split(',').map { it.trim().toFloatOrNull() }
        if (p.size != 6 || p.any { it == null }) return null
        val flag = p[0]!!
        if (flag != 0f && flag != 1f) return null
        fun inRange(v: Float?, s: Spec) = v != null && v >= s.min && v <= s.max
        if (!inRange(p[1], LimiterSpec.attack) || !inRange(p[2], LimiterSpec.release) ||
            !inRange(p[3], LimiterSpec.ratio) || !inRange(p[4], LimiterSpec.threshold) ||
            !inRange(p[5], LimiterSpec.postGain)
        ) return null
        return LimiterSettings(flag == 1f, p[1]!!, p[2]!!, p[3]!!, p[4]!!, p[5]!!)
    }

    fun parse(text: String): Result {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return Result(emptyList(), emptyList())
        if (!lines[0].equals(HEADER, ignoreCase = true) && !lines[0].equals(HEADER_V1, ignoreCase = true)) {
            return Result(emptyList(), listOf("Baris pertama harus \"$HEADER\""))
        }
        val items = mutableListOf<Item>()
        val errors = mutableListOf<String>()
        lines.drop(1).forEachIndexed { idx, line ->
            val no = idx + 2
            val parts = line.split('|')
            if (parts.size !in 2..3) { errors.add("Baris $no: format tidak dikenali"); return@forEachIndexed }
            val name = cleanName(parts[0])
            if (name.isEmpty()) { errors.add("Baris $no: nama kosong"); return@forEachIndexed }
            val nums = parts[1].split(',').map { it.trim().toIntOrNull() }
            if (!Bands.isValid(nums.size) || nums.any { it == null || it < -LIMIT || it > LIMIT }) {
                errors.add("Baris $no: harus 5, 10, 13, atau 21 angka antara -$LIMIT dan $LIMIT")
                return@forEachIndexed
            }
            var limiter: LimiterSettings? = null
            if (parts.size == 3) {
                limiter = parseLimiter(parts[2].trim())
                if (limiter == null) { errors.add("Baris $no: data limiter tidak valid"); return@forEachIndexed }
            }
            items.add(Item(name, IntArray(nums.size) { nums[it]!! }, limiter))
        }
        if (items.isEmpty() && errors.isEmpty()) errors.add("Tidak ada preset di dalam teks")
        return Result(items, errors)
    }
}

/** Daftar aplikasi pemutar yang terdeteksi lewat Mode Sesi Aplikasi. Default: semua diproses. */
object AppStore {
    private const val KEY = "detected_apps"
    private const val ON_PREFIX = "app_on_"

    fun detected(ctx: Context): List<String> = try {
        val a = JSONArray(Store.prefs(ctx).getString(KEY, "[]"))
        List(a.length()) { a.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }

    fun add(ctx: Context, pkg: String) {
        val list = detected(ctx)
        if (pkg !in list) Store.prefs(ctx).edit().putString(KEY, JSONArray(list + pkg).toString()).apply()
    }

    fun isEnabled(ctx: Context, pkg: String): Boolean = Store.prefs(ctx).getBoolean(ON_PREFIX + pkg, true)

    fun setEnabled(ctx: Context, pkg: String, on: Boolean) {
        Store.prefs(ctx).edit().putBoolean(ON_PREFIX + pkg, on).apply()
    }

    fun clear(ctx: Context) {
        val p = Store.prefs(ctx)
        val e = p.edit().remove(KEY)
        p.all.keys.filter { it.startsWith(ON_PREFIX) }.forEach { e.remove(it) }
        e.apply()
    }
}

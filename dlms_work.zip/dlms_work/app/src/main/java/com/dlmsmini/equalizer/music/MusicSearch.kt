package com.dlmsmini.equalizer.music

import android.content.Context
import com.dlmsmini.equalizer.DiagLog
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException

/** Penilaian "keresmian" hasil pencarian. Murni (tanpa Android) agar bisa diuji. */
object OfficialRank {
    private val BAD = listOf(
        "cover", "remix", "karaoke", "instrumental", "slowed", "reverb", "sped up", "speed up", "nightcore",
        "8d", "bass boosted", "live", "reaction", "tutorial", "lesson", "mashup", "bootleg", "fanmade", "fan made",
        "acoustic version", "piano version", "ringtone", "full album", "playlist"
    )
    private val GOOD = listOf("official audio", "official music video", "official video", "official lyric", "(official", "[official", "provided to youtube")

    /** Kata pada judul yang dikecualikan dari penalti bila pengguna memang mencarinya. */
    fun score(title: String, artist: String, verified: Boolean, fromMusicFilter: Boolean, query: String): Int {
        val t = title.lowercase()
        val a = artist.lowercase()
        val q = query.lowercase()
        var s = 0
        if (fromMusicFilter) s += 50
        if (a.endsWith("- topic") || a.contains("vevo")) s += 35
        if (verified) s += 20
        if (GOOD.any { t.contains(it) }) s += 10
        for (w in BAD) {
            val inTitle = Regex("(^|[^a-z0-9])" + Regex.escape(w) + "([^a-z0-9]|$)").containsMatchIn(t)
            if (inTitle && !q.contains(w)) s -= 40
        }
        if (Regex("lyrics?( video)?").containsMatchIn(t) && !q.contains("lyric")) s -= 5
        return s
    }

    fun isOfficial(score: Int): Boolean = score >= 40
}

/** Merapikan judul/artis untuk tampilan dan untuk pencarian lirik. */
object TitleClean {
    private val NOISE = Regex(
        "[\\(\\[\\{][^\\)\\]\\}]*(official|video|audio|lyric|lirik|mv|hd|hq|4k|remaster|visualizer|clip|resmi)[^\\)\\]\\}]*[\\)\\]\\}]",
        RegexOption.IGNORE_CASE
    )
    private val FEAT = Regex("\\s*[\\(\\[]?\\s*(feat\\.?|ft\\.?|featuring)\\s[^\\)\\]]*[\\)\\]]?", RegexOption.IGNORE_CASE)

    fun artist(raw: String): String = raw.replace(Regex("\\s*-\\s*Topic$", RegexOption.IGNORE_CASE), "").trim()

    fun title(raw: String): String = raw.replace(NOISE, "").replace(Regex("\\s+"), " ").trim()

    /** Judul tanpa "feat." dan tanpa awalan "Artis - " agar cocok dengan basis data lirik. */
    fun forLyrics(rawTitle: String, rawArtist: String): Pair<String, String> {
        val artist = artist(rawArtist)
        var t = title(rawTitle).replace(FEAT, "").trim()
        val dash = t.indexOf(" - ")
        if (dash > 0 && t.substring(0, dash).trim().equals(artist, true)) t = t.substring(dash + 3).trim()
        return t to artist
    }
}

/** Klien Piped: daftar instans publik, pencarian, dan halaman berikutnya, dengan failover antar-instans. */
object PipedClient {
    private val FALLBACK = listOf(
        "https://pipedapi.kavin.rocks",
        "https://api.piped.private.coffee",
        "https://pipedapi.adminforge.de",
        "https://pipedapi.leptons.xyz",
        "https://pipedapi.nosebs.ru",
        "https://pipedapi.reallyaweso.me",
        "https://piped-api.garudalinux.org"
    )
    private const val LIST_URL = "https://piped-instances.kavin.rocks/"
    private const val LIST_TTL = 6 * 3600_000L
    private val badUntil = HashMap<String, Long>()

    class Page(val items: List<JSONObject>, val next: String?, val base: String)

    private fun fetchList(ctx: Context): List<String> {
        val cached = MusicPrefs.instancesJson(ctx)
        val fresh = System.currentTimeMillis() - MusicPrefs.instancesAt(ctx) < LIST_TTL
        var json = if (fresh) cached else ""
        if (json.isBlank()) {
            json = try {
                Http.get(LIST_URL, timeoutMs = 8000).also { MusicPrefs.saveInstances(ctx, it) }
            } catch (_: Exception) { cached }
        }
        if (json.isBlank()) return emptyList()
        return try {
            val a = JSONArray(json)
            val rows = ArrayList<Pair<String, Double>>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val url = o.optString("api_url").trimEnd('/')
                if (url.startsWith("https://")) rows.add(url to o.optDouble("uptime_30d", 0.0))
            }
            rows.sortedByDescending { it.second }.take(8).map { it.first }
        } catch (_: Exception) { emptyList() }
    }

    /** Urutan percobaan: instans buatan pengguna, instans yang baru berhasil, daftar resmi, lalu daftar bawaan. */
    private fun candidates(ctx: Context, preferred: String?): List<String> {
        val out = LinkedHashSet<String>()
        val custom = MusicPrefs.customPiped(ctx)
        if (custom.startsWith("http")) out.add(custom.trimEnd('/'))
        if (preferred != null) out.add(preferred)
        out.addAll(fetchList(ctx))
        out.addAll(FALLBACK)
        val now = System.currentTimeMillis()
        return out.filter { (badUntil[it] ?: 0L) < now }.ifEmpty { out.toList() }
    }

    fun search(ctx: Context, query: String, filter: String, token: String?, preferred: String?): Page {
        var last: Exception? = null
        var tried = 0
        for (base in candidates(ctx, preferred)) {
            if (tried >= 4) break
            tried++
            try {
                val url = if (token == null) "$base/search?q=${query.enc()}&filter=$filter"
                else "$base/nextpage/search?nextpage=${token.enc()}&q=${query.enc()}&filter=$filter"
                val o = JSONObject(Http.get(url, timeoutMs = 12000))
                if (o.has("error")) throw IOException(o.optString("message", "error"))
                val arr = o.optJSONArray("items") ?: JSONArray()
                val items = ArrayList<JSONObject>()
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { items.add(it) }
                val next = if (o.isNull("nextpage")) null else o.optString("nextpage").ifBlank { null }
                return Page(items, next, base)
            } catch (e: Exception) {
                last = e
                badUntil[base] = System.currentTimeMillis() + 10 * 60_000L
                DiagLog.log("Piped $base gagal: ${e.message}")
            }
        }
        throw IOException("Semua instans Piped gagal${last?.message?.let { ": $it" } ?: ""}", last)
    }
}

/**
 * Sesi pencarian dengan hasil tanpa batas: [loadMore] dipanggil berulang saat daftar digulir.
 * Urutan tahap: lagu YouTube Music (resmi) → video musik → semua video; di dalam tiap halaman, yang paling resmi diutamakan.
 * Pencarian lewat NewPipeExtractor (lokal di perangkat); bila gagal, dilanjutkan lewat instans Piped.
 */
class SearchSession(private val ctx: Context, val query: String) {
    private val stages = listOf("music_songs", "music_videos", "videos")
    private var stage = 0
    private var token: String? = null
    private var npPage: Page? = null
    // NewPipe (lokal di HP) jadi jalur utama: tanpa antre failover antar-instans Piped, jadi jauh lebih cepat.
    // Piped baru dipakai kalau pencarian lokal gagal.
    private var npMode = true
    private var base: String? = null
    private val seen = HashSet<String>()
    private val idRe = Regex("[?&]v=([\\w-]{11})")

    @Volatile var exhausted = false
        private set

    /** Blocking. Mengembalikan paling sedikit beberapa lagu baru, atau kosong bila habis. */
    fun loadMore(): List<Track> {
        val out = ArrayList<Track>()
        var rounds = 0
        while (out.size < 8 && !exhausted && rounds < 4) {
            rounds++
            val filter = stages[stage]
            var batch: List<Pair<Track, Int>> = emptyList()
            var hasNext = false
            if (npMode) {
                try {
                    val r = npSearch(filter)
                    batch = r.first
                    hasNext = r.second
                } catch (e: Exception) {
                    DiagLog.log("Musik: pencarian lokal gagal (${e.javaClass.simpleName}: ${e.message})")
                    if (npPage == null && token == null) {
                        // gagal di halaman pertama tahap ini: coba lewat Piped
                        npMode = false
                        continue
                    }
                    // gagal di tengah rantai halaman: anggap ujung tahap ini
                    batch = emptyList()
                    hasNext = false
                }
            } else {
                val p = PipedClient.search(ctx, query, filter, token, base)
                base = p.base
                token = p.next
                hasNext = p.next != null
                batch = p.items.mapNotNull { fromPiped(it, filter) }
            }
            // Dalam satu halaman, yang paling resmi lebih dulu (urutan asli dipertahankan bila skor sama).
            val sorted = batch.withIndex().sortedWith(compareByDescending<IndexedValue<Pair<Track, Int>>> { it.value.second }.thenBy { it.index })
            for (iv in sorted) {
                val t = iv.value.first
                if (seen.add(t.id)) out.add(t)
            }
            if (!hasNext) {
                stage++
                token = null
                npPage = null
                if (stage >= stages.size) exhausted = true
            }
        }
        return out
    }

    private fun fromPiped(o: JSONObject, filter: String): Pair<Track, Int>? {
        val type = o.optString("type", "stream")
        if (type != "stream") return null
        if (o.optBoolean("isShort", false)) return null
        val id = idRe.find(o.optString("url"))?.groupValues?.get(1) ?: return null
        val dur = o.optLong("duration", -1L)
        if (dur <= 0L || dur > 3 * 3600L) return null
        val rawTitle = o.optString("title")
        val rawArtist = o.optString("uploaderName")
        val score = OfficialRank.score(rawTitle, rawArtist, o.optBoolean("uploaderVerified", false), filter == "music_songs", query)
        val t = Track(
            id = id,
            title = TitleClean.title(rawTitle).ifBlank { rawTitle },
            artist = TitleClean.artist(rawArtist),
            durationSec = dur.toInt(),
            thumb = o.optString("thumbnail"),
            official = OfficialRank.isOfficial(score)
        )
        return t to score
    }

    private fun npSearch(filter: String): Pair<List<Pair<Track, Int>>, Boolean> {
        val s = NewPipeBridge.service()
        val qh = s.searchQHFactory.fromQuery(query, listOf(filter), "")
        val items: List<InfoItem>
        val next: Page?
        val cur = npPage
        if (cur == null) {
            val info = SearchInfo.getInfo(s, qh)
            items = info.relatedItems
            next = info.nextPage
        } else {
            val p = SearchInfo.getMoreItems(s, qh, cur)
            items = p.items
            next = p.nextPage
        }
        npPage = next
        val rows = ArrayList<Pair<Track, Int>>()
        for (item in items) {
            if (item !is StreamInfoItem) continue
            val id = idRe.find(item.url)?.groupValues?.get(1) ?: continue
            if (item.duration <= 0L || item.duration > 3 * 3600L) continue
            val score = OfficialRank.score(item.name, item.uploaderName ?: "", item.isUploaderVerified, filter == "music_songs", query)
            val thumb = item.thumbnails.maxByOrNull { img -> img.height }?.url ?: ""
            rows.add(
                Track(
                    id = id, title = TitleClean.title(item.name).ifBlank { item.name },
                    artist = TitleClean.artist(item.uploaderName ?: ""), durationSec = item.duration.toInt(),
                    thumb = thumb, official = OfficialRank.isOfficial(score)
                ) to score
            )
        }
        return rows to (next != null && items.isNotEmpty())
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Spectrum Analyzer 2.0.
 *  - Sumbu frekuensi logaritmik 20 Hz - 20 kHz (48 pita) dari FFT Visualizer, dengan label frekuensi.
 *  - Tampilan: BAR, WAVE (bentuk gelombang), CURVE (kurva halus berisi), WATERFALL (riwayat spektrum berwarna).
 *  - Readout RMS/puncak (dBFS), frekuensi puncak, dan kursor frekuensi (sentuh grafik).
 *  - Smoothing (attack cepat, release lambat; 3 tingkat) dan peak hold (tahan lalu jatuh).
 *  - Animasi tiga meter BASS / MID / TREBLE dengan efek denyut.
 *  - Indikator CLIP bila gelombang keluaran menyentuh batas penuh.
 * Data dikirim dari thread Visualizer; seluruh animasi dihitung di thread UI saat menggambar.
 */
class SpectrumView(context: Context) : View(context) {

    enum class Mode { BAR, WAVE, CURVE, WATERFALL }

    var mode: Mode = Mode.BAR
        set(v) { field = v; invalidate() }
    var peakHold: Boolean = true
        set(v) { field = v; invalidate() }

    /** 0 = rendah (responsif), 1 = sedang, 2 = tinggi (halus). */
    var smoothing: Int = 1

    private val n = BARS
    @Volatile private var target = FloatArray(n)
    @Volatile private var wave = FloatArray(0)
    @Volatile private var lastData = 0L
    @Volatile private var clipUntil = 0L

    // RMS / puncak (dBFS) dari gelombang, dan waterfall (riwayat spektrum, baris terbaru di atas).
    @Volatile private var rmsDb = -90f
    @Volatile private var peakDbRead = -90f
    private val wfLock = Any()
    private val wfRows = Array(WF_ROWS) { FloatArray(BARS) }
    private var wfHead = 0
    private var wfCount = 0
    private var wfBitmap: Bitmap? = null
    private val wfPixels = IntArray(BARS * WF_ROWS)
    private val wfSrc = Rect()
    private val wfDst = RectF()
    private val wfPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private var cursorX = -1f
    private var cursorUntil = 0L
    private var peakFreq = 0f

    private val disp = FloatArray(n)
    private val peak = FloatArray(n)
    private val peakAt = LongArray(n)
    private val peakVel = FloatArray(n)
    private val bandTarget = FloatArray(3)
    private val bandDisp = FloatArray(3)
    private val bandPulse = FloatArray(3)
    private var waveEnv = 0f
    private var lastFrame = 0L

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x223B82C5; strokeWidth = 1f }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d(2f); strokeJoin = Paint.Join.ROUND }
    private val peakPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFEAF6FF.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7D8FAE.toInt(); textSize = d(8.5f); textAlign = Paint.Align.CENTER }
    private val readoutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFCFE6FF.toInt(); textSize = d(9f); isFakeBoldText = true }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF4D4D.toInt(); style = Paint.Style.FILL }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = d(9f); textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val bandLabel = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = d(8.5f); isFakeBoldText = true }
    private val path = Path()
    private val fillPath = Path()
    private val rect = RectF()

    private val bandColors = intArrayOf(0xFFFF7A59.toInt(), 0xFF2BD8FF.toInt(), 0xFFB07CFF.toInt())
    private val bandNames = arrayOf("BASS", "MID", "TREBLE")

    // ---------- data masuk (thread Visualizer) ----------

    /** [data] = keluaran FFT Visualizer (pasangan real/imajiner 8-bit); [samplingMilliHz] = laju sampel dalam mHz. */
    fun submitFft(data: ByteArray, samplingMilliHz: Int) {
        val captureSize = data.size
        if (captureSize < 8 || samplingMilliHz <= 0) return
        val sr = samplingMilliHz / 1000f
        val binW = sr / captureSize
        val bins = captureSize / 2
        val mag = FloatArray(bins)
        for (j in 1 until bins) {
            val re = data[2 * j].toInt().toFloat()
            val im = data[2 * j + 1].toInt().toFloat()
            mag[j] = sqrt(re * re + im * im)
        }
        mag[0] = abs(data[0].toInt()).toFloat()
        val out = FloatArray(n)
        for (k in 0 until n) {
            val f1 = F_MIN * (F_MAX / F_MIN).pow(k.toFloat() / n)
            val f2 = F_MIN * (F_MAX / F_MIN).pow((k + 1f) / n)
            val fc = sqrt(f1 * f2)
            val j1 = f1 / binW
            val j2 = f2 / binW
            val m: Float = if (j2 - j1 < 1f) {
                val pos = (fc / binW).coerceIn(0f, (bins - 1).toFloat())
                val i0 = pos.toInt()
                val i1 = min(i0 + 1, bins - 1)
                mag[i0] + (mag[i1] - mag[i0]) * (pos - i0)
            } else {
                var best = 0f
                for (j in max(1, j1.toInt() + 1)..min(bins - 1, j2.toInt())) best = max(best, mag[j])
                best
            }
            // Kemiringan +2 dB/oktaf agar spektrum musik tampak seimbang, skala -70..0 dB.
            val tilt = 2f * (ln2(fc / 500f))
            val db = 20f * log10(max(m, 0.5f) / 180f) + tilt
            out[k] = ((db + 70f) / 70f).coerceIn(0f, 1f)
        }
        target = out
        synchronized(wfLock) {
            System.arraycopy(out, 0, wfRows[wfHead], 0, n)
            wfHead = (wfHead + 1) % WF_ROWS
            if (wfCount < WF_ROWS) wfCount++
        }
        lastData = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    /** [data] = gelombang 8-bit tak bertanda (128 = senyap). */
    fun submitWave(data: ByteArray) {
        val w = FloatArray(data.size) { ((data[it].toInt() and 0xFF) - 128) / 128f }
        var hits = 0
        for (v in w) if (abs(v) >= 0.985f) hits++
        if (hits >= 2) clipUntil = SystemClock.uptimeMillis() + 900
        wave = w
        val rd = Meter.readWave8(data)
        rmsDb = rd.rmsDb
        peakDbRead = rd.peakDb
        lastData = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    fun clear() {
        target = FloatArray(n)
        wave = FloatArray(0)
        postInvalidateOnAnimation()
    }

    private fun ln2(x: Float): Float = (kotlin.math.ln(max(x, 1e-6f)) / kotlin.math.ln(2f))

    // ---------- animasi & gambar (thread UI) ----------

    private fun advance(now: Long) {
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.1f)
        lastFrame = now
        val (atk, rel) = when (smoothing) { 0 -> 0.03f to 0.12f; 2 -> 0.12f to 0.45f; else -> 0.06f to 0.25f }
        val aA = 1f - exp(-dt / atk)
        val aR = 1f - exp(-dt / rel)
        val t = target
        val fresh = now - lastData < 1500
        for (i in 0 until n) {
            val goal = if (fresh) t[i] else 0f
            disp[i] += (goal - disp[i]) * (if (goal > disp[i]) aA else aR)
            if (disp[i] >= peak[i]) {
                peak[i] = disp[i]; peakAt[i] = now; peakVel[i] = 0f
            } else if (now - peakAt[i] > 650) {
                peakVel[i] += 2.2f * dt
                peak[i] = max(disp[i], peak[i] - peakVel[i] * dt)
            }
        }
        if (smoothing == 2) {
            for (i in 1 until n - 1) disp[i] = disp[i] * 0.6f + (disp[i - 1] + disp[i + 1]) * 0.2f
        }
        var bi = 0
        for (i in 1 until n) if (disp[i] > disp[bi]) bi = i
        peakFreq = if (disp[bi] > 0.12f) F_MIN * (F_MAX / F_MIN).pow((bi + 0.5f) / n) else 0f
        // Meter bass / mid / treble dari rata-rata pita: bass < 250 Hz, mid 250 Hz - 4 kHz, treble > 4 kHz.
        val sum = FloatArray(3)
        val cnt = IntArray(3)
        for (k in 0 until n) {
            val fc = F_MIN * (F_MAX / F_MIN).pow((k + 0.5f) / n)
            val g = if (fc < 250f) 0 else if (fc < 4000f) 1 else 2
            sum[g] += (if (fresh) t[k] else 0f); cnt[g]++
        }
        for (g in 0 until 3) {
            val goal = if (cnt[g] > 0) sum[g] / cnt[g] else 0f
            val before = bandDisp[g]
            bandDisp[g] += (goal - bandDisp[g]) * (if (goal > bandDisp[g]) 1f - exp(-dt / 0.04f) else 1f - exp(-dt / 0.3f))
            // Denyut: lonjakan naik memicu pulsa yang meluruh.
            val rise = bandDisp[g] - before
            if (rise > 0.012f) bandPulse[g] = min(1f, bandPulse[g] + rise * 14f)
            bandPulse[g] = max(0f, bandPulse[g] - dt * 2.5f)
        }
        val wv = wave
        var m = 0f
        for (v in wv) m = max(m, abs(v))
        waveEnv = if (!fresh) waveEnv * 0.9f else max(m, waveEnv - dt * 0.8f)
    }

    private fun isAnimating(now: Long): Boolean {
        if (now - lastData < 1500) return true
        for (v in disp) if (v > 0.01f) return true
        for (v in bandDisp) if (v > 0.01f) return true
        return now < clipUntil
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val now = SystemClock.uptimeMillis()
        advance(now)

        val w = width.toFloat()
        val h = height.toFloat()
        val metersH = d(24f)
        val axisH = d(12f)
        val gTop = d(4f)
        val gBottom = h - metersH - axisH
        val gH = gBottom - gTop

        for (line in 1..3) {
            val y = gTop + gH * line / 4f
            canvas.drawLine(0f, y, w, y, gridPaint)
        }
        if (mode != Mode.WAVE) drawAxis(canvas, w, gBottom, axisH)
        if (mode == Mode.WATERFALL) drawWaterfall(canvas, w, gTop, gBottom)
        when (mode) {
            Mode.BAR -> drawBars(canvas, w, gTop, gBottom)
            Mode.CURVE -> drawCurve(canvas, w, gTop, gBottom)
            Mode.WAVE -> drawWave(canvas, w, gTop, gBottom)
            Mode.WATERFALL -> {}
        }
        drawReadout(canvas, w, gTop, gBottom, now)
        drawMeters(canvas, w, h - metersH + d(4f), metersH - d(4f))

        if (now < clipUntil) {
            rect.set(w - d(40f), gTop, w - d(2f), gTop + d(15f))
            canvas.drawRoundRect(rect, d(4f), d(4f), badgePaint)
            canvas.drawText("CLIP", rect.centerX(), rect.centerY() + d(3.2f), badgeText)
        }
        if (isAnimating(now)) postInvalidateOnAnimation() else lastFrame = 0L
    }

    private fun wfColor(v: Float): Int {
        val t = v.coerceIn(0f, 1f)
        val stops = intArrayOf(0xFF050B1A.toInt(), 0xFF0B3C8C.toInt(), 0xFF18B6D8.toInt(), 0xFFF2E55C.toInt(), 0xFFFF4D3A.toInt())
        val pos = t * (stops.size - 1)
        val i = min(pos.toInt(), stops.size - 2)
        val f = pos - i
        fun ch(shift: Int) = (((stops[i] shr shift) and 0xFF) * (1 - f) + ((stops[i + 1] shr shift) and 0xFF) * f).toInt()
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    private fun drawWaterfall(canvas: Canvas, w: Float, top: Float, bottom: Float) {
        var bmp = wfBitmap
        if (bmp == null) {
            bmp = Bitmap.createBitmap(BARS, WF_ROWS, Bitmap.Config.ARGB_8888)
            wfBitmap = bmp
        }
        synchronized(wfLock) {
            for (r in 0 until WF_ROWS) {
                val src = (wfHead - 1 - r + WF_ROWS * 2) % WF_ROWS
                val has = r < wfCount
                for (k in 0 until BARS) wfPixels[r * BARS + k] = if (has) wfColor(wfRows[src][k]) else 0xFF050B1A.toInt()
            }
        }
        bmp.setPixels(wfPixels, 0, BARS, 0, 0, BARS, WF_ROWS)
        wfSrc.set(0, 0, BARS, WF_ROWS)
        wfDst.set(0f, top, w, bottom)
        canvas.drawBitmap(bmp, wfSrc, wfDst, wfPaint)
    }

    private fun levelAt(x: Float, w: Float): Pair<Float, Float> {
        val t = (x / w).coerceIn(0f, 1f)
        val hz = F_MIN * (F_MAX / F_MIN).pow(t)
        val k = (t * n).toInt().coerceIn(0, n - 1)
        return Pair(hz, disp[k] * 70f - 70f)
    }

    private fun fmtHz(hz: Float): String =
        if (hz >= 1000f) String.format(Locale.US, "%.2f kHz", hz / 1000f) else String.format(Locale.US, "%.0f Hz", hz)

    private fun drawReadout(canvas: Canvas, w: Float, top: Float, bottom: Float, now: Long) {
        val pk = if (peakFreq > 0f) "  ▲ ${fmtHz(peakFreq)}" else ""
        val rms = if (rmsDb <= -89f) "—" else String.format(Locale.US, "%.1f", rmsDb)
        val pkd = if (peakDbRead <= -89f) "—" else String.format(Locale.US, "%.1f", peakDbRead)
        canvas.drawText("RMS $rms dB  PK $pkd dB$pk", d(4f), top + d(10f), readoutPaint)
        if (cursorX >= 0f && now < cursorUntil) {
            val lv = levelAt(cursorX, w)
            canvas.drawLine(cursorX, top, cursorX, bottom, peakPaint)
            val t = "${fmtHz(lv.first)}  ${String.format(Locale.US, "%.0f", lv.second)} dB"
            val tw = readoutPaint.measureText(t)
            canvas.drawText(t, (cursorX + d(4f)).coerceAtMost(w - tw - d(2f)), top + d(24f), readoutPaint)
            postInvalidateOnAnimation()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cursorX = e.x; cursorUntil = SystemClock.uptimeMillis() + 3000
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                cursorX = e.x; cursorUntil = SystemClock.uptimeMillis() + 3000
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                cursorUntil = SystemClock.uptimeMillis() + 2500
                invalidate(); return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun drawAxis(canvas: Canvas, w: Float, y: Float, hgt: Float) {
        val marks = floatArrayOf(20f, 50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f, 20000f)
        val names = arrayOf("20", "50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k")
        for (i in marks.indices) {
            val x = (kotlin.math.ln(marks[i] / F_MIN) / kotlin.math.ln(F_MAX / F_MIN)) * w
            val tx = x.coerceIn(d(8f), w - d(8f))
            canvas.drawText(names[i], tx, y + hgt - d(1f), textPaint)
        }
    }

    private fun drawBars(canvas: Canvas, w: Float, top: Float, bottom: Float) {
        val gap = w * 0.008f
        val bw = (w - gap * (n - 1)) / n
        val gH = bottom - top
        for (i in 0 until n) {
            val level = disp[i].coerceIn(0f, 1f)
            val bh = max(d(2f), gH * level)
            val left = i * (bw + gap)
            val hi = i > n * 0.72f
            glowPaint.color = if (hi) 0x553F6BFF else 0x4436AFFF
            barPaint.shader = LinearGradient(0f, bottom - bh, 0f, bottom,
                intArrayOf(if (hi) 0xFF9B63FF.toInt() else 0xFF20D6E8.toInt(), 0xFF167CFF.toInt()), null, Shader.TileMode.CLAMP)
            rect.set(left - 1f, bottom - bh - 2f, left + bw + 1f, bottom + 1f)
            canvas.drawRoundRect(rect, d(2f), d(2f), glowPaint)
            rect.set(left, bottom - bh, left + bw, bottom)
            canvas.drawRoundRect(rect, d(1.5f), d(1.5f), barPaint)
            if (peakHold) {
                val py = bottom - gH * peak[i].coerceIn(0f, 1f) - d(2f)
                canvas.drawRect(left, py - d(1.5f), left + bw, py, peakPaint)
            }
        }
    }

    private fun curvePath(p: Path, src: FloatArray, w: Float, top: Float, bottom: Float) {
        val gH = bottom - top
        val step = w / (n - 1)
        p.reset()
        p.moveTo(0f, bottom - gH * src[0].coerceIn(0f, 1f))
        for (i in 1 until n) {
            val x0 = (i - 1) * step
            val y0 = bottom - gH * src[i - 1].coerceIn(0f, 1f)
            val x1 = i * step
            val y1 = bottom - gH * src[i].coerceIn(0f, 1f)
            val mx = (x0 + x1) / 2f
            val my = (y0 + y1) / 2f
            p.quadTo(x0, y0, mx, my)
            if (i == n - 1) p.lineTo(x1, y1)
        }
    }

    private fun drawCurve(canvas: Canvas, w: Float, top: Float, bottom: Float) {
        curvePath(path, disp, w, top, bottom)
        fillPath.set(path)
        fillPath.lineTo(w, bottom)
        fillPath.lineTo(0f, bottom)
        fillPath.close()
        barPaint.shader = LinearGradient(0f, top, 0f, bottom, intArrayOf(0x8836C8FF.toInt(), 0x11167CFF), null, Shader.TileMode.CLAMP)
        canvas.drawPath(fillPath, barPaint)
        linePaint.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(0xFF20D6E8.toInt(), 0xFF45C5FF.toInt(), 0xFF9B63FF.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawPath(path, linePaint)
        linePaint.shader = null
        if (peakHold) {
            curvePath(path, peak, w, top, bottom)
            linePaint.color = 0x99EAF6FF.toInt()
            linePaint.strokeWidth = d(1f)
            canvas.drawPath(path, linePaint)
            linePaint.strokeWidth = d(2f)
        }
    }

    private fun drawWave(canvas: Canvas, w: Float, top: Float, bottom: Float) {
        val mid = (top + bottom) / 2f
        val half = (bottom - top) / 2f * 0.92f
        gridPaint.color = 0x443B82C5
        canvas.drawLine(0f, mid, w, mid, gridPaint)
        gridPaint.color = 0x223B82C5
        val wv = wave
        if (wv.size < 2) return
        val stepIdx = max(1, wv.size / 256)
        val cnt = wv.size / stepIdx
        path.reset()
        for (i in 0 until cnt) {
            val v = wv[i * stepIdx]
            val x = w * i / (cnt - 1)
            val y = mid - v.coerceIn(-1f, 1f) * half
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        linePaint.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(0xFF20D6E8.toInt(), 0xFF45C5FF.toInt(), 0xFF9B63FF.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawPath(path, linePaint)
        linePaint.shader = null
        if (peakHold) {
            val env = waveEnv.coerceIn(0f, 1f) * half
            linePaint.color = 0x88EAF6FF.toInt()
            linePaint.strokeWidth = d(1f)
            canvas.drawLine(0f, mid - env, w, mid - env, linePaint)
            canvas.drawLine(0f, mid + env, w, mid + env, linePaint)
            linePaint.strokeWidth = d(2f)
        }
    }

    private fun drawMeters(canvas: Canvas, w: Float, top: Float, hgt: Float) {
        val seg = w / 3f
        for (g in 0 until 3) {
            val left = g * seg + d(4f)
            val right = (g + 1) * seg - d(4f)
            val level = bandDisp[g].coerceIn(0f, 1f)
            val pulse = bandPulse[g]
            bandLabel.color = bandColors[g]
            canvas.drawText(bandNames[g], left, top + d(8f), bandLabel)
            val barTop = top + d(11f)
            val bh = d(4f) + d(3f) * pulse
            glowPaint.shader = null
            glowPaint.color = 0x22FFFFFF
            rect.set(left, barTop, right, barTop + bh)
            canvas.drawRoundRect(rect, bh / 2f, bh / 2f, glowPaint)
            val fillW = (right - left) * level
            if (fillW > 1f) {
                glowPaint.color = (bandColors[g] and 0x00FFFFFF) or ((40 + (110 * pulse).toInt()) shl 24)
                rect.set(left - d(2f) * pulse, barTop - d(2f) * pulse, left + fillW + d(2f) * pulse, barTop + bh + d(2f) * pulse)
                canvas.drawRoundRect(rect, bh, bh, glowPaint)
                barPaint.shader = null
                barPaint.color = bandColors[g]
                rect.set(left, barTop, left + fillW, barTop + bh)
                canvas.drawRoundRect(rect, bh / 2f, bh / 2f, barPaint)
            }
        }
    }

    companion object {
        const val BARS = 48
        private const val WF_ROWS = 80
        private const val F_MIN = 20f
        private const val F_MAX = 20000f
    }
}

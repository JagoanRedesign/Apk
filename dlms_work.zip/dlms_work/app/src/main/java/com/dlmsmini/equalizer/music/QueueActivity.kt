package com.dlmsmini.equalizer.music

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/** Antrean pemutaran: ketuk untuk lompat, seret gagang untuk ubah urutan, geser ke samping untuk hapus, plus Mix. */
class QueueActivity : AppCompatActivity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null
    private val items = ArrayList<MediaItem>()
    private var currentIdx = -1
    private var dragging = false

    private lateinit var count: TextView
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var touch: ItemTouchHelper

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { if (!dragging) refresh() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.BG) }
        Ui.fitSystemBars(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Icons.view(this, Icons.BACK, 18f, Pal.TEXT, "Kembali").apply { setOnClickListener { finish() } })
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        head.addView(Ui.label(this, "Antrean", 16f, Pal.TEXT, true))
        count = Ui.label(this, "", 12f, Pal.MUTED)
        head.addView(count)
        top.addView(head, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Icons.view(this, Icons.MIX, 18f, Pal.CYAN, "Mix").apply {
            setOnClickListener { controller?.let { c -> MixUi.start(this@QueueActivity, scope, c) } }
        })
        root.addView(top)

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@QueueActivity)
            adapter = QueueAdapter()
            clipToPadding = false
            setPadding(0, 0, 0, Ui.dp(this@QueueActivity, 16))
        }
        touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun isLongPressDragEnabled() = false

            override fun getSwipeDirs(rv: RecyclerView, vh: RecyclerView.ViewHolder): Int =
                if (vh.bindingAdapterPosition == currentIdx) 0 else super.getSwipeDirs(rv, vh)

            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val from = vh.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from < 0 || to < 0) return false
                controller?.moveMediaItem(from, to)
                items.add(to, items.removeAt(from))
                currentIdx = controller?.currentMediaItemIndex ?: currentIdx
                list.adapter?.notifyItemMoved(from, to)
                return true
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {
                val pos = vh.bindingAdapterPosition
                if (pos < 0 || pos >= items.size) return
                controller?.removeMediaItem(pos)
                items.removeAt(pos)
                if (pos < currentIdx) currentIdx--
                list.adapter?.notifyItemRemoved(pos)
                updateCount()
            }

            override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(vh, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) dragging = true
            }

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                dragging = false
                refresh()
            }
        })
        touch.attachToRecyclerView(list)

        empty = Ui.label(this, "Antrean kosong.\nPutar lagu dari pencarian atau perpustakaan.", 15f, Pal.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(Ui.dp(this@QueueActivity, 24), Ui.dp(this@QueueActivity, 40), Ui.dp(this@QueueActivity, 24), 0)
        }
        root.addView(empty, LinearLayout.LayoutParams(-1, -2))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        MusicClient.get(this) { c ->
            controller = c
            c.addListener(listener)
            refresh()
        }
    }

    override fun onStop() {
        controller?.removeListener(listener)
        controller = null
        super.onStop()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun updateCount() {
        count.text = "${items.size} lagu"
        empty.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun refresh() {
        val c = controller ?: return
        val fresh = (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
        val cur = c.currentMediaItemIndex
        val same = fresh.size == items.size && fresh.indices.all { fresh[it].mediaId == items[it].mediaId }
        items.clear(); items.addAll(fresh)
        val old = currentIdx
        currentIdx = cur
        updateCount()
        if (same) {
            if (old != cur) {
                if (old in items.indices) list.adapter?.notifyItemChanged(old)
                if (cur in items.indices) list.adapter?.notifyItemChanged(cur)
            }
        } else {
            list.adapter?.notifyDataSetChanged()
        }
        if (!same && cur in items.indices) list.scrollToPosition(cur)
    }

    private inner class VH(val row: LinearLayout, val grip: TextView, val cover: ImageView, val title: TextView, val artist: TextView, val remove: TextView) :
        RecyclerView.ViewHolder(row)

    private inner class QueueAdapter : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size

        @SuppressLint("ClickableViewAccessibility")
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4))
                layoutParams = RecyclerView.LayoutParams(-1, -2)
                isClickable = true
            }
            val grip = Icons.view(ctx, Icons.GRIP, 16f, Pal.MUTED, "Seret untuk mengurutkan")
            val cover = Img.cover(ctx, 46, 8)
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(ctx, 12), 0, Ui.dp(ctx, 8), 0) }
            val title = Ui.label(ctx, "", 15f, Pal.TEXT, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            val artist = Ui.label(ctx, "", 12f, Pal.MUTED).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
            col.addView(title); col.addView(artist)
            val remove = Icons.view(ctx, Icons.CLOSE, 14f, Pal.MUTED, "Hapus dari antrean")
            row.addView(grip)
            row.addView(cover)
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(remove)
            val vh = VH(row, grip, cover, title, artist, remove)
            grip.setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) touch.startDrag(vh)
                false
            }
            row.setOnClickListener {
                val p = vh.bindingAdapterPosition
                if (p >= 0) controller?.let { c -> c.seekTo(p, 0L); c.play() }
            }
            remove.setOnClickListener {
                val p = vh.bindingAdapterPosition
                if (p < 0 || p >= items.size || p == currentIdx) return@setOnClickListener
                controller?.removeMediaItem(p)
                items.removeAt(p)
                if (p < currentIdx) currentIdx--
                notifyItemRemoved(p)
                updateCount()
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val t = items[position].toTrack()
            val isCur = position == currentIdx
            h.title.text = t.title
            h.title.setTextColor(if (isCur) Pal.CYAN else Pal.TEXT)
            h.artist.text = t.artist
            h.remove.visibility = if (isCur) android.view.View.INVISIBLE else android.view.View.VISIBLE
            h.row.background = if (isCur) Ui.rounded(h.row.context, Pal.PANEL, 10) else null
            Img.load(h.cover, t.thumb, 120)
        }
    }
}

package com.dlmsmini.equalizer.music

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Delay per kanal untuk pemutar musik di dalam aplikasi saja. Prosesor ini dipasang di jalur audio ExoPlayer milik
 * [MusicService] (sebelum AudioTrack), jadi tidak menyentuh audio aplikasi lain. Kanal genap (kiri) memakai [leftMs],
 * kanal ganjil (kanan) memakai [rightMs]. Mendukung PCM 16-bit dan float; format lain dilewatkan apa adanya.
 */
class DelayAudioProcessor : BaseAudioProcessor() {
    @Volatile var leftMs = 0f
    @Volatile var rightMs = 0f

    private var ring: Array<ByteArray> = emptyArray()
    private var ringFrames = 2
    private var pos = 0
    private var bps = 2
    private var channels = 2
    private var rate = 44100

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            return AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun onFlush() {
        val f = inputAudioFormat
        bps = if (f.encoding == C.ENCODING_PCM_FLOAT) 4 else 2
        channels = f.channelCount.coerceAtLeast(1)
        rate = f.sampleRate.coerceAtLeast(8000)
        ringFrames = ceil(MusicDelay.MAX_MS / 1000.0 * rate).toInt() + 2
        ring = Array(channels) { ByteArray(ringFrames * bps) }
        pos = 0
    }

    override fun onReset() {
        ring = emptyArray()
    }

    private fun framesFor(ms: Float): Int =
        (ms.coerceIn(0f, MusicDelay.MAX_MS) * rate / 1000f).roundToInt().coerceIn(0, ringFrames - 1)

    override fun queueInput(inputBuffer: ByteBuffer) {
        val frameSize = channels * bps
        val frames = inputBuffer.remaining() / frameSize
        if (frames == 0 || ring.size != channels) {
            inputBuffer.position(inputBuffer.limit())
            return
        }
        val out = replaceOutputBuffer(frames * frameSize)
        val dL = framesFor(leftMs)
        val dR = framesFor(rightMs)
        var idx = inputBuffer.position()
        for (f in 0 until frames) {
            val w = pos * bps
            for (c in 0 until channels) {
                val d = if (c % 2 == 0) dL else dR
                val r = ring[c]
                for (b in 0 until bps) r[w + b] = inputBuffer.get(idx + b)
                var rp = pos - d
                if (rp < 0) rp += ringFrames
                val ri = rp * bps
                for (b in 0 until bps) out.put(r[ri + b])
                idx += bps
            }
            pos++
            if (pos == ringFrames) pos = 0
        }
        inputBuffer.position(inputBuffer.position() + frames * frameSize)
        out.flip()
    }
}

/** Status delay musik yang dipakai bersama layar pengaturan dan [MusicService] (satu proses). */
object MusicDelay {
    const val MAX_MS = 100f
    val processor = DelayAudioProcessor()

    fun load(ctx: Context) {
        processor.leftMs = MusicPrefs.delayLeft10(ctx) / 10f
        processor.rightMs = MusicPrefs.delayRight10(ctx) / 10f
    }

    val leftMs: Float get() = processor.leftMs
    val rightMs: Float get() = processor.rightMs

    fun set(ctx: Context, left: Float? = null, right: Float? = null) {
        if (left != null) {
            processor.leftMs = left.coerceIn(0f, MAX_MS)
            MusicPrefs.setDelayLeft10(ctx, (processor.leftMs * 10).roundToInt())
        }
        if (right != null) {
            processor.rightMs = right.coerceIn(0f, MAX_MS)
            MusicPrefs.setDelayRight10(ctx, (processor.rightMs * 10).roundToInt())
        }
    }

    /** Kecepatan suara (m/s) pada suhu udara [tempC] derajat Celsius. */
    fun speed(tempC: Int): Double = 331.3 + 0.606 * tempC

    fun distanceM(ms: Float, tempC: Int): Double = ms / 1000.0 * speed(tempC)
}

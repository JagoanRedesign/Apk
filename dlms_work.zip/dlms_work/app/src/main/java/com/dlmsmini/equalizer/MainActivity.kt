package com.dlmsmini.equalizer

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private val frequencies = arrayOf("31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz")
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    private val values = IntArray(10)
    private val sliders = mutableListOf<SeekBar>()
    private var eq: Equalizer? = null
    private var visualizer: Visualizer? = null
    private var spectrumView: SpectrumView? = null
    private var status: TextView? = null
    private var effectsEnabled = true
    private var eqMode = "1WAY"
    private var presetSpinner: Spinner? = null
    private var presetNames: List<String> = emptyList()
    private var eqModeInfo: TextView? = null
    private var lowGroupLabel: TextView? = null
    private var highGroupLabel: TextView? = null
    private val prefs by lazy {
        getSharedPreferences("dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_"), Context.MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSettings()
        buildUi()
        initEqualizer()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVisualizer()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(v: Long) = v.toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(0xFF090D16))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }

        fun text(value: String, size: Float = 13f, tint: Int = color(0xFFB8C4D8), bold: Boolean = false): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(tint)
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        fun sectionTitle(value: String) {
            val t = text(value, 16f, color(0xFFF2F6FF), true)
            t.setPadding(0, dp(20), 0, dp(10)); content.addView(t)
        }
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(color(0xFF151D2B)); cornerRadius = dp(18).toFloat()
                setStroke(dp(1), color(0xFF26364D))
            }
        }
        fun addGap(height: Int = 10) { content.addView(View(this), LinearLayout.LayoutParams(1, dp(height))) }

        val header = card()
        header.addView(text("DLMS MINI", 12f, color(0xFF55D6FF), true))
        header.addView(text("EQUALIZER", 27f, color(0xFFFFFFFF), true))
        header.addView(text("10-Band Sound Studio  •  Ilham Galeh", 12f))
        content.addView(header)
        addGap()

        sectionTitle("LIVE AUDIO VISUALIZER")
        val visualCard = card()
        spectrumView = SpectrumView(this)
        visualCard.addView(spectrumView, LinearLayout.LayoutParams(-1, dp(112)))
        visualCard.addView(text("Spektrum mengikuti audio yang dapat diakses perangkat.", 11f))
        content.addView(visualCard)
        status = text("Status: menyiapkan audio…", 11f, color(0xFF69D9A5))
        status?.setPadding(dp(3), dp(8), 0, 0)
        content.addView(status)

        sectionTitle("EQUALIZER • 1-WAY / 2-WAY")
        val eqCard = card()
        val toggle = Switch(this).apply {
            text = "Equalizer aktif"; setTextColor(color(0xFFF3F6FC)); isChecked = effectsEnabled
        }
        toggle.setOnCheckedChangeListener { _, checked ->
            effectsEnabled = checked
            try { eq?.enabled = checked } catch (_: Exception) { }
            status?.text = if (checked) "Status: equalizer aktif (dukungan perangkat)" else "Status: equalizer nonaktif"
            saveSettings()
        }
        eqCard.addView(toggle)

        val modeLabel = text("MODE EQUALIZER", 11f, color(0xFF7F91AA), true)
        modeLabel.setPadding(0, dp(12), 0, dp(4))
        eqCard.addView(modeLabel)
        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val oneWay = RadioButton(this).apply { text = "1-Way • Full Range"; setTextColor(color(0xFFEAF1FC)); id = View.generateViewId() }
        val twoWay = RadioButton(this).apply { text = "2-Way • Low / High"; setTextColor(color(0xFFEAF1FC)); id = View.generateViewId() }
        modeGroup.addView(oneWay, RadioGroup.LayoutParams(0, -2, 1f))
        modeGroup.addView(twoWay, RadioGroup.LayoutParams(0, -2, 1f))
        modeGroup.check(if (eqMode == "2WAY") twoWay.id else oneWay.id)
        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            eqMode = if (checkedId == twoWay.id) "2WAY" else "1WAY"
            renderEqModeInfo()
            saveSettings()
        }
        eqCard.addView(modeGroup)
        val modeInfo = text(if (eqMode == "2WAY") "2-Way: LOW (31–500 Hz) dan HIGH (1–16 kHz) ditampilkan sebagai dua bagian pengaturan terpisah." else "1-Way: satu kurva EQ untuk seluruh rentang frekuensi 31 Hz–16 kHz.", 11f)
        modeInfo.tag = "eq_mode_info"
        eqModeInfo = modeInfo
        modeInfo.setPadding(0, dp(3), 0, dp(8))
        eqCard.addView(modeInfo)
        val scale = text("+12 dB       +6 dB        0 dB       -6 dB       -12 dB       -24 dB", 9f, color(0xFF7F91AA))
        scale.setPadding(0, dp(12), 0, dp(5)); eqCard.addView(scale)

        frequencies.forEachIndexed { index, frequency ->
            if (index == 0 || index == 5) {
                val groupName = if (index == 0 && eqMode == "2WAY") "LOW SECTION • 31–500 Hz" else if (index == 5) "HIGH SECTION • 1–16 kHz" else "FULL RANGE • 31 Hz–16 kHz"
                val groupTitle = text(groupName, 10f, color(0xFF55D6FF), true)
                groupTitle.setPadding(0, dp(12), 0, dp(5))
                groupTitle.tag = "eq_group_$index"
                if (index == 0) lowGroupLabel = groupTitle else highGroupLabel = groupTitle
                if (index == 5 && eqMode != "2WAY") groupTitle.visibility = View.GONE
                eqCard.addView(groupTitle)
            }
            val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
            top.addView(text(frequency, 12f, color(0xFFE7EDF8), true), LinearLayout.LayoutParams(0, -2, 1f))
            val minus = Button(this).apply { text = "−"; textSize = 15f; minWidth = dp(42); minimumWidth = dp(42); minHeight = dp(36); minimumHeight = dp(36); setPadding(0, 0, 0, 0) }
            val plus = Button(this).apply { text = "+"; textSize = 15f; minWidth = dp(42); minimumWidth = dp(42); minHeight = dp(36); minimumHeight = dp(36); setPadding(0, 0, 0, 0) }
            val valueLabel = text("${values[index]}.0 dB", 12f, color(0xFF62D8FF), true)
            top.addView(minus); top.addView(plus)
            block.addView(top)
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val seek = SeekBar(this).apply {
                max = 36
                progress = (values[index] + 24).coerceIn(0, 36)
                progressTintList = android.content.res.ColorStateList.valueOf(color(0xFF28BFFF))
                thumbTintList = android.content.res.ColorStateList.valueOf(color(0xFFE4F5FF))
            }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    values[index] = p - 24
                    valueLabel.text = String.format(java.util.Locale.US, "%.1f dB", values[index].toFloat())
                    if (user) { applyEqualizer(); saveSettings() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            sliders.add(seek)
            row.addView(seek, LinearLayout.LayoutParams(0, dp(34), 1f))
            row.addView(valueLabel, LinearLayout.LayoutParams(dp(65), -2))
            block.addView(row)
            minus.setOnClickListener { seek.progress = (seek.progress - 1).coerceAtLeast(0) }
            plus.setOnClickListener { seek.progress = (seek.progress + 1).coerceAtMost(seek.max) }
            eqCard.addView(block)
            if (index != frequencies.lastIndex) {
                val line = View(this).apply { setBackgroundColor(color(0xFF253247)) }
                eqCard.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        content.addView(eqCard)

        sectionTitle("PRESET MUSIK")
        val presetCard = card()
        val builtIns = listOf("Custom", "Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
        val customNames = prefs.all.keys.filter { it.startsWith("custom_") }.map { it.removePrefix("custom_") }
        presetNames = (builtIns + customNames).distinct()
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presetNames)
        }
        presetSpinner = spinner
        presetCard.addView(spinner)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val name = presetNames[position]
                    if (name in builtIns) applyPreset(name) else applySavedPreset(name)
                }
            }
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = Button(this).apply { text = "Save Preset"; setOnClickListener { saveCustomPreset() } }
        val flat = Button(this).apply { text = "Reset Flat"; setOnClickListener { values.fill(0); updateSliders(); applyEqualizer(); saveSettings() } }
        actions.addView(save, LinearLayout.LayoutParams(0, -2, 1f)); actions.addView(flat, LinearLayout.LayoutParams(0, -2, 1f))
        presetCard.addView(actions)
        content.addView(presetCard)

        sectionTitle("TENTANG APLIKASI")
        val about = card()
        about.addView(text("DLMS Mini Equalizer", 15f, color(0xFFFFFFFF), true))
        about.addView(text("Dibuat oleh Ilham Galeh\n© ${java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)} Ilham Galeh. All rights reserved.", 12f))
        about.addView(text("Mode 1-Way menggunakan satu kurva full-range. Mode 2-Way membagi pengaturan menjadi LOW (31–500 Hz) dan HIGH (1–16 kHz). Jumlah band yang benar-benar diterapkan mengikuti kemampuan equalizer hardware perangkat.", 11f))
        content.addView(about)

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun renderEqModeInfo() {
        if (eqMode == "2WAY") {
            eqModeInfo?.text = "2-Way: LOW (31–500 Hz) dan HIGH (1–16 kHz) ditampilkan sebagai dua bagian pengaturan terpisah."
            lowGroupLabel?.text = "LOW SECTION • 31–500 Hz"
            highGroupLabel?.visibility = View.VISIBLE
        } else {
            eqModeInfo?.text = "1-Way: satu kurva EQ untuk seluruh rentang frekuensi 31 Hz–16 kHz."
            lowGroupLabel?.text = "FULL RANGE • 31 Hz–16 kHz"
            highGroupLabel?.visibility = View.GONE
        }
    }

    private fun initEqualizer() {
        try {
            eq = Equalizer(0, 0).also { it.enabled = effectsEnabled }
            applyEqualizer()
            status?.text = "Status: Equalizer tersambung; band hardware menyesuaikan perangkat"
        } catch (e: Exception) {
            status?.text = "Status: audio effect global tidak didukung (${e.javaClass.simpleName})"
        }
    }

    private fun applyEqualizer() {
        val effect = eq ?: return
        if (!effectsEnabled) return
        try {
            val range = effect.bandLevelRange
            // Beberapa perangkat hanya memiliki 5 band hardware. Nilai 10 band UI
            // digabung rata-rata ke band hardware terdekat agar hasil preset stabil.
            val buckets = Array(effect.numberOfBands.toInt()) { mutableListOf<Int>() }
            values.forEachIndexed { index, db ->
                val band = nearestBand(effect, centerHz[index]).toInt()
                buckets[band].add(db)
            }
            for (band in 0 until effect.numberOfBands) {
                val list = buckets[band]
                val db = if (list.isEmpty()) 0 else list.average().toInt()
                val milliDb = (db * 100).coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band.toShort(), milliDb.toShort())
            }
        } catch (_: Exception) { }
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Short {
        var best = 0
        var difference = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < difference) { difference = d; best = i }
        }
        return best.toShort()
    }

    private fun applyPreset(name: String) {
        val preset = when (name) {
            "Flat" -> intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
            "Pop" -> intArrayOf(2, 1, 0, -1, -1, 1, 2, 2, 1, 1)
            "Rock" -> intArrayOf(3, 2, 1, 0, -1, 1, 2, 3, 3, 3)
            "Jazz" -> intArrayOf(2, 1, 0, 1, -1, -1, 0, 1, 2, 2)
            "Bass Boost" -> intArrayOf(5, 4, 3, 2, 1, 0, 0, 0, 0, 0)
            "Vocal" -> intArrayOf(-2, -1, 0, 1, 3, 4, 3, 2, 0, -1)
            "Dangdut" -> intArrayOf(4, 3, 2, 1, 0, 1, 2, 2, 1, 1)
            "DJ Horeg" -> intArrayOf(5, 4, 3, 1, -1, 0, 2, 3, 4, 3)
            else -> IntArray(10)
        }
        for (i in values.indices) values[i] = preset[i].coerceIn(-24, 12)
        updateSliders()
        applyEqualizer()
        saveSettings()
    }

    private fun updateSliders() {
        sliders.forEachIndexed { i, slider -> slider.progress = (values[i] + 24).coerceIn(0, 36) }
    }

    private fun startVisualizer() {
        try {
            visualizer = Visualizer(0).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {
                        data?.let { bytes ->
                            val bars = FloatArray(36)
                            for (i in bars.indices) {
                                val index = 2 + i * 2
                                if (index < bytes.size) bars[i] = (abs(bytes[index].toInt()).toFloat() / 128f).coerceIn(0f, 1f)
                            }
                            runOnUiThread { spectrumView?.setBars(bars) }
                        }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (_: Exception) {
            status?.text = "Status: visualizer tidak tersedia pada perangkat / sesi audio ini"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVisualizer()
    }

    private fun saveCustomPreset() {
        val input = EditText(this).apply { hint = "Nama preset" }
        AlertDialog.Builder(this).setTitle("Simpan preset equalizer").setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Preset Saya" }
                prefs.edit().putString("custom_$name", JSONArray(values.toList()).toString()).apply()
                presetNames = (listOf("Custom", "Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg") + prefs.all.keys.filter { it.startsWith("custom_") }.map { it.removePrefix("custom_") }).distinct()
                presetSpinner?.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presetNames)
                val selected = presetNames.indexOf(name)
                if (selected >= 0) presetSpinner?.setSelection(selected)
                Toast.makeText(this, "Preset $name disimpan", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun applySavedPreset(name: String) {
        try {
            val json = JSONArray(prefs.getString("custom_$name", "[]"))
            if (json.length() == 10) {
                for (i in values.indices) values[i] = json.getInt(i).coerceIn(-24, 12)
                updateSliders(); applyEqualizer(); saveSettings()
            }
        } catch (_: Exception) { Toast.makeText(this, "Preset tidak dapat dibaca", Toast.LENGTH_SHORT).show() }
    }

    private fun loadSettings() {
        for (i in values.indices) values[i] = prefs.getInt("band_$i", 0).coerceIn(-24, 12)
        effectsEnabled = prefs.getBoolean("eq_enabled", true)
        eqMode = prefs.getString("eq_mode", "1WAY") ?: "1WAY"
    }

    private fun saveSettings() {
        val editor = prefs.edit()
        values.forEachIndexed { i, v -> editor.putInt("band_$i", v) }
        editor.putString("eq_mode", eqMode)
            .putBoolean("eq_enabled", effectsEnabled)
            .apply()
    }

    override fun onDestroy() {
        try { visualizer?.release(); eq?.release() } catch (_: Exception) { }
        super.onDestroy()
    }
}

private class SpectrumView(context: Context) : View(context) {
    private var bars = FloatArray(36)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF36C8FF.toInt(); style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x5536C8FF; style = Paint.Style.FILL }
    fun setBars(newBars: FloatArray) { bars = newBars; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gap = width * 0.012f
        val barWidth = (width - gap * (bars.size - 1)) / bars.size
        val base = height * 0.88f
        bars.forEachIndexed { i, level ->
            val h = (height * 0.78f * level.coerceIn(0.04f, 1f)).coerceAtLeast(4f)
            val left = i * (barWidth + gap)
            val rect = RectF(left, base - h, left + barWidth, base)
            canvas.drawRoundRect(RectF(left - 1, base - h - 2, left + barWidth + 1, base + 1), 5f, 5f, glowPaint)
            canvas.drawRoundRect(rect, 5f, 5f, barPaint)
        }
    }
}

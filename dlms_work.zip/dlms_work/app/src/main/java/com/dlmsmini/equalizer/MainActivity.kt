package com.dlmsmini.equalizer

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val frequencies = arrayOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    private val builtIns = listOf("Custom", "Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
    private val faders = mutableListOf<VerticalFader>()
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    private var eq: Equalizer? = null
    private var visualizer: Visualizer? = null
    private var spectrumView: SpectrumView? = null
    private var spectrumTitle: TextView? = null
    private var spectrumCard: View? = null
    private var status: TextView? = null
    private var modeInfo: TextView? = null
    private var limiterNote: TextView? = null
    private var presetGrid: LinearLayout? = null

    private class Param(
        val title: String, val unit: String,
        val min: Float, val max: Float, val step: Float, val decimals: Int
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.init(this)
        buildUi()
        initEqualizer()
        EffectEngine.retain(applicationContext)
        if (AppSettings.backgroundService) EffectService.start(this)
        if (!hasRecordPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        }
    }

    override fun onStart() {
        super.onStart()
        EffectEngine.onChange = { refreshStatus() }
        refreshStatus()
        val show = AppSettings.showSpectrum
        spectrumTitle?.visibility = if (show) View.VISIBLE else View.GONE
        spectrumCard?.visibility = if (show) View.VISIBLE else View.GONE
        if (show && hasRecordPermission()) startVisualizer()
    }

    override fun onStop() {
        EffectEngine.onChange = null
        stopVisualizer()
        super.onStop()
    }

    override fun onDestroy() {
        try { eq?.release() } catch (_: Throwable) {}
        eq = null
        EffectEngine.release()
        super.onDestroy()
    }

    private fun hasRecordPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun refreshStatus() {
        status?.text = if (eq != null) "Equalizer aktif • mengikuti dukungan audio perangkat" else "Equalizer tidak tersedia pada perangkat"
        limiterNote?.text = EffectEngine.limiterNote()
    }

    // Equalizer dikembalikan ke pengelolaan langsung seperti versi yang terbukti berfungsi.
    private fun initEqualizer() {
        try {
            eq = Equalizer(0, 0).also { effect ->
                effect.enabled = AppSettings.eqEnabled
            }
            if (eq != null) applyEqualizer()
        } catch (_: Throwable) {
            eq = null
        }
        refreshStatus()
    }

    private fun applyEqualizer() {
        val effect = eq ?: return
        try {
            effect.enabled = AppSettings.eqEnabled
            if (!AppSettings.eqEnabled) {
                refreshStatus()
                return
            }
            val count = effect.numberOfBands.toInt()
            if (count <= 0) return
            val range = effect.bandLevelRange
            val buckets = Array(count) { mutableListOf<Int>() }
            for (i in centerHz.indices) {
                val band = nearestBand(effect, centerHz[i])
                buckets[band].add(AppSettings.bands[i])
            }
            for (band in 0 until count) {
                val halfDb = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                val milliBel = (halfDb * 50).coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band.toShort(), milliBel.toShort())
            }
        } catch (_: Throwable) {
            // Beberapa vendor menolak operasi tertentu; UI tetap dapat digunakan.
        }
        refreshStatus()
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Int {
        var best = 0
        var bestDiff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands.toInt()) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val diff = kotlin.math.abs(center - hz.toLong())
            if (diff < bestDiff) {
                bestDiff = diff
                best = i
            }
        }
        return best
    }

    // =====================================================================================
    // UI
    // =====================================================================================

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(c(0xFF080B12))
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(20))
        }

        buildHeader(content)

        status = label("Menyiapkan audio…", 10f, c(0xFF80DDB5))
        status?.setPadding(dp(3), dp(10), dp(3), 0)
        content.addView(status)

        // Spektrum
        spectrumTitle = sectionTitle(content, "SPECTRUM")
        val specCard = makeCard().apply { setPadding(dp(10), dp(10), dp(10), dp(10)) }
        val specHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        specHeader.addView(label("●  AUDIO ANALYZER", 11f, c(0xFF48C5FF), true), LinearLayout.LayoutParams(0, -2, 1f))
        specHeader.addView(label("LIVE", 9f, c(0xFF7BE3B0), true))
        specCard.addView(specHeader)
        spectrumView = SpectrumView(this)
        specCard.addView(spectrumView, LinearLayout.LayoutParams(-1, dp(92)))
        spectrumCard = specCard
        content.addView(specCard)

        buildEqCard(content)
        buildLimiterCard(content)
        buildPresetCard(content)

        content.addView(label("Dibuat oleh Ilham Galeh", 11f, c(0xFF8294B2), true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(5))
        }, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun buildHeader(content: LinearLayout) {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(8), dp(12))
            background = rounded(c(0xFF111827), 20, c(0xFF263B5D))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("DLMS", 23f, c(0xFFF3F6FF), true))
        brand.addView(label("MINI EQUALIZER", 10f, c(0xFF35B8FF), true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))

        val modeGroup = RadioGroup(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(c(0xFF080F1D), 18, c(0xFF31486B))
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val tint = ColorStateList.valueOf(c(0xFF28AFFF))
        val one = RadioButton(this).apply {
            text = "1-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = tint
            setPadding(dp(5), 0, dp(5), 0)
        }
        val two = RadioButton(this).apply {
            text = "2-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = tint
            setPadding(dp(5), 0, dp(5), 0)
        }
        modeGroup.addView(one); modeGroup.addView(two)
        modeGroup.check(if (AppSettings.eqMode == "2WAY") two.id else one.id)
        modeGroup.setOnCheckedChangeListener { _, id ->
            AppSettings.eqMode = if (id == two.id) "2WAY" else "1WAY"
            updateModeLabels()
        }
        header.addView(modeGroup)

        val menu = TextView(this).apply {
            text = "⋮"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(c(0xFFEAF4FF))
            setPadding(dp(12), dp(2), dp(12), dp(2))
            isClickable = true
        }
        menu.setOnClickListener { showMenu(menu) }
        header.addView(menu)
        content.addView(header)
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "Pengaturan")
        popup.menu.add(0, 2, 1, "Tentang aplikasi")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> startActivityForResult(Intent(this, SettingsActivity::class.java), 5)
                2 -> startActivity(Intent(this, AboutActivity::class.java))
            }
            true
        }
        popup.show()
    }

    @Deprecated("Deprecated by Android; retained for compatibility with the current project structure")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // Pengaturan di-reset: muat ulang tampilan agar fader/limiter ikut kembali ke bawaan.
        if (requestCode == 5 && resultCode == RESULT_OK) recreate()
    }

    // ---------------- Equalizer ----------------

    private fun buildEqCard(content: LinearLayout) {
        sectionTitle(content, "10-BAND EQUALIZER")
        val eqCard = makeCard().apply { setPadding(dp(7), dp(10), dp(7), dp(10)) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val enabled = Switch(this).apply {
            text = "EQ aktif"; textSize = 11f; setTextColor(c(0xFFEAF0FF))
            isChecked = AppSettings.eqEnabled
            buttonTintList = ColorStateList.valueOf(c(0xFF27B5FF))
        }
        enabled.setOnCheckedChangeListener { _, checked ->
            AppSettings.eqEnabled = checked
            applyEqualizer()
        }
        controls.addView(enabled, LinearLayout.LayoutParams(0, -2, 1f))
        modeInfo = label("", 9f, c(0xFF9DAFC9))
        controls.addView(modeInfo)
        eqCard.addView(controls)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        frequencies.forEachIndexed { index, freq ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(1), 0, dp(1), 0)
            }
            column.addView(label(freq, 10f, c(0xFFDDE7F8), true).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-1, dp(25)))

            val plus = stepButton("+")
            column.addView(plus, LinearLayout.LayoutParams(-1, dp(30)).apply { setMargins(dp(1), dp(3), dp(1), dp(5)) })

            val valueText = label(formatDb(AppSettings.bands[index]), 9f, c(0xFF45C5FF), true).apply { gravity = Gravity.CENTER }
            val fader = VerticalFader(this).apply {
                setValue(AppSettings.bands[index])
                onValueChanged = { newValue, fromUser ->
                    AppSettings.bands[index] = newValue
                    valueText.text = formatDb(newValue)
                    if (fromUser) { AppSettings.saveBands(); applyEqualizer() }
                }
            }
            faders.add(fader)
            column.addView(fader, LinearLayout.LayoutParams(-1, dp(174)))

            val minus = stepButton("−")
            column.addView(minus, LinearLayout.LayoutParams(-1, dp(30)).apply { setMargins(dp(1), dp(5), dp(1), dp(4)) })
            column.addView(valueText, LinearLayout.LayoutParams(-1, dp(22)))
            plus.setOnClickListener { fader.setValue((fader.value + 1).coerceAtMost(24), true) }
            minus.setOnClickListener { fader.setValue((fader.value - 1).coerceAtLeast(-24), true) }
            row.addView(column, LinearLayout.LayoutParams(0, -2, 1f))
        }
        eqCard.addView(row)
        eqCard.addView(label("−12 dB     0 dB     +12 dB   •   Langkah 0,5 dB", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0)
        })
        content.addView(eqCard)
        updateModeLabels()
    }

    private fun stepButton(symbol: String): TextView = TextView(this).apply {
        text = symbol; textSize = 19f; gravity = Gravity.CENTER
        setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
        isClickable = true
    }

    private fun updateModeLabels() {
        modeInfo?.text = if (AppSettings.eqMode == "2WAY")
            "2-Way aktif • LOW: 31–500 Hz  |  HIGH: 1–16 kHz"
        else
            "1-Way aktif • Semua frekuensi dalam satu kurva 31 Hz–16 kHz"
    }

    private fun formatDb(value: Int): String = String.format(java.util.Locale.US, "%.1f dB", value / 2f)

    private fun updateFaders() {
        faders.forEachIndexed { i, fader -> fader.setValue(AppSettings.bands[i], false) }
    }

    // ---------------- Limiter ----------------

    private fun buildLimiterCard(content: LinearLayout) {
        sectionTitle(content, "LIMITER")
        val card = makeCard()

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val supported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
        val enable = CheckBox(this).apply {
            text = "Limiter enabled"; textSize = 16f; setTextColor(c(0xFFFFFFFF))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            buttonTintList = ColorStateList.valueOf(c(0xFF00D0F0))
            isChecked = AppSettings.limEnabled && supported
            isEnabled = supported
        }
        enable.setOnCheckedChangeListener { _, checked ->
            AppSettings.limEnabled = checked
            EffectEngine.applyLimiter()
        }
        head.addView(enable, LinearLayout.LayoutParams(0, -2, 1f))
        val info = TextView(this).apply {
            text = "i"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(c(0xFF9DAFC9)); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(2), c(0xFF8A94A6)) }
            isClickable = true
        }
        info.setOnClickListener { showLimiterInfo() }
        head.addView(info, LinearLayout.LayoutParams(dp(30), dp(30)))
        card.addView(head)

        limiterNote = label("", 10f, c(0xFF80DDB5))
        card.addView(limiterNote)

        addSlider(card, Param("Attack time", " ms", 0f, 200f, 0.5f, 1), { AppSettings.limAttack }, { AppSettings.limAttack = it })
        addSlider(card, Param("Release time", " ms", 0f, 2000f, 10f, 0), { AppSettings.limRelease }, { AppSettings.limRelease = it })
        addSlider(card, Param("Ratio", ":1", 1f, 20f, 0.5f, 1), { AppSettings.limRatio }, { AppSettings.limRatio = it })
        addSlider(card, Param("Threshold", " dB", -60f, 0f, 0.5f, 1), { AppSettings.limThreshold }, { AppSettings.limThreshold = it })
        addSlider(card, Param("Post-gain", " dB", -12f, 12f, 0.5f, 1), { AppSettings.limPostGain }, { AppSettings.limPostGain = it })
        content.addView(card)
    }

    private fun addSlider(parent: LinearLayout, p: Param, get: () -> Float, set: (Float) -> Unit) {
        fun show(v: Float): String = String.format(java.util.Locale.US, "%.${p.decimals}f%s", v, p.unit)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(p.title, 13f, c(0xFFEAF0FF), true), LinearLayout.LayoutParams(0, -2, 1f))
        val valueText = label(show(get()), 12f, c(0xFF45C5FF), true)
        row.addView(valueText)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(12), 0, 0) })

        val steps = Math.round((p.max - p.min) / p.step)
        val bar = SeekBar(this)
        bar.max = steps
        bar.progress = Math.round((get() - p.min) / p.step).coerceIn(0, steps)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = p.min + progress * p.step
                valueText.text = show(v)
                if (fromUser) {
                    set(v)
                    EffectEngine.applyLimiter()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        parent.addView(bar, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showLimiterInfo() {
        val text = "• Limiter enabled: mengaktifkan atau menonaktifkan pembatas audio.\n\n" +
            "• Attack time (waktu mulai): waktu yang dibutuhkan limiter untuk mulai bekerja setelah volume melewati batas (threshold).\n\n" +
            "• Release time (waktu lepas): waktu yang dibutuhkan limiter untuk berhenti bekerja dan mengembalikan volume ke normal setelah suara kembali di bawah batas.\n\n" +
            "• Ratio (rasio): seberapa kuat penekanan volume setelah sinyal melewati ambang.\n\n" +
            "• Threshold (ambang batas): level volume (dB) tempat limiter mulai memotong puncak suara agar tidak pecah.\n\n" +
            "• Post-gain (penguatan setelahnya): penyesuaian volume akhir (dB) setelah proses pembatas, untuk menjaga loudness."
        AlertDialog.Builder(this).setTitle("Limiter").setMessage(text).setPositiveButton("TUTUP", null).show()
    }

    // ---------------- Preset ----------------

    private fun buildPresetCard(content: LinearLayout) {
        sectionTitle(content, "PRESET MUSIK")
        val card = makeCard().apply { setPadding(dp(10), dp(10), dp(10), dp(10)) }
        presetGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        populatePresetGrid()
        card.addView(presetGrid)
        card.addView(label("Tekan lama preset buatan sendiri untuk menghapus.", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4))
        })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun action(textLabel: String, onClick: () -> Unit) {
            val b = Button(this).apply { text = textLabel; textSize = 10f; setOnClickListener { onClick() } }
            actions.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        action("Simpan") { saveCustomPreset() }
        action("Import") { showImportDialog() }
        action("Export") { showExportDialog() }
        action("Flat") { applyPreset("Flat") }
        card.addView(actions)
        content.addView(card)
    }

    private fun populatePresetGrid() {
        val grid = presetGrid ?: return
        grid.removeAllViews()
        val custom = AppSettings.customPresets().keys.toList()
        val available = (builtIns.filter { it != "Custom" } + custom).distinct()
        available.chunked(3).forEach { names ->
            val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            names.forEach { name ->
                val button = TextView(this).apply {
                    text = name; textSize = 11f; gravity = Gravity.CENTER
                    setTextColor(c(0xFFE5EDFF)); background = rounded(c(0xFF1B2638), 12, c(0xFF304968))
                    setPadding(dp(3), dp(11), dp(3), dp(11))
                    isClickable = true
                    setOnClickListener { if (name in builtIns) applyPreset(name) else applySavedPreset(name) }
                    if (name !in builtIns) setOnLongClickListener { confirmDelete(name); true }
                }
                presetRow.addView(button, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            grid.addView(presetRow)
        }
    }

    private fun confirmDelete(name: String) {
        AlertDialog.Builder(this).setTitle("Hapus preset")
            .setMessage("Hapus preset \"$name\"?")
            .setPositiveButton("Hapus") { _, _ -> AppSettings.deletePreset(name); populatePresetGrid() }
            .setNegativeButton("Batal", null).show()
    }

    private fun applyPreset(name: String) {
        val preset = when (name) {
            "Flat" -> intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
            "Pop" -> intArrayOf(4, 2, 0, -2, -2, 2, 4, 4, 2, 2)
            "Rock" -> intArrayOf(6, 4, 2, 0, -2, 2, 4, 6, 6, 6)
            "Jazz" -> intArrayOf(4, 2, 0, 2, -2, -2, 0, 2, 4, 4)
            "Bass Boost" -> intArrayOf(10, 8, 6, 4, 2, 0, 0, 0, 0, 0)
            "Vocal" -> intArrayOf(-4, -2, 0, 2, 6, 8, 6, 4, 0, -2)
            "Dangdut" -> intArrayOf(8, 6, 4, 2, 0, 2, 4, 4, 2, 2)
            "DJ Horeg" -> intArrayOf(10, 8, 6, 2, -2, 0, 4, 6, 8, 6)
            else -> IntArray(10)
        }
        setBands(preset)
    }

    private fun applySavedPreset(name: String) {
        val bands = AppSettings.customPresets()[name]
        if (bands == null) toast("Preset tidak dapat dibaca") else setBands(bands)
    }

    private fun setBands(values: IntArray) {
        for (i in 0 until 10) AppSettings.bands[i] = values[i].coerceIn(-24, 24)
        updateFaders()
        AppSettings.saveBands()
        applyEqualizer()
    }

    private fun uniqueName(raw: String): String {
        var name = raw
        if (name in builtIns) name = "$name 2"
        return name
    }

    private fun saveCustomPreset() {
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        val input = EditText(this).apply { hint = "Nama preset"; setSingleLine(true) }
        box.addView(input, LinearLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(this).setTitle("Simpan preset").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val name = uniqueName(input.text.toString().trim().ifBlank { "Preset Saya" })
                AppSettings.savePreset(name, AppSettings.bands.copyOf())
                populatePresetGrid()
                toast("Preset $name disimpan")
            }.setNegativeButton("Batal", null).show()
    }

    // ---------------- Import / Export lewat salin & tempel ----------------

    private fun readClipboard(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        return if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() else null
    }

    private fun showImportDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(TextView(this).apply {
            text = "Tempel data preset sebagai teks, lalu verifikasi dan impor ke aplikasi. " +
                "Pastikan teks tetap sama persis dengan format hasil ekspor."
            textSize = 13f
        })
        val input = EditText(this).apply {
            hint = "[Data Preset]"
            minLines = 8
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE
            textSize = 12f
        }
        box.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val dialog = AlertDialog.Builder(this).setTitle("Import preset").setView(box)
            .setPositiveButton("IMPORT", null)
            .setNeutralButton("TEMPEL", null)
            .setNegativeButton("TUTUP", null)
            .create()
        dialog.setOnShowListener {
            val importBtn = dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE)
            val pasteBtn = dialog.getButton(android.content.DialogInterface.BUTTON_NEUTRAL)
            importBtn.isEnabled = false
            input.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) { importBtn.isEnabled = !s.isNullOrBlank() }
            })
            pasteBtn.setOnClickListener {
                val text = readClipboard()
                if (text.isNullOrBlank()) toast("Clipboard kosong") else input.setText(text)
            }
            importBtn.setOnClickListener {
                try {
                    val list = PresetCodec.parse(input.text.toString())
                    for (p in list) AppSettings.savePreset(uniqueName(p.name), p.halfDb)
                    populatePresetGrid()
                    toast("${list.size} preset berhasil diimpor")
                    dialog.dismiss()
                } catch (e: Exception) {
                    toast("Import gagal: ${e.message ?: "format tidak valid"}")
                }
            }
        }
        dialog.show()
    }

    private fun showExportDialog() {
        val list = ArrayList<PresetCodec.Preset>()
        list.add(PresetCodec.Preset("Kurva Saat Ini", AppSettings.bands.copyOf()))
        for ((name, bands) in AppSettings.customPresets()) list.add(PresetCodec.Preset(name, bands))
        val text = PresetCodec.export(list)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        box.addView(TextView(this).apply {
            this.text = "Salin teks di bawah (kurva saat ini + semua preset buatan sendiri), lalu tempel di perangkat lain lewat Import."
            textSize = 13f
        })
        val output = EditText(this).apply {
            setText(text)
            minLines = 8
            gravity = Gravity.TOP or Gravity.START
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            keyListener = null
        }
        box.addView(output, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val dialog = AlertDialog.Builder(this).setTitle("Export preset").setView(box)
            .setNeutralButton("SALIN", null)
            .setNegativeButton("TUTUP", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.content.DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Preset DLMS", text))
                toast("Preset disalin ke clipboard")
            }
        }
        dialog.show()
    }

    // ---------------- Spektrum ----------------

    private fun startVisualizer() {
        if (visualizer != null) return
        try {
            val v = Visualizer(0)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, data: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, data: ByteArray?, samplingRate: Int) {
                    data?.let { bytes ->
                        val bars = FloatArray(36)
                        for (i in bars.indices) {
                            val index = 2 + i * 2
                            if (index < bytes.size) bars[i] = (abs(bytes[index].toInt()).toFloat() / 128f).coerceIn(0f, 1f)
                        }
                        runOnUiThread { spectrumView?.setBars(bars) }
                    }
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.setEnabled(true)
            visualizer = v
        } catch (_: Exception) {
            visualizer = null
        }
    }

    private fun stopVisualizer() {
        try { visualizer?.setEnabled(false) } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && AppSettings.showSpectrum) {
            startVisualizer()
        }
    }
}

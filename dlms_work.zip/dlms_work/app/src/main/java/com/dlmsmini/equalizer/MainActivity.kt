package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val frequencies = arrayOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    private val bands = IntArray(10)
    private lateinit var prefs: android.content.SharedPreferences
    private var eq: Equalizer? = null
    private var limiter: DynamicsProcessing? = null
    private var eqEnabled = true
    private var limiterEnabled = false
    private var attackMs = 5
    private var releaseMs = 80
    private var ratio = 10
    private var thresholdDb = -2
    private var postGainDb = 0
    private var eqMode = "1WAY"
    private var statusView: TextView? = null
    private var presetList: LinearLayout? = null
    private val builtIns = listOf("Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
    private val presets = linkedMapOf<String, IntArray>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("dlms_equalizer_settings", Context.MODE_PRIVATE)
        loadSettings()
        createAudioEffects()
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun bg(color: Int, radius: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun text(s: String, size: Float = 14f, color: Int = 0xFFEDEDED.toInt(), bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = bg(0xFF222326.toInt(), 18, 0xFF34363A.toInt())
    }
    private fun addSection(parent: LinearLayout, title: String) {
        parent.addView(text(title, 15f, 0xFF00D8E8.toInt(), true).apply {
            setPadding(dp(3), dp(18), dp(3), dp(9))
        })
    }
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101113.toInt())
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(12), dp(12))
        }
        top.addView(text("DLMS EQUALIZER", 21f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val settings = Button(this).apply { text = "Pengaturan"; setOnClickListener { showSettings() } }
        top.addView(settings)
        val about = Button(this).apply { text = "About"; setOnClickListener { showAbout() } }
        top.addView(about)
        root.addView(top)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(20))
        }
        addSection(content, "STATUS AUDIO")
        val statusCard = card()
        statusView = text("Equalizer sedang disiapkan…", 13f, 0xFFB9BEC8.toInt())
        statusCard.addView(statusView)
        content.addView(statusCard)

        addSection(content, "10-BAND EQUALIZER")
        val eqCard = card()
        val enable = Switch(this).apply {
            text = "Equalizer enabled"; textSize = 15f; isChecked = eqEnabled
            setOnCheckedChangeListener { _, checked ->
                eqEnabled = checked
                try { eq?.enabled = checked } catch (_: Exception) {}
                saveSettings()
            }
        }
        eqCard.addView(enable)
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        modeRow.addView(text("Mode EQ", 13f), LinearLayout.LayoutParams(0, -2, 1f))
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1-Way", "2-Way"))
            setSelection(if (eqMode == "2WAY") 1 else 0)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    eqMode = if (position == 1) "2WAY" else "1WAY"; saveSettings()
                }
            }
        }
        modeRow.addView(mode, LinearLayout.LayoutParams(dp(120), -2))
        eqCard.addView(modeRow)
        for (i in bands.indices) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            line.addView(text("${frequencies[i]} Hz", 12f, 0xFFE0E0E0.toInt()), LinearLayout.LayoutParams(dp(58), -2))
            val valueLabel = text(String.format(java.util.Locale.US, "%.1f", bands[i] / 2f), 11f, 0xFF00D8E8.toInt(), true)
            valueLabel.gravity = Gravity.END
            val seek = SeekBar(this).apply {
                max = 48; progress = bands[i] + 24
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        bands[i] = progress - 24
                        valueLabel.text = String.format(java.util.Locale.US, "%.1f dB", bands[i] / 2f)
                        applyEqualizer(); saveSettings()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            line.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(valueLabel, LinearLayout.LayoutParams(dp(48), -2))
            eqCard.addView(line)
        }
        eqCard.addView(text("Rentang −12 dB hingga +12 dB • langkah 0,5 dB", 11f, 0xFF9299A5.toInt()))
        content.addView(eqCard)

        addSection(content, "LIMITER")
        val limiterCard = card()
        val limiterSwitch = Switch(this).apply {
            text = "Limiter enabled"; isChecked = limiterEnabled
            setOnCheckedChangeListener { _, checked -> limiterEnabled = checked; applyLimiter(); saveSettings() }
        }
        limiterCard.addView(limiterSwitch)
        addLimiterControl(limiterCard, "Attack time", "ms", 1, 100, attackMs) { attackMs = it }
        addLimiterControl(limiterCard, "Release time", "ms", 5, 1000, releaseMs) { releaseMs = it }
        addLimiterControl(limiterCard, "Ratio", ":1", 1, 20, ratio) { ratio = it }
        addLimiterControl(limiterCard, "Threshold", "dBFS", -30, 0, thresholdDb) { thresholdDb = it }
        addLimiterControl(limiterCard, "Post-gain", "dB", -12, 12, postGainDb) { postGainDb = it }
        limiterCard.addView(text("Limiter memakai DynamicsProcessing Android 9 (API 28) atau lebih baru. Pada perangkat yang tidak mendukung efek ini, kontrol akan tersimpan tetapi tidak diproses.", 11f, 0xFF9EA4AE.toInt()))
        content.addView(limiterCard)

        addSection(content, "PRESET")
        val presetCard = card()
        presetList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        presetCard.addView(presetList)
        val presetActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presetActions.addView(Button(this).apply {
            text = "Simpan preset"; setOnClickListener { savePresetDialog() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        presetActions.addView(Button(this).apply {
            text = "Import / Paste"; setOnClickListener { showImportDialog() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        presetActions.addView(Button(this).apply {
            text = "Export / Copy"; setOnClickListener { showExportDialog() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        presetCard.addView(presetActions)
        content.addView(presetCard)
        rebuildPresets()

        addSection(content, "YOUTUBE PLAYER")
        val youtubeCard = card()
        youtubeCard.addView(text("Masukkan link YouTube atau ID video. Video diputar melalui pemutar embed resmi YouTube.", 12f, 0xFFB7BCC5.toInt()))
        val urlInput = EditText(this).apply {
            hint = "https://www.youtube.com/watch?v=VIDEO_ID"
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(0xFF858B95.toInt())
            background = bg(0xFF151618.toInt(), 10, 0xFF55585E.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        youtubeCard.addView(urlInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        youtubeCard.addView(Button(this).apply {
            text = "Putar YouTube"
            setOnClickListener {
                val id = extractYoutubeId(urlInput.text.toString())
                if (id == null) Toast.makeText(this@MainActivity, "Link atau ID video tidak valid", Toast.LENGTH_LONG).show()
                else showYoutubePlayer(id)
            }
        })
        content.addView(youtubeCard)

        content.addView(text("DLMS Equalizer • dibuat oleh Ilham Galeh", 11f, 0xFF7F8792.toInt()).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(10))
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        statusView?.text = if (eq != null) "Equalizer siap • sesi audio global (jika didukung perangkat)" else "Equalizer tidak tersedia pada perangkat ini"
    }

    private fun addLimiterControl(parent: LinearLayout, title: String, unit: String, min: Int, max: Int, initial: Int, update: (Int) -> Unit) {
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = text(title, 13f)
        heading.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val value = text("$initial $unit", 12f, 0xFF00D8E8.toInt(), true)
        heading.addView(value)
        parent.addView(heading)
        val seek = SeekBar(this).apply {
            this.max = max - min; progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min; value.text = "$v $unit"; update(v); applyLimiter(); saveSettings()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        parent.addView(seek)
    }

    private fun createAudioEffects() {
        try { eq?.release() } catch (_: Exception) {}
        try { limiter?.release() } catch (_: Exception) {}
        eq = null
        limiter = null
        try {
            eq = Equalizer(0, 0).also { it.enabled = eqEnabled }
            applyEqualizer()
        } catch (_: Exception) { eq = null }
        applyLimiter()
    }
    private fun nearestBand(effect: Equalizer, hz: Int): Short {
        var best = 0; var diff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands) {
            val d = abs(effect.getCenterFreq(i.toShort()).toLong() / 1000L - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best.toShort()
    }
    private fun applyEqualizer() {
        val e = eq ?: return
        try {
            e.enabled = eqEnabled
            if (!eqEnabled) return
            val range = e.bandLevelRange
            val grouped = Array(e.numberOfBands.toInt()) { mutableListOf<Int>() }
            bands.forEachIndexed { i, v -> grouped[nearestBand(e, centerHz[i]).toInt()].add(v) }
            for (i in 0 until e.numberOfBands) {
                val halfDb = grouped[i].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                e.setBandLevel(i.toShort(), (halfDb * 50).coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
        } catch (_: Exception) {}
    }
    private fun applyLimiter() {
        if (Build.VERSION.SDK_INT < 28) {
            statusView?.text = if (limiterEnabled) "Limiter membutuhkan Android 9/API 28+" else "Audio effects siap"
            return
        }
        try {
            val config = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION, 2,
                false, 0, false, 0, false, 0, true
            ).setLimiterAllChannelsTo(
                DynamicsProcessing.Limiter(
                    true, limiterEnabled, 0,
                    attackMs.toFloat(), releaseMs.toFloat(), ratio.toFloat(),
                    thresholdDb.toFloat(), postGainDb.toFloat()
                )
            ).build()
            if (limiter == null) {
                limiter = DynamicsProcessing(0, 0, config).also { it.enabled = true }
            } else {
                limiter?.setLimiterAllChannelsTo(
                    DynamicsProcessing.Limiter(
                        true, limiterEnabled, 0,
                        attackMs.toFloat(), releaseMs.toFloat(), ratio.toFloat(),
                        thresholdDb.toFloat(), postGainDb.toFloat()
                    )
                )
                limiter?.enabled = true
            }
            statusView?.text = if (limiterEnabled) "Limiter aktif • threshold ${thresholdDb} dBFS" else "Limiter nonaktif"
        } catch (e: Exception) {
            statusView?.text = "Limiter tidak didukung perangkat: ${e.javaClass.simpleName}"
        }
    }

    private fun loadSettings() {
        for (i in bands.indices) bands[i] = prefs.getInt("band_$i", 0).coerceIn(-24, 24)
        eqEnabled = prefs.getBoolean("eq_enabled", true)
        limiterEnabled = prefs.getBoolean("limiter_enabled", false)
        attackMs = prefs.getInt("lim_attack", 5).coerceIn(1, 100)
        releaseMs = prefs.getInt("lim_release", 80).coerceIn(5, 1000)
        ratio = prefs.getInt("lim_ratio", 10).coerceIn(1, 20)
        thresholdDb = prefs.getInt("lim_threshold", -2).coerceIn(-30, 0)
        postGainDb = prefs.getInt("lim_postgain", 0).coerceIn(-12, 12)
        eqMode = prefs.getString("eq_mode", "1WAY") ?: "1WAY"
        presets.clear()
        prefs.all.forEach { (key, value) ->
            if (key.startsWith("custom_") && value is String) {
                try {
                    val arr = JSONArray(value)
                    if (arr.length() == 10) {
                        presets[key.removePrefix("custom_")] = IntArray(10) { i -> arr.getInt(i).coerceIn(-24, 24) }
                    }
                } catch (_: Exception) {}
            }
        }
    }
    private fun saveSettings() {
        val ed = prefs.edit().putBoolean("eq_enabled", eqEnabled).putBoolean("limiter_enabled", limiterEnabled)
            .putInt("lim_attack", attackMs).putInt("lim_release", releaseMs).putInt("lim_ratio", ratio)
            .putInt("lim_threshold", thresholdDb).putInt("lim_postgain", postGainDb).putString("eq_mode", eqMode)
        bands.forEachIndexed { i, v -> ed.putInt("band_$i", v) }
        ed.apply()
    }

    private fun rebuildPresets() {
        val target = presetList ?: return
        target.removeAllViews()
        val all = linkedMapOf<String, IntArray>()
        all["Flat"] = IntArray(10)
        all["Pop"] = intArrayOf(4, 3, 1, 0, -1, 1, 3, 4, 4, 3)
        all["Rock"] = intArrayOf(5, 4, 2, 0, -2, 2, 4, 5, 5, 4)
        all["Jazz"] = intArrayOf(3, 2, 1, 2, -1, 1, 2, 3, 4, 4)
        all["Bass Boost"] = intArrayOf(10, 8, 5, 2, 0, 0, 0, 1, 2, 2)
        all["Vocal"] = intArrayOf(-3, -2, 0, 3, 5, 5, 3, 1, 0, -1)
        all["Dangdut"] = intArrayOf(5, 4, 2, 1, 0, 2, 3, 4, 4, 3)
        all["DJ Horeg"] = intArrayOf(8, 6, 2, -2, -3, 0, 3, 5, 6, 5)
        for ((name, values) in all) addPresetButton(target, name, values, false)
        for ((name, values) in presets) addPresetButton(target, name, values, true)
    }
    private fun addPresetButton(parent: LinearLayout, name: String, values: IntArray, custom: Boolean) {
        parent.addView(Button(this).apply {
            text = if (custom) "$name  ×" else name
            setOnClickListener {
                if (custom) AlertDialog.Builder(this@MainActivity).setTitle(name)
                    .setItems(arrayOf("Terapkan preset", "Hapus preset")) { _, which ->
                        if (which == 0) applyPreset(values) else {
                            presets.remove(name); prefs.edit().remove("custom_$name").apply(); rebuildPresets()
                        }
                    }.show()
                else applyPreset(values)
            }
        })
    }
    private fun applyPreset(values: IntArray) {
        for (i in bands.indices) bands[i] = values[i].coerceIn(-24, 24)
        saveSettings(); createAudioEffects(); buildUi()
    }
    private fun savePresetDialog() {
        val input = EditText(this).apply { hint = "Nama preset" }
        AlertDialog.Builder(this).setTitle("Simpan preset").setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Preset ${presets.size + 1}" }
                presets[name] = bands.copyOf()
                prefs.edit().putString("custom_$name", JSONArray(bands.toList()).toString()).apply()
                rebuildPresets()
            }.setNegativeButton("Batal", null).show()
    }

    private fun exportJson(): String {
        val array = JSONArray()
        val current = JSONObject().put("name", "Current").put("bands_db", JSONArray().also { a ->
            bands.forEach { a.put(it / 2.0) }
        })
        array.put(current)
        for ((name, vals) in presets) {
            array.put(JSONObject().put("name", name).put("bands_db", JSONArray().also { a -> vals.forEach { a.put(it / 2.0) } }))
        }
        return JSONObject().put("format", "dlms-mini-presets").put("version", 1).put("presets", array).toString(2)
    }
    private fun showExportDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        box.addView(text("Salin JSON ini untuk menyimpan atau memindahkan preset.", 13f, 0xFFBFC3CC.toInt()))
        val editor = EditText(this).apply {
            setText(exportJson()); setTextColor(Color.WHITE); textSize = 12f
            gravity = Gravity.TOP; minLines = 12; isVerticalScrollBarEnabled = true
            background = bg(0xFF111214.toInt(), 8, 0xFF55585E.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        box.addView(editor, LinearLayout.LayoutParams(-1, dp(300)))
        val dialog = AlertDialog.Builder(this).setTitle("Export presets").setView(box)
            .setNegativeButton("Tutup", null).create()
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "COPY") { _, _ ->
            copyText(editor.text.toString()); Toast.makeText(this, "JSON preset disalin", Toast.LENGTH_SHORT).show()
        }
        dialog.show()
    }
    private fun showImportDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        box.addView(text("Paste JSON hasil export DLMS. Format JSON harus tetap valid.", 13f, 0xFFBFC3CC.toInt()))
        val editor = EditText(this).apply {
            hint = "[Preset Data]"; setTextColor(Color.WHITE); textSize = 13f
            gravity = Gravity.TOP; minLines = 12; isVerticalScrollBarEnabled = true
            background = bg(0xFF111214.toInt(), 8, 0xFF55585E.toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        box.addView(editor, LinearLayout.LayoutParams(-1, dp(300)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "PASTE"; setOnClickListener {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val value = clip.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString()
                if (value.isNullOrBlank()) Toast.makeText(this@MainActivity, "Clipboard kosong", Toast.LENGTH_SHORT).show()
                else editor.setText(value)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(actions)
        val dialog = AlertDialog.Builder(this).setTitle("Import presets").setView(box)
            .setNegativeButton("Tutup", null)
            .setPositiveButton("IMPORT", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    importJson(editor.text.toString())
                    Toast.makeText(this, "Preset berhasil diimpor", Toast.LENGTH_LONG).show()
                    dialog.dismiss()
                } catch (e: Exception) {
                    Toast.makeText(this, "Import gagal: ${e.message ?: "JSON tidak valid"}", Toast.LENGTH_LONG).show()
                }
            }
        }
        dialog.show()
    }
    private fun importJson(raw: String) {
        val root = JSONObject(raw)
        val list = if (root.has("presets")) root.getJSONArray("presets") else JSONArray().put(root)
        require(list.length() > 0) { "Tidak ada preset di JSON" }
        val incoming = linkedMapOf<String, IntArray>()
        for (i in 0 until list.length()) {
            val item = list.getJSONObject(i)
            val name = item.optString("name", "Imported ${i + 1}").trim().take(32).ifBlank { "Imported ${i + 1}" }
            val arr = if (item.has("bands_db")) item.getJSONArray("bands_db") else item.getJSONArray("bands")
            require(arr.length() == 10) { "Preset $name wajib berisi 10 band" }
            incoming[name] = IntArray(10) { b ->
                val n = arr.getDouble(b)
                (if (item.has("bands_db")) (n * 2).roundToInt() else n.roundToInt()).coerceIn(-24, 24)
            }
        }
        presets.putAll(incoming)
        val ed = prefs.edit()
        incoming.forEach { (name, values) -> ed.putString("custom_$name", JSONArray(values.toList()).toString()) }
        ed.apply()
        rebuildPresets()
    }
    private fun copyText(value: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("DLMS preset JSON", value))
    }

    private fun showSettings() {
        val items = arrayOf("Equalizer aktif/nonaktif", "Mode 1-Way / 2-Way", "Atur limiter", "Reset semua pengaturan")
        AlertDialog.Builder(this).setTitle("Pengaturan DLMS Equalizer")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        eqEnabled = !eqEnabled
                        try { eq?.enabled = eqEnabled } catch (_: Exception) {}
                        saveSettings(); buildUi()
                        Toast.makeText(this, if (eqEnabled) "EQ aktif" else "EQ nonaktif", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        eqMode = if (eqMode == "1WAY") "2WAY" else "1WAY"
                        saveSettings(); buildUi()
                        Toast.makeText(this, "Mode $eqMode", Toast.LENGTH_SHORT).show()
                    }
                    2 -> showLimiterInfo()
                    3 -> AlertDialog.Builder(this).setMessage("Reset EQ dan limiter ke pengaturan awal?")
                        .setNegativeButton("Batal", null).setPositiveButton("Reset") { _, _ ->
                            bands.fill(0); eqEnabled = true; limiterEnabled = false
                            attackMs = 5; releaseMs = 80; ratio = 10; thresholdDb = -2; postGainDb = 0
                            saveSettings(); createAudioEffects(); buildUi()
                        }.show()
                }
            }.show()
    }
    private fun showLimiterInfo() {
        AlertDialog.Builder(this).setTitle("Pengaturan Limiter")
            .setMessage("Attack: ${attackMs} ms\nRelease: ${releaseMs} ms\nRatio: ${ratio}:1\nThreshold: ${thresholdDb} dBFS\nPost-gain: ${postGainDb} dB\n\nUbah nilainya pada bagian LIMITER di halaman utama.")
            .setPositiveButton("OK", null).show()
    }
    private fun showAbout() {
        AlertDialog.Builder(this).setTitle("Tentang DLMS Equalizer")
            .setMessage("DLMS Equalizer\nVersi 3.0\n\nEqualizer 10-band, mode 1-Way/2-Way, preset JSON copy-paste, YouTube embedded player, dan limiter DynamicsProcessing.\n\nDibuat oleh Ilham Galeh.\n\nCatatan: efek audio global bergantung pada dukungan Android dan vendor perangkat. YouTube tetap mengikuti batasan embed, hak cipta, dan kebijakan YouTube.")
            .setPositiveButton("Tutup", null).show()
    }

    private fun extractYoutubeId(input: String): String? {
        val s = input.trim()
        if (s.matches(Regex("^[A-Za-z0-9_-]{11}$"))) return s
        val patterns = listOf(
            Regex("(?:youtube\\.com/watch\\?v=|youtu\\.be/|youtube\\.com/embed/|youtube-nocookie\\.com/embed/)([A-Za-z0-9_-]{11})"),
            Regex("youtube\\.com/shorts/([A-Za-z0-9_-]{11})")
        )
        return patterns.firstNotNullOfOrNull { it.find(s)?.groupValues?.getOrNull(1) }
    }
    private fun showYoutubePlayer(videoId: String) {
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                    handler?.cancel()
                }
            }
            val html = """
                <!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
                <style>html,body{margin:0;padding:0;background:#000;width:100%;height:100%;overflow:hidden}
                iframe{border:0;width:100%;height:100%}</style></head><body>
                <iframe src="https://www.youtube.com/embed/$videoId?autoplay=1&playsinline=1&rel=0"
                allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe>
                </body></html>
            """.trimIndent()
            loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        }
        val container = FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(-1, -1))
        }
        val dialog = AlertDialog.Builder(this).setTitle("YouTube")
            .setView(container).setNegativeButton("Tutup", null).create()
        dialog.setOnDismissListener { web.stopLoading(); web.loadUrl("about:blank"); web.destroy() }
        dialog.show()
        dialog.window?.setLayout(-1, dp(280))
    }

    override fun onDestroy() {
        try { eq?.release() } catch (_: Exception) {}
        try { limiter?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

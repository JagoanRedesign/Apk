package com.dlmsmini.equalizer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val freqs = arrayOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    private val bands = IntArray(10)
    private val prefs by lazy { getSharedPreferences("dlms_equalizer", MODE_PRIVATE) }
    private var engine: AudioCaptureEngine? = null
    private var captureButton: Button? = null
    private var status: TextView? = null
    private var eqEnabled = true
    private var eqMode = "1WAY"
    private var limiterEnabled = false
    private var attack = 10
    private var release = 100
    private var ratio = 20
    private var threshold = -3
    private var postGain = 0
    private var limiterLabels = mutableListOf<TextView>()
    private var limiterSeek = mutableListOf<SeekBar>()
    private var faders = mutableListOf<SeekBar>()
    private var bandLabels = mutableListOf<TextView>()

    companion object { private const val REQUEST_CAPTURE = 6102 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun panel(color: Int = 0xFF242426.toInt(), radius: Float = 18f) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
    }
    private fun text(value: String, size: Float, color: Int = 0xFFECECF1.toInt(), bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }
    private fun button(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xFF080808.toInt()); setOnClickListener { action() }
    }
    private fun section(parent: LinearLayout, title: String) {
        parent.addView(text(title, 14f, 0xFFBEBAC5.toInt(), true).apply { setPadding(dp(4), dp(20), 0, dp(9)) })
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = panel()
    }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF080808.toInt()) }
        val scroll = ScrollView(this).apply { fillViewport = true }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(24)) }
        val header = row().apply { background = panel(0xFF111827.toInt()); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("DLMS", 23f, 0xFFFFFFFF.toInt(), true)); brand.addView(text("MINI EQUALIZER", 10f, 0xFF00D8EA.toInt(), true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("⚙") { showSettings() }); header.addView(button("ⓘ") { showAbout() })
        body.addView(header)

        section(body, "AUDIO CAPTURE")
        val captureCard = card()
        captureCard.addView(text("Equalizer audio aplikasi", 17f, 0xFFFFFFFF.toInt(), true))
        captureCard.addView(text("Tangkap audio aplikasi yang mengizinkan AudioPlaybackCapture. Pilih Izinkan saat dialog Android muncul.", 12f, 0xFFB9B9C2.toInt()).apply { setPadding(0, dp(6), 0, dp(10)) })
        captureButton = button("MULAI AUDIO CAPTURE") { requestCapture() }
        captureCard.addView(captureButton)
        status = text("Status: belum terhubung", 11f, 0xFF00D8EA.toInt()).apply { setPadding(0, dp(10), 0, 0) }
        captureCard.addView(status)
        body.addView(captureCard)

        section(body, "EQUALIZER")
        val eqCard = card()
        val eqTop = row()
        eqTop.addView(text("Equalizer enabled", 16f, 0xFFFFFFFF.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        val eqSwitch = Switch(this).apply { isChecked = eqEnabled; setOnCheckedChangeListener { _, checked -> eqEnabled = checked; save(); applyEngine() } }
        eqTop.addView(eqSwitch); eqCard.addView(eqTop)
        val modeRow = row().apply { setPadding(0, dp(8), 0, dp(8)) }
        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val one = RadioButton(this).apply { text = "1-Way"; id = View.generateViewId(); setTextColor(0xFFFFFFFF.toInt()) }
        val two = RadioButton(this).apply { text = "2-Way"; id = View.generateViewId(); setTextColor(0xFFFFFFFF.toInt()) }
        modeGroup.addView(one); modeGroup.addView(two); modeGroup.check(if (eqMode == "2WAY") two.id else one.id)
        modeGroup.setOnCheckedChangeListener { _, checked -> eqMode = if (checked == two.id) "2WAY" else "1WAY"; save() }
        modeRow.addView(modeGroup); eqCard.addView(modeRow)
        val hint = text("Rentang setiap band: -12 dB sampai +12 dB", 11f, 0xFFB9B9C2.toInt()); eqCard.addView(hint)
        faders.clear(); bandLabels.clear()
        freqs.forEachIndexed { i, hz ->
            val r = row().apply { setPadding(0, dp(5), 0, dp(5)) }
            r.addView(text("$hz Hz", 12f, 0xFFE8E8ED.toInt()), LinearLayout.LayoutParams(dp(58), -2))
            val seek = SeekBar(this).apply {
                max = 48; progress = bands[i] + 24
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, from: Boolean) { bands[i] = p - 24; bandLabels[i].text = String.format(java.util.Locale.US, "%+.1f dB", bands[i] / 2f); if (from) { save(); applyEngine() } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            val value = text(String.format(java.util.Locale.US, "%+.1f dB", bands[i] / 2f), 11f, 0xFF00D8EA.toInt())
            bandLabels.add(value); faders.add(seek)
            r.addView(seek, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(value, LinearLayout.LayoutParams(dp(58), -2))
            eqCard.addView(r)
        }
        val presetActions = row()
        presetActions.addView(button("PRESET") { showPresets() }, LinearLayout.LayoutParams(0, -2, 1f))
        presetActions.addView(button("IMPORT / EXPORT") { showPresetTransfer() }, LinearLayout.LayoutParams(0, -2, 1f))
        eqCard.addView(presetActions); body.addView(eqCard)

        section(body, "LIMITER")
        val limCard = card()
        val limHead = row()
        limHead.addView(text("Limiter enabled", 17f, 0xFFFFFFFF.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        limHead.addView(Switch(this).apply { isChecked = limiterEnabled; setOnCheckedChangeListener { _, v -> limiterEnabled = v; save(); applyEngine() } })
        limCard.addView(limHead)
        addLimiterControl(limCard, "Attack time", "ms", 1, 100, attack) { attack = it }
        addLimiterControl(limCard, "Release time", "ms", 10, 1000, release) { release = it }
        addLimiterControl(limCard, "Ratio", ":1", 1, 20, ratio) { ratio = it }
        addLimiterControl(limCard, "Threshold", "dB", -24, 0, threshold) { threshold = it }
        addLimiterControl(limCard, "Post-gain", "dB", -12, 12, postGain) { postGain = it }
        body.addView(limCard)

        section(body, "PENGATURAN & INFORMASI")
        val settingsCard = card()
        settingsCard.addView(button("Pengaturan aplikasi") { showSettings() })
        settingsCard.addView(button("About DLMS Equalizer") { showAbout() })
        body.addView(settingsCard)
        scroll.addView(body); root.addView(scroll); setContentView(root)
    }

    private fun addLimiterControl(parent: LinearLayout, title: String, unit: String, min: Int, max: Int, initial: Int, update: (Int) -> Unit) {
        parent.addView(text(title, 15f, 0xFFECECF1.toInt()).apply { setPadding(0, dp(13), 0, 0) })
        val value = text("$initial $unit", 12f, 0xFF00D8EA.toInt())
        val seek = SeekBar(this).apply {
            this.max = max - min; progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, from: Boolean) { val v = p + min; value.text = "$v $unit"; update(v); if (from) { save(); applyEngine() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(value); parent.addView(seek)
    }

    private fun requestCapture() {
        if (engine != null) { stopCapture(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 6101)
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Deprecated in Android API; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                try {
                    engine = AudioCaptureEngine(this, resultCode, data) { message -> runOnUiThread { status?.text = "Status: $message" } }
                    engine?.setParameters(bands.copyOf(), eqEnabled, limiterEnabled, attack, release, ratio, threshold, postGain)
                    engine?.start(); captureButton?.text = "HENTIKAN AUDIO CAPTURE"; status?.text = "Status: capture berjalan"
                } catch (e: Exception) { engine = null; status?.text = "Status: gagal memulai (${e.message})" }
            } else status?.text = "Status: izin capture dibatalkan"
        }
    }

    private fun stopCapture() { engine?.stop(); engine = null; captureButton?.text = "MULAI AUDIO CAPTURE"; status?.text = "Status: dihentikan" }
    private fun applyEngine() { engine?.setParameters(bands.copyOf(), eqEnabled, limiterEnabled, attack, release, ratio, threshold, postGain) }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 6101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestCapture()
        else if (requestCode == 6101) status?.text = "Status: izin mikrofon diperlukan untuk AudioPlaybackCapture"
    }

    private fun showPresets() {
        val names = arrayOf("Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
        AlertDialog.Builder(this).setTitle("Preset Equalizer").setItems(names) { _, which ->
            val p = when (names[which]) {
                "Pop" -> intArrayOf(4,2,0,-2,-2,2,4,4,2,2); "Rock" -> intArrayOf(6,4,2,0,-2,2,4,6,6,6)
                "Jazz" -> intArrayOf(4,2,0,2,-2,-2,0,2,4,4); "Bass Boost" -> intArrayOf(10,8,6,4,2,0,0,0,0,0)
                "Vocal" -> intArrayOf(-4,-2,0,2,6,8,6,4,0,-2); "Dangdut" -> intArrayOf(8,6,4,2,0,2,4,4,2,2)
                "DJ Horeg" -> intArrayOf(10,8,6,2,-2,0,4,6,8,6); else -> IntArray(10)
            }
            p.copyInto(bands); refreshBands(); save(); applyEngine()
        }.setNegativeButton("Tutup", null).show()
    }

    private fun presetJson(): String {
        val root = JSONObject(); root.put("format", "dlms-equalizer-presets"); root.put("version", 1)
        val presets = JSONArray(); val p = JSONObject(); p.put("name", "DLMS Custom"); p.put("bands_db", JSONArray().also { a -> bands.forEach { a.put(it / 2.0) } }); p.put("eq_enabled", eqEnabled); p.put("eq_mode", eqMode)
        p.put("limiter", JSONObject().put("enabled", limiterEnabled).put("attack_ms", attack).put("release_ms", release).put("ratio", ratio).put("threshold_db", threshold).put("post_gain_db", postGain))
        presets.put(p); root.put("presets", presets); return root.toString(2)
    }

    private fun showPresetTransfer() {
        val input = EditText(this).apply { hint = "[Preset Data]"; gravity = Gravity.TOP or Gravity.START; minLines = 9; setPadding(dp(12), dp(12), dp(12), dp(12)); background = panel(0xFF0B0B0B.toInt(), 2f); setTextColor(0xFFFFFFFF.toInt()) }
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(4)) }
        holder.addView(input, LinearLayout.LayoutParams(-1, dp(250)))
        holder.addView(button("PASTE") {
            val clip = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val value = clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            if (value.isBlank()) Toast.makeText(this, "Clipboard kosong", Toast.LENGTH_SHORT).show() else input.setText(value)
        })
        val dialog = AlertDialog.Builder(this).setTitle("Import / Export presets")
            .setMessage("COPY menyalin preset sebagai JSON. PASTE mengambil JSON dari clipboard. Tekan IMPORT untuk menerapkan preset.")
            .setView(holder).setNeutralButton("COPY", null).setPositiveButton("IMPORT", null).setNegativeButton("CLOSE", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val clip = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("DLMS preset", presetJson())); Toast.makeText(this, "JSON preset disalin", Toast.LENGTH_SHORT).show()
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { importPreset(input.text.toString()) }
        }
        dialog.show()
    }

    private fun importPreset(raw: String) {
        try {
            val root = JSONObject(raw.trim()); val array = root.optJSONArray("presets") ?: JSONArray()
            if (array.length() == 0) throw IllegalArgumentException("Daftar preset kosong")
            val item = array.getJSONObject(0); val a = item.optJSONArray("bands_db") ?: item.optJSONArray("bands") ?: throw IllegalArgumentException("bands_db tidak ditemukan")
            if (a.length() != 10) throw IllegalArgumentException("Harus tepat 10 band")
            for (i in 0 until 10) bands[i] = (a.getDouble(i) * if (item.has("bands_db")) 2 else 1).roundToInt().coerceIn(-24, 24)
            eqEnabled = item.optBoolean("eq_enabled", eqEnabled); eqMode = item.optString("eq_mode", eqMode)
            val lim = item.optJSONObject("limiter")
            if (lim != null) { limiterEnabled = lim.optBoolean("enabled", limiterEnabled); attack = lim.optInt("attack_ms", attack).coerceIn(1,100); release = lim.optInt("release_ms", release).coerceIn(10,1000); ratio = lim.optInt("ratio", ratio).coerceIn(1,20); threshold = lim.optInt("threshold_db", threshold).coerceIn(-24,0); postGain = lim.optInt("post_gain_db", postGain).coerceIn(-12,12) }
            save(); recreate(); Toast.makeText(this, "Preset berhasil diimpor", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Import gagal: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showSettings() {
        val items = arrayOf("Aktifkan equalizer", "Mode 1-Way / 2-Way", "Mulai audio capture", "Hentikan audio capture", "Import / Export preset", "About aplikasi")
        AlertDialog.Builder(this).setTitle("Pengaturan DLMS Equalizer").setItems(items) { _, i -> when (i) {
            0 -> { eqEnabled = !eqEnabled; save(); applyEngine(); recreate() }
            1 -> { eqMode = if (eqMode == "1WAY") "2WAY" else "1WAY"; save(); recreate() }
            2 -> requestCapture(); 3 -> stopCapture(); 4 -> showPresetTransfer(); 5 -> showAbout()
        } }.setNegativeButton("Tutup", null).show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this).setTitle("About DLMS Equalizer").setMessage("DLMS Mini Equalizer\nVersi 3.0\n\nEqualizer 10-band, mode 1-Way/2-Way, AudioPlaybackCapture dan limiter DSP.\n\nDibuat oleh Ilham Galeh.\n\nAudioPlaybackCapture bergantung pada versi Android, kebijakan aplikasi sumber, dan perangkat.")
            .setPositiveButton("OK", null).show()
    }

    private fun refreshBands() { faders.forEachIndexed { i, s -> s.progress = bands[i] + 24 }; bandLabels.forEachIndexed { i, t -> t.text = String.format(java.util.Locale.US, "%+.1f dB", bands[i] / 2f) } }
    private fun load() {
        for (i in bands.indices) bands[i] = prefs.getInt("band_$i", 0).coerceIn(-24,24)
        eqEnabled = prefs.getBoolean("eq_enabled", true); eqMode = prefs.getString("eq_mode", "1WAY") ?: "1WAY"
        limiterEnabled = prefs.getBoolean("limiter_enabled", false); attack = prefs.getInt("attack",10).coerceIn(1,100); release = prefs.getInt("release",100).coerceIn(10,1000); ratio = prefs.getInt("ratio",20).coerceIn(1,20); threshold = prefs.getInt("threshold",-3).coerceIn(-24,0); postGain = prefs.getInt("post_gain",0).coerceIn(-12,12)
    }
    private fun save() { prefs.edit().also { e -> bands.forEachIndexed { i,v -> e.putInt("band_$i",v) }; e.putBoolean("eq_enabled",eqEnabled).putString("eq_mode",eqMode).putBoolean("limiter_enabled",limiterEnabled).putInt("attack",attack).putInt("release",release).putInt("ratio",ratio).putInt("threshold",threshold).putInt("post_gain",postGain).apply() } }
    override fun onDestroy() { stopCapture(); super.onDestroy() }
}

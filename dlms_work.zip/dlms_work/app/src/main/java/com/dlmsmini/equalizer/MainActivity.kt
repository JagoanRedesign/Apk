package com.dlmsmini.equalizer

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private val frequencies = arrayOf("31 Hz", "62 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz")
    private val values = IntArray(10)
    private val sliders = mutableListOf<SeekBar>()
    private var preamp = 0
    private var balance = 0
    private var autoGain = true
    private var eq: Equalizer? = null
    private var virtualizer: Virtualizer? = null
    private var reverb: PresetReverb? = null
    private var visualizer: Visualizer? = null
    private var spectrumView: SpectrumView? = null
    private var status: TextView? = null
    private val prefs by lazy { getSharedPreferences("dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_"), Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSettings()
        buildUi()
        initEffects()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        } else startVisualizer()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 18); setBackgroundColor(0xFF10131B.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun heading(s: String) = TextView(this).apply { text = s; textSize = 18f; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 18, 0, 8); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        fun small(s: String) = TextView(this).apply { text = s; textSize = 12f; setTextColor(0xFFB7C0D2.toInt()) }
        content.addView(TextView(this).apply { text = "DLMS MINI EQUALIZER"; textSize = 23f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setTextColor(0xFF70D6FF.toInt()) })
        content.addView(small("10-Band Audio Control • Ilham Galeh"))
        content.addView(heading("LIVE SPECTRUM ANALYZER"))
        spectrumView = SpectrumView(this)
        content.addView(spectrumView, LinearLayout.LayoutParams(-1, 130))
        status = small("Status: menginisialisasi audio effect…")
        content.addView(status)

        val enable = Switch(this).apply { text = "Equalizer aktif"; setTextColor(-1); isChecked = true }
        enable.setOnCheckedChangeListener { _, checked ->
            try { eq?.enabled = checked; virtualizer?.enabled = checked; reverb?.enabled = checked; status?.text = if (checked) "Status: efek aktif (bergantung dukungan perangkat)" else "Status: efek nonaktif" } catch (_: Exception) { }
        }
        content.addView(enable)

        content.addView(heading("PRESET GENRE"))
        val builtInPresets = listOf("Custom", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
        val presetNames = (builtInPresets + prefs.all.keys.filter { it.startsWith("custom_") }.map { it.removePrefix("custom_") }).distinct()
        val presetSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presetNames) }
        content.addView(presetSpinner)
        presetSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    val selected = presetNames[position]
                    if (selected in builtInPresets) applyPreset(selected) else applySavedPreset(selected)
                }
            }
        }
        val presetButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 2f }
        val save = Button(this).apply { text = "Save Preset"; setOnClickListener { saveCustomPreset() } }
        val reset = Button(this).apply { text = "Reset Flat"; setOnClickListener { values.fill(0); preamp = 0; updateSliders(); applyEffects(); saveSettings() } }
        presetButtons.addView(save, LinearLayout.LayoutParams(0, -2, 1f)); presetButtons.addView(reset, LinearLayout.LayoutParams(0, -2, 1f)); content.addView(presetButtons)

        content.addView(heading("10-BAND EQUALIZER"))
        frequencies.forEachIndexed { i, label ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = label; setTextColor(-1); textSize = 12f }, LinearLayout.LayoutParams(54, -2))
            val seek = SeekBar(this).apply { max = 24; progress = values[i] + 12 }
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { values[i] = p - 12; if (user) { applyEffects(); saveSettings() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            sliders.add(seek); row.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
            val db = TextView(this).apply { text = "${values[i]} dB"; setTextColor(0xFF70D6FF.toInt()); textSize = 11f; gravity = Gravity.END }
            seek.tag = db
            row.addView(db, LinearLayout.LayoutParams(48, -2)); content.addView(row)
        }

        content.addView(heading("PREAMP & ANTI-CLIPPING"))
        content.addView(small("Preamp: -12 dB sampai +12 dB"))
        val pre = SeekBar(this).apply { max = 24; progress = preamp + 12 }
        val preLabel = small("${preamp} dB")
        pre.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { preamp = p - 12; preLabel.text = "${preamp} dB"; if (user) { applyEffects(); saveSettings() } }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(pre); content.addView(preLabel)
        val limiter = Switch(this).apply { text = "Smart Limiter / Auto-Reduce"; setTextColor(-1); isChecked = autoGain }
        limiter.setOnCheckedChangeListener { _, checked -> autoGain = checked; applyEffects(); saveSettings() }; content.addView(limiter)
        val gainInfo = small(""); content.addView(gainInfo)

        content.addView(heading("BALANCE & SPATIAL EFFECTS"))
        content.addView(small("L/R Balance: kiri -100 • tengah 0 • kanan +100"))
        val bal = SeekBar(this).apply { max = 200; progress = balance + 100 }
        val balText = small("Balance ${balance}")
        bal.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { balance = p - 100; balText.text = "Balance ${balance}"; if (user) saveSettings() }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(bal); content.addView(balText)
        content.addView(small("Catatan: balance stereo global tidak tersedia melalui API efek Android standar; kontrol ini disimpan untuk kompatibilitas pipeline audio aplikasi."))
        content.addView(small("Virtualizer"))
        val virt = SeekBar(this).apply { max = 100 }
        virt.setOnSeekBarChangeListener(simpleListener { try { virtualizer?.setStrength(it.toShort()); saveSettings() } catch (_: Exception) {} }); content.addView(virt)
        content.addView(small("Preset Reverb"))
        val revNames = arrayOf("Off", "Small Room", "Medium Room", "Large Room", "Plate", "Hall")
        val rev = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, revNames) }
        content.addView(rev)
        rev.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { try { reverb?.preset = when(position) { 1 -> PresetReverb.PRESET_SMALLROOM; 2 -> PresetReverb.PRESET_MEDIUMROOM; 3 -> PresetReverb.PRESET_LARGEROOM; 4 -> PresetReverb.PRESET_PLATE; 5 -> PresetReverb.PRESET_MEDIUMHALL; else -> PresetReverb.PRESET_NONE }; saveSettings() } catch (_: Exception) {} }
        }
        content.addView(heading("TENTANG"))
        content.addView(small("DLMS Mini Equalizer\nDibuat oleh Ilham Galeh\n© ${java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)} Ilham Galeh. All rights reserved."))
        content.addView(small("Efek audio sistem penuh hanya bekerja jika ROM / audio HAL perangkat mengizinkan session 0. Android dapat membatasi efek global. Spectrum membutuhkan izin mikrofon (RECORD_AUDIO) dan sumber audio yang dapat divisualisasikan."))
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        pre.progress = preamp + 12
        updateSliders()
    }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun updateSliders() { sliders.forEachIndexed { i, s -> s.progress = values[i] + 12; (s.tag as? TextView)?.text = "${values[i]} dB" } }
    private fun applyPreset(name: String) {
        val p = when(name) {
            "Pop" -> intArrayOf(-1, 2, 4, 4, 1, -1, -1, 1, 2, 2)
            "Rock" -> intArrayOf(5, 4, 2, -1, -2, 1, 4, 5, 5, 5)
            "Jazz" -> intArrayOf(3, 2, 1, 2, -2, -2, 0, 1, 3, 4)
            "Bass Boost" -> intArrayOf(8, 7, 5, 3, 1, 0, 0, 0, 0, 0)
            "Vocal" -> intArrayOf(-3, -2, -1, 1, 4, 5, 4, 2, 0, -1)
            "Dangdut" -> intArrayOf(6, 5, 3, 1, -1, 1, 3, 3, 2, 1)
            "DJ Horeg" -> intArrayOf(10, 8, 5, 2, -2, -1, 2, 4, 5, 4)
            else -> IntArray(10)
        }
        for (i in values.indices) values[i] = p[i].coerceIn(-12, 12)
        updateSliders(); applyEffects(); saveSettings()
    }

    private fun initEffects() {
        try {
            eq = Equalizer(0, 0).also { it.enabled = true }
            virtualizer = Virtualizer(0, 0).also { it.enabled = true }
            reverb = PresetReverb(0, 0).also { it.enabled = false }
            status?.text = "Status: efek Android terpasang; kompatibilitas global bergantung perangkat"
            applyEffects()
        } catch (e: Exception) { status?.text = "Status: perangkat menolak global audio effect (${e.javaClass.simpleName})" }
    }

    private fun applyEffects() {
        val effect = eq ?: return
        try {
            val range = effect.bandLevelRange
            val maxGain = values.maxOrNull() ?: 0
            val autoReduction = if (autoGain) max(0, maxGain + preamp) else 0
            val effectivePreamp = preamp - autoReduction
            values.forEachIndexed { i, db ->
                val targetHz = intArrayOf(31,62,125,250,500,1000,2000,4000,8000,16000)[i]
                val band = nearestBand(effect, targetHz)
                val gainDb = (db + effectivePreamp).coerceIn(-12, 12)
                val milliDb = (gainDb * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band, milliDb.toShort())
            }
        } catch (_: Exception) { }
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Short {
        var best = 0; var diff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = kotlin.math.abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best.toShort()
    }

    private fun startVisualizer() {
        try {
            visualizer = Visualizer(0).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {
                        data?.let { bytes ->
                            val bars = FloatArray(32)
                            for (i in bars.indices) { val idx = 2 + i * 2; if (idx < bytes.size) bars[i] = (kotlin.math.abs(bytes[idx].toInt()).toFloat() / 128f).coerceIn(0f, 1f) }
                            runOnUiThread { spectrumView?.setBars(bars) }
                        }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (_: Exception) { status?.text = "Status: spectrum tidak didukung / izin audio ditolak" }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVisualizer()
    }

    private fun saveCustomPreset() {
        val input = EditText(this).apply { hint = "Nama preset" }
        AlertDialog.Builder(this).setTitle("Simpan preset").setView(input).setPositiveButton("Simpan") { _, _ ->
            val name = input.text.toString().trim().ifBlank { "Preset Saya" }
            prefs.edit().putString("custom_$name", JSONArray(values.toList()).toString()).apply()
            Toast.makeText(this, "Preset $name disimpan. Buka ulang daftar preset untuk memuatnya.", Toast.LENGTH_LONG).show()
        }.setNegativeButton("Batal", null).show()
    }

    private fun applySavedPreset(name: String) {
        try {
            val json = JSONArray(prefs.getString("custom_$name", "[]"))
            if (json.length() == 10) {
                for (i in values.indices) values[i] = json.getInt(i).coerceIn(-12, 12)
                updateSliders(); applyEffects(); saveSettings()
            }
        } catch (_: Exception) { Toast.makeText(this, "Preset tidak dapat dibaca", Toast.LENGTH_SHORT).show() }
    }

    private fun loadSettings() {
        for (i in values.indices) values[i] = prefs.getInt("band_$i", 0)
        preamp = prefs.getInt("preamp", 0); balance = prefs.getInt("balance", 0); autoGain = prefs.getBoolean("auto_gain", true)
    }
    private fun saveSettings() {
        val e = prefs.edit(); values.forEachIndexed { i, v -> e.putInt("band_$i", v) }
        e.putInt("preamp", preamp).putInt("balance", balance).putBoolean("auto_gain", autoGain).apply()
    }

    override fun onDestroy() {
        try { visualizer?.release(); eq?.release(); virtualizer?.release(); reverb?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    private class SpectrumView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var bars = FloatArray(32)
        fun setBars(data: FloatArray) { bars = data; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val gap = 5f; val bw = (w - gap * (bars.size - 1)) / bars.size
            bars.forEachIndexed { i, value ->
                val bh = max(4f, value * (h - 8f)); paint.color = when { value > .72f -> 0xFFFF6B6B.toInt(); value > .4f -> 0xFFFFC857.toInt(); else -> 0xFF46C8FF.toInt() }
                canvas.drawRoundRect(RectF(i * (bw + gap), h - bh, i * (bw + gap) + bw, h), 5f, 5f, paint)
            }
        }
    }
}

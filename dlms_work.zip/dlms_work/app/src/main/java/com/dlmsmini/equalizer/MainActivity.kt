package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val frequencies = arrayOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    private val centerHz = intArrayOf(31,62,125,250,500,1000,2000,4000,8000,16000)
    private val values = IntArray(10)
    private val faders = mutableListOf<VerticalFader>()
    private val prefs by lazy { getSharedPreferences("dlms_equaliser", MODE_PRIVATE) }
    private var eqEnabled = true
    private var eqMode = "1WAY"
    private var limiterEnabled = false
    private var attack = 5f
    private var release = 100f
    private var ratio = 20f
    private var threshold = -1f
    private var postGain = 0f
    private var engine: PlaybackCaptureEngine? = null
    private var projection: MediaProjection? = null
    private var status: TextView? = null
    private var captureButton: Button? = null
    private var presetGrid: LinearLayout? = null
    private var limiterPanel: LinearLayout? = null
    private var limiterSummary: TextView? = null
    private val projectionRequest = 4101
    private val builtIns = listOf("Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSettings()
        buildUi()
        syncEngineSettings()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
    private fun color(v:Long)=v.toInt()
    private fun rounded(bg:Int,r:Int,stroke:Int=0)=GradientDrawable().apply {
        setColor(bg); cornerRadius=dp(r).toFloat(); if(stroke!=0) setStroke(dp(1),stroke)
    }
    private fun label(s:String,size:Float=13f,tint:Int=color(0xFFCACAD2),bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(tint); if(bold) typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL)
    }
    private fun card()=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(14),dp(14),dp(14));
        background=rounded(color(0xFF242426),18,color(0xFF343438))
    }
    private fun section(parent:LinearLayout,title:String) {
        parent.addView(label(title,13f,color(0xFFE7E7ED),true).apply { setPadding(dp(2),dp(20),dp(2),dp(9)) })
    }
    private fun buildUi() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(color(0xFF080B12)) }
        val scroll=ScrollView(this).apply { clipToPadding=false }
        val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(22)) }
        val header=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12))
            background=rounded(color(0xFF111827),18,color(0xFF263B5D))
        }
        val brand=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        brand.addView(label("DLMS",23f,color(0xFFF3F6FF),true)); brand.addView(label("MINI EQUALISER",10f,color(0xFF35B8FF),true))
        header.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        val modes=RadioGroup(this).apply { orientation=RadioGroup.HORIZONTAL; background=rounded(color(0xFF080F1D),18,color(0xFF31486B)); setPadding(dp(4),dp(2),dp(4),dp(2)) }
        val one=RadioButton(this).apply { id=View.generateViewId(); text="1-Way"; textSize=11f; setTextColor(-1); buttonTintList=android.content.res.ColorStateList.valueOf(color(0xFF28AFFF)) }
        val two=RadioButton(this).apply { id=View.generateViewId(); text="2-Way"; textSize=11f; setTextColor(-1); buttonTintList=android.content.res.ColorStateList.valueOf(color(0xFF28AFFF)) }
        modes.addView(one); modes.addView(two); modes.check(if(eqMode=="2WAY") two.id else one.id)
        modes.setOnCheckedChangeListener { _,id -> eqMode=if(id==two.id) "2WAY" else "1WAY"; syncEngineSettings(); saveSettings() }
        header.addView(modes); content.addView(header)

        section(content,"AUDIO PLAYBACK CAPTURE")
        val capture=card().apply { background=rounded(color(0xFF111827),18,color(0xFF263B5D)) }
        capture.addView(label("Tangkap audio dari aplikasi lain",15f,color(0xFFF0F5FF),true))
        capture.addView(label("Putar YouTube atau aplikasi musik, lalu mulai capture. Audio akan diproses oleh equalizer DLMS. Aplikasi sumber harus mengizinkan capture.",11f,color(0xFF9DAFC9)).apply { setPadding(0,dp(6),0,dp(10)) })
        captureButton=Button(this).apply { text="MULAI AUDIO CAPTURE"; setOnClickListener { if(engine?.running==true) stopCapture() else requestCapture() } }
        capture.addView(captureButton); status=label("Status: belum terhubung",10f,color(0xFF80DDB5)).apply { setPadding(0,dp(8),0,0) }; capture.addView(status)
        content.addView(capture)

        section(content,"10-BAND EQUALIZER")
        val eqCard=card().apply { background=rounded(color(0xFF111827),18,color(0xFF263B5D)); setPadding(dp(7),dp(10),dp(7),dp(10)) }
        val enabled=Switch(this).apply { text="Equalizer aktif"; textSize=12f; setTextColor(-1); isChecked=eqEnabled }
        enabled.setOnCheckedChangeListener { _,v -> eqEnabled=v; syncEngineSettings(); saveSettings() }
        eqCard.addView(enabled)
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        frequencies.forEachIndexed { i,f ->
            val col=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER_HORIZONTAL; setPadding(dp(1),0,dp(1),0) }
            col.addView(label(f,9f,color(0xFFDDE7F8),true).apply { gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,dp(24)))
            val plus=TextView(this).apply { text="+"; textSize=18f; gravity=Gravity.CENTER; setTextColor(-1); background=rounded(color(0xFF1D3554),8,color(0xFF315B8B)) }
            col.addView(plus,LinearLayout.LayoutParams(-1,dp(29)))
            val valueText=label(formatDb(values[i]),9f,color(0xFF45C5FF),true).apply { gravity=Gravity.CENTER }
            val fader=VerticalFader(this).apply {
                setValue(values[i]); onValueChanged={v,from -> values[i]=v; valueText.text=formatDb(v); if(from){ syncEngineSettings(); saveSettings() } }
            }
            faders.add(fader); col.addView(fader,LinearLayout.LayoutParams(-1,dp(165)))
            val minus=TextView(this).apply { text="−"; textSize=18f; gravity=Gravity.CENTER; setTextColor(-1); background=rounded(color(0xFF1D3554),8,color(0xFF315B8B)) }
            col.addView(minus,LinearLayout.LayoutParams(-1,dp(29))); col.addView(valueText)
            plus.setOnClickListener { fader.setValue((fader.value+1).coerceAtMost(24),true) }
            minus.setOnClickListener { fader.setValue((fader.value-1).coerceAtLeast(-24),true) }
            row.addView(col,LinearLayout.LayoutParams(0,-2,1f))
        }
        eqCard.addView(row); eqCard.addView(label("−12 dB        0 dB        +12 dB • langkah 0,5 dB",9f,color(0xFF899AB5)).apply { gravity=Gravity.CENTER; setPadding(0,dp(8),0,0) })
        content.addView(eqCard)

        section(content,"LIMITER")
        val lim=card().apply { background=rounded(color(0xFF111827),18,color(0xFF263B5D)) }; limiterPanel=lim
        val check=CheckBox(this).apply { text="Limiter enabled"; textSize=16f; setTextColor(-1); buttonTintList=android.content.res.ColorStateList.valueOf(color(0xFF00D5E8)); isChecked=limiterEnabled }
        check.setOnCheckedChangeListener { _,v -> limiterEnabled=v; syncEngineSettings(); saveSettings(); updateLimiterVisibility() }
        lim.addView(check)
        addLimiterSlider(lim,"Attack time",0.1f,200f,attack,"ms") { attack=it }
        addLimiterSlider(lim,"Release time",1f,2000f,release,"ms") { release=it }
        addLimiterSlider(lim,"Ratio",1f,40f,ratio,":1") { ratio=it }
        addLimiterSlider(lim,"Threshold",-24f,0f,threshold," dB") { threshold=it }
        addLimiterSlider(lim,"Post-gain",-12f,12f,postGain," dB") { postGain=it }
        content.addView(lim); updateLimiterVisibility()

        section(content,"PRESET MUSIK")
        val preset=card().apply { background=rounded(color(0xFF111827),18,color(0xFF263B5D)) }
        presetGrid=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; preset.addView(presetGrid); populatePresets()
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val save=Button(this).apply { text="Simpan"; setOnClickListener { saveCustomPreset() } }
        val copy=Button(this).apply { text="COPY"; setOnClickListener { copyPresets() } }
        val paste=Button(this).apply { text="PASTE"; setOnClickListener { pastePresets() } }
        actions.addView(save,LinearLayout.LayoutParams(0,-2,1f)); actions.addView(copy,LinearLayout.LayoutParams(0,-2,1f)); actions.addView(paste,LinearLayout.LayoutParams(0,-2,1f)); preset.addView(actions)
        content.addView(preset)

        val bottom=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        bottom.addView(Button(this).apply { text="PENGATURAN"; setOnClickListener { showSettings() } },LinearLayout.LayoutParams(0,-2,1f))
        bottom.addView(Button(this).apply { text="ABOUT"; setOnClickListener { showAbout() } },LinearLayout.LayoutParams(0,-2,1f))
        content.addView(bottom)
        content.addView(label("DLMS Mini Equaliser",10f,color(0xFF8294B2)).apply { gravity=Gravity.CENTER; setPadding(0,dp(12),0,0) })
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    private fun addLimiterSlider(parent:LinearLayout,title:String,min:Float,max:Float,initial:Float,unit:String,onChange:(Float)->Unit) {
        val value=label("${formatNumber(initial)}$unit",12f,color(0xFF45C5FF),true)
        parent.addView(label(title,14f,color(0xFFE7E7ED),true)); parent.addView(value)
        val seek=SeekBar(this).apply { this.max=1000; progress=(((initial-min)/(max-min))*1000).roundToInt().coerceIn(0,1000) }
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,user:Boolean) { val v=min+(max-min)*p/1000f; value.text="${formatNumber(v)}$unit"; onChange(v); if(user){syncEngineSettings();saveSettings()} }
            override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){syncEngineSettings();saveSettings()}
        })
        parent.addView(seek)
    }
    private fun updateLimiterVisibility(){ limiterPanel?.let { for(i in 1 until it.childCount) it.getChildAt(i).visibility=if(limiterEnabled) View.VISIBLE else View.GONE } }
    private fun requestCapture() {
        if(Build.VERSION.SDK_INT<29){ Toast.makeText(this,"Fitur ini memerlukan Android 10+",Toast.LENGTH_LONG).show(); return }
        val manager=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(),projectionRequest)
    }
    @Deprecated("Legacy result callback used for MediaProjection consent")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=projectionRequest) return
        if(resultCode!=RESULT_OK || data==null){ status?.text="Izin capture dibatalkan"; return }
        try {
            val manager=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection=manager.getMediaProjection(resultCode,data)
            val p=projection ?: throw IllegalStateException("MediaProjection tidak tersedia")
            p.registerCallback(object:MediaProjection.Callback(){ override fun onStop(){ runOnUiThread { stopCapture() } } },android.os.Handler(mainLooper))
            engine=PlaybackCaptureEngine(p,applicationInfo.uid){ msg -> runOnUiThread { status?.text=msg; stopCapture() } }
            syncEngineSettings(); engine?.start()
            captureButton?.text="HENTIKAN CAPTURE"; status?.text="Capture berjalan • putar audio YouTube/aplikasi lain"
        } catch(e:Exception){ status?.text="Gagal memulai capture: ${e.message}"; stopCapture() }
    }
    private fun stopCapture(){ engine?.stop(); engine=null; try{projection?.stop()}catch(_:Exception){}; projection=null; captureButton?.text="MULAI AUDIO CAPTURE"; if(status?.text?.startsWith("Gagal")!=true) status?.text="Capture berhenti" }
    private fun syncEngineSettings(){ engine?.let { it.eqEnabled=eqEnabled; it.gainsDb=FloatArray(10){i->values[i]/2f}; it.twoWay=eqMode=="2WAY"; it.limiterEnabled=limiterEnabled; it.attackMs=attack; it.releaseMs=release; it.ratio=ratio; it.thresholdDb=threshold; it.postGainDb=postGain } }

    private fun populatePresets(){ val grid=presetGrid?:return; grid.removeAllViews(); val custom=prefs.all.keys.filter{it.startsWith("preset_")}.map{it.removePrefix("preset_")}.sorted(); (builtIns+custom).distinct().chunked(3).forEach { names ->
        val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; names.forEach { n -> r.addView(TextView(this).apply{text=n;textSize=11f;gravity=Gravity.CENTER;setTextColor(-1);background=rounded(color(0xFF1B2638),10,color(0xFF304968));setPadding(dp(4),dp(12),dp(4),dp(12));setOnClickListener{if(n in builtIns)applyPreset(n) else applySavedPreset(n)}},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(3),dp(3),dp(3),dp(3))}) }; grid.addView(r)
    } }
    private fun applyPreset(name:String){ val a=when(name){"Pop"->intArrayOf(4,2,0,-2,-2,2,4,4,2,2);"Rock"->intArrayOf(6,4,2,0,-2,2,4,6,6,6);"Jazz"->intArrayOf(4,2,0,2,-2,-2,0,2,4,4);"Bass Boost"->intArrayOf(10,8,6,4,2,0,0,0,0,0);"Vocal"->intArrayOf(-4,-2,0,2,6,8,6,4,0,-2);"Dangdut"->intArrayOf(8,6,4,2,0,2,4,4,2,2);"DJ Horeg"->intArrayOf(10,8,6,2,-2,0,4,6,8,6);else->IntArray(10)}; a.copyInto(values); updateFaders(); syncEngineSettings(); saveSettings() }
    private fun saveCustomPreset(){ val input=EditText(this).apply{hint="Nama preset"}; AlertDialog.Builder(this).setTitle("Simpan preset").setView(input).setPositiveButton("Simpan"){_,_->val n=input.text.toString().trim().ifBlank{"Preset Saya"}.take(28);prefs.edit().putString("preset_$n",JSONArray(values.map{it/2.0}).toString()).apply();populatePresets()}.setNegativeButton("Batal",null).show() }
    private fun applySavedPreset(name:String){try{val a=JSONArray(prefs.getString("preset_$name","[]"));if(a.length()!=10)throw Exception("Jumlah band tidak sesuai");for(i in 0..9)values[i]=(a.getDouble(i)*2).roundToInt().coerceIn(-24,24);updateFaders();syncEngineSettings();saveSettings()}catch(e:Exception){Toast.makeText(this,"Preset tidak valid",Toast.LENGTH_SHORT).show()}}
    private fun copyPresets(){ val list=JSONArray(); prefs.all.filterKeys{it.startsWith("preset_")}.forEach{(k,v)->try{val ar=JSONArray(v as String);list.put(JSONObject().put("name",k.removePrefix("preset_")).put("bands_db",ar))}catch(_:Exception){}}; list.put(JSONObject().put("name","Current").put("bands_db",JSONArray(values.map{it/2.0}))); val payload=JSONObject().put("format","dlms-mini-presets").put("version",1).put("presets",list).toString(2); (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("DLMS presets",payload)); Toast.makeText(this,"Preset disalin ke clipboard",Toast.LENGTH_SHORT).show() }
    private fun pastePresets(){ val clip=(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip; val text=clip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim(); if(text.isNullOrBlank()){Toast.makeText(this,"Clipboard kosong",Toast.LENGTH_SHORT).show();return}; try{val root=JSONObject(text);val arr=if(root.has("presets"))root.getJSONArray("presets") else JSONArray().put(root);var count=0;for(i in 0 until arr.length()){val item=arr.getJSONObject(i);val name=item.optString("name","Preset ${i+1}").replace(Regex("[^A-Za-z0-9 _-]"),"").take(28).ifBlank{"Preset ${i+1}"};val bands=item.optJSONArray("bands_db")?:item.optJSONArray("bands")?:throw Exception("bands_db tidak ada");if(bands.length()!=10)throw Exception("Preset harus memiliki 10 band");val out=JSONArray();for(b in 0..9){val x=bands.getDouble(b);out.put((if(item.has("bands_db"))x*2 else x).roundToInt().coerceIn(-24,24)/2.0)};prefs.edit().putString("preset_$name",out.toString()).apply();count++};populatePresets();Toast.makeText(this,"$count preset berhasil ditempel",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"Paste gagal: ${e.message}",Toast.LENGTH_LONG).show()} }
    private fun showSettings(){ val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),dp(8))}; val info=label("Pengaturan aplikasi DLMS Equaliser",16f,-1,true);box.addView(info);val keep=CheckBox(this).apply{text="Simpan pengaturan otomatis";isChecked=prefs.getBoolean("autosave",true);setTextColor(-1)};box.addView(keep);val about=Button(this).apply{text="Informasi aplikasi";setOnClickListener{showAbout()}};box.addView(about);AlertDialog.Builder(this).setTitle("Pengaturan").setView(box).setPositiveButton("Simpan"){_,_->prefs.edit().putBoolean("autosave",keep.isChecked).apply()}.setNegativeButton("Tutup",null).show() }
    private fun showAbout(){AlertDialog.Builder(this).setTitle("Tentang DLMS Equaliser").setMessage("DLMS Mini Equaliser\nVersi 3.0\n10-band equalizer, AudioPlaybackCapture, preset clipboard dan limiter DSP.\n\nAudio capture bergantung pada izin MediaProjection dan kebijakan aplikasi sumber.\n\nDibuat oleh Ilham Galeh.").setPositiveButton("OK",null).show()}
    private fun updateFaders(){faders.forEachIndexed{i,f->f.setValue(values[i],false)}}
    private fun formatDb(v:Int)=String.format(java.util.Locale.US,"%.1f dB",v/2f)
    private fun formatNumber(v:Float)=String.format(java.util.Locale.US,"%.1f",v)
    private fun loadSettings(){for(i in 0..9)values[i]=prefs.getInt("band_$i",0).coerceIn(-24,24);eqEnabled=prefs.getBoolean("eq_enabled",true);eqMode=prefs.getString("eq_mode","1WAY")?:"1WAY";limiterEnabled=prefs.getBoolean("limiter_enabled",false);attack=prefs.getFloat("limiter_attack",5f);release=prefs.getFloat("limiter_release",100f);ratio=prefs.getFloat("limiter_ratio",20f);threshold=prefs.getFloat("limiter_threshold",-1f);postGain=prefs.getFloat("limiter_post",0f)}
    private fun saveSettings(){val e=prefs.edit();values.forEachIndexed{i,v->e.putInt("band_$i",v)};e.putBoolean("eq_enabled",eqEnabled).putString("eq_mode",eqMode).putBoolean("limiter_enabled",limiterEnabled).putFloat("limiter_attack",attack).putFloat("limiter_release",release).putFloat("limiter_ratio",ratio).putFloat("limiter_threshold",threshold).putFloat("limiter_post",postGain).apply()}
    override fun onDestroy(){stopCapture();super.onDestroy()}
}

private class VerticalFader(context: Context) : View(context) {
    var value: Int = 0
        private set
    var onValueChanged: ((Int, Boolean) -> Unit)? = null
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBFC5D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f
    }
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    fun setValue(newValue: Int, fromUser: Boolean = false) {
        val v = newValue.coerceIn(-24, 24)
        if (value != v) {
            value = v
            invalidate()
            onValueChanged?.invoke(v, fromUser)
        } else if (fromUser) onValueChanged?.invoke(v, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = d(8f)
        val bottom = height - d(8f)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val y = center - (value / 24f) * half
        val rail = RectF(cx - d(5f), top, cx + d(5f), bottom)
        trackPaint.shader = LinearGradient(rail.left, 0f, rail.right, 0f,
            intArrayOf(0xFF050A14.toInt(), 0xFF25364E.toInt(), 0xFF050A14.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rail, d(5f), d(5f), trackPaint)
        fillPaint.color = 0xFF168DFF.toInt()
        if (value >= 0) canvas.drawRoundRect(RectF(cx - d(3f), y, cx + d(3f), center), d(3f), d(3f), fillPaint)
        else canvas.drawRoundRect(RectF(cx - d(3f), center, cx + d(3f), y), d(3f), d(3f), fillPaint)
        val thumbHalf = (width * 0.43f).coerceAtMost(d(12f)).coerceAtLeast(d(5f))
        val thumb = RectF(cx - thumbHalf, y - d(10f), cx + thumbHalf, y + d(10f))
        thumbPaint.shader = LinearGradient(thumb.left, thumb.top, thumb.right, thumb.bottom,
            intArrayOf(0xFFF0F1F4.toInt(), 0xFFBFC3CC.toInt(), 0xFFE4E6EA.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(thumb, d(11f), d(11f), thumbPaint)
        canvas.drawRoundRect(thumb, d(11f), d(11f), borderPaint)
    }

    private fun updateFromY(y: Float) {
        val top = d(8f)
        val bottom = height - d(8f)
        val clamped = y.coerceIn(top, bottom)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        setValue((24f * (center - clamped) / half).roundToInt(), true)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                updateFromY(event.y)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}


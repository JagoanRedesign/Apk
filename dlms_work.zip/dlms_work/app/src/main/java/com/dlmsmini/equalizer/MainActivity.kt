package com.dlmsmini.equalizer

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private var bandCount = Bands.DEFAULT
    private var layout: BandLayout = Bands.forCount(Bands.DEFAULT)
    private var bandHost: FrameLayout? = null
    private var eqTitle: TextView? = null

    // Nilai dalam satuan 0,5 dB. Normal: -24..24 (±12 dB). Kekuatan Penuh: -44..44 (±22 dB).
    // Jumlah elemen = jumlah band aktif (5/10/13/15/21/31).
    private var values = IntArray(Bands.DEFAULT)
    // EQ kiri/kanan terpisah: [values] = kurva KIRI (dan kurva stereo bila chSplit = false), [valuesR] = kurva KANAN.
    private var valuesR = IntArray(Bands.DEFAULT)
    private var chSplit = false
    private var editCh = 0 // kanal yang sedang diedit fader (0 = kiri, 1 = kanan); hanya berarti bila chSplit
    private var themeVersion = Pal.version
    private var chipStereo: TextView? = null
    private var chipL: TextView? = null
    private var chipR: TextView? = null
    private var chipCopyLR: TextView? = null
    private var chipCopyRL: TextView? = null
    private var channelHint: TextView? = null
    private val faders = mutableListOf<VerticalFader>()
    private var visualizer: Visualizer? = null
    private var visualizerSession = -2
    private var service: EqualizerService? = null
    private var bound = false
    private val handler = Handler(Looper.getMainLooper())
    private var hintRunnable: Runnable? = null
    private var hintShown = false
    private var sessionHint: TextView? = null
    private var eqSwitch: Switch? = null
    private var sessionMode = false
    private var bgService = true
    private var created = false
    private var spectrumView: SpectrumView? = null
    private var spectrumGroup: LinearLayout? = null
    private var status: TextView? = null
    private var modeInfo: TextView? = null
    private var rangeLabel: TextView? = null
    private var presetHost: LinearLayout? = null

    private var effectsEnabled = true
    private var eqMode = "1WAY"
    private var fullPower = false
    private var pipeline = Store.PIPE_STANDARD
    private var spectrumOn = true
    private var keepScreen = false
    private var askedAudioPermission = false
    private var limiter = LimiterSettings()
    private var master = MasterSettings()
    private var eqLimit = 12
    private var strip: MasterStrip? = null
    private var historyHost: LinearLayout? = null
    private val volRefreshers = mutableListOf<() -> Unit>()
    private var notifPending = false
    private var updateDialog: AlertDialog? = null
    private val TAB_LIMITER = 2
    private var peqSettings = PeqSettings()
    private var xoSettings = CrossoverSettings()
    private var peqPanel: PeqPanel? = null
    private var xoPanel: CrossoverPanel? = null
    private var meterView: MeterView? = null

    /** Tampilkan dialog pembaruan dari hasil terakhir (cache). Wajib = tidak bisa ditutup. */
    private fun showUpdateDialog() {
        val st = UpdateChecker.state(this) ?: return
        if (!st.available || isFinishing || isDestroyed) return
        if (updateDialog?.isShowing == true) return
        if (!st.forced && UpdateChecker.skipped(this) == st.latestCode) return
        val name = if (st.latestName.isNotEmpty()) st.latestName else st.latestCode.toString()
        val msg = buildString {
            append(if (st.forced) "Versi ${UpdateChecker.installedName(this@MainActivity)} sudah tidak didukung. Pasang versi $name untuk melanjutkan."
                   else "Versi $name tersedia (terpasang: ${UpdateChecker.installedName(this@MainActivity)}).")
            if (st.message.isNotEmpty()) append("\n\n").append(st.message)
            if (st.notes.isNotEmpty()) append("\n\n").append(st.notes)
        }
        val b = AlertDialog.Builder(this)
            .setTitle(if (st.forced) "Pembaruan wajib" else "Pembaruan tersedia")
            .setMessage(msg)
            .setCancelable(!st.forced)
            .setPositiveButton("Perbarui", null)
        if (!st.forced) b.setNegativeButton("Nanti") { _, _ -> UpdateChecker.skip(this, st.latestCode) }
        val d = b.create()
        d.show()
        // Tombol dipasang ulang agar dialog wajib tidak menutup sendiri saat Perbarui diketuk.
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (!UpdateChecker.openDownload(this, st)) Toast.makeText(this, "Tautan unduhan tidak tersedia", Toast.LENGTH_LONG).show()
            else if (!st.forced) d.dismiss()
        }
        updateDialog = d
    }

    private fun checkForUpdates() {
        showUpdateDialog()
        if (!UpdateConfig.configured || !UpdateChecker.dueForCheck(this)) return
        Thread {
            val r = UpdateChecker.check(applicationContext)
            if (r.ok) {
                UpdateChecker.notifyIfNeeded(applicationContext)
                runOnUiThread { showUpdateDialog() }
            }
        }.start()
    }

    private val maxHalf: Int get() = if (fullPower) 44 else eqLimit * 2
    private val builtIns: List<String> = BuiltInPresets.names
    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        notifPending = false
        syncVisualizer()
    }

    /** Android 13+: izin notifikasi runtime (notifikasi layanan latar belakang). Ditanyakan sekali. */
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean(Store.KEY_ASKED_NOTIF, false)
        ) {
            prefs.edit().putBoolean(Store.KEY_ASKED_NOTIF, true).apply()
            notifPending = true
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            refreshStrip()
            handler.postDelayed(this, 3000)
        }
    }

    private fun refreshStrip() {
        val s = service
        strip?.update(master, s?.indicator(), s?.route?.let { it.label + if (it.name.isNotEmpty()) " (${it.name})" else "" }.orEmpty(),
            if (s != null && EqualizerService.lastFgError != null) "Layanan latar belakang ditolak sistem"
            else if (s != null && s.contested) "EQ/efek lain memegang kendali — matikan efek bawaan HP"
            else "")
    }

    private fun onMasterToggled(on: Boolean) {
        master = master.copy(on = on)
        Store.saveMaster(this, master)
        service?.updateMaster(master)
        refreshStrip()
    }
    private var lastClipped = false
    private val prefs by lazy { Store.prefs(this) }

    // Referensi UI limiter
    private var limiterCheck: CheckBox? = null
    private var limiterNote: TextView? = null
    private val limiterBars = mutableListOf<View>()
    private var limiterCurve: LimiterCurveView? = null
    private val limiterRefreshers = mutableListOf<() -> Unit>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadAppSettings()
        loadSettings()
        master = Store.loadMaster(this)
        buildUi()
        askNotificationPermission()
        UpdateScheduler.apply(this)
        if (bgService) EqualizerService.start(this)
        bound = bindService(Intent(this, EqualizerService::class.java), connection, Context.BIND_AUTO_CREATE)
        created = true
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as? EqualizerService.LocalBinder)?.service ?: return
            service = s
            s.onChanged = { runOnUiThread { onServiceChanged() } }
            s.reload()
            onServiceChanged()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service?.onChanged = null
            service = null
        }
    }

    override fun onResume() {
        super.onResume()
        if (themeVersion != Pal.version) { recreate(); return } // tema diganti di Setelan: bangun ulang dengan warna baru
        val oldMax = maxHalf
        loadAppSettings()
        syncFromPrefs()
        if (oldMax != maxHalf) applyRange()
        if (bgService) EqualizerService.start(this)
        spectrumGroup?.visibility = if (spectrumOn) View.VISIBLE else View.GONE
        if (keepScreen) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        master = Store.loadMaster(this)
        volRefreshers.forEach { it() }
        service?.reload()
        onServiceChanged()
        syncVisualizer()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 3000)
        checkForUpdates()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        hintRunnable?.let { handler.removeCallbacks(it) }
        hintRunnable = null
        stopVisualizer()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopVisualizer()
        service?.onChanged = null
        if (bound) { try { unbindService(connection) } catch (_: Exception) {} ; bound = false }
        service = null
        super.onDestroy()
    }

    // ---------- EQ kiri/kanan ----------
    /** Kurva yang sedang diedit fader. */
    private fun editValues(): IntArray = if (chSplit && editCh == 1) valuesR else values

    /** Kirim kurva (dan mode kanal) ke layanan. */
    private fun pushEq() { service?.updateEq(effectsEnabled, values, valuesR, chSplit) }

    private fun faderColor(): Int = when {
        !chSplit -> 0xFF168DFF.toInt()
        editCh == 0 -> 0xFFFF7A59.toInt() // kiri = oranye (sama dengan tab 2-Way)
        else -> 0xFFB07CFF.toInt()        // kanan = ungu
    }

    private fun refreshFaders() {
        val src = editValues()
        val col = faderColor()
        faders.forEachIndexed { i, f ->
            f.fillColor = col
            if (i < src.size) f.setValue(src[i], false)
            f.invalidate()
        }
    }

    private fun setChannelMode(split: Boolean, ch: Int) {
        if (split && !chSplit && !Bands.hasR(prefs, bandCount)) valuesR = values.copyOf() // pertama kali: kanan = kiri
        chSplit = split
        editCh = if (split) ch else 0
        saveSettings()
        refreshChannelUi()
        refreshFaders()
        pushEq()
    }

    private fun copyChannel(from: Int, to: Int) {
        if (!chSplit) return
        val src = if (from == 0) values else valuesR
        val dst = if (to == 0) values else valuesR
        src.copyInto(dst)
        saveSettings()
        refreshFaders()
        pushEq()
        Toast.makeText(this, if (from == 0) "Kurva kiri disalin ke kanan" else "Kurva kanan disalin ke kiri", Toast.LENGTH_SHORT).show()
    }

    private fun refreshChannelUi() {
        chipStereo?.let { Ui.setChipSelected(it, !chSplit) }
        chipL?.let { Ui.setChipSelected(it, chSplit && editCh == 0) }
        chipR?.let { Ui.setChipSelected(it, chSplit && editCh == 1) }
        val a = if (chSplit) 1f else 0.4f
        chipCopyLR?.alpha = a
        chipCopyRL?.alpha = a
        val hint = channelHint
        if (hint != null) {
            val s = service
            when {
                !chSplit -> {
                    hint.text = "Satu kurva untuk kiri dan kanan. Pilih L atau R untuk mengatur tiap kanal sendiri."
                    hint.setTextColor(Pal.MUTED)
                }
                s != null && effectsEnabled && !s.channelEqActive -> {
                    hint.text = "Perangkat/pipeline ini tidak mendukung EQ per kanal: kurva kiri dan kanan dirata-ratakan."
                    hint.setTextColor(c(0xFFFFB86B))
                }
                else -> {
                    hint.text = if (editCh == 0) "Mengedit kanal KIRI (oranye) • EQ L/R terpisah aktif" else "Mengedit kanal KANAN (ungu) • EQ L/R terpisah aktif"
                    hint.setTextColor(Pal.MUTED)
                }
            }
        }
        updateModeLabels()
    }

    private fun buildChannelRow(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(3), dp(8), dp(3), dp(2)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun chip(text: String, action: () -> Unit): TextView = Ui.chip(this, text, false).apply { setOnClickListener { action() } }
        chipStereo = chip("STEREO") { setChannelMode(false, 0) }
        chipL = chip("L") { setChannelMode(true, 0) }
        chipR = chip("R") { setChannelMode(true, 1) }
        chipCopyLR = chip("L→R") { copyChannel(0, 1) }
        chipCopyRL = chip("R→L") { copyChannel(1, 0) }
        listOf(chipStereo, chipL, chipR, chipCopyLR, chipCopyRL).forEach { c ->
            row.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) })
        }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        channelHint = label("", 9f, Pal.MUTED).apply { setPadding(dp(2), dp(6), dp(2), 0) }
        box.addView(channelHint)
        return box
    }

    // ---------- helpers UI ----------
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun c(v: Long) = Pal.c(v)
    private fun rounded(color: Int, radius: Int, stroke: Int = 0) = Ui.rounded(this, color, radius, stroke)
    private fun label(value: String, size: Float = 13f, tint: Int = c(0xFFCACAD2), bold: Boolean = false) =
        Ui.label(this, value, size, tint, bold)

    private fun makeCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(c(0xFF242426), 22, c(0xFF303034))
    }

    private fun section(parent: LinearLayout, title: String) {
        val t = label(title, 14f, c(0xFFE7E7ED), true)
        t.setPadding(dp(2), dp(22), dp(2), dp(10))
        parent.addView(t)
    }

    private fun panelCard(pad: Int = 10): LinearLayout = makeCard().apply {
        background = rounded(Pal.PANEL, 18, Pal.PANEL_STROKE)
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    // ---------- UI utama ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
        }
        tabGroups = Array(6) { LinearLayout(this).apply { orientation = LinearLayout.VERTICAL } }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(20))
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(12))
            background = rounded(Pal.PANEL, 20, Pal.PANEL_STROKE)
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("DLMS", 23f, c(0xFFF3F6FF), true))
        brand.addView(label("MINI EQUALIZER", 10f, c(0xFF35B8FF), true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val modeGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            background = rounded(c(0xFF080F1D), 18, c(0xFF31486B))
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val tint = ColorStateList.valueOf(c(0xFF28AFFF))
        val one = RadioButton(this).apply {
            text = "1-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = tint
            setPadding(dp(5), 0, dp(5), 0)
        }
        val two = RadioButton(this).apply {
            text = "2-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = tint
            setPadding(dp(5), 0, dp(5), 0)
        }
        modeGroup.addView(one); modeGroup.addView(two)
        modeGroup.check(if (eqMode == "2WAY") two.id else one.id)
        modeGroup.setOnCheckedChangeListener { _, id ->
            eqMode = if (id == two.id) "2WAY" else "1WAY"
            updateModeLabels(); saveSettings()
            service?.reload()
        }
        header.addView(modeGroup)
        val music = TextView(this).apply {
            text = "♫"; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(c(0xFF45C3FF))
            setPadding(dp(8), dp(2), dp(8), dp(2))
            isClickable = true
            contentDescription = "DLMS Music"
            setOnClickListener { startActivity(Intent(this@MainActivity, MusicActivity::class.java)) }
        }
        header.addView(music)
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(c(0xFFCFE6FF))
            setPadding(dp(12), dp(2), dp(8), dp(2))
            isClickable = true
            contentDescription = "Pengaturan"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        header.addView(gear)
        content.addView(header)
        strip = MasterStrip(this, master, { on -> onMasterToggled(on) }, { startActivity(Intent(this, DiagnosticsActivity::class.java)) })
        content.addView(strip!!.view, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        // Spectrum analyzer 2.0
        val spectrum = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        section(spectrum, "SPECTRUM")
        val spectrumCard = panelCard()
        val spectrumHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        spectrumHeader.addView(label("●  AUDIO ANALYZER  20 Hz – 20 kHz", 11f, c(0xFF48C5FF), true), LinearLayout.LayoutParams(0, -2, 1f))
        spectrumHeader.addView(label("LIVE", 9f, c(0xFF7BE3B0), true))
        spectrumCard.addView(spectrumHeader)
        val sv = SpectrumView(this).apply {
            mode = SpectrumView.Mode.values().getOrElse(prefs.getInt(Store.KEY_SPEC_MODE, 0)) { SpectrumView.Mode.BAR }
            peakHold = prefs.getBoolean(Store.KEY_SPEC_PEAK, true)
            smoothing = prefs.getInt(Store.KEY_SPEC_SMOOTH, 1).coerceIn(0, 2)
        }
        spectrumView = sv
        spectrumCard.addView(sv, LinearLayout.LayoutParams(-1, dp(150)))
        val specControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        val modeChips = SpectrumView.Mode.values().map { m -> m to Ui.chip(this, m.name, m == sv.mode) }
        modeChips.forEach { (m, chip) ->
            chip.setOnClickListener {
                sv.mode = m
                prefs.edit().putInt(Store.KEY_SPEC_MODE, m.ordinal).apply()
                modeChips.forEach { (mm, cc) -> Ui.setChipSelected(cc, mm == m) }
            }
            specControls.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) })
        }
        val peakChip = Ui.chip(this, "PEAK", sv.peakHold)
        peakChip.setOnClickListener {
            sv.peakHold = !sv.peakHold
            prefs.edit().putBoolean(Store.KEY_SPEC_PEAK, sv.peakHold).apply()
            Ui.setChipSelected(peakChip, sv.peakHold)
        }
        specControls.addView(peakChip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) })
        val smoothNames = arrayOf("SMOOTH −", "SMOOTH ●", "SMOOTH +")
        val smoothChip = Ui.chip(this, smoothNames[sv.smoothing], true)
        smoothChip.setOnClickListener {
            sv.smoothing = (sv.smoothing + 1) % 3
            prefs.edit().putInt(Store.KEY_SPEC_SMOOTH, sv.smoothing).apply()
            smoothChip.text = smoothNames[sv.smoothing]
        }
        specControls.addView(smoothChip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) })
        val fftChip = Ui.chip(this, fftChipText(), true)
        fftChip.setOnClickListener {
            val sizes = fftSizes()
            val cur = currentFft()
            val next = sizes.firstOrNull { it > cur } ?: sizes.first()
            prefs.edit().putInt(Store.KEY_SPEC_FFT, next).apply()
            fftChip.text = fftChipText()
            stopVisualizer()
            syncVisualizer()
        }
        specControls.addView(fftChip)
        spectrumCard.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(specControls) })
        spectrum.addView(spectrumCard)
        spectrumGroup = spectrum
        spectrum.visibility = if (spectrumOn) View.VISIBLE else View.GONE
        tabGroups[0].addView(spectrum)

        status = label("Menyiapkan audio…", 10f, c(0xFF80DDB5))
        status?.setPadding(dp(3), dp(6), dp(3), 0)
        content.addView(status)

        sessionHint = label("", 10f, c(0xFFFFB86B), true).apply {
            setPadding(dp(3), dp(4), dp(3), 0)
            visibility = View.GONE
            isClickable = true
            setOnClickListener { showSessionDialog() }
        }
        content.addView(sessionHint)

        // Equalizer
        section(tabGroups[0], "${layout.count}-BAND EQUALIZER")
        eqTitle = tabGroups[0].getChildAt(tabGroups[0].childCount - 1) as? TextView
        val eqCard = panelCard().apply { setPadding(dp(7), dp(10), dp(7), dp(10)) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val enabled = Switch(this).apply {
            text = "EQ aktif"; textSize = 11f; setTextColor(c(0xFFEAF0FF))
            isChecked = effectsEnabled
        }
        eqSwitch = enabled
        enabled.setOnCheckedChangeListener { _, checked ->
            effectsEnabled = checked
            pushEq()
            service?.updateLimiter(limiter, effectsEnabled)
            status?.text = if (checked) "Equalizer aktif" else "Equalizer nonaktif"
            saveSettings()
        }
        controls.addView(enabled, LinearLayout.LayoutParams(0, -2, 1f))
        modeInfo = label("", 9f, Pal.MUTED)
        controls.addView(modeInfo)
        eqCard.addView(controls)
        eqCard.addView(buildChannelRow())

        bandHost = FrameLayout(this)
        eqCard.addView(bandHost, LinearLayout.LayoutParams(-1, -2))
        rebuildBandRow()
        rangeLabel = label("", 9f, c(0xFF899AB5)).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) }
        eqCard.addView(rangeLabel)
        tabGroups[0].addView(eqCard)
        refreshChannelUi()
        updateRangeLabel()

        section(tabGroups[1], "PARAMETRIC EQ 2.0")
        peqPanel = PeqPanel(this, tabGroups[1], peqSettings) { st, done ->
            peqSettings = st
            service?.updatePeq(st)
            if (done) PeqStore.save(this, st)
        }
        buildLimiterCard(tabGroups[2])
        section(tabGroups[3], "CROSSOVER 2-WAY")
        xoPanel = CrossoverPanel(this, tabGroups[3], xoSettings, prefs.getBoolean(Store.KEY_XO_SWAP, false)) { x, sw, done ->
            xoSettings = x
            service?.updateCrossover(x, sw)
            if (done) {
                Store.saveCrossoverSettings(this, x)
                prefs.edit().putBoolean(Store.KEY_XO_SWAP, sw).apply()
                updateModeLabels()
            }
        }
        updateModeLabels()
        buildEffectsCards(tabGroups[4])
        buildPresetCard(tabGroups[5])
        tabGroups.forEach { content.addView(it) }

        val footer = label("Dibuat oleh Ilham Galeh", 11f, c(0xFF8294B2), true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(5))
        }
        content.addView(footer)
        scroll.addView(content)
        mainScroll = scroll
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildBottomBar(), LinearLayout.LayoutParams(-1, -2))
        Ui.fitSystemBars(root)
        setContentView(root)
        showTab(prefs.getInt(Store.KEY_TAB, 0).coerceIn(0, tabGroups.size - 1), remember = false)
    }


    /** Bangun deret fader sesuai jumlah band. 13, 15, 21, dan 31 band memakai layar geser horizontal. */
    private fun rebuildBandRow() {
        val host = bandHost ?: return
        host.removeAllViews()
        faders.clear()
        val wide = layout.count > 10
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        layout.labels.forEachIndexed { index, freq ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(1), 0, dp(1), 0)
            }
            column.addView(label(freq, 10f, c(0xFFDDE7F8), true).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-1, dp(25)))

            val plus = TextView(this).apply {
                text = "+"; textSize = 19f; gravity = Gravity.CENTER
                setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
                isClickable = true
            }
            column.addView(plus, LinearLayout.LayoutParams(-1, dp(30)).apply { setMargins(dp(1), dp(3), dp(1), dp(5)) })

            val valueText = label(formatDb(editValues()[index]), 9f, Pal.CYAN, true).apply { gravity = Gravity.CENTER }
            val fader = VerticalFader(this).apply {
                maxHalf = this@MainActivity.maxHalf
                fillColor = faderColor()
                setValue(editValues()[index])
                onValueChanged = { newValue, fromUser ->
                    val cur = editValues()
                    if (index < cur.size) cur[index] = newValue
                    valueText.text = formatDb(newValue)
                    if (fromUser) { pushEq(); saveSettings() }
                }
            }
            faders.add(fader)
            column.addView(fader, LinearLayout.LayoutParams(-1, dp(174)))

            val minus = TextView(this).apply {
                text = "−"; textSize = 19f; gravity = Gravity.CENTER
                setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
                isClickable = true
            }
            column.addView(minus, LinearLayout.LayoutParams(-1, dp(30)).apply { setMargins(dp(1), dp(5), dp(1), dp(4)) })
            column.addView(valueText, LinearLayout.LayoutParams(-1, dp(22)))
            plus.setOnClickListener { fader.setValue((fader.value + 1).coerceAtMost(fader.maxHalf), true) }
            minus.setOnClickListener { fader.setValue((fader.value - 1).coerceAtLeast(-fader.maxHalf), true) }
            row.addView(column, if (wide) LinearLayout.LayoutParams(dp(if (layout.count > 21) 40 else 46), -2) else LinearLayout.LayoutParams(0, -2, 1f))
        }
        if (wide) {
            val scroller = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(row)
            }
            host.addView(scroller, FrameLayout.LayoutParams(-1, -2))
        } else {
            host.addView(row, FrameLayout.LayoutParams(-1, -2))
        }
    }

    // ---------- Limiter ----------
    private fun buildLimiterCard(content: LinearLayout) {
        section(content, "LIMITER")
        val meterCard = panelCard(12)
        meterCard.addView(label("METER  (OUT terukur • IN* dan GR* estimasi dari kurva limiter)", 10f, Pal.MUTED, true))
        val mv = MeterView(this)
        meterView = mv
        meterCard.addView(mv, LinearLayout.LayoutParams(-1, dp(96)).apply { topMargin = dp(6) })
        meterCard.addView(label("Butuh izin rekam audio. Android tidak membuka sinyal sebelum efek, jadi IN dan GR dihitung dari level keluaran dan pengaturan limiter.", 9f, Pal.MUTED).apply { setPadding(0, dp(4), 0, 0) })
        content.addView(meterCard, LinearLayout.LayoutParams(-1, -2))

        val curveCard = panelCard(14)
        curveCard.addView(label("DYNAMIC LIMITER / COMP", 14f, c(0xFF2EE59D), true).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.1f
        })
        val curve = LimiterCurveView(this).apply {
            setParams(limiter.thresholdDb, limiter.ratio)
            onChange = { thr, ratio, done ->
                limiter = limiter.copy(thresholdDb = thr, ratio = ratio)
                limiterRefreshers.forEach { it() }
                onLimiterChanged(save = false)
                if (done) Store.saveLimiter(this@MainActivity, limiter)
            }
        }
        limiterCurve = curve
        curveCard.addView(curve, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        content.addView(curveCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val card = panelCard(14)
        card.setPadding(dp(14), dp(14), dp(14), dp(14))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val check = CheckBox(this).apply {
            text = "Limiter enabled"; textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(c(0xFFFFFFFF))
            buttonTintList = ColorStateList.valueOf(c(0xFF00CFFF))
            isChecked = limiter.enabled
        }
        limiterCheck = check
        check.setOnCheckedChangeListener { _, checked ->
            limiter = limiter.copy(enabled = checked)
            onLimiterChanged()
        }
        top.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
        val info = TextView(this).apply {
            text = "i"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(c(0xFFB5B5BA))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0)
                setStroke(dp(2), c(0xFF8E8E93))
            }
            isClickable = true
            contentDescription = "Info limiter"
            setOnClickListener { showLimiterInfo() }
        }
        top.addView(info, LinearLayout.LayoutParams(dp(32), dp(32)))
        card.addView(top)

        limiterNote = label("", 10f, c(0xFFFFB86B)).apply { setPadding(dp(4), dp(4), dp(4), 0); visibility = View.GONE }
        card.addView(limiterNote)

        limiterBars.clear(); limiterRefreshers.clear()
        limiterCurve?.let { limiterBars.add(it) }
        limiterRow(card, "Attack time", LimiterSpec.attack, { limiter.attackMs }) { limiter = limiter.copy(attackMs = it) }
        limiterRow(card, "Release time", LimiterSpec.release, { limiter.releaseMs }) { limiter = limiter.copy(releaseMs = it) }
        limiterRow(card, "Ratio", LimiterSpec.ratio, { limiter.ratio }) { limiter = limiter.copy(ratio = it) }
        limiterRow(card, "Threshold", LimiterSpec.threshold, { limiter.thresholdDb }) { limiter = limiter.copy(thresholdDb = it) }
        limiterRow(card, "Post-gain", LimiterSpec.postGain, { limiter.postGainDb }) { limiter = limiter.copy(postGainDb = it) }

        val reset = Ui.pill(this, "RESET LIMITER").apply { textSize = 12f; setPadding(dp(8), dp(11), dp(8), dp(11)) }
        reset.setOnClickListener {
            limiter = LimiterSettings(enabled = limiter.enabled)
            limiterRefreshers.forEach { it() }
            onLimiterChanged()
        }
        card.addView(reset, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        content.addView(card)
    }

    private fun limiterRow(card: LinearLayout, title: String, spec: Spec, get: () -> Float, set: (Float) -> Unit) {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(16), dp(4), 0)
        }
        head.addView(label(title, 15f, c(0xFFFFFFFF)), LinearLayout.LayoutParams(0, -2, 1f))
        val valueText = label(spec.format(get()), 13f, Pal.CYAN, true)
        head.addView(valueText)
        val tintList = ColorStateList.valueOf(c(0xFF00CFFF))
        val bar = SeekBar(this).apply {
            max = spec.steps
            progress = spec.toProgress(get())
            progressTintList = tintList
            thumbTintList = tintList
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = spec.toValue(p)
                    valueText.text = spec.format(v)
                    if (fromUser) { set(v); onLimiterChanged(save = false) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Store.saveLimiter(this@MainActivity, limiter) }
            })
        }
        card.addView(head)
        card.addView(bar, LinearLayout.LayoutParams(-1, -2))
        limiterBars.add(head); limiterBars.add(bar)
        limiterRefreshers.add {
            bar.progress = spec.toProgress(get())
            valueText.text = spec.format(get())
        }
    }

    private fun onLimiterChanged(save: Boolean = true) {
        if (save) Store.saveLimiter(this, limiter)
        service?.updateLimiter(limiter, effectsEnabled)
        refreshLimiterUi()
    }

    private fun refreshLimiterUi() {
        val usable = service?.limiterAvailable ?: (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
        limiterCheck?.isEnabled = usable
        val note = limiterNote
        if (note != null) {
            note.visibility = if (usable) View.GONE else View.VISIBLE
            note.text = "Limiter membutuhkan Android 9+ dan dukungan efek DynamicsProcessing pada perangkat."
        }
        limiterCurve?.setParams(limiter.thresholdDb, limiter.ratio)
        val alpha = if (limiter.enabled && usable) 1f else 0.45f
        limiterBars.forEach { it.alpha = alpha }
    }

    private fun showLimiterInfo() {
        val msg = "• Limiter enabled: mengaktifkan atau menonaktifkan pembatas audio.\n\n" +
            "• Attack time (waktu mulai): waktu yang dibutuhkan limiter untuk mulai bekerja setelah volume melewati batas (threshold).\n\n" +
            "• Release time (waktu lepas): waktu yang dibutuhkan limiter untuk berhenti bekerja dan mengembalikan volume ke normal setelah suara kembali di bawah batas.\n\n" +
            "• Ratio (rasio): seberapa kuat penekanan volume setelah sinyal melewati ambang batas.\n\n" +
            "• Threshold (ambang batas): level volume (dB) tempat limiter mulai memotong puncak suara agar tidak pecah.\n\n" +
            "• Post-gain (penguatan setelahnya): penyesuaian volume akhir (dB) setelah proses limiter, untuk menjaga loudness."
        AlertDialog.Builder(this).setTitle("Limiter").setMessage(msg).setPositiveButton("Tutup", null).show()
    }



    // ---------- Navigasi bawah ----------
    private class NavItem(val box: LinearLayout, val icon: TextView, val text: TextView)

    /** Font Awesome Free 6 (Solid) dari assets. Bila gagal dimuat, ikon disembunyikan dan label tetap tampil. */
    private val faTypeface: Typeface? by lazy {
        try { Typeface.createFromAsset(assets, "fonts/fa-solid-900.ttf") } catch (_: Exception) { null }
    }

    private var tabGroups: Array<LinearLayout> = emptyArray()
    private val navItems = mutableListOf<NavItem>()
    private var mainScroll: ScrollView? = null
    private var currentTab = 0

    private fun buildBottomBar(): View {
        navItems.clear()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Pal.PANEL)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        // Font Awesome Free 6 Solid: sliders, shield-halved, wand-magic-sparkles, floppy-disk, gear
        val entries = listOf("\uf1de" to "EQ", "\uf201" to "PEQ", "\uf3ed" to "Limiter", "\uf126" to "2-Way", "\ue2ca" to "Efek", "\uf0c7" to "Preset", "\uf013" to "Setelan")
        entries.forEachIndexed { i, entry ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(6), dp(2), dp(6))
                isClickable = true
                contentDescription = entry.second
            }
            val ic = TextView(this).apply {
                text = entry.first
                textSize = 16f
                gravity = Gravity.CENTER
                includeFontPadding = false
                setPadding(0, 0, 0, dp(2))
                val face = faTypeface
                if (face != null) typeface = face else visibility = View.GONE
            }
            val tx = label(entry.second, 10f, Pal.MUTED, true).apply { gravity = Gravity.CENTER }
            box.addView(ic)
            box.addView(tx)
            if (i < tabGroups.size) {
                navItems.add(NavItem(box, ic, tx))
                box.setOnClickListener { showTab(i) }
            } else {
                box.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
            }
            bar.addView(box, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(View(this).apply { setBackgroundColor(Pal.PANEL_STROKE) }, LinearLayout.LayoutParams(-1, dp(1)))
        wrap.addView(bar, LinearLayout.LayoutParams(-1, -2))
        return wrap
    }

    private fun showTab(index: Int, remember: Boolean = true) {
        if (tabGroups.isEmpty()) return
        currentTab = index.coerceIn(0, tabGroups.size - 1)
        tabGroups.forEachIndexed { i, g -> g.visibility = if (i == currentTab) View.VISIBLE else View.GONE }
        navItems.forEachIndexed { i, n ->
            val on = i == currentTab
            n.text.setTextColor(if (on) Pal.CYAN else Pal.MUTED)
            n.icon.alpha = if (on) 1f else 0.55f
            n.box.background = if (on) rounded(c(0xFF17304A), 14, c(0xFF304968)) else null
        }
        mainScroll?.scrollTo(0, 0)
        if (remember) prefs.edit().putInt(Store.KEY_TAB, currentTab).apply()
        syncVisualizer()
    }

    // ---------- Efek suara ----------
    private var fx = EffectSettings()
    private val fxRefreshers = mutableListOf<() -> Unit>()
    private var fxNote: TextView? = null

    private fun onFxChanged() {
        Store.saveEffects(this, fx)
        service?.updateEffects(fx)
        updateFxNote()
    }

    private fun updateFxNote() {
        val note = fxNote ?: return
        val issues = service?.fxIssues().orEmpty()
        if (issues.isEmpty()) {
            note.visibility = View.GONE
        } else {
            note.visibility = View.VISIBLE
            note.text = "Tidak berhasil diterapkan di perangkat/sesi ini: " + issues.joinToString(", ")
        }
    }

    private fun fxCard(content: LinearLayout, title: String, hint: String = ""): LinearLayout {
        val card = panelCard(14)
        card.addView(label(title, 16f, c(0xFFFFFFFF), true))
        if (hint.isNotEmpty()) {
            card.addView(label(hint, 11f, Pal.MUTED).apply { setPadding(0, dp(3), 0, dp(2)); setLineSpacing(0f, 1.1f) })
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        return card
    }

    private fun fxCheck(card: LinearLayout, title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val cb = CheckBox(this).apply {
            text = title; textSize = 15f
            setTextColor(c(0xFFFFFFFF))
            buttonTintList = ColorStateList.valueOf(c(0xFF00CFFF))
            isChecked = get()
        }
        cb.setOnCheckedChangeListener { _, checked ->
            set(checked)
            onFxChanged()
        }
        card.addView(cb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        fxRefreshers.add { if (cb.isChecked != get()) cb.isChecked = get() }
    }

    private fun fxSlider(card: LinearLayout, title: String, spec: Spec, get: () -> Float, set: (Float) -> Unit) {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(12), dp(4), 0)
        }
        head.addView(label(title, 14f, c(0xFFFFFFFF)), LinearLayout.LayoutParams(0, -2, 1f))
        val valueText = label(spec.format(get()), 13f, Pal.CYAN, true)
        head.addView(valueText)
        val tintList = ColorStateList.valueOf(c(0xFF00CFFF))
        val bar = SeekBar(this).apply {
            max = spec.steps
            progress = spec.toProgress(get())
            progressTintList = tintList
            thumbTintList = tintList
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = spec.toValue(p)
                    valueText.text = spec.format(v)
                    if (fromUser) { set(v); onFxChanged() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        card.addView(head)
        card.addView(bar, LinearLayout.LayoutParams(-1, -2))
        fxRefreshers.add {
            bar.progress = spec.toProgress(get())
            valueText.text = spec.format(get())
        }
    }

    private fun buildEffectsCards(content: LinearLayout) {
        section(content, "EFEK SUARA")
        fxRefreshers.clear()
        volRefreshers.clear()

        val volCard = fxCard(content, "Volume Kiri / Kanan",
            "Volume tiap kanal 0–100 (0 = senyap). Terpisah dari Balance dan Mute; butuh DynamicsProcessing (Android 9+).")
        volRefreshers += Ui.slider(this, volCard, "Volume kiri (L)", Spec(0f, 100f, 1f, 0, "%"), { master.volL.toFloat() },
            { master = master.copy(volL = it.toInt()); service?.updateMaster(master) }, { Store.saveMaster(this, master) })
        volRefreshers += Ui.slider(this, volCard, "Volume kanan (R)", Spec(0f, 100f, 1f, 0, "%"), { master.volR.toFloat() },
            { master = master.copy(volR = it.toInt()); service?.updateMaster(master) }, { Store.saveMaster(this, master) })
        val volReset = Ui.pill(this, "SAMAKAN 100%").apply { textSize = 12f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        volReset.setOnClickListener {
            master = master.copy(volL = 100, volR = 100)
            Store.saveMaster(this, master)
            volRefreshers.forEach { it() }
            service?.updateMaster(master)
        }
        volCard.addView(volReset, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        var card = fxCard(content, "Pre-amp & Balance",
            "Pre-amp mengatur level sebelum EQ (pakai Limiter bila dinaikkan). Balance menggeser suara ke kiri atau kanan; mute mematikan satu kanal.")
        fxSlider(card, "Pre-amp", FxSpec.preamp, { fx.preampDb }) { fx = fx.copy(preampDb = it) }
        fxSlider(card, "Balance", FxSpec.balance, { fx.balance.toFloat() }) { fx = fx.copy(balance = it.toInt()) }
        fxCheck(card, "Mute kiri", { fx.muteLeft }) { fx = fx.copy(muteLeft = it) }
        fxCheck(card, "Mute kanan", { fx.muteRight }) { fx = fx.copy(muteRight = it) }

        card = fxCard(content, "Bass Boost", "Penguat bass bawaan sistem. Dukungan bergantung perangkat.")
        fxCheck(card, "Bass Boost aktif", { fx.bassOn }) { fx = fx.copy(bassOn = it) }
        fxSlider(card, "Kekuatan", FxSpec.strength, { fx.bassPct.toFloat() }) { fx = fx.copy(bassPct = it.toInt()) }

        card = fxCard(content, "Virtualizer", "Memperlebar kesan stereo, paling terasa di headphone.")
        fxCheck(card, "Virtualizer aktif", { fx.virtOn }) { fx = fx.copy(virtOn = it) }
        fxSlider(card, "Kekuatan", FxSpec.strength, { fx.virtPct.toFloat() }) { fx = fx.copy(virtPct = it.toInt()) }

        card = fxCard(content, "Loudness", "Menaikkan kenyaringan keseluruhan tanpa mengubah kurva EQ.")
        fxCheck(card, "Loudness aktif", { fx.loudOn }) { fx = fx.copy(loudOn = it) }
        fxSlider(card, "Penguatan", FxSpec.loud, { fx.loudDb }) { fx = fx.copy(loudDb = it) }

        card = fxCard(content, "Reverb",
            "Efek ruang. Paling andal di Mode Sesi Aplikasi; pada Mix Global banyak perangkat tidak menerapkannya.")
        val reverbBtn = Ui.pill(this, "").apply { textSize = 13f }
        fun reverbText() = "Preset: " + FxSpec.REVERB_NAMES[fx.reverbPreset.coerceIn(0, FxSpec.REVERB_NAMES.lastIndex)]
        reverbBtn.text = reverbText()
        reverbBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Reverb")
                .setSingleChoiceItems(FxSpec.REVERB_NAMES.toTypedArray(), fx.reverbPreset) { d, which ->
                    fx = fx.copy(reverbPreset = which)
                    reverbBtn.text = reverbText()
                    onFxChanged()
                    d.dismiss()
                }
                .setNegativeButton("Batal", null).show()
        }
        fxRefreshers.add { reverbBtn.text = reverbText() }
        card.addView(reverbBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        card = fxCard(content, "Kompresor Multiband",
            "3 band (<250 Hz, 250–3000 Hz, >3000 Hz) dengan pengaturan sama. Merapikan dinamika dan menahan puncak per band. Butuh Android 9+.")
        fxCheck(card, "Kompresor aktif", { fx.mbcOn }) { fx = fx.copy(mbcOn = it) }
        fxSlider(card, "Threshold", FxSpec.mbcThreshold, { fx.mbcThresholdDb }) { fx = fx.copy(mbcThresholdDb = it) }
        fxSlider(card, "Ratio", FxSpec.mbcRatio, { fx.mbcRatio }) { fx = fx.copy(mbcRatio = it) }
        fxSlider(card, "Attack", FxSpec.mbcAttack, { fx.mbcAttackMs }) { fx = fx.copy(mbcAttackMs = it) }
        fxSlider(card, "Release", FxSpec.mbcRelease, { fx.mbcReleaseMs }) { fx = fx.copy(mbcReleaseMs = it) }
        fxSlider(card, "Makeup gain", FxSpec.mbcMakeup, { fx.mbcMakeupDb }) { fx = fx.copy(mbcMakeupDb = it) }

        card = fxCard(content, "Post-EQ (Tone)",
            "Kontrol nada 3 band setelah kompresor: Bass <250 Hz, Mid 250–4000 Hz, Treble >4000 Hz. Butuh Android 9+.")
        fxCheck(card, "Post-EQ aktif", { fx.toneOn }) { fx = fx.copy(toneOn = it) }
        fxSlider(card, "Bass", FxSpec.tone, { fx.toneLowDb }) { fx = fx.copy(toneLowDb = it) }
        fxSlider(card, "Mid", FxSpec.tone, { fx.toneMidDb }) { fx = fx.copy(toneMidDb = it) }
        fxSlider(card, "Treble", FxSpec.tone, { fx.toneHighDb }) { fx = fx.copy(toneHighDb = it) }

        val reset = Ui.pill(this, "RESET SEMUA EFEK").apply { textSize = 12f; setPadding(dp(8), dp(11), dp(8), dp(11)) }
        reset.setOnClickListener {
            fx = EffectSettings()
            fxRefreshers.forEach { it() }
            onFxChanged()
            Toast.makeText(this, "Semua efek direset", Toast.LENGTH_SHORT).show()
        }
        content.addView(reset, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        fxNote = label("", 10f, c(0xFFFFB86B), true).apply { setPadding(dp(3), dp(8), dp(3), 0); visibility = View.GONE }
        content.addView(fxNote)
    }

    // ---------- Profil headphone & notifikasi preset ----------
    private val headphoneProfiles = linkedMapOf(
        "Netral (referensi)" to intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        "Earbud / bass lemah" to intArrayOf(8, 6, 4, 2, 0, 0, 0, 0, 1, 1),
        "TWS ringan" to intArrayOf(6, 5, 3, 1, 0, 0, 1, 1, 0, 0),
        "Over-ear V-shape (netralkan)" to intArrayOf(-4, -3, -1, 0, 1, 2, 1, 0, -2, -3),
        "In-ear treble tajam" to intArrayOf(0, 0, 0, 0, 0, 0, -1, -3, -5, -4),
        "Mid terkubur" to intArrayOf(0, 0, 0, 1, 3, 4, 3, 2, 0, 0)
    )

    private fun showHeadphoneProfiles() {
        val names = headphoneProfiles.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("Profil headphone (generik)")
            .setItems(names) { _, i ->
                setAllValues(headphoneProfiles.getValue(names[i]))
                notifyPreset("Profil ${names[i]}")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Beri tahu pengguna bahwa preset/profil sedang digunakan. */
    private fun notifyPreset(name: String, extra: String = "") {
        var text = "Preset \"$name\" digunakan" + extra
        if (lastClipped) text += ". Sebagian nilai dipotong ke ±${maxHalf / 2} dB (aktifkan Kekuatan Penuh di Pengaturan untuk nilai penuh)"
        status?.text = text
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    // ---------- Preset ----------
    private fun buildPresetCard(content: LinearLayout) {
        section(content, "PRESET MUSIK")
        val presetCard = panelCard()
        presetCard.addView(label("Terakhir dipakai", 11f, Pal.MUTED, true).apply { setPadding(dp(3), 0, 0, dp(6)) })
        val hHost = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        historyHost = hHost
        presetCard.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(hHost) })
        val host = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        presetHost = host
        presetCard.addView(host)
        presetCard.addView(label("Tahan lama preset kustom untuk menghapus", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
        })

        fun actionRow(vararg pairs: Pair<String, () -> Unit>) {
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pairs.forEach { (text, action) ->
                val b = Ui.pill(this, text).apply { textSize = 12f; setPadding(dp(6), dp(12), dp(6), dp(12)) }
                b.setOnClickListener { action() }
                actions.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            presetCard.addView(actions)
        }
        actionRow("SIMPAN PRESET" to { saveCustomPreset() }, "RESET FLAT" to { applyPreset("Flat") })
        actionRow("EXPORT" to { exportPresets() }, "IMPORT" to { importPresets() })
        actionRow("PROFIL HEADPHONE (GENERIK)" to { showHeadphoneProfiles() })
        content.addView(presetCard)
        rebuildHistory()
        rebuildPresetGrid()
    }

    private fun rebuildHistory() {
        val host = historyHost ?: return
        host.removeAllViews()
        val items = PresetHistory.list(this).take(6)
        if (items.isEmpty()) {
            host.addView(label("Belum ada preset yang dipakai", 10f, c(0xFF899AB5)).apply { setPadding(dp(3), dp(4), 0, dp(4)) })
            return
        }
        items.forEach { e ->
            val chip = Ui.chip(this, e.name, false)
            chip.setOnClickListener { if (e.custom) applySavedPreset(e.name) else applyPreset(e.name) }
            host.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
    }

    private fun rebuildPresetGrid() {
        val host = presetHost ?: return
        host.removeAllViews()
        val all = builtIns.map { it to false } + PresetStore.names(this).map { it to true }
        all.chunked(3).forEach { rowItems ->
            val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { (name, custom) ->
                val button = TextView(this).apply {
                    text = name; textSize = 11f; gravity = Gravity.CENTER
                    setTextColor(c(0xFFE5EDFF))
                    background = rounded(if (custom) c(0xFF17304A) else c(0xFF1B2638), 12, c(0xFF304968))
                    setPadding(dp(3), dp(11), dp(3), dp(11))
                    isClickable = true
                    setOnClickListener { if (custom) applySavedPreset(name) else applyPreset(name) }
                    if (custom) setOnLongClickListener { confirmDelete(name); true }
                }
                presetRow.addView(button, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            repeat(3 - rowItems.size) { presetRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            host.addView(presetRow)
        }
    }

    private fun confirmDelete(name: String) {
        AlertDialog.Builder(this).setTitle("Hapus preset").setMessage("Hapus preset \"$name\"?")
            .setPositiveButton("Hapus") { _, _ -> PresetStore.delete(this, name); rebuildPresetGrid() }
            .setNegativeButton("Batal", null).show()
    }

    private fun applyPreset(name: String) {
        val preset = BuiltInPresets.find(name) ?: return
        setAllValues(preset.values)
        applyLimiterPreset(preset.limiter)
        applyEffectsPreset(preset.effects)
        PresetHistory.record(this, name, false)
        rebuildHistory()
        notifyPreset(name, " (EQ + limiter + efek)")
    }

    private fun applySavedPreset(name: String) {
        val saved = PresetStore.get(this, name)
        if (saved == null) {
            Toast.makeText(this, "Preset tidak dapat dibaca", Toast.LENGTH_SHORT).show()
            PresetHistory.remove(this, name, true)
            rebuildHistory()
            return
        }
        PresetHistory.record(this, name, true)
        rebuildHistory()
        setAllValues(saved.values, saved.valuesR)
        saved.limiter?.let { applyLimiterPreset(it) }
        saved.effects?.let { applyEffectsPreset(it) }
        saved.peq?.let { applyPeqPreset(it) }
        val parts = mutableListOf(if (saved.valuesR != null) "EQ L/R" else "EQ")
        if (saved.limiter != null) parts.add("limiter")
        if (saved.effects != null) parts.add("efek")
        if (saved.peq != null) parts.add("PEQ")
        notifyPreset(name, if (parts.size > 1) " (" + parts.joinToString(" + ") + ")" else "")
    }

    private fun applyPeqPreset(p: PeqSettings) {
        peqSettings = p
        PeqStore.save(this, p)
        peqPanel?.set(p)
        service?.updatePeq(p)
    }

    /** Terapkan semua efek yang tersimpan di dalam preset. */
    private fun applyEffectsPreset(f: EffectSettings) {
        fx = f
        fxRefreshers.forEach { it() }
        onFxChanged()
    }

    /** Terapkan pengaturan limiter yang tersimpan di dalam preset. */
    private fun applyLimiterPreset(l: LimiterSettings) {
        limiter = l
        limiterCheck?.let { if (it.isChecked != l.enabled) it.isChecked = l.enabled }
        limiterRefreshers.forEach { it() }
        Store.saveLimiter(this, limiter)
        service?.updateLimiter(limiter, effectsEnabled)
        refreshLimiterUi()
    }

    /**
     * Terapkan kurva preset. [right] = kurva kanan untuk preset EQ L/R terpisah; null = preset stereo
     * (mode kanal kembali ke STEREO, kurva kanan tersimpan tidak diubah).
     */
    private fun setAllValues(preset: IntArray, right: IntArray? = null) {
        val target = if (preset.size == values.size) preset else Bands.resample(preset, layout)
        lastClipped = false
        for (i in values.indices) {
            val v = target[i].coerceIn(-maxHalf, maxHalf)
            if (v != target[i]) lastClipped = true
            values[i] = v
        }
        if (right != null) {
            val tr = if (right.size == valuesR.size) right else Bands.resample(right, layout)
            for (i in valuesR.indices) {
                val v = tr[i].coerceIn(-maxHalf, maxHalf)
                if (v != tr[i]) lastClipped = true
                valuesR[i] = v
            }
            chSplit = true
        } else {
            chSplit = false
            editCh = 0
        }
        refreshChannelUi()
        refreshFaders()
        pushEq()
        saveSettings()
    }

    private fun saveCustomPreset() {
        val input = EditText(this).apply { hint = "Nama preset"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Simpan preset").setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = PresetCodec.cleanName(input.text.toString()).ifBlank { "Preset Saya" }
                if (builtIns.any { it.equals(name, ignoreCase = true) }) {
                    Toast.makeText(this, "Nama itu dipakai preset bawaan", Toast.LENGTH_SHORT).show()
                } else {
                    PresetStore.save(this, name, values, limiter, fx, peqSettings, if (chSplit) valuesR else null)
                    rebuildPresetGrid()
                    Toast.makeText(this, "Preset $name disimpan (" + (if (chSplit) "EQ L/R" else "EQ") + " + limiter + efek + PEQ)", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun exportPresets() {
        val saved = PresetStore.names(this).mapNotNull { n -> PresetStore.get(this, n)?.let { PresetCodec.Item(n, it.values, it.limiter, it.effects, it.peq, it.valuesR) } }
        val items = if (saved.isEmpty()) listOf(PresetCodec.Item("Preset Saya", values.copyOf(), limiter, fx, peqSettings, if (chSplit) valuesR.copyOf() else null)) else saved
        PresetDialogs.showExport(this, PresetCodec.export(items))
    }

    private fun importPresets() {
        PresetDialogs.showImport(this) { items ->
            items.forEach { item ->
                var name = item.name
                if (builtIns.any { it.equals(name, ignoreCase = true) }) name = PresetCodec.cleanName("$name (impor)")
                PresetStore.save(this, name, item.values, item.limiter, item.effects, item.peq, item.valuesR)
            }
            rebuildPresetGrid()
            Toast.makeText(this, "${items.size} preset diimpor", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Audio ----------
    private fun formatDb(value: Int): String = String.format(java.util.Locale.US, "%.1f dB", value / 2f)

    private fun updateModeLabels() {
        val x = Store.loadCrossoverSettings(prefs)
        val swap = prefs.getBoolean(Store.KEY_XO_SWAP, false)
        val sm = service?.splitMode
        val suffix = when (sm) {
            AudioEngine.SPLIT_EQ -> " (pendekatan EQ)"
            AudioEngine.SPLIT_MBC -> " (slope tetap)"
            AudioEngine.SPLIT_FAIL -> " (tidak didukung)"
            else -> ""
        }
        val text = if (eqMode == "2WAY")
            (if (swap) "2-Way: Kiri = HIGH (>${x.freqHz} Hz) • Kanan = LOW" else "2-Way: Kiri = LOW (<${x.freqHz} Hz) • Kanan = HIGH") + suffix
        else
            "1-Way aktif • " + (if (chSplit) "EQ kiri/kanan terpisah" else "Semua frekuensi dalam satu kurva")
        modeInfo?.text = text
        xoPanel?.setInfo(
            (if (eqMode == "2WAY") "● 2-WAY AKTIF — " else "○ 1-Way (pilih 2-Way di header) — ") +
                "${x.freqHz} Hz, ${x.slopeDbOct} dB/okt" + suffix + "  (oranye = kiri, ungu = kanan)"
        )
    }

    private fun updateRangeLabel() {
        val r = maxHalf / 2
        rangeLabel?.text = "−$r dB     0 dB     +$r dB   •   Langkah 0,5 dB"
    }

    private fun applyRange() {
        faders.forEach { it.setMax(maxHalf) }
        updateRangeLabel()
        saveSettings()
    }

    /** Dipanggil saat layanan terhubung atau status/sesi berubah. */
    private fun onServiceChanged() {
        val s = service ?: return
        status?.text = s.status
        master = Store.loadMaster(this)
        refreshStrip()
        updateModeLabels()
        refreshLimiterUi()
        updateSessionHint(s)
        updateFxNote()
        refreshChannelUi()
        peqPanel?.setSupport(s.peqSupported, peqSettings.active)
        syncVisualizer()
    }

    private fun updateSessionHint(s: EqualizerService) {
        val hint = sessionHint ?: return
        if (!s.isSessionMode) {
            hint.visibility = View.GONE
            return
        }
        hint.visibility = View.VISIBLE
        if (s.sessionCount > 0) {
            hint.setTextColor(c(0xFF7BE3B0))
            hint.text = "Mode Sesi Aplikasi • sesi aktif: " + s.sessionPackages.joinToString(", ")
        } else {
            hint.setTextColor(c(0xFFFFB86B))
            hint.text = "Mode Sesi Aplikasi aktif, belum ada pemutar terdeteksi — ketuk untuk info"
            if (!hintShown && hintRunnable == null) {
                val r = Runnable {
                    hintRunnable = null
                    val cur = service
                    if (!hintShown && cur != null && cur.isSessionMode && cur.sessionCount == 0) {
                        hintShown = true
                        showSessionDialog()
                    }
                }
                hintRunnable = r
                handler.postDelayed(r, 6000)
            }
        }
    }

    private fun showSessionDialog() {
        val msg = "Mode Sesi Aplikasi aktif, tetapi belum ada aplikasi yang disetujui mengirim sinyal putar baru-baru ini — " +
            "equalizer belum diterapkan ke pemutar mana pun.\n\n" +
            "Tips:\n" +
            "• Buka DLMS Mini Equalizer sebelum membuka aplikasi musik Anda\n" +
            "• Pastikan aplikasi diizinkan di Pengaturan › Kelola aplikasi terdeteksi\n" +
            "• Tekan putar/jeda di dalam aplikasi musik untuk memicu deteksi\n\n" +
            "Aplikasi tidak didukung? Beralih ke mode Standar (Mix Global): berfungsi dengan semua aplikasi, " +
            "dengan beberapa batasan pada Android Auto."
        AlertDialog.Builder(this).setTitle("Sesi audio").setMessage(msg)
            .setPositiveButton("Oke", null)
            .setNeutralButton("Beralih ke Mix Global") { _, _ ->
                prefs.edit().putBoolean(Store.KEY_SESSION_MODE, false).apply()
                loadAppSettings()
                service?.reload()
                onServiceChanged()
            }
            .show()
    }

    /** Muat ulang nilai dari penyimpanan setelah kembali dari Pengaturan (mis. setelah reset). */
    private fun syncFromPrefs() {
        if (!created) return
        val oldBands = bandCount
        loadSettings()
        if (bandCount != oldBands) {
            eqTitle?.text = "${layout.count}-BAND EQUALIZER"
            rebuildBandRow()
        } else {
            faders.forEach { it.setMax(maxHalf) }
        }
        refreshChannelUi()
        refreshFaders()
        eqSwitch?.let { sw ->
            if (sw.isChecked != effectsEnabled) sw.isChecked = effectsEnabled
        }
        limiterCheck?.let { if (it.isChecked != limiter.enabled) it.isChecked = limiter.enabled }
        limiterRefreshers.forEach { it() }
        fxRefreshers.forEach { it() }
        volRefreshers.forEach { it() }
        peqPanel?.set(peqSettings)
        xoPanel?.set(xoSettings, prefs.getBoolean(Store.KEY_XO_SWAP, false))
        refreshStrip()
        updateModeLabels()
        updateRangeLabel()
    }

    private fun syncVisualizer() {
        val want = if (!spectrumOn && currentTab != TAB_LIMITER) -1 else (service?.visualizerSession() ?: -1)
        if (want < 0) { stopVisualizer(); return }
        if (visualizer != null && visualizerSession == want) return
        stopVisualizer()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVisualizer(want)
        } else if (!askedAudioPermission && !notifPending) {
            askedAudioPermission = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        }
    }

    private fun startVisualizer(session: Int) {
        try {
            visualizerSession = session
            visualizer = Visualizer(session).apply {
                captureSize = currentFft()
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {
                        data?.let {
                            spectrumView?.submitWave(it)
                            meterView?.submit(Meter.readWave8(it), service?.limiterSnapshot())
                        }
                    }
                    override fun onFftDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {
                        data?.let { spectrumView?.submitFft(it, samplingRate) }
                    }
                }, Visualizer.getMaxCaptureRate(), true, true)
                enabled = true
            }
        } catch (_: Exception) {
            visualizer = null
            status?.text = "Spectrum Analyzer tidak tersedia pada sesi audio ini"
        }
    }

    private fun fftSizes(): List<Int> {
        val r = try { Visualizer.getCaptureSizeRange() } catch (_: Throwable) { intArrayOf(128, 1024) }
        val all = listOf(256, 512, 1024, 2048, 4096).filter { it >= r[0] && it <= r[1] }
        return if (all.isEmpty()) listOf(r[1]) else all
    }

    private fun currentFft(): Int {
        val sizes = fftSizes()
        val want = prefs.getInt(Store.KEY_SPEC_FFT, 0)
        return if (want in sizes) want else sizes.last()
    }

    private fun fftChipText() = "FFT ${currentFft()}"

    private fun stopVisualizer() {
        try { visualizer?.enabled = false; visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        visualizerSession = -2
        meterView?.clear()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED && spectrumOn) syncVisualizer()
    }

    // ---------- Pengaturan tersimpan ----------
    private fun loadAppSettings() {
        fullPower = prefs.getBoolean(Store.KEY_FULL_POWER, false)
        pipeline = prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
        spectrumOn = prefs.getBoolean(Store.KEY_SPECTRUM, true)
        keepScreen = prefs.getBoolean(Store.KEY_KEEP_SCREEN, false)
        sessionMode = prefs.getBoolean(Store.KEY_SESSION_MODE, false)
        bgService = prefs.getBoolean(Store.KEY_BG, true)
        eqLimit = prefs.getInt(Store.KEY_EQ_LIMIT, 12).coerceIn(3, 12)
    }

    private fun loadSettings() {
        val n = prefs.getInt(Store.KEY_BANDS, Bands.DEFAULT).let { if (Bands.isValid(it)) it else Bands.DEFAULT }
        if (n != bandCount || values.size != n) {
            bandCount = n
            layout = Bands.forCount(n)
            values = IntArray(n)
            valuesR = IntArray(n)
        }
        for (i in values.indices) values[i] = prefs.getInt(Bands.key(n, i), 0).coerceIn(-maxHalf, maxHalf)
        val right = Bands.loadR(prefs, n)
        for (i in valuesR.indices) valuesR[i] = right[i].coerceIn(-maxHalf, maxHalf)
        chSplit = prefs.getBoolean(Store.KEY_CH_SPLIT, false)
        editCh = prefs.getInt(Store.KEY_CH_EDIT, 0).coerceIn(0, 1)
        effectsEnabled = prefs.getBoolean(Store.KEY_EQ_ENABLED, true)
        eqMode = prefs.getString(Store.KEY_EQ_MODE, "1WAY") ?: "1WAY"
        limiter = Store.loadLimiter(this)
        fx = Store.loadEffects(this)
        peqSettings = PeqStore.load(this)
        xoSettings = Store.loadCrossoverSettings(prefs)
    }

    private fun saveSettings() {
        val editor = prefs.edit()
        values.forEachIndexed { i, v -> editor.putInt(Bands.key(values.size, i), v) }
        if (chSplit) valuesR.forEachIndexed { i, v -> editor.putInt(Bands.keyR(valuesR.size, i), v) }
        editor.putBoolean(Store.KEY_CH_SPLIT, chSplit).putInt(Store.KEY_CH_EDIT, editCh)
        editor.putString(Store.KEY_EQ_MODE, eqMode).putBoolean(Store.KEY_EQ_ENABLED, effectsEnabled).apply()
    }
}

private class VerticalFader(context: Context) : View(context) {
    var value: Int = 0
        private set
    var maxHalf: Int = 24
    var onValueChanged: ((Int, Boolean) -> Unit)? = null
    /** Warna isi fader (biru = stereo, oranye = kiri, ungu = kanan). */
    var fillColor: Int = 0xFF168DFF.toInt()
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBFC5D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f
    }
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    fun setMax(newMax: Int) {
        maxHalf = newMax
        setValue(value, false)
        invalidate()
    }

    fun setValue(newValue: Int, fromUser: Boolean = false) {
        val v = newValue.coerceIn(-maxHalf, maxHalf)
        if (value != v) {
            value = v
            invalidate()
            onValueChanged?.invoke(v, fromUser)
        } else if (fromUser) onValueChanged?.invoke(v, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = d(8f)
        val bottom = height - d(8f)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val y = center - (value / maxHalf.toFloat()) * half
        val rail = RectF(cx - d(5f), top, cx + d(5f), bottom)
        trackPaint.shader = LinearGradient(rail.left, 0f, rail.right, 0f,
            intArrayOf(0xFF050A14.toInt(), 0xFF25364E.toInt(), 0xFF050A14.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rail, d(5f), d(5f), trackPaint)
        fillPaint.color = fillColor
        if (value >= 0) canvas.drawRoundRect(RectF(cx - d(3f), y, cx + d(3f), center), d(3f), d(3f), fillPaint)
        else canvas.drawRoundRect(RectF(cx - d(3f), center, cx + d(3f), y), d(3f), d(3f), fillPaint)
        // skala putih di tengah fader: satu garis tiap 3 dB (1 langkah fader = 0,5 dB)
        val maxDb = maxHalf / 2f
        var db = -(maxDb / 3f).toInt() * 3
        val tickMax = (width / 2f - d(1f))
        while (db <= maxDb) {
            val ty = center - (db * 2f / maxHalf) * half
            val len = (if (db == 0) d(10f) else d(7f)).coerceAtMost(tickMax)
            tickPaint.strokeWidth = if (db == 0) d(1.6f) else d(1f)
            tickPaint.alpha = if (db == 0) 255 else 200
            canvas.drawLine(cx - len, ty, cx + len, ty, tickPaint)
            db += 3
        }
        val thumbHalf = (width * 0.43f).coerceAtMost(d(12f)).coerceAtLeast(d(5f))
        val thumb = RectF(cx - thumbHalf, y - d(10f), cx + thumbHalf, y + d(10f))
        thumbPaint.shader = LinearGradient(thumb.left, thumb.top, thumb.right, thumb.bottom,
            intArrayOf(0xFFF0F1F4.toInt(), 0xFFBFC3CC.toInt(), 0xFFE4E6EA.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(thumb, d(11f), d(11f), thumbPaint)
        canvas.drawRoundRect(thumb, d(11f), d(11f), borderPaint)
    }

    private fun updateFromY(y: Float) {
        val top = d(8f)
        val bottom = height - d(8f)
        val clamped = y.coerceIn(top, bottom)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        setValue((maxHalf * (center - clamped) / half).roundToInt(), true)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                updateFromY(event.y)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

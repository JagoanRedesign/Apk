package com.dlmsmini.equalizer

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private var bandCount = Bands.DEFAULT
    private var layout: BandLayout = Bands.forCount(Bands.DEFAULT)
    private var bandHost: FrameLayout? = null
    private var eqTitle: TextView? = null

    // Nilai dalam satuan 0,5 dB. Normal: -24..24 (±12 dB). Kekuatan Penuh: -44..44 (±22 dB).
    // Jumlah elemen = jumlah band aktif (5/10/13/21).
    private var values = IntArray(Bands.DEFAULT)
    private val faders = mutableListOf<VerticalFader>()
    private var visualizer: Visualizer? = null
    private var visualizerSession = -2
    private var service: EqualizerService? = null
    private var bound = false
    private val handler = Handler(Looper.getMainLooper())
    private var hintRunnable: Runnable? = null
    private var hintShown = false
    private var sessionHint: TextView? = null
    private var eqSwitch: Switch? = null
    private var sessionMode = false
    private var bgService = true
    private var created = false
    private var spectrumView: SpectrumView? = null
    private var spectrumGroup: LinearLayout? = null
    private var status: TextView? = null
    private var modeInfo: TextView? = null
    private var rangeLabel: TextView? = null
    private var presetHost: LinearLayout? = null

    private var effectsEnabled = true
    private var eqMode = "1WAY"
    private var fullPower = false
    private var pipeline = Store.PIPE_STANDARD
    private var spectrumOn = true
    private var keepScreen = false
    private var askedAudioPermission = false
    private var limiter = LimiterSettings()

    private val maxHalf: Int get() = if (fullPower) 44 else 24
    private val builtIns = listOf("Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
    private val prefs by lazy { Store.prefs(this) }

    // Referensi UI limiter
    private var limiterCheck: CheckBox? = null
    private var limiterNote: TextView? = null
    private val limiterBars = mutableListOf<View>()
    private val limiterRefreshers = mutableListOf<() -> Unit>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadAppSettings()
        loadSettings()
        buildUi()
        if (bgService) EqualizerService.start(this)
        bound = bindService(Intent(this, EqualizerService::class.java), connection, Context.BIND_AUTO_CREATE)
        created = true
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as? EqualizerService.LocalBinder)?.service ?: return
            service = s
            s.onChanged = { runOnUiThread { onServiceChanged() } }
            s.reload()
            onServiceChanged()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service?.onChanged = null
            service = null
        }
    }

    override fun onResume() {
        super.onResume()
        val oldMax = maxHalf
        loadAppSettings()
        syncFromPrefs()
        if (oldMax != maxHalf) applyRange()
        if (bgService) EqualizerService.start(this)
        spectrumGroup?.visibility = if (spectrumOn) View.VISIBLE else View.GONE
        if (keepScreen) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        service?.reload()
        onServiceChanged()
        syncVisualizer()
    }

    override fun onPause() {
        hintRunnable?.let { handler.removeCallbacks(it) }
        hintRunnable = null
        stopVisualizer()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopVisualizer()
        service?.onChanged = null
        if (bound) { try { unbindService(connection) } catch (_: Exception) {} ; bound = false }
        service = null
        super.onDestroy()
    }

    // ---------- helpers UI ----------
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun c(v: Long) = v.toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int = 0) = Ui.rounded(this, color, radius, stroke)
    private fun label(value: String, size: Float = 13f, tint: Int = c(0xFFCACAD2), bold: Boolean = false) =
        Ui.label(this, value, size, tint, bold)

    private fun makeCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(c(0xFF242426), 22, c(0xFF303034))
    }

    private fun section(parent: LinearLayout, title: String) {
        val t = label(title, 14f, c(0xFFE7E7ED), true)
        t.setPadding(dp(2), dp(22), dp(2), dp(10))
        parent.addView(t)
    }

    private fun panelCard(pad: Int = 10): LinearLayout = makeCard().apply {
        background = rounded(Pal.PANEL, 18, Pal.PANEL_STROKE)
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    // ---------- UI utama ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(20))
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(12))
            background = rounded(Pal.PANEL, 20, Pal.PANEL_STROKE)
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("DLMS", 23f, c(0xFFF3F6FF), true))
        brand.addView(label("MINI EQUALIZER", 10f, c(0xFF35B8FF), true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val modeGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            background = rounded(c(0xFF080F1D), 18, c(0xFF31486B))
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val tint = ColorStateList.valueOf(c(0xFF28AFFF))
        val one = RadioButton(this).apply {
            text = "1-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = tint
            setPadding(dp(5), 0, dp(5), 0)
        }
        val two = RadioButton(this).apply {
            text = "2-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = tint
            setPadding(dp(5), 0, dp(5), 0)
        }
        modeGroup.addView(one); modeGroup.addView(two)
        modeGroup.check(if (eqMode == "2WAY") two.id else one.id)
        modeGroup.setOnCheckedChangeListener { _, id ->
            eqMode = if (id == two.id) "2WAY" else "1WAY"
            updateModeLabels(); saveSettings()
        }
        header.addView(modeGroup)
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 24f; gravity = Gravity.CENTER
            setTextColor(c(0xFFCFE6FF))
            setPadding(dp(12), dp(2), dp(8), dp(2))
            isClickable = true
            contentDescription = "Pengaturan"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        header.addView(gear)
        content.addView(header)

        // Spectrum analyzer
        val spectrum = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        section(spectrum, "SPECTRUM")
        val spectrumCard = panelCard()
        val spectrumHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        spectrumHeader.addView(label("●  AUDIO ANALYZER", 11f, c(0xFF48C5FF), true), LinearLayout.LayoutParams(0, -2, 1f))
        spectrumHeader.addView(label("LIVE", 9f, c(0xFF7BE3B0), true))
        spectrumCard.addView(spectrumHeader)
        spectrumView = SpectrumView(this)
        spectrumCard.addView(spectrumView, LinearLayout.LayoutParams(-1, dp(92)))
        spectrum.addView(spectrumCard)
        spectrumGroup = spectrum
        spectrum.visibility = if (spectrumOn) View.VISIBLE else View.GONE
        content.addView(spectrum)

        status = label("Menyiapkan audio…", 10f, c(0xFF80DDB5))
        status?.setPadding(dp(3), dp(6), dp(3), 0)
        content.addView(status)

        sessionHint = label("", 10f, c(0xFFFFB86B), true).apply {
            setPadding(dp(3), dp(4), dp(3), 0)
            visibility = View.GONE
            isClickable = true
            setOnClickListener { showSessionDialog() }
        }
        content.addView(sessionHint)

        // Equalizer
        section(content, "${layout.count}-BAND EQUALIZER")
        eqTitle = content.getChildAt(content.childCount - 1) as? TextView
        val eqCard = panelCard().apply { setPadding(dp(7), dp(10), dp(7), dp(10)) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val enabled = Switch(this).apply {
            text = "EQ aktif"; textSize = 11f; setTextColor(c(0xFFEAF0FF))
            isChecked = effectsEnabled
        }
        eqSwitch = enabled
        enabled.setOnCheckedChangeListener { _, checked ->
            effectsEnabled = checked
            service?.updateEq(effectsEnabled, values)
            service?.updateLimiter(limiter, effectsEnabled)
            status?.text = if (checked) "Equalizer aktif" else "Equalizer nonaktif"
            saveSettings()
        }
        controls.addView(enabled, LinearLayout.LayoutParams(0, -2, 1f))
        modeInfo = label("", 9f, Pal.MUTED)
        controls.addView(modeInfo)
        eqCard.addView(controls)

        bandHost = FrameLayout(this)
        eqCard.addView(bandHost, LinearLayout.LayoutParams(-1, -2))
        rebuildBandRow()
        rangeLabel = label("", 9f, c(0xFF899AB5)).apply { gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0) }
        eqCard.addView(rangeLabel)
        content.addView(eqCard)
        updateModeLabels()
        updateRangeLabel()

        buildLimiterCard(content)
        buildPresetCard(content)

        val footer = label("Dibuat oleh Ilham Galeh", 11f, c(0xFF8294B2), true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(5))
        }
        content.addView(footer)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }


    /** Bangun deret fader sesuai jumlah band. 13 dan 21 band memakai layar geser horizontal. */
    private fun rebuildBandRow() {
        val host = bandHost ?: return
        host.removeAllViews()
        faders.clear()
        val wide = layout.count > 10
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        layout.labels.forEachIndexed { index, freq ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(1), 0, dp(1), 0)
            }
            column.addView(label(freq, 10f, c(0xFFDDE7F8), true).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(-1, dp(25)))

            val plus = TextView(this).apply {
                text = "+"; textSize = 19f; gravity = Gravity.CENTER
                setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
                isClickable = true
            }
            column.addView(plus, LinearLayout.LayoutParams(-1, dp(30)).apply { setMargins(dp(1), dp(3), dp(1), dp(5)) })

            val valueText = label(formatDb(values[index]), 9f, Pal.CYAN, true).apply { gravity = Gravity.CENTER }
            val fader = VerticalFader(this).apply {
                maxHalf = this@MainActivity.maxHalf
                setValue(values[index])
                onValueChanged = { newValue, fromUser ->
                    if (index < values.size) values[index] = newValue
                    valueText.text = formatDb(newValue)
                    if (fromUser) { service?.updateEq(effectsEnabled, values); saveSettings() }
                }
            }
            faders.add(fader)
            column.addView(fader, LinearLayout.LayoutParams(-1, dp(174)))

            val minus = TextView(this).apply {
                text = "−"; textSize = 19f; gravity = Gravity.CENTER
                setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
                isClickable = true
            }
            column.addView(minus, LinearLayout.LayoutParams(-1, dp(30)).apply { setMargins(dp(1), dp(5), dp(1), dp(4)) })
            column.addView(valueText, LinearLayout.LayoutParams(-1, dp(22)))
            plus.setOnClickListener { fader.setValue((fader.value + 1).coerceAtMost(fader.maxHalf), true) }
            minus.setOnClickListener { fader.setValue((fader.value - 1).coerceAtLeast(-fader.maxHalf), true) }
            row.addView(column, if (wide) LinearLayout.LayoutParams(dp(46), -2) else LinearLayout.LayoutParams(0, -2, 1f))
        }
        if (wide) {
            val scroller = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(row)
            }
            host.addView(scroller, FrameLayout.LayoutParams(-1, -2))
        } else {
            host.addView(row, FrameLayout.LayoutParams(-1, -2))
        }
    }

    // ---------- Limiter ----------
    private fun buildLimiterCard(content: LinearLayout) {
        section(content, "LIMITER")
        val card = panelCard(14)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val check = CheckBox(this).apply {
            text = "Limiter enabled"; textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(c(0xFFFFFFFF))
            buttonTintList = ColorStateList.valueOf(c(0xFF00CFFF))
            isChecked = limiter.enabled
        }
        limiterCheck = check
        check.setOnCheckedChangeListener { _, checked ->
            limiter = limiter.copy(enabled = checked)
            onLimiterChanged()
        }
        top.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
        val info = TextView(this).apply {
            text = "i"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(c(0xFFB5B5BA))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0)
                setStroke(dp(2), c(0xFF8E8E93))
            }
            isClickable = true
            contentDescription = "Info limiter"
            setOnClickListener { showLimiterInfo() }
        }
        top.addView(info, LinearLayout.LayoutParams(dp(32), dp(32)))
        card.addView(top)

        limiterNote = label("", 10f, c(0xFFFFB86B)).apply { setPadding(dp(4), dp(4), dp(4), 0); visibility = View.GONE }
        card.addView(limiterNote)

        limiterBars.clear(); limiterRefreshers.clear()
        limiterRow(card, "Attack time", LimiterSpec.attack, { limiter.attackMs }) { limiter = limiter.copy(attackMs = it) }
        limiterRow(card, "Release time", LimiterSpec.release, { limiter.releaseMs }) { limiter = limiter.copy(releaseMs = it) }
        limiterRow(card, "Ratio", LimiterSpec.ratio, { limiter.ratio }) { limiter = limiter.copy(ratio = it) }
        limiterRow(card, "Threshold", LimiterSpec.threshold, { limiter.thresholdDb }) { limiter = limiter.copy(thresholdDb = it) }
        limiterRow(card, "Post-gain", LimiterSpec.postGain, { limiter.postGainDb }) { limiter = limiter.copy(postGainDb = it) }

        val reset = Ui.pill(this, "RESET LIMITER").apply { textSize = 12f; setPadding(dp(8), dp(11), dp(8), dp(11)) }
        reset.setOnClickListener {
            limiter = LimiterSettings(enabled = limiter.enabled)
            limiterRefreshers.forEach { it() }
            onLimiterChanged()
        }
        card.addView(reset, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        content.addView(card)
    }

    private fun limiterRow(card: LinearLayout, title: String, spec: Spec, get: () -> Float, set: (Float) -> Unit) {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(16), dp(4), 0)
        }
        head.addView(label(title, 15f, c(0xFFFFFFFF)), LinearLayout.LayoutParams(0, -2, 1f))
        val valueText = label(spec.format(get()), 13f, Pal.CYAN, true)
        head.addView(valueText)
        val tintList = ColorStateList.valueOf(c(0xFF00CFFF))
        val bar = SeekBar(this).apply {
            max = spec.steps
            progress = spec.toProgress(get())
            progressTintList = tintList
            thumbTintList = tintList
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = spec.toValue(p)
                    valueText.text = spec.format(v)
                    if (fromUser) { set(v); onLimiterChanged(save = false) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Store.saveLimiter(this@MainActivity, limiter) }
            })
        }
        card.addView(head)
        card.addView(bar, LinearLayout.LayoutParams(-1, -2))
        limiterBars.add(head); limiterBars.add(bar)
        limiterRefreshers.add {
            bar.progress = spec.toProgress(get())
            valueText.text = spec.format(get())
        }
    }

    private fun onLimiterChanged(save: Boolean = true) {
        if (save) Store.saveLimiter(this, limiter)
        service?.updateLimiter(limiter, effectsEnabled)
        refreshLimiterUi()
    }

    private fun refreshLimiterUi() {
        val usable = service?.limiterAvailable ?: (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
        limiterCheck?.isEnabled = usable
        val note = limiterNote
        if (note != null) {
            note.visibility = if (usable) View.GONE else View.VISIBLE
            note.text = "Limiter membutuhkan Android 9+ dan dukungan efek DynamicsProcessing pada perangkat."
        }
        val alpha = if (limiter.enabled && usable) 1f else 0.45f
        limiterBars.forEach { it.alpha = alpha }
    }

    private fun showLimiterInfo() {
        val msg = "• Limiter enabled: mengaktifkan atau menonaktifkan pembatas audio.\n\n" +
            "• Attack time (waktu mulai): waktu yang dibutuhkan limiter untuk mulai bekerja setelah volume melewati batas (threshold).\n\n" +
            "• Release time (waktu lepas): waktu yang dibutuhkan limiter untuk berhenti bekerja dan mengembalikan volume ke normal setelah suara kembali di bawah batas.\n\n" +
            "• Ratio (rasio): seberapa kuat penekanan volume setelah sinyal melewati ambang batas.\n\n" +
            "• Threshold (ambang batas): level volume (dB) tempat limiter mulai memotong puncak suara agar tidak pecah.\n\n" +
            "• Post-gain (penguatan setelahnya): penyesuaian volume akhir (dB) setelah proses limiter, untuk menjaga loudness."
        AlertDialog.Builder(this).setTitle("Limiter").setMessage(msg).setPositiveButton("Tutup", null).show()
    }

    // ---------- Preset ----------
    private fun buildPresetCard(content: LinearLayout) {
        section(content, "PRESET MUSIK")
        val presetCard = panelCard()
        val host = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        presetHost = host
        presetCard.addView(host)
        presetCard.addView(label("Tahan lama preset kustom untuk menghapus", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
        })

        fun actionRow(vararg pairs: Pair<String, () -> Unit>) {
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pairs.forEach { (text, action) ->
                val b = Ui.pill(this, text).apply { textSize = 12f; setPadding(dp(6), dp(12), dp(6), dp(12)) }
                b.setOnClickListener { action() }
                actions.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            presetCard.addView(actions)
        }
        actionRow("SIMPAN PRESET" to { saveCustomPreset() }, "RESET FLAT" to { applyPreset("Flat") })
        actionRow("EXPORT" to { exportPresets() }, "IMPORT" to { importPresets() })
        content.addView(presetCard)
        rebuildPresetGrid()
    }

    private fun rebuildPresetGrid() {
        val host = presetHost ?: return
        host.removeAllViews()
        val all = builtIns.map { it to false } + PresetStore.names(this).map { it to true }
        all.chunked(3).forEach { rowItems ->
            val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { (name, custom) ->
                val button = TextView(this).apply {
                    text = name; textSize = 11f; gravity = Gravity.CENTER
                    setTextColor(c(0xFFE5EDFF))
                    background = rounded(if (custom) c(0xFF17304A) else c(0xFF1B2638), 12, c(0xFF304968))
                    setPadding(dp(3), dp(11), dp(3), dp(11))
                    isClickable = true
                    setOnClickListener { if (custom) applySavedPreset(name) else applyPreset(name) }
                    if (custom) setOnLongClickListener { confirmDelete(name); true }
                }
                presetRow.addView(button, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            repeat(3 - rowItems.size) { presetRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            host.addView(presetRow)
        }
    }

    private fun confirmDelete(name: String) {
        AlertDialog.Builder(this).setTitle("Hapus preset").setMessage("Hapus preset \"$name\"?")
            .setPositiveButton("Hapus") { _, _ -> PresetStore.delete(this, name); rebuildPresetGrid() }
            .setNegativeButton("Batal", null).show()
    }

    private fun applyPreset(name: String) {
        val preset = when (name) {
            "Flat" -> intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
            "Pop" -> intArrayOf(4, 2, 0, -2, -2, 2, 4, 4, 2, 2)
            "Rock" -> intArrayOf(6, 4, 2, 0, -2, 2, 4, 6, 6, 6)
            "Jazz" -> intArrayOf(4, 2, 0, 2, -2, -2, 0, 2, 4, 4)
            "Bass Boost" -> intArrayOf(10, 8, 6, 4, 2, 0, 0, 0, 0, 0)
            "Vocal" -> intArrayOf(-4, -2, 0, 2, 6, 8, 6, 4, 0, -2)
            "Dangdut" -> intArrayOf(8, 6, 4, 2, 0, 2, 4, 4, 2, 2)
            "DJ Horeg" -> intArrayOf(10, 8, 6, 2, -2, 0, 4, 6, 8, 6)
            else -> IntArray(10)
        }
        setAllValues(preset)
    }

    private fun applySavedPreset(name: String) {
        val saved = PresetStore.get(this, name)
        if (saved == null) {
            Toast.makeText(this, "Preset tidak dapat dibaca", Toast.LENGTH_SHORT).show()
            return
        }
        setAllValues(saved.values)
        saved.limiter?.let { applyLimiterPreset(it) }
    }

    /** Terapkan pengaturan limiter yang tersimpan di dalam preset. */
    private fun applyLimiterPreset(l: LimiterSettings) {
        limiter = l
        limiterCheck?.let { if (it.isChecked != l.enabled) it.isChecked = l.enabled }
        limiterRefreshers.forEach { it() }
        Store.saveLimiter(this, limiter)
        service?.updateLimiter(limiter, effectsEnabled)
        refreshLimiterUi()
    }

    private fun setAllValues(preset: IntArray) {
        val target = if (preset.size == values.size) preset else Bands.resample(preset, layout)
        for (i in values.indices) values[i] = target[i].coerceIn(-maxHalf, maxHalf)
        faders.forEachIndexed { i, f -> f.setValue(values[i], false) }
        service?.updateEq(effectsEnabled, values)
        saveSettings()
    }

    private fun saveCustomPreset() {
        val input = EditText(this).apply { hint = "Nama preset"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Simpan preset").setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = PresetCodec.cleanName(input.text.toString()).ifBlank { "Preset Saya" }
                if (builtIns.any { it.equals(name, ignoreCase = true) }) {
                    Toast.makeText(this, "Nama itu dipakai preset bawaan", Toast.LENGTH_SHORT).show()
                } else {
                    PresetStore.save(this, name, values, limiter)
                    rebuildPresetGrid()
                    Toast.makeText(this, "Preset $name disimpan (EQ + limiter)", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun exportPresets() {
        val saved = PresetStore.names(this).mapNotNull { n -> PresetStore.get(this, n)?.let { PresetCodec.Item(n, it.values, it.limiter) } }
        val items = if (saved.isEmpty()) listOf(PresetCodec.Item("Preset Saya", values.copyOf(), limiter)) else saved
        PresetDialogs.showExport(this, PresetCodec.export(items))
    }

    private fun importPresets() {
        PresetDialogs.showImport(this) { items ->
            items.forEach { item ->
                var name = item.name
                if (builtIns.any { it.equals(name, ignoreCase = true) }) name = PresetCodec.cleanName("$name (impor)")
                PresetStore.save(this, name, item.values, item.limiter)
            }
            rebuildPresetGrid()
            Toast.makeText(this, "${items.size} preset diimpor", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Audio ----------
    private fun formatDb(value: Int): String = String.format(java.util.Locale.US, "%.1f dB", value / 2f)

    private fun updateModeLabels() {
        modeInfo?.text = if (eqMode == "2WAY")
            "2-Way aktif • LOW: 31–500 Hz  |  HIGH: 1–16 kHz"
        else
            "1-Way aktif • Semua frekuensi dalam satu kurva 31 Hz–16 kHz"
    }

    private fun updateRangeLabel() {
        val r = maxHalf / 2
        rangeLabel?.text = "−$r dB     0 dB     +$r dB   •   Langkah 0,5 dB"
    }

    private fun applyRange() {
        faders.forEach { it.setMax(maxHalf) }
        updateRangeLabel()
        saveSettings()
    }

    /** Dipanggil saat layanan terhubung atau status/sesi berubah. */
    private fun onServiceChanged() {
        val s = service ?: return
        status?.text = s.status
        refreshLimiterUi()
        updateSessionHint(s)
        syncVisualizer()
    }

    private fun updateSessionHint(s: EqualizerService) {
        val hint = sessionHint ?: return
        if (!s.isSessionMode) {
            hint.visibility = View.GONE
            return
        }
        hint.visibility = View.VISIBLE
        if (s.sessionCount > 0) {
            hint.setTextColor(c(0xFF7BE3B0))
            hint.text = "Mode Sesi Aplikasi • sesi aktif: " + s.sessionPackages.joinToString(", ")
        } else {
            hint.setTextColor(c(0xFFFFB86B))
            hint.text = "Mode Sesi Aplikasi aktif, belum ada pemutar terdeteksi — ketuk untuk info"
            if (!hintShown && hintRunnable == null) {
                val r = Runnable {
                    hintRunnable = null
                    val cur = service
                    if (!hintShown && cur != null && cur.isSessionMode && cur.sessionCount == 0) {
                        hintShown = true
                        showSessionDialog()
                    }
                }
                hintRunnable = r
                handler.postDelayed(r, 6000)
            }
        }
    }

    private fun showSessionDialog() {
        val msg = "Mode Sesi Aplikasi aktif, tetapi belum ada aplikasi yang disetujui mengirim sinyal putar baru-baru ini — " +
            "equalizer belum diterapkan ke pemutar mana pun.\n\n" +
            "Tips:\n" +
            "• Buka DLMS Mini Equalizer sebelum membuka aplikasi musik Anda\n" +
            "• Pastikan aplikasi diizinkan di Pengaturan › Kelola aplikasi terdeteksi\n" +
            "• Tekan putar/jeda di dalam aplikasi musik untuk memicu deteksi\n\n" +
            "Aplikasi tidak didukung? Beralih ke mode Standar (Mix Global): berfungsi dengan semua aplikasi, " +
            "dengan beberapa batasan pada Android Auto."
        AlertDialog.Builder(this).setTitle("Sesi audio").setMessage(msg)
            .setPositiveButton("Oke", null)
            .setNeutralButton("Beralih ke Mix Global") { _, _ ->
                prefs.edit().putBoolean(Store.KEY_SESSION_MODE, false).apply()
                loadAppSettings()
                service?.reload()
                onServiceChanged()
            }
            .show()
    }

    /** Muat ulang nilai dari penyimpanan setelah kembali dari Pengaturan (mis. setelah reset). */
    private fun syncFromPrefs() {
        if (!created) return
        val oldBands = bandCount
        loadSettings()
        if (bandCount != oldBands) {
            eqTitle?.text = "${layout.count}-BAND EQUALIZER"
            rebuildBandRow()
        } else {
            faders.forEach { it.setMax(maxHalf) }
            faders.forEachIndexed { i, f -> f.setValue(values[i], false) }
        }
        eqSwitch?.let { sw ->
            if (sw.isChecked != effectsEnabled) sw.isChecked = effectsEnabled
        }
        limiterCheck?.let { if (it.isChecked != limiter.enabled) it.isChecked = limiter.enabled }
        limiterRefreshers.forEach { it() }
        updateModeLabels()
        updateRangeLabel()
    }

    private fun syncVisualizer() {
        val want = if (!spectrumOn) -1 else (service?.visualizerSession() ?: -1)
        if (want < 0) { stopVisualizer(); return }
        if (visualizer != null && visualizerSession == want) return
        stopVisualizer()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVisualizer(want)
        } else if (!askedAudioPermission) {
            askedAudioPermission = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        }
    }

    private fun startVisualizer(session: Int) {
        try {
            visualizerSession = session
            visualizer = Visualizer(session).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {
                        data?.let { bytes ->
                            val bars = FloatArray(36)
                            for (i in bars.indices) {
                                val index = 2 + i * 2
                                if (index < bytes.size) bars[i] = (abs(bytes[index].toInt()).toFloat() / 128f).coerceIn(0f, 1f)
                            }
                            runOnUiThread { spectrumView?.setBars(bars) }
                        }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (_: Exception) {
            visualizer = null
            status?.text = "Spectrum Analyzer tidak tersedia pada sesi audio ini"
        }
    }

    private fun stopVisualizer() {
        try { visualizer?.enabled = false; visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        visualizerSession = -2
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED && spectrumOn) syncVisualizer()
    }

    // ---------- Pengaturan tersimpan ----------
    private fun loadAppSettings() {
        fullPower = prefs.getBoolean(Store.KEY_FULL_POWER, false)
        pipeline = prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
        spectrumOn = prefs.getBoolean(Store.KEY_SPECTRUM, true)
        keepScreen = prefs.getBoolean(Store.KEY_KEEP_SCREEN, false)
        sessionMode = prefs.getBoolean(Store.KEY_SESSION_MODE, false)
        bgService = prefs.getBoolean(Store.KEY_BG, true)
    }

    private fun loadSettings() {
        val n = prefs.getInt(Store.KEY_BANDS, Bands.DEFAULT).let { if (Bands.isValid(it)) it else Bands.DEFAULT }
        if (n != bandCount || values.size != n) {
            bandCount = n
            layout = Bands.forCount(n)
            values = IntArray(n)
        }
        for (i in values.indices) values[i] = prefs.getInt(Bands.key(n, i), 0).coerceIn(-maxHalf, maxHalf)
        effectsEnabled = prefs.getBoolean(Store.KEY_EQ_ENABLED, true)
        eqMode = prefs.getString(Store.KEY_EQ_MODE, "1WAY") ?: "1WAY"
        limiter = Store.loadLimiter(this)
    }

    private fun saveSettings() {
        val editor = prefs.edit()
        values.forEachIndexed { i, v -> editor.putInt(Bands.key(values.size, i), v) }
        editor.putString(Store.KEY_EQ_MODE, eqMode).putBoolean(Store.KEY_EQ_ENABLED, effectsEnabled).apply()
    }
}

private class VerticalFader(context: Context) : View(context) {
    var value: Int = 0
        private set
    var maxHalf: Int = 24
    var onValueChanged: ((Int, Boolean) -> Unit)? = null
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBFC5D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f
    }
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    fun setMax(newMax: Int) {
        maxHalf = newMax
        setValue(value, false)
        invalidate()
    }

    fun setValue(newValue: Int, fromUser: Boolean = false) {
        val v = newValue.coerceIn(-maxHalf, maxHalf)
        if (value != v) {
            value = v
            invalidate()
            onValueChanged?.invoke(v, fromUser)
        } else if (fromUser) onValueChanged?.invoke(v, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = d(8f)
        val bottom = height - d(8f)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val y = center - (value / maxHalf.toFloat()) * half
        val rail = RectF(cx - d(5f), top, cx + d(5f), bottom)
        trackPaint.shader = LinearGradient(rail.left, 0f, rail.right, 0f,
            intArrayOf(0xFF050A14.toInt(), 0xFF25364E.toInt(), 0xFF050A14.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rail, d(5f), d(5f), trackPaint)
        fillPaint.color = 0xFF168DFF.toInt()
        if (value >= 0) canvas.drawRoundRect(RectF(cx - d(3f), y, cx + d(3f), center), d(3f), d(3f), fillPaint)
        else canvas.drawRoundRect(RectF(cx - d(3f), center, cx + d(3f), y), d(3f), d(3f), fillPaint)
        val thumbHalf = (width * 0.43f).coerceAtMost(d(12f)).coerceAtLeast(d(5f))
        val thumb = RectF(cx - thumbHalf, y - d(10f), cx + thumbHalf, y + d(10f))
        thumbPaint.shader = LinearGradient(thumb.left, thumb.top, thumb.right, thumb.bottom,
            intArrayOf(0xFFF0F1F4.toInt(), 0xFFBFC3CC.toInt(), 0xFFE4E6EA.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(thumb, d(11f), d(11f), thumbPaint)
        canvas.drawRoundRect(thumb, d(11f), d(11f), borderPaint)
    }

    private fun updateFromY(y: Float) {
        val top = d(8f)
        val bottom = height - d(8f)
        val clamped = y.coerceIn(top, bottom)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        setValue((maxHalf * (center - clamped) / half).roundToInt(), true)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                updateFromY(event.y)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

private class SpectrumView(context: Context) : View(context) {
    private var bars = FloatArray(36)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x4436AFFF; style = Paint.Style.FILL }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x223B82C5; strokeWidth = 1f }
    fun setBars(newBars: FloatArray) { bars = newBars; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (bars.isEmpty() || width <= 0) return
        for (line in 1..3) {
            val y = height * line / 4f
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
        val gap = width * 0.012f
        val barWidth = (width - gap * (bars.size - 1)) / bars.size
        val base = height * 0.9f
        bars.forEachIndexed { i, level ->
            val h = (height * 0.78f * level.coerceIn(0.04f, 1f)).coerceAtLeast(4f)
            val left = i * (barWidth + gap)
            val rect = RectF(left, base - h, left + barWidth, base)
            glowPaint.color = if (i > bars.size * 0.72f) 0x553F6BFF else 0x4436AFFF
            barPaint.shader = LinearGradient(0f, base - h, 0f, base,
                intArrayOf(if (i > bars.size * 0.72f) 0xFF9B63FF.toInt() else 0xFF20D6E8.toInt(), 0xFF167CFF.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(left - 1, base - h - 2, left + barWidth + 1, base + 1), 4f, 4f, glowPaint)
            canvas.drawRoundRect(rect, 3f, 3f, barPaint)
        }
    }
}

package com.dlmsmini.equalizer

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.audiofx.Equalizer
import android.media.AudioManager
import android.media.audiofx.Visualizer
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val frequencies = arrayOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    // Values are half-dB units: -24..24 represents -12.0..+12.0 dB.
    private val values = IntArray(10)
    private val faders = mutableListOf<VerticalFader>()
    private var eq: Equalizer? = null
    private var visualizer: Visualizer? = null
    private var spectrumView: SpectrumView? = null
    private var status: TextView? = null
    private var effectsEnabled = true
    private var eqMode = "1WAY"
    private var modeInfo: TextView? = null
    private var lowTitle: TextView? = null
    private var highTitle: TextView? = null
    // Channel gain is stored in half-dB units: -24..24 = -12.0..+12.0 dB.
    private var volL = 0
    private var volR = 0
    private var muteL = false
    private var muteR = false
    private var meterL: LevelMeterView? = null
    private var meterR: LevelMeterView? = null
    private var volLText: TextView? = null
    private var volRText: TextView? = null
    private var muteLButton: TextView? = null
    private var muteRButton: TextView? = null
    private var presetGrid: LinearLayout? = null
    // Pemutar bawaan: satu-satunya jalur audio yang bisa diatur VOL L/R dan MUTE.
    private var player: ChannelPlayer? = null
    private var effectSession = 0
    private var trackTitle: TextView? = null
    private var timeText: TextView? = null
    private var playButton: Button? = null
    private var seekBar: SeekBar? = null
    private var userSeeking = false
    private var trackDurationMs = 0L
    private var lastAudioUri: Uri? = null
    private val builtIns = listOf("Custom", "Flat", "Pop", "Rock", "Jazz", "Bass Boost", "Vocal", "Dangdut", "DJ Horeg")
    private val prefs by lazy {
        getSharedPreferences("dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_"), Context.MODE_PRIVATE)
    }

    private val playerListener = object : ChannelPlayer.Listener {
        override fun onAudioSession(sessionId: Int) { attachEffects(sessionId) }
        override fun onLevels(left: Float, right: Float) { meterL?.setLevel(left); meterR?.setLevel(right) }
        override fun onProgress(positionMs: Long, durationMs: Long) { updateProgress(positionMs, durationMs) }
        override fun onFinished() { finishPlayback("Lagu selesai") }
        override fun onError(message: String) {
            finishPlayback(message)
            Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
        }
    }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            player?.pause()
            setPlayingUi(false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSettings()
        buildUi()
        player = ChannelPlayer(this, playerListener)
        pushGains()
        attachEffects(0)
        if (!hasRecordPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
        }
    }

    private fun hasRecordPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()
    private fun c(v: Long) = v.toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(1), stroke)
        }

    private fun label(value: String, size: Float = 13f, tint: Int = c(0xFFCACAD2), bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(tint)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

    private fun makeCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(c(0xFF242426), 22, c(0xFF303034))
    }

    private fun section(parent: LinearLayout, title: String) {
        val t = label(title, 14f, c(0xFFE7E7ED), true)
        t.setPadding(dp(2), dp(22), dp(2), dp(10))
        parent.addView(t)
    }

    private fun addGap(parent: LinearLayout, height: Int = 12) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(c(0xFF080B12))
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(20))
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(c(0xFF111827), 20, c(0xFF263B5D))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("DLMS", 23f, c(0xFFF3F6FF), true))
        brand.addView(label("MINI EQUALIZER", 10f, c(0xFF35B8FF), true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val modeGroup = RadioGroup(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(c(0xFF080F1D), 18, c(0xFF31486B))
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        val one = RadioButton(this).apply {
            text = "1-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = android.content.res.ColorStateList.valueOf(c(0xFF28AFFF))
            setPadding(dp(5), 0, dp(5), 0)
        }
        val two = RadioButton(this).apply {
            text = "2-Way"; textSize = 11f; setTextColor(c(0xFFEAF4FF))
            id = View.generateViewId(); buttonTintList = android.content.res.ColorStateList.valueOf(c(0xFF28AFFF))
            setPadding(dp(5), 0, dp(5), 0)
        }
        modeGroup.addView(one); modeGroup.addView(two)
        modeGroup.check(if (eqMode == "2WAY") two.id else one.id)
        modeGroup.setOnCheckedChangeListener { _, id ->
            eqMode = if (id == two.id) "2WAY" else "1WAY"
            updateModeLabels(); saveSettings()
        }
        header.addView(modeGroup)
        content.addView(header)

        // Spectrum analyzer
        section(content, "SPECTRUM")
        val spectrumCard = makeCard().apply {
            background = rounded(c(0xFF101827), 18, c(0xFF263B5D))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val spectrumHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        spectrumHeader.addView(label("●  AUDIO ANALYZER", 11f, c(0xFF48C5FF), true), LinearLayout.LayoutParams(0, -2, 1f))
        spectrumHeader.addView(label("LIVE", 9f, c(0xFF7BE3B0), true))
        spectrumCard.addView(spectrumHeader)
        spectrumView = SpectrumView(this)
        spectrumCard.addView(spectrumView, LinearLayout.LayoutParams(-1, dp(92)))
        content.addView(spectrumCard)

        // Pemutar bawaan: hanya audio yang diputar di sini yang bisa diatur VOL L/R dan MUTE.
        section(content, "PEMUTAR")
        val playerCard = makeCard().apply {
            background = rounded(c(0xFF111827), 18, c(0xFF263B5D))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        trackTitle = label("Belum ada lagu — tekan Pilih lagu", 11f, c(0xFFDDE7F8), true).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        playerCard.addView(trackTitle)
        seekBar = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && trackDurationMs > 0) {
                        timeText?.text = formatTime(progress.toLong() * trackDurationMs / 1000L) + " / " + formatTime(trackDurationMs)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    userSeeking = false
                    if (trackDurationMs > 0) player?.seekTo((sb?.progress ?: 0).toLong() * trackDurationMs / 1000L)
                }
            })
        }
        playerCard.addView(seekBar, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, 0) })
        timeText = label("0:00 / 0:00", 10f, c(0xFF9DAFC9)).apply { gravity = Gravity.END }
        playerCard.addView(timeText)
        val playerActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pickBtn = Button(this).apply { text = "Pilih lagu"; textSize = 11f; setOnClickListener { pickAudio() } }
        playButton = Button(this).apply { text = "▶ Putar"; textSize = 11f; setOnClickListener { togglePlay() } }
        val stopBtn = Button(this).apply { text = "■ Stop"; textSize = 11f; setOnClickListener { stopPlayback() } }
        playerActions.addView(pickBtn, LinearLayout.LayoutParams(0, -2, 1f))
        playerActions.addView(playButton, LinearLayout.LayoutParams(0, -2, 1f))
        playerActions.addView(stopBtn, LinearLayout.LayoutParams(0, -2, 1f))
        playerCard.addView(playerActions)
        playerCard.addView(label("VOL L/R & MUTE bekerja pada lagu yang diputar di sini. Android tidak mengizinkan pengaturan per-kanal untuk audio aplikasi lain (Spotify, YouTube, dll).", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
        })
        content.addView(playerCard)

        // Independent Sub/Mid level controls and peak meters.
        section(content, "OUTPUT LEVEL")
        val outputCard = makeCard().apply {
            background = rounded(c(0xFF111827), 18, c(0xFF263B5D))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val channelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        addChannelControl(channelRow, "VOL L", "SUB", true)
        addChannelControl(channelRow, "VOL R", "MID", false)
        outputCard.addView(channelRow)
        outputCard.addView(label("Gain digital • −12 dB sampai +12 dB • dasar 0 dB • aktif untuk lagu di Pemutar", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0)
        })
        content.addView(outputCard)

        status = label("Menyiapkan audio…", 10f, c(0xFF80DDB5))
        status?.setPadding(dp(3), dp(6), dp(3), 0)
        content.addView(status)

        // Equalizer panel: ten weighted columns, no horizontal scrolling.
        section(content, "10-BAND EQUALIZER")
        val eqCard = makeCard().apply {
            background = rounded(c(0xFF111827), 18, c(0xFF263B5D))
            setPadding(dp(7), dp(10), dp(7), dp(10))
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val enabled = Switch(this).apply {
            text = "EQ aktif"; textSize = 11f; setTextColor(c(0xFFEAF0FF))
            isChecked = effectsEnabled
            buttonTintList = android.content.res.ColorStateList.valueOf(c(0xFF27B5FF))
        }
        enabled.setOnCheckedChangeListener { _, checked ->
            effectsEnabled = checked
            try { eq?.enabled = checked } catch (_: Exception) {}
            status?.text = if (checked) "Equalizer aktif" else "Equalizer nonaktif"
            saveSettings()
        }
        controls.addView(enabled, LinearLayout.LayoutParams(0, -2, 1f))
        modeInfo = label("", 9f, c(0xFF9DAFC9))
        controls.addView(modeInfo)
        eqCard.addView(controls)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        frequencies.forEachIndexed { index, freq ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(1), 0, dp(1), 0)
            }
            column.addView(label(freq, 10f, c(0xFFDDE7F8), true).apply {
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, dp(25)))

            val plus = TextView(this).apply {
                text = "+"; textSize = 19f; gravity = Gravity.CENTER
                setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
                isClickable = true
            }
            column.addView(plus, LinearLayout.LayoutParams(-1, dp(30)).apply {
                setMargins(dp(1), dp(3), dp(1), dp(5))
            })

            val valueText = label(formatDb(values[index]), 9f, c(0xFF45C5FF), true).apply { gravity = Gravity.CENTER }
            val fader = VerticalFader(this).apply {
                setValue(values[index])
                onValueChanged = { newValue, fromUser ->
                    values[index] = newValue
                    valueText.text = formatDb(newValue)
                    if (fromUser) { applyEqualizer(); saveSettings() }
                }
            }
            faders.add(fader)
            column.addView(fader, LinearLayout.LayoutParams(-1, dp(174)))

            val minus = TextView(this).apply {
                text = "−"; textSize = 19f; gravity = Gravity.CENTER
                setTextColor(c(0xFFFFFFFF)); background = rounded(c(0xFF1D3554), 9, c(0xFF315B8B))
                isClickable = true
            }
            column.addView(minus, LinearLayout.LayoutParams(-1, dp(30)).apply {
                setMargins(dp(1), dp(5), dp(1), dp(4))
            })
            column.addView(valueText, LinearLayout.LayoutParams(-1, dp(22)))
            plus.setOnClickListener { fader.setValue((fader.value + 1).coerceAtMost(24), true) }
            minus.setOnClickListener { fader.setValue((fader.value - 1).coerceAtLeast(-24), true) }
            row.addView(column, LinearLayout.LayoutParams(0, -2, 1f))
        }
        eqCard.addView(row)
        eqCard.addView(label("−12 dB     0 dB     +12 dB   •   Langkah 0,5 dB", 9f, c(0xFF899AB5)).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(7), 0, 0)
        })
        content.addView(eqCard)
        updateModeLabels()

        // Presets
        section(content, "PRESET MUSIK")
        val presetCard = makeCard().apply {
            background = rounded(c(0xFF111827), 18, c(0xFF263B5D))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        presetGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        populatePresetGrid()
        presetCard.addView(presetGrid)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = Button(this).apply { text = "Simpan preset baru"; textSize = 11f; setOnClickListener { saveCustomPreset() } }
        val importBtn = Button(this).apply { text = "Import preset"; textSize = 11f; setOnClickListener { importPresetFile() } }
        val reset = Button(this).apply { text = "Reset Flat"; textSize = 11f; setOnClickListener { applyPreset("Flat") } }
        actions.addView(save, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(importBtn, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(reset, LinearLayout.LayoutParams(0, -2, 1f))
        presetCard.addView(actions)
        content.addView(presetCard)

        val footer = label("Dibuat oleh Ilham Galeh", 11f, c(0xFF8294B2), true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(5))
        }
        content.addView(footer)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addChannelControl(parent: LinearLayout, title: String, subtitle: String, left: Boolean) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = rounded(c(0xFF182235), 14, c(0xFF2B4568))
        }
        panel.addView(label(title, 13f, c(0xFFF0F5FF), true).apply { gravity = Gravity.CENTER })
        panel.addView(label(subtitle, 10f, c(0xFF42C5FF), true).apply { gravity = Gravity.CENTER })

        val meterAndFader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        val meter = LevelMeterView(this)
        if (left) meterL = meter else meterR = meter
        meterAndFader.addView(meter, LinearLayout.LayoutParams(dp(24), dp(126)).apply {
            setMargins(dp(3), 0, dp(7), 0)
        })

        val valueText = label(formatDb(if (left) volL else volR), 11f, c(0xFF45C5FF), true).apply {
            gravity = Gravity.CENTER
        }
        if (left) volLText = valueText else volRText = valueText
        val fader = VerticalFader(this).apply {
            setValue(if (left) volL else volR)
            onValueChanged = { newValue, fromUser ->
                if (left) volL = newValue else volR = newValue
                valueText.text = formatDb(newValue)
                pushGains()
                if (fromUser) saveSettings()
            }
        }
        meterAndFader.addView(fader, LinearLayout.LayoutParams(dp(48), dp(126)))
        panel.addView(meterAndFader)
        panel.addView(valueText)

        val muteButton = TextView(this).apply {
            text = if (if (left) muteL else muteR) "MUTED" else "MUTE"
            textSize = 10f; gravity = Gravity.CENTER
            setTextColor(c(0xFFFFFFFF))
            background = rounded(if (if (left) muteL else muteR) c(0xFF9F3345) else c(0xFF263B5D), 9, c(0xFF42658E))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setOnClickListener {
                if (left) muteL = !muteL else muteR = !muteR
                val muted = if (left) muteL else muteR
                text = if (muted) "MUTED" else "MUTE"
                background = rounded(if (muted) c(0xFF9F3345) else c(0xFF263B5D), 9, c(0xFF42658E))
                pushGains()
                saveSettings()
                Toast.makeText(this@MainActivity, "$title ${if (muted) "mute" else "aktif"}", Toast.LENGTH_SHORT).show()
            }
        }
        if (left) muteLButton = muteButton else muteRButton = muteButton
        panel.addView(muteButton, LinearLayout.LayoutParams(-1, dp(34)).apply {
            setMargins(dp(2), dp(6), dp(2), 0)
        })
        parent.addView(panel, LinearLayout.LayoutParams(0, -2, 1f).apply {
            setMargins(dp(3), 0, dp(3), 0)
        })
    }

    // ---------------- Preset grid ----------------

    private fun populatePresetGrid() {
        val grid = presetGrid ?: return
        grid.removeAllViews()
        val custom = prefs.all.keys.filter { it.startsWith("custom_") }.map { it.removePrefix("custom_") }.sorted()
        val available = (builtIns.filter { it != "Custom" } + custom).distinct()
        available.chunked(3).forEach { names ->
            val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            names.forEach { name ->
                val button = TextView(this).apply {
                    text = name; textSize = 11f; gravity = Gravity.CENTER
                    setTextColor(c(0xFFE5EDFF)); background = rounded(c(0xFF1B2638), 12, c(0xFF304968))
                    setPadding(dp(3), dp(11), dp(3), dp(11))
                    isClickable = true
                    setOnClickListener {
                        if (name in builtIns) applyPreset(name) else applySavedPreset(name)
                    }
                }
                presetRow.addView(button, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            grid.addView(presetRow)
        }
    }

    // ---------------- Pemutar bawaan: tempat VOL L/R & MUTE benar-benar bekerja ----------------

    /** Kirim gain linear ke pemutar. 0.5 dB per langkah: gain = 10^(halfDb / 40). MUTE = 0. */
    private fun pushGains() {
        fun lin(halfDb: Int, muted: Boolean): Float =
            if (muted) 0f else Math.pow(10.0, halfDb / 40.0).toFloat()
        player?.setGains(lin(volL, muteL), lin(volR, muteR))
    }

    private fun pickAudio() {
        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "audio/*"
        }
        try { startActivityForResult(intent, 902) }
        catch (_: Exception) { Toast.makeText(this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show() }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val name = cursor.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "Audio"
    }

    private fun startPlayback(uri: Uri) {
        lastAudioUri = uri
        trackDurationMs = 0L
        trackTitle?.text = displayName(uri)
        seekBar?.progress = 0
        timeText?.text = "0:00 / 0:00"
        requestAudioFocus()
        pushGains()
        player?.start(uri)
        setPlayingUi(true)
        status?.text = "Memuat audio…"
    }

    private fun togglePlay() {
        val p = player ?: return
        when {
            !p.isActive -> {
                val uri = lastAudioUri
                if (uri != null) startPlayback(uri) else pickAudio()
            }
            p.isPlaying -> { p.pause(); setPlayingUi(false) }
            else -> { requestAudioFocus(); p.resume(); setPlayingUi(true) }
        }
    }

    private fun stopPlayback() {
        player?.stop()
        finishPlayback("Pemutar berhenti")
    }

    /** Dipanggil saat lagu selesai/dihentikan/error: reset tampilan dan kembalikan efek ke sesi global. */
    private fun finishPlayback(message: String) {
        abandonAudioFocus()
        setPlayingUi(false)
        seekBar?.progress = 0
        timeText?.text = "0:00 / ${formatTime(trackDurationMs)}"
        meterL?.setLevel(0f); meterR?.setLevel(0f)
        attachEffects(0)
        status?.text = message
    }

    private fun setPlayingUi(playing: Boolean) {
        playButton?.text = if (playing) "❚❚ Jeda" else "▶ Putar"
    }

    private fun updateProgress(positionMs: Long, durationMs: Long) {
        trackDurationMs = durationMs
        if (userSeeking) return
        timeText?.text = formatTime(positionMs) + " / " + formatTime(durationMs)
        if (durationMs > 0) seekBar?.progress = (positionMs * 1000L / durationMs).toInt().coerceIn(0, 1000)
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        return String.format(java.util.Locale.US, "%d:%02d", total / 60, total % 60)
    }

    @Suppress("DEPRECATION")
    private fun requestAudioFocus() {
        try {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun abandonAudioFocus() {
        try { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocus(focusListener) }
        catch (_: Exception) {}
    }

    private fun importPresetFile() {
        val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        try { startActivityForResult(intent, 901) }
        catch (_: Exception) { Toast.makeText(this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated by Android; retained for compatibility with the current project structure")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 902) { data?.data?.let { startPlayback(it) }; return }
        if (requestCode != 901) return
        val uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
            } ?: throw IllegalArgumentException("File kosong")
            val root = JSONObject(text)
            val imported = JSONArray()
            if (root.has("presets")) {
                val list = root.getJSONArray("presets")
                for (i in 0 until list.length()) imported.put(list.getJSONObject(i))
            } else imported.put(root)

            var count = 0
            for (i in 0 until imported.length()) {
                val item = imported.getJSONObject(i)
                val name = item.optString("name", "Imported ${i + 1}").trim()
                    .replace(Regex("[^A-Za-z0-9 _-]"), "").take(28).ifBlank { "Imported ${i + 1}" }
                val bands = when {
                    item.has("bands_db") -> item.getJSONArray("bands_db")
                    item.has("bands") -> item.getJSONArray("bands")
                    else -> throw IllegalArgumentException("Preset $name tidak memiliki bands_db")
                }
                if (bands.length() != 10) throw IllegalArgumentException("Preset $name harus memiliki 10 band")
                val halfDb = JSONArray()
                for (b in 0 until 10) {
                    val raw = bands.getDouble(b)
                    // bands_db uses dB values; legacy bands uses half-dB integer units.
                    val value = if (item.has("bands_db")) (raw * 2.0).roundToInt() else raw.roundToInt()
                    halfDb.put(value.coerceIn(-24, 24))
                }
                prefs.edit().putString("custom_$name", halfDb.toString()).apply()
                count++
            }
            Toast.makeText(this, "$count preset berhasil diimpor", Toast.LENGTH_LONG).show()
            rebuildPresetButtons()
        } catch (e: Exception) {
            Toast.makeText(this, "Import gagal: ${e.message ?: "format JSON tidak valid"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun rebuildPresetButtons() {
        // Isi ulang grid preset tanpa recreate(), supaya lagu yang sedang diputar tidak terhenti.
        populatePresetGrid()
    }

    private fun formatDb(value: Int): String = String.format(java.util.Locale.US, "%.1f dB", value / 2f)

    private fun updateModeLabels() {
        modeInfo?.text = if (eqMode == "2WAY")
            "2-Way aktif • LOW: 31–500 Hz  |  HIGH: 1–16 kHz"
        else
            "1-Way aktif • Semua frekuensi dalam satu kurva 31 Hz–16 kHz"
        lowTitle?.visibility = if (eqMode == "2WAY") View.VISIBLE else View.GONE
        highTitle?.visibility = if (eqMode == "2WAY") View.VISIBLE else View.GONE
    }

    /** Pasang Equalizer + Visualizer ke sesi audio. Sesi 0 = global (cadangan), sesi lain = pemutar bawaan. */
    private fun attachEffects(sessionId: Int) {
        effectSession = sessionId
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        try { eq?.release() } catch (_: Exception) {}
        eq = null
        initEqualizer(sessionId)
        if (hasRecordPermission()) startVisualizer(sessionId)
    }

    private fun initEqualizer(sessionId: Int) {
        try {
            eq = Equalizer(0, sessionId).also { it.enabled = effectsEnabled }
            applyEqualizer()
            status?.text = if (sessionId == 0)
                "Status: EQ global aktif • VOL L/R & MUTE hanya untuk lagu di Pemutar"
            else
                "Pemutar aktif • EQ, VOL L/R & MUTE berlaku"
        } catch (e: Exception) {
            status?.text = "Status: efek audio tidak didukung perangkat (${e.javaClass.simpleName})"
        }
    }

    private fun applyEqualizer() {
        val effect = eq ?: return
        if (!effectsEnabled) return
        try {
            val range = effect.bandLevelRange
            val buckets = Array(effect.numberOfBands.toInt()) { mutableListOf<Int>() }
            values.forEachIndexed { index, halfDb ->
                buckets[nearestBand(effect, centerHz[index]).toInt()].add(halfDb)
            }
            for (band in 0 until effect.numberOfBands) {
                val halfDb = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                val milliBel = (halfDb * 50).coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band.toShort(), milliBel.toShort())
            }
        } catch (_: Exception) {}
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Short {
        var best = 0
        var difference = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < difference) { difference = d; best = i }
        }
        return best.toShort()
    }

    private fun updateFaders() {
        faders.forEachIndexed { i, fader -> fader.setValue(values[i], false) }
    }

    private fun applyPreset(name: String) {
        val preset = when (name) {
            "Flat" -> intArrayOf(0,0,0,0,0,0,0,0,0,0)
            "Pop" -> intArrayOf(4,2,0,-2,-2,2,4,4,2,2)
            "Rock" -> intArrayOf(6,4,2,0,-2,2,4,6,6,6)
            "Jazz" -> intArrayOf(4,2,0,2,-2,-2,0,2,4,4)
            "Bass Boost" -> intArrayOf(10,8,6,4,2,0,0,0,0,0)
            "Vocal" -> intArrayOf(-4,-2,0,2,6,8,6,4,0,-2)
            "Dangdut" -> intArrayOf(8,6,4,2,0,2,4,4,2,2)
            "DJ Horeg" -> intArrayOf(10,8,6,2,-2,0,4,6,8,6)
            else -> IntArray(10)
        }
        preset.forEachIndexed { i, v -> values[i] = v.coerceIn(-24, 24) }
        updateFaders()
        applyEqualizer()
        saveSettings()
    }

    private fun startVisualizer(sessionId: Int) {
        try {
            visualizer = Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, data: ByteArray?, samplingRate: Int) {
                        data?.let { bytes ->
                            val bars = FloatArray(36)
                            for (i in bars.indices) {
                                val index = 2 + i * 2
                                if (index < bytes.size) bars[i] = (abs(bytes[index].toInt()).toFloat() / 128f).coerceIn(0f, 1f)
                            }
                            // Meter L/R sekarang dari PCM pemutar (ChannelPlayer); Visualizer hanya untuk spektrum.
                            runOnUiThread { spectrumView?.setBars(bars) }
                        }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (_: Exception) {
            status?.text = "Status: Spectrum Analyzer tidak tersedia pada sesi audio ini"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVisualizer(effectSession)
    }

    private fun saveCustomPreset() {
        val input = EditText(this).apply { hint = "Nama preset" }
        AlertDialog.Builder(this).setTitle("Simpan preset").setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Preset Saya" }
                prefs.edit().putString("custom_$name", JSONArray(values.toList()).toString()).apply()
                populatePresetGrid()
                Toast.makeText(this, "Preset $name disimpan", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun applySavedPreset(name: String) {
        try {
            val json = JSONArray(prefs.getString("custom_$name", "[]"))
            if (json.length() == 10) {
                for (i in values.indices) values[i] = json.getInt(i).coerceIn(-24, 24)
                updateFaders(); applyEqualizer(); saveSettings()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Preset tidak dapat dibaca", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSettings() {
        for (i in values.indices) values[i] = prefs.getInt("band_$i", 0).coerceIn(-24, 24)
        effectsEnabled = prefs.getBoolean("eq_enabled", true)
        eqMode = prefs.getString("eq_mode", "1WAY") ?: "1WAY"
        volL = prefs.getInt("vol_l", 0).coerceIn(-24, 24)
        volR = prefs.getInt("vol_r", 0).coerceIn(-24, 24)
        muteL = prefs.getBoolean("mute_l", false)
        muteR = prefs.getBoolean("mute_r", false)
    }

    private fun saveSettings() {
        val editor = prefs.edit()
        values.forEachIndexed { i, v -> editor.putInt("band_$i", v) }
        editor.putString("eq_mode", eqMode)
            .putBoolean("eq_enabled", effectsEnabled)
            .putInt("vol_l", volL).putInt("vol_r", volR)
            .putBoolean("mute_l", muteL).putBoolean("mute_r", muteR)
            .apply()
    }

    override fun onDestroy() {
        player?.stop()
        abandonAudioFocus()
        try { visualizer?.release(); eq?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

private class VerticalFader(context: Context) : View(context) {
    var value: Int = 0
        private set
    var onValueChanged: ((Int, Boolean) -> Unit)? = null
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBFC5D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f
    }
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    fun setValue(newValue: Int, fromUser: Boolean = false) {
        val v = newValue.coerceIn(-24, 24)
        if (value != v) {
            value = v
            invalidate()
            onValueChanged?.invoke(v, fromUser)
        } else if (fromUser) onValueChanged?.invoke(v, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = d(8f)
        val bottom = height - d(8f)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val y = center - (value / 24f) * half
        val rail = RectF(cx - d(5f), top, cx + d(5f), bottom)
        trackPaint.shader = LinearGradient(rail.left, 0f, rail.right, 0f,
            intArrayOf(0xFF050A14.toInt(), 0xFF25364E.toInt(), 0xFF050A14.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rail, d(5f), d(5f), trackPaint)
        fillPaint.color = 0xFF168DFF.toInt()
        if (value >= 0) canvas.drawRoundRect(RectF(cx - d(3f), y, cx + d(3f), center), d(3f), d(3f), fillPaint)
        else canvas.drawRoundRect(RectF(cx - d(3f), center, cx + d(3f), y), d(3f), d(3f), fillPaint)
        val thumbHalf = (width * 0.43f).coerceAtMost(d(12f)).coerceAtLeast(d(5f))
        val thumb = RectF(cx - thumbHalf, y - d(10f), cx + thumbHalf, y + d(10f))
        thumbPaint.shader = LinearGradient(thumb.left, thumb.top, thumb.right, thumb.bottom,
            intArrayOf(0xFFF0F1F4.toInt(), 0xFFBFC3CC.toInt(), 0xFFE4E6EA.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(thumb, d(11f), d(11f), thumbPaint)
        canvas.drawRoundRect(thumb, d(11f), d(11f), borderPaint)
    }

    private fun updateFromY(y: Float) {
        val top = d(8f)
        val bottom = height - d(8f)
        val clamped = y.coerceIn(top, bottom)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        setValue((24f * (center - clamped) / half).roundToInt(), true)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                updateFromY(event.y)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

private class SpectrumView(context: Context) : View(context) {
    private var bars = FloatArray(36)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x4436AFFF; style = Paint.Style.FILL }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x223B82C5; strokeWidth = 1f }
    fun setBars(newBars: FloatArray) { bars = newBars; invalidate() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (bars.isEmpty() || width <= 0) return
        for (line in 1..3) {
            val y = height * line / 4f
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
        val gap = width * 0.012f
        val barWidth = (width - gap * (bars.size - 1)) / bars.size
        val base = height * 0.9f
        bars.forEachIndexed { i, level ->
            val h = (height * 0.78f * level.coerceIn(0.04f, 1f)).coerceAtLeast(4f)
            val left = i * (barWidth + gap)
            val rect = RectF(left, base - h, left + barWidth, base)
            glowPaint.color = if (i > bars.size * 0.72f) 0x553F6BFF else 0x4436AFFF
            barPaint.shader = LinearGradient(0f, base - h, 0f, base,
                intArrayOf(if (i > bars.size * 0.72f) 0xFF9B63FF.toInt() else 0xFF20D6E8.toInt(), 0xFF167CFF.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(left - 1, base - h - 2, left + barWidth + 1, base + 1), 4f, 4f, glowPaint)
            canvas.drawRoundRect(rect, 3f, 3f, barPaint)
        }
    }
}


/** Compact level meter with a red peak-hold marker. Input level is normalized 0..1. */
private class LevelMeterView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private var level = 0f
    private var peak = 0f
    private var holdFrames = 0
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF050A14.toInt() }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val peakPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF5364.toInt(); strokeWidth = d(3f) }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x557F9AB8; strokeWidth = d(1f) }

    fun setLevel(value: Float) {
        level = value.coerceIn(0f, 1f)
        if (level >= peak) { peak = level; holdFrames = 18 }
        else if (holdFrames > 0) holdFrames-- else peak = (peak - 0.025f).coerceAtLeast(level)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = width * 0.22f
        val right = width * 0.78f
        val top = d(4f)
        val bottom = height - d(4f)
        val track = RectF(left, top, right, bottom)
        canvas.drawRoundRect(track, d(5f), d(5f), bgPaint)
        for (i in 1..4) {
            val y = bottom - (bottom - top) * i / 5f
            canvas.drawLine(left, y, right, y, tickPaint)
        }
        val fillTop = bottom - (bottom - top) * level
        barPaint.shader = LinearGradient(0f, bottom, 0f, top,
            intArrayOf(0xFF20D6A0.toInt(), 0xFFB8E34A.toInt(), 0xFFFFB547.toInt(), 0xFFFF5265.toInt()),
            floatArrayOf(0f, 0.58f, 0.82f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(left + d(1f), fillTop, right - d(1f), bottom), d(4f), d(4f), barPaint)
        // Fixed red line at the top marks the clipping boundary.
        canvas.drawLine(left - d(3f), top + d(1f), right + d(3f), top + d(1f), peakPaint)
        // Moving peak-hold line shows the recent maximum signal level.
        val peakY = bottom - (bottom - top) * peak
        peakPaint.color = 0xFFFFC04D.toInt()
        canvas.drawLine(left - d(2f), peakY, right + d(2f), peakY, peakPaint)
        peakPaint.color = 0xFFFF5364.toInt()
    }
}

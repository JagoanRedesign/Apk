package com.dlmsmini.equalizer

import kotlin.math.abs
import kotlin.math.pow

/**
 * Stateful sample limiter for PCM float audio in the -1.0..1.0 range.
 * Call process() for each consecutive audio block from an app-owned PCM pipeline.
 * Android's global Equalizer effect does not expose other apps' PCM buffers, so this
 * processor cannot be attached to all system audio by an ordinary third-party app.
 */
class LimiterProcessor(
    var sampleRate: Int = 48000,
    var attackMs: Float = 9f,
    var releaseMs: Float = 100f,
    var ratio: Float = 3.1f,
    var thresholdDb: Float = -10.1f,
    var postGainDb: Float = 1.8f
) {
    private var envelope = 0f

    fun reset() { envelope = 0f }

    fun process(input: FloatArray, output: FloatArray = FloatArray(input.size)): FloatArray {
        require(output.size >= input.size) { "Output buffer lebih kecil dari input" }
        val threshold = 10.0.pow((thresholdDb.coerceIn(-60f, 0f) / 20.0)).toFloat()
        val postGain = 10.0.pow((postGainDb.coerceIn(-24f, 24f) / 20.0)).toFloat()
        val attack = coefficient(attackMs)
        val release = coefficient(releaseMs)
        val safeRatio = ratio.coerceIn(1f, 100f)

        for (i in input.indices) {
            val sample = input[i].coerceIn(-1f, 1f)
            val level = abs(sample)
            val coefficient = if (level > envelope) attack else release
            envelope = coefficient * envelope + (1f - coefficient) * level

            val over = if (envelope > threshold && threshold > 0f) envelope / threshold else 1f
            val compressedOver = if (over > 1f) over.pow(1f / safeRatio) else 1f
            val gain = (if (over > 1f) compressedOver / over else 1f) * postGain
            output[i] = (sample * gain).coerceIn(-1f, 1f)
        }
        return output
    }

    private fun coefficient(timeMs: Float): Float {
        val seconds = timeMs.coerceIn(0.1f, 5000f) / 1000f
        return kotlin.math.exp(-1f / (sampleRate.coerceAtLeast(8000) * seconds))
    }
}

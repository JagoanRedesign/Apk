package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * Slider bergaya fader mixer: jalur gelap dengan isian bercahaya, tanda skala tipis, dan gagang persegi
 * dengan garis aksen di tengah. Dipakai di layar Delay dan Limiter.
 */
class FaderSlider(context: Context) : View(context) {
    var max = 100
        set(v) { field = v.coerceAtLeast(1); invalidate() }
    var progress = 0
        set(v) { field = v.coerceIn(0, max); invalidate() }
    var accent: Int = Pal.c(0xFF00E5FF)
        set(v) { field = v; rebuildShader(); invalidate() }

    /** Dipanggil hanya saat pengguna menggeser. */
    var onUser: ((Int) -> Unit)? = null
    var onStop: (() -> Unit)? = null

    private val dens = resources.displayMetrics.density
    private fun d(v: Float) = v * dens

    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF0A101C); style = Paint.Style.FILL }
    private val trackStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF1E2A40); style = Paint.Style.STROKE; strokeWidth = d(1f) }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF22304A); strokeWidth = d(1.2f) }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val thumbP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val thumbStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF05080F); style = Paint.Style.STROKE; strokeWidth = d(2f) }
    private val thumbEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF34425E); style = Paint.Style.STROKE; strokeWidth = d(1f) }
    private val barP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()
    private var dragging = false

    private val thumbW get() = d(26f)
    private val thumbH get() = d(38f)
    private val padX get() = thumbW / 2f + d(4f)
    private val trackL get() = padX
    private val trackR get() = width - padX

    init { isClickable = true }

    private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun rebuildShader() {
        if (width <= 0) return
        fillP.shader = LinearGradient(trackL, 0f, trackR, 0f, intArrayOf(alpha(accent, 70), accent), null, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { rebuildShader() }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(getDefaultSize(suggestedMinimumWidth, w), resolveSize(d(56f).roundToInt(), h))
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f - d(3f)
        val cx = trackL + (trackR - trackL) * progress / max
        // Jalur.
        rect.set(trackL, cy - d(4f), trackR, cy + d(4f))
        c.drawRoundRect(rect, d(4f), d(4f), trackP)
        c.drawRoundRect(rect, d(4f), d(4f), trackStroke)
        // Isian.
        if (cx > trackL) {
            rect.set(trackL, cy - d(3f), cx, cy + d(3f))
            c.drawRoundRect(rect, d(3f), d(3f), fillP)
        }
        // Skala.
        for (i in 0..10) {
            val x = trackL + (trackR - trackL) * i / 10f
            val h = if (i % 5 == 0) d(7f) else d(4f)
            c.drawLine(x, cy + d(14f), x, cy + d(14f) + h, tickP)
        }
        // Cahaya di sekitar gagang.
        for (i in 3 downTo 1) {
            glowP.color = alpha(accent, if (dragging) 30 + (4 - i) * 14 else 16 + (4 - i) * 8)
            rect.set(cx - thumbW / 2 - d(i * 2.5f), cy - thumbH / 2 - d(i * 2.5f), cx + thumbW / 2 + d(i * 2.5f), cy + thumbH / 2 + d(i * 2.5f))
            c.drawRoundRect(rect, d(10f + i * 2.5f), d(10f + i * 2.5f), glowP)
        }
        // Gagang.
        rect.set(cx - thumbW / 2, cy - thumbH / 2, cx + thumbW / 2, cy + thumbH / 2)
        thumbP.shader = LinearGradient(0f, rect.top, 0f, rect.bottom, Pal.c(0xFF2A3550), Pal.c(0xFF141B2B), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, d(9f), d(9f), thumbP)
        c.drawRoundRect(rect, d(9f), d(9f), thumbStroke)
        rect.inset(d(1.5f), d(1.5f))
        c.drawRoundRect(rect, d(8f), d(8f), thumbEdge)
        // Garis aksen.
        barP.color = accent
        rect.set(cx - d(2f), cy - d(11f), cx + d(2f), cy + d(11f))
        c.drawRoundRect(rect, d(2f), d(2f), barP)
    }

    private fun update(x: Float) {
        val span = (trackR - trackL).coerceAtLeast(1f)
        val p = ((x - trackL) / span * max).roundToInt().coerceIn(0, max)
        if (p != progress) { progress = p; onUser?.invoke(p) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                update(e.x); invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (dragging) update(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) { dragging = false; onStop?.invoke(); invalidate() }
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}

/** Komponen visual bersama untuk panel DSP (Delay, Limiter): panel, label mono, kotak nilai, kontrol segmen. */
object Dsp {
    val CYAN get() = Pal.c(0xFF00E5FF)
    val GREEN get() = Pal.c(0xFF2EE59D)
    val AMBER get() = Pal.c(0xFFFFC94D)
    val LABEL get() = Pal.c(0xFF8EA0BF)
    val STROKE get() = Pal.c(0xFF1C2740)

    fun mono(ctx: Context, text: String, size: Float, color: Int, bold: Boolean = true, spacing: Float = 0.06f): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
            letterSpacing = spacing
            includeFontPadding = false
        }

    fun panel(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.rounded(ctx, Pal.c(0xFF0B1120), 18, STROKE)
        setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 14), Ui.dp(ctx, 16), Ui.dp(ctx, 16))
    }

    /** Judul bagian: garis aksen kecil + teks mono kapital. */
    fun heading(ctx: Context, title: String, color: Int = CYAN): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(View(ctx).apply { background = Ui.rounded(ctx, color, 2) }, LinearLayout.LayoutParams(Ui.dp(ctx, 4), Ui.dp(ctx, 16)))
        addView(mono(ctx, title, 12f, Pal.c(0xFFDCE6FA), true, 0.14f).apply { setPadding(Ui.dp(ctx, 8), 0, 0, 0) })
    }

    /** Kotak nilai bergaris aksen redup. */
    fun readout(ctx: Context, text: String, color: Int, size: Float = 13f): TextView = mono(ctx, text, size, color).apply {
        gravity = Gravity.CENTER
        minWidth = Ui.dp(ctx, 78)
        background = Ui.rounded(ctx, Pal.c(0xFF070B14), 10, (color and 0x00FFFFFF) or 0x55000000)
        setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 6), Ui.dp(ctx, 10), Ui.dp(ctx, 6))
    }

    /** Kartu statistik kecil: label kecil di atas, nilai besar di bawah. */
    fun stat(ctx: Context, title: String, color: Int): Pair<LinearLayout, TextView> {
        val v = mono(ctx, "", 15f, color)
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = Ui.rounded(ctx, Pal.c(0xFF070B14), 12, Pal.c(0xFF172036))
            setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 9), Ui.dp(ctx, 6), Ui.dp(ctx, 9))
            addView(mono(ctx, title, 9f, LABEL, false, 0.12f))
            addView(v, LinearLayout.LayoutParams(-2, -2).apply { topMargin = Ui.dp(ctx, 4) })
        }
        return box to v
    }

    /** Baris statistik berjajar sama lebar. */
    fun statRow(ctx: Context, vararg boxes: View): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        boxes.forEachIndexed { i, b ->
            addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = Ui.dp(ctx, 8) })
        }
    }

    /** Kontrol segmen. Mengembalikan (tampilan, fungsi pemilih tanpa memicu callback). */
    fun segmented(ctx: Context, items: List<String>, selected: Int, onSelect: (Int) -> Unit): Pair<LinearLayout, (Int) -> Unit> {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(ctx, Pal.c(0xFF070B14), 14, Pal.c(0xFF172036))
            setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3))
        }
        val tabs = ArrayList<TextView>()
        fun paint(sel: Int) {
            tabs.forEachIndexed { i, t ->
                val on = i == sel
                t.setTextColor(if (on) Pal.c(0xFFFFFFFF) else LABEL)
                t.background = if (on) Ui.rounded(ctx, Pal.c(0xFF10324A), 11, Pal.c(0xFF2D9CC4)) else null
            }
        }
        items.forEachIndexed { i, s ->
            val t = mono(ctx, s, 11f, LABEL, true, 0.04f).apply {
                gravity = Gravity.CENTER
                setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 10), Ui.dp(ctx, 4), Ui.dp(ctx, 10))
                isClickable = true
                setOnClickListener { paint(i); onSelect(i) }
            }
            tabs.add(t)
            box.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        paint(selected)
        return box to { sel -> paint(sel) }
    }

    /**
     * Baris parameter: nama kapital kecil di kiri, kotak nilai di kanan, fader di bawah, label rentang min/maks.
     * Mengembalikan fungsi penyegar yang memuat ulang nilai dari [get]. Baris ditambahkan juga ke [dim] (bila ada)
     * supaya bisa diredupkan saat fitur nonaktif.
     */
    fun paramRow(
        ctx: Context, parent: LinearLayout, title: String, spec: Spec,
        get: () -> Float, onValue: (Float) -> Unit, onDone: (() -> Unit)? = null,
        accent: Int = CYAN, dim: MutableList<View>? = null
    ): () -> Unit {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, Ui.dp(ctx, 16), 0, 0) }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(mono(ctx, title.uppercase(), 12f, Pal.c(0xFFC9D6EE), true, 0.12f), LinearLayout.LayoutParams(0, -2, 1f))
        val value = readout(ctx, spec.format(get()), accent)
        head.addView(value)
        row.addView(head)
        val bar = FaderSlider(ctx).apply {
            this.accent = accent
            max = spec.steps
            progress = spec.toProgress(get())
            this.onUser = { p -> val v = spec.toValue(p); value.text = spec.format(v); onValue(v) }
            this.onStop = { onDone?.invoke() }
        }
        row.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 4) })
        val range = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4), 0) }
        range.addView(mono(ctx, spec.format(spec.min), 9f, Pal.c(0xFF5C6E8E), false), LinearLayout.LayoutParams(0, -2, 1f))
        range.addView(mono(ctx, spec.format(spec.max), 9f, Pal.c(0xFF5C6E8E), false))
        row.addView(range)
        parent.addView(row)
        dim?.add(row)
        return {
            bar.progress = spec.toProgress(get())
            value.text = spec.format(get())
        }
    }
}


/**
 * Slider garis tipis: jalur gelap, isian biru bergradasi, gagang bulat pucat dengan lingkar cahaya.
 * Dipakai untuk baris parameter Limiter.
 */
class LineSlider(context: Context) : View(context) {
    var max = 100
        set(v) { field = v.coerceAtLeast(1); invalidate() }
    var progress = 0
        set(v) { field = v.coerceIn(0, max); invalidate() }

    /** Dipanggil hanya saat pengguna menggeser. */
    var onUser: ((Int) -> Unit)? = null
    var onStop: (() -> Unit)? = null

    private val dens = resources.displayMetrics.density
    private fun d(v: Float) = v * dens
    private val trackP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFF182235) }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Pal.c(0xFFD6ECFF) }
    private val rect = RectF()
    private var dragging = false
    private val padX get() = d(14f)

    init { isClickable = true }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fillP.shader = LinearGradient(padX, 0f, (w - padX).coerceAtLeast(padX + 1f), 0f, Pal.c(0xFF1E8CFF), Pal.c(0xFF29B8FF), Shader.TileMode.CLAMP)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(getDefaultSize(suggestedMinimumWidth, w), resolveSize(d(40f).roundToInt(), h))
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val l = padX
        val r = width - padX
        val cx = l + (r - l) * progress / max
        rect.set(l, cy - d(3.5f), r, cy + d(3.5f))
        c.drawRoundRect(rect, d(4f), d(4f), trackP)
        if (cx > l) {
            rect.set(l, cy - d(3.5f), cx, cy + d(3.5f))
            c.drawRoundRect(rect, d(4f), d(4f), fillP)
        }
        glowP.color = (Pal.c(0xFF29B8FF) and 0x00FFFFFF) or ((if (dragging) 70 else 38) shl 24)
        c.drawCircle(cx, cy, d(if (dragging) 17f else 15f), glowP)
        c.drawCircle(cx, cy, d(11.5f), thumbP)
    }

    private fun update(x: Float) {
        val span = (width - 2 * padX).coerceAtLeast(1f)
        val p = ((x - padX) / span * max).roundToInt().coerceIn(0, max)
        if (p != progress) { progress = p; onUser?.invoke(p) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dragging = true; parent?.requestDisallowInterceptTouchEvent(true); update(e.x); invalidate() }
            MotionEvent.ACTION_MOVE -> if (dragging) update(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) { dragging = false; onStop?.invoke(); invalidate() }
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}

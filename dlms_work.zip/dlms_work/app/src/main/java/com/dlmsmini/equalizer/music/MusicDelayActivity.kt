package com.dlmsmini.equalizer.music

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.dlmsmini.equalizer.Dsp
import com.dlmsmini.equalizer.FaderSlider
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Delay kanal untuk pemutar musik di dalam aplikasi. Susunan: pilihan kanal, angka delay besar (bisa diketik),
 * jarak akustik, fader, tombol langkah, preset jarak, lalu kartu lingkungan (suhu) dan ringkasan OUT 1 / OUT 2.
 */
class MusicDelayActivity : AppCompatActivity() {
    private var target = 2 // 0 = OUT 1 (kiri), 1 = OUT 2 (kanan), 2 = keduanya
    private var suppress = false
    private var tempC = 28

    private lateinit var valueBox: EditText
    private lateinit var distText: TextView
    private lateinit var slider: FaderSlider
    private lateinit var selectSeg: (Int) -> Unit
    private lateinit var statSpeed: TextView
    private lateinit var statTemp: TextView
    private lateinit var tempSlider: FaderSlider
    private lateinit var leftBar: View
    private lateinit var leftRest: View
    private lateinit var leftVal: TextView
    private lateinit var rightBar: View
    private lateinit var rightRest: View
    private lateinit var rightVal: TextView

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun current(): Float = if (target == 1) MusicDelay.rightMs else MusicDelay.leftMs
    private fun fmt(v: Float): String = String.format(Locale("id", "ID"), "%.1f", v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicDelay.load(this)
        tempC = MusicPrefs.delayTemp(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.BG) }
        Ui.fitSystemBars(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Icons.view(this, Icons.BACK, 18f, Pal.TEXT, "Kembali").apply { setOnClickListener { finish() } })
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(Ui.label(this, "Delay pemutar", 16f, Pal.TEXT, true))
        titleCol.addView(Ui.label(this, "Hanya untuk musik di dalam aplikasi", 11f, Pal.MUTED))
        top.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Ui.chip(this, "Reset").apply {
            setOnClickListener { MusicDelay.set(this@MusicDelayActivity, 0f, 0f); refresh() }
        })
        top.addView(View(this), LinearLayout.LayoutParams(dp(12), 1))
        root.addView(top)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(24))
        }

        // ---- Kartu delay ----
        val dc = Dsp.panel(this)
        dc.addView(Dsp.heading(this, "DELAY KANAL"))
        val (seg, select) = Dsp.segmented(this, listOf("OUT 1 · KIRI", "OUT 2 · KANAN", "KEDUANYA"), target) { i -> target = i; refresh() }
        selectSeg = select
        dc.addView(seg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // Angka besar yang bisa diketik.
        val big = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        valueBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine()
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 38f
            setTextColor(Dsp.CYAN)
            background = null
            minWidth = dp(120)
            setPadding(dp(4), dp(2), dp(4), dp(2))
            setOnEditorActionListener { v, id, _ ->
                if (id == EditorInfo.IME_ACTION_DONE) { commitBox(); v.clearFocus(); true } else false
            }
            setOnFocusChangeListener { _, has -> if (!has) commitBox() }
        }
        big.addView(valueBox)
        big.addView(Dsp.mono(this, "MS", 16f, Pal.c(0xFF5FB8D0)).apply { setPadding(dp(4), dp(14), 0, 0) })
        dc.addView(big, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        dc.addView(View(this).apply { setBackgroundColor(Pal.c(0xFF16405A)) }, LinearLayout.LayoutParams(dp(150), dp(2)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        distText = Dsp.mono(this, "", 13f, Dsp.AMBER).apply { gravity = Gravity.CENTER }
        dc.addView(distText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        slider = FaderSlider(this).apply {
            accent = Dsp.CYAN
            max = (MusicDelay.MAX_MS * 10).toInt()
            onUser = { p -> if (!suppress) setDelay(p / 10f) }
        }
        dc.addView(slider, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val range = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), 0, dp(4), 0) }
        range.addView(Dsp.mono(this, "0 MS", 9f, Pal.c(0xFF5C6E8E), false), LinearLayout.LayoutParams(0, -2, 1f))
        range.addView(Dsp.mono(this, "${MusicDelay.MAX_MS.roundToInt()} MS", 9f, Pal.c(0xFF5C6E8E), false))
        dc.addView(range)

        // Tombol langkah.
        val steps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(-10f, -1f, -0.1f, 0f, 0.1f, 1f, 10f).forEachIndexed { i, d ->
            val label = when {
                d == 0f -> "0"
                d == d.toInt().toFloat() -> (if (d > 0) "+" else "") + d.toInt()
                else -> (if (d > 0) "+" else "") + d.toString()
            }
            val b = Dsp.mono(this, label, 12f, if (d == 0f) Dsp.AMBER else Pal.c(0xFFB9C7E0), true, 0f).apply {
                gravity = Gravity.CENTER
                background = Ui.rounded(this@MusicDelayActivity, Pal.c(0xFF111A2B), 10, Pal.c(0xFF22304A))
                setPadding(0, dp(11), 0, dp(11))
                isClickable = true
                setOnClickListener { setDelay(if (d == 0f) 0f else current() + d) }
            }
            steps.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(4) })
        }
        dc.addView(steps, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // Atur dari jarak.
        dc.addView(Dsp.mono(this, "ATUR DARI JARAK", 10f, Dsp.LABEL, false, 0.14f), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(18) })
        val dist = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(0.5f, 1f, 2f, 3f, 5f, 10f).forEachIndexed { i, m ->
            val b = Ui.chip(this, (if (m < 1f) "0,5" else m.toInt().toString()) + " m").apply {
                gravity = Gravity.CENTER
                setOnClickListener { setDelay((m / MusicDelay.speed(tempC) * 1000.0).toFloat()) }
            }
            dist.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(4) })
        }
        dc.addView(dist, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        body.addView(dc)

        // ---- Kartu ringkasan OUT 1 / OUT 2 ----
        val oc = Dsp.panel(this)
        oc.addView(Dsp.heading(this, "RINGKASAN KANAL", Dsp.GREEN))
        val l = miniBar("OUT 1")
        leftBar = l.first; leftRest = l.second; leftVal = l.third
        val r = miniBar("OUT 2")
        rightBar = r.first; rightRest = r.second; rightVal = r.third
        oc.addView(l.fourth, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        oc.addView(r.fourth, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        body.addView(oc, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // ---- Kartu lingkungan ----
        val ec = Dsp.panel(this)
        ec.addView(Dsp.heading(this, "KOREKSI SUHU LAPANGAN", Dsp.AMBER))
        val (sT, vT) = Dsp.stat(this, "SUHU UDARA", Dsp.GREEN)
        val (sS, vS) = Dsp.stat(this, "KECEPATAN SUARA", Dsp.AMBER)
        statTemp = vT; statSpeed = vS
        ec.addView(Dsp.statRow(this, sT, sS), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        tempSlider = FaderSlider(this).apply {
            accent = Dsp.GREEN
            max = 50
            onUser = { p -> if (!suppress) { tempC = p; MusicPrefs.setDelayTemp(this@MusicDelayActivity, p); refresh() } }
        }
        ec.addView(tempSlider, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), 0, dp(4), 0) }
        tr.addView(Dsp.mono(this, "0°C", 9f, Pal.c(0xFF5C6E8E), false), LinearLayout.LayoutParams(0, -2, 1f))
        tr.addView(Dsp.mono(this, "50°C", 9f, Pal.c(0xFF5C6E8E), false))
        ec.addView(tr)
        body.addView(ec, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        body.addView(Ui.label(this,
            "Delay ini hanya berlaku untuk pemutar musik di dalam aplikasi (streaming, unduhan, dan lagu perangkat). " +
                "Audio aplikasi lain tidak ikut berubah. Jarak dihitung dari delay dan kecepatan suara pada suhu yang dipilih.",
            12f, Pal.MUTED).apply { setPadding(dp(4), dp(14), dp(4), 0) })

        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    private class Quad(val first: View, val second: View, val third: TextView, val fourth: LinearLayout)

    /** Batang kecil: label, batang terisi menurut delay, dan nilai ms. */
    private fun miniBar(name: String): Quad {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(Dsp.mono(this, name, 11f, Pal.c(0xFFC9D6EE), true, 0.1f), LinearLayout.LayoutParams(dp(52), -2))
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(this@MusicDelayActivity, Pal.c(0xFF070B14), 6, Pal.c(0xFF172036))
        }
        val fill = View(this).apply { background = Ui.rounded(this@MusicDelayActivity, Dsp.CYAN, 6) }
        val rest = View(this)
        track.addView(fill, LinearLayout.LayoutParams(0, dp(12), 0f))
        track.addView(rest, LinearLayout.LayoutParams(0, dp(12), 1f))
        row.addView(track, LinearLayout.LayoutParams(0, dp(12), 1f).apply { leftMargin = dp(6); rightMargin = dp(10) })
        val v = Dsp.mono(this, "", 12f, Dsp.CYAN).apply { gravity = Gravity.END }
        row.addView(v, LinearLayout.LayoutParams(dp(72), -2))
        return Quad(fill, rest, v, row)
    }

    private fun setBar(fill: View, rest: View, ms: Float) {
        val f = (ms / MusicDelay.MAX_MS).coerceIn(0f, 1f)
        (fill.layoutParams as LinearLayout.LayoutParams).weight = f
        (rest.layoutParams as LinearLayout.LayoutParams).weight = 1f - f
        fill.visibility = if (f <= 0f) View.INVISIBLE else View.VISIBLE
        fill.requestLayout(); rest.requestLayout()
    }

    private fun commitBox() {
        if (suppress) return
        val v = valueBox.text.toString().trim().replace(',', '.').toFloatOrNull()
        if (v != null) setDelay(v) else refresh()
    }

    private fun setDelay(v: Float) {
        val x = ((v * 10).roundToInt() / 10f).coerceIn(0f, MusicDelay.MAX_MS)
        when (target) {
            0 -> MusicDelay.set(this, left = x)
            1 -> MusicDelay.set(this, right = x)
            else -> MusicDelay.set(this, x, x)
        }
        refresh()
    }

    private fun refresh() {
        suppress = true
        selectSeg(target)
        val v = current()
        valueBox.setText(fmt(v))
        slider.progress = (v * 10).roundToInt()
        val m = MusicDelay.distanceM(v, tempC)
        distText.text = String.format(Locale.US, "≈ %.2f M  ·  %.2f FT", m, m * 3.28084)
        statTemp.text = "${tempC}°C"
        statSpeed.text = "${MusicDelay.speed(tempC).roundToInt()} M/S"
        tempSlider.progress = tempC
        setBar(leftBar, leftRest, MusicDelay.leftMs)
        setBar(rightBar, rightRest, MusicDelay.rightMs)
        leftVal.text = fmt(MusicDelay.leftMs) + " ms"
        rightVal.text = fmt(MusicDelay.rightMs) + " ms"
        suppress = false
    }
}

package com.dlmsmini.equalizer.music

import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import java.util.Locale
import kotlin.math.roundToInt

/** Delay kanal untuk pemutar musik di dalam aplikasi: slider, kotak nilai, tombol langkah, jarak akustik, koreksi suhu. */
class MusicDelayActivity : AppCompatActivity() {
    private var target = 2 // 0 = OUT 1 (kiri), 1 = OUT 2 (kanan), 2 = keduanya
    private var suppress = false
    private var tempC = 28

    private lateinit var distText: TextView
    private lateinit var tempText: TextView
    private lateinit var delayLabel: TextView
    private lateinit var valueBox: EditText
    private lateinit var bar: SeekBar
    private lateinit var tempVal: TextView
    private lateinit var tempBar: SeekBar
    private val chips = ArrayList<TextView>()

    private fun mono(text: String, size: Float, color: Int, bold: Boolean = true): TextView =
        Ui.label(this, text, size, color, bold).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.rounded(this@MusicDelayActivity, Pal.c(0xFF0A0F1A), 16, Pal.c(0xFF1B2433))
        setPadding(Ui.dp(this@MusicDelayActivity, 16), Ui.dp(this@MusicDelayActivity, 14), Ui.dp(this@MusicDelayActivity, 16), Ui.dp(this@MusicDelayActivity, 14))
    }

    private fun gap(h: Int) = android.view.View(this).also { it.minimumHeight = Ui.dp(this, h) }

    private fun current(): Float = if (target == 1) MusicDelay.rightMs else MusicDelay.leftMs

    private fun fmt(v: Float): String = String.format(Locale("id", "ID"), "%.1f", v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicDelay.load(this)
        tempC = MusicPrefs.delayTemp(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.BG) }
        Ui.fitSystemBars(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Icons.view(this, Icons.BACK, 18f, Pal.TEXT, "Kembali").apply { setOnClickListener { finish() } })
        top.addView(Ui.label(this, "Delay pemutar", 16f, Pal.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Ui.chip(this, "Reset semua").apply {
            setOnClickListener { MusicDelay.set(this@MusicDelayActivity, 0f, 0f); refresh() }
        })
        top.addView(android.view.View(this), LinearLayout.LayoutParams(Ui.dp(this, 12), 1))
        root.addView(top)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MusicDelayActivity, 14), Ui.dp(this@MusicDelayActivity, 6), Ui.dp(this@MusicDelayActivity, 14), Ui.dp(this@MusicDelayActivity, 20))
        }

        // Jarak akustik + suhu udara.
        val infoRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val c1 = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        c1.addView(mono("JARAK AKUSTIK", 11f, Pal.MUTED, false))
        distText = mono("", 16f, Pal.c(0xFFFFC145))
        c1.addView(distText)
        val c2 = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        c2.addView(mono("SUHU UDARA", 11f, Pal.MUTED, false))
        tempText = mono("", 16f, Pal.c(0xFF3DE8A0))
        c2.addView(tempText)
        infoRow.addView(c1, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(this@MusicDelayActivity, 6) })
        infoRow.addView(c2, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = Ui.dp(this@MusicDelayActivity, 6) })
        body.addView(infoRow)
        body.addView(gap(12))

        // Kartu delay.
        val dc = card()
        val pick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("OUT 1 (Kiri)", "OUT 2 (Kanan)", "Keduanya").forEachIndexed { i, s ->
            val ch = Ui.chip(this, s, i == target).apply {
                setOnClickListener { target = i; refresh() }
            }
            chips.add(ch)
            pick.addView(ch, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = Ui.dp(this@MusicDelayActivity, 6) })
        }
        dc.addView(pick)
        dc.addView(gap(14))

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        delayLabel = mono("", 15f, Pal.MUTED)
        head.addView(delayLabel, LinearLayout.LayoutParams(0, -2, 1f))
        valueBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine()
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 20f
            setTextColor(Pal.CYAN)
            background = Ui.rounded(this@MusicDelayActivity, Pal.c(0xFF0A0F1A), 10, Pal.c(0xFF1B7A8F))
            setPadding(Ui.dp(this@MusicDelayActivity, 12), Ui.dp(this@MusicDelayActivity, 8), Ui.dp(this@MusicDelayActivity, 12), Ui.dp(this@MusicDelayActivity, 8))
            setOnEditorActionListener { v, id, _ ->
                if (id == EditorInfo.IME_ACTION_DONE) { commitBox(); v.clearFocus(); true } else false
            }
            setOnFocusChangeListener { _, has -> if (!has) commitBox() }
        }
        head.addView(valueBox, LinearLayout.LayoutParams(Ui.dp(this, 96), -2))
        head.addView(mono(" MS", 15f, Pal.CYAN).apply { setPadding(Ui.dp(this@MusicDelayActivity, 6), 0, 0, 0) })
        dc.addView(head)

        val tint = ColorStateList.valueOf(Pal.CYAN)
        bar = SeekBar(this).apply {
            max = (MusicDelay.MAX_MS * 10).toInt()
            progressTintList = tint
            thumbTintList = tint
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser && !suppress) setDelay(p / 10f) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        dc.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@MusicDelayActivity, 8) })

        val steps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(-10f, -1f, -0.1f, 0f, 0.1f, 1f, 10f).forEachIndexed { i, d ->
            val label = when {
                d == 0f -> "0"
                d > 0 -> "+" + (if (d == d.toInt().toFloat()) d.toInt().toString() else d.toString())
                else -> (if (d == d.toInt().toFloat()) d.toInt().toString() else d.toString())
            }
            val b = Ui.chip(this, label).apply {
                textSize = 13f
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                if (d == 0f) setTextColor(Pal.c(0xFFD9A441))
                setOnClickListener { setDelay(if (d == 0f) 0f else current() + d) }
            }
            steps.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = Ui.dp(this@MusicDelayActivity, 4) })
        }
        dc.addView(steps, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@MusicDelayActivity, 12) })
        body.addView(dc)
        body.addView(gap(12))

        // Koreksi suhu lapangan.
        val tc = card()
        val th = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        th.addView(mono("KOREKSI SUHU LAPANGAN:", 13f, Pal.MUTED, false), LinearLayout.LayoutParams(0, -2, 1f))
        tempVal = mono("", 15f, Pal.c(0xFF3DE8A0))
        th.addView(tempVal)
        tc.addView(th)
        tempBar = SeekBar(this).apply {
            max = 50
            progressTintList = tint
            thumbTintList = tint
            progress = tempC
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && !suppress) { tempC = p; MusicPrefs.setDelayTemp(this@MusicDelayActivity, p); refresh() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        tc.addView(tempBar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@MusicDelayActivity, 8) })
        body.addView(tc)

        body.addView(Ui.label(this,
            "Delay ini hanya berlaku untuk pemutar musik di dalam aplikasi (streaming, unduhan, dan lagu perangkat). " +
                "Audio aplikasi lain tidak ikut berubah. Jarak akustik dihitung dari delay dan kecepatan suara pada suhu yang dipilih.",
            12f, Pal.MUTED).apply { setPadding(Ui.dp(this@MusicDelayActivity, 4), Ui.dp(this@MusicDelayActivity, 14), Ui.dp(this@MusicDelayActivity, 4), 0) })

        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun commitBox() {
        if (suppress) return
        val v = valueBox.text.toString().trim().replace(',', '.').toFloatOrNull()
        if (v != null) setDelay(v) else refresh()
    }

    private fun setDelay(v: Float) {
        val x = ((v * 10).roundToInt() / 10f).coerceIn(0f, MusicDelay.MAX_MS)
        when (target) {
            0 -> MusicDelay.set(this, left = x)
            1 -> MusicDelay.set(this, right = x)
            else -> MusicDelay.set(this, x, x)
        }
        refresh()
    }

    private fun refresh() {
        suppress = true
        chips.forEachIndexed { i, c -> Ui.setChipSelected(c, i == target) }
        val v = current()
        delayLabel.text = "DELAY: " + when (target) { 0 -> "OUT 1"; 1 -> "OUT 2"; else -> "OUT 1+2" }
        valueBox.setText(fmt(v))
        bar.progress = (v * 10).roundToInt()
        val m = MusicDelay.distanceM(v, tempC)
        distText.text = String.format(Locale.US, "%.2f M (%.2f FT)", m, m * 3.28084)
        tempText.text = "${tempC}°C (${MusicDelay.speed(tempC).roundToInt()} M/S)"
        tempVal.text = "${tempC}°C"
        tempBar.progress = tempC
        suppress = false
    }
}

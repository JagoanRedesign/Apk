package com.dlmsmini.equalizer

import kotlin.math.PI
import kotlin.math.exp

/**
 * Stereo PCM delay processor for an app-owned audio pipeline. Input/output are interleaved
 * Float samples in [-1, 1]. This cannot be attached to arbitrary third-party Android audio
 * sessions through AudioEffect; integrate it only where DLMS owns the PCM stream.
 */
class DelayProcessor(sampleRate: Int) {
    data class Settings(
        val enabled: Boolean = false, val timeMs: Int = 280,
        val feedback: Float = 0.35f, val wet: Float = 0.25f, val dry: Float = 1f,
        val stereo: Boolean = true, val pingPong: Boolean = false,
        val lowCutHz: Float = 20f, val highCutHz: Float = 20000f
    )

    private val rate = sampleRate.coerceAtLeast(8000)
    private var left = FloatArray(rate * 2)
    private var right = FloatArray(rate * 2)
    private var index = 0
    private var lowL = 0f; private var lowR = 0f
    private var highL = 0f; private var highR = 0f
    var settings = Settings()
        set(value) { field = value.copy(timeMs = value.timeMs.coerceIn(1, 1000), feedback = value.feedback.coerceIn(0f, .9f), wet = value.wet.coerceIn(0f, 1f), dry = value.dry.coerceIn(0f, 1f), lowCutHz = value.lowCutHz.coerceIn(20f, 1000f), highCutHz = value.highCutHz.coerceIn(1000f, 20000f)) }

    /** Process one interleaved stereo buffer in-place. */
    @Synchronized fun process(samples: FloatArray) {
        if (!settings.enabled || samples.size < 2) return
        val delay = (rate * settings.timeMs / 1000).coerceIn(1, left.size - 1)
        val lpA = (1.0 - exp(-2.0 * PI * settings.highCutHz / rate)).toFloat()
        val hpA = (1.0 - exp(-2.0 * PI * settings.lowCutHz / rate)).toFloat()
        var frame = 0
        while (frame + 1 < samples.size) {
            val inL = samples[frame]; val inR = samples[frame + 1]
            val read = (index - delay + left.size) % left.size
            var echoL = left[read]; var echoR = right[read]
            lowL += lpA * (echoL - lowL); lowR += lpA * (echoR - lowR)
            highL += hpA * (lowL - highL); highR += hpA * (lowR - highR)
            echoL = highL; echoR = highR
            val fbL = if (settings.pingPong) echoR else echoL
            val fbR = if (settings.pingPong) echoL else echoR
            left[index] = (inL + fbL * settings.feedback).coerceIn(-1f, 1f)
            right[index] = (inR + fbR * settings.feedback).coerceIn(-1f, 1f)
            samples[frame] = (inL * settings.dry + echoL * settings.wet).coerceIn(-1f, 1f)
            samples[frame + 1] = (inR * settings.dry + echoR * settings.wet).coerceIn(-1f, 1f)
            index = (index + 1) % left.size
            frame += 2
        }
    }

    @Synchronized fun clear() { left.fill(0f); right.fill(0f); index = 0; lowL = 0f; lowR = 0f; highL = 0f; highR = 0f }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.log10

/**
 * Pemutar audio bawaan DLMS.
 *
 * Android TIDAK menyediakan gain/mute per-kanal (L/R) untuk audio aplikasi lain, jadi VOL L,
 * VOL R, dan MUTE hanya bisa bekerja kalau aplikasi ini yang memegang jalur audionya.
 * Kelas ini men-decode file audio (MediaExtractor + MediaCodec) menjadi PCM 16-bit stereo,
 * mengalikan kanal 0 (L) dan kanal 1 (R) dengan gain masing-masing, lalu memutarnya lewat
 * AudioTrack. Meter level dihitung dari sampel PCM yang benar-benar dikirim (setelah gain/mute).
 *
 * Semua callback Listener dijalankan di main thread.
 */
class ChannelPlayer(context: Context, private val listener: Listener) {

    interface Listener {
        /** AudioTrack sudah dibuat; pasang Equalizer/Visualizer ke session ini. */
        fun onAudioSession(sessionId: Int)
        /** Level puncak kanal kiri/kanan, 0..1, sudah termasuk gain dan mute. */
        fun onLevels(left: Float, right: Float)
        fun onProgress(positionMs: Long, durationMs: Long)
        fun onFinished()
        fun onError(message: String)
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var gainL = 1f
    @Volatile private var gainR = 1f

    private class Run(val uri: Uri) {
        @Volatile var stop = false
        @Volatile var paused = false
        @Volatile var seekMs = -1L
    }

    private class Pcm {
        var channels = 2
        var rate = 44100
        var encoding = AudioFormat.ENCODING_PCM_16BIT
    }

    private var current: Run? = null

    val isActive: Boolean get() = current != null
    val isPlaying: Boolean get() = current?.paused == false

    /** Gain linear (1.0 = 0 dB, 0.0 = mute) untuk kanal kiri dan kanan. Aman dipanggil kapan saja. */
    fun setGains(left: Float, right: Float) {
        gainL = left.coerceAtLeast(0f)
        gainR = right.coerceAtLeast(0f)
    }

    fun start(uri: Uri) {
        stop()
        val run = Run(uri)
        current = run
        Thread({ decodeLoop(run) }, "dlms-channel-player").apply { isDaemon = true }.start()
    }

    fun pause() { current?.paused = true }
    fun resume() { current?.paused = false }
    fun seekTo(ms: Long) { current?.seekMs = ms.coerceAtLeast(0L) }

    fun stop() {
        current?.stop = true
        current = null
    }

    // ------------------------------------------------------------------------------------

    private fun post(run: Run, block: () -> Unit) {
        main.post { if (current === run) block() }
    }

    private fun fail(run: Run, message: String) {
        post(run) { current = null; listener.onError(message) }
    }

    private fun readPcm(f: MediaFormat, pcm: Pcm) {
        if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) pcm.channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) pcm.rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        // "pcm-encoding" (API 24+): 2 = 16-bit, 4 = float. Jika tidak ada, decoder mengeluarkan 16-bit.
        pcm.encoding = if (f.containsKey("pcm-encoding")) f.getInteger("pcm-encoding") else AudioFormat.ENCODING_PCM_16BIT
    }

    private fun createTrack(rate: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferBytes = (if (min > 0) min else rate / 2 * 4) * 4
        val am = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val sessionId = am.generateAudioSessionId().let { if (it > 0) it else AudioManager.AUDIO_SESSION_ID_GENERATE }
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setSessionId(sessionId)
            .build()
    }

    private fun meter(peak: Int): Float {
        if (peak <= 0) return 0f
        val db = 20.0 * log10(peak / 32768.0)
        return ((db + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()   // lantai -60 dBFS
    }

    private fun decodeLoop(run: Run) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        var track: AudioTrack? = null
        try {
            extractor.setDataSource(appContext, run.uri, null)
            var audioIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val trackMime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (trackMime.startsWith("audio/")) { audioIndex = i; inputFormat = f; break }
            }
            if (audioIndex < 0 || inputFormat == null) { fail(run, "File ini tidak berisi audio"); return }

            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: ""
            val durationMs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION))
                inputFormat.getLong(MediaFormat.KEY_DURATION) / 1000L else 0L
            extractor.selectTrack(audioIndex)

            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(inputFormat, null, null, 0)
            dec.start()

            val info = MediaCodec.BufferInfo()
            val pcm = Pcm()
            var inputDone = false
            var outputDone = false
            var srcBuf = ShortArray(0)
            var outBuf = ShortArray(0)
            var curL = gainL
            var curR = gainR
            var framesSinceFlush = 0L
            var lastProgress = 0L

            while (!outputDone && !run.stop) {
                // ---- jeda ----
                if (run.paused) {
                    track?.pause()
                    post(run) { listener.onLevels(0f, 0f) }
                    while (run.paused && !run.stop && run.seekMs < 0) Thread.sleep(30)
                    if (run.stop) break
                    if (!run.paused) track?.play()
                }

                // ---- seek ----
                val seek = run.seekMs
                if (seek >= 0) {
                    run.seekMs = -1L
                    extractor.seekTo(seek * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                    dec.flush()
                    inputDone = false
                    framesSinceFlush = 0L
                    track?.let { it.pause(); it.flush(); if (!run.paused) it.play() }
                }

                // ---- kirim data terkompresi ke decoder ----
                if (!inputDone) {
                    val inIndex = dec.dequeueInputBuffer(5_000L)
                    if (inIndex >= 0) {
                        val inBuf = dec.getInputBuffer(inIndex)
                        val size = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                        if (size < 0) {
                            dec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                // ---- ambil PCM dari decoder ----
                val outIndex = dec.dequeueOutputBuffer(info, 5_000L)
                if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    readPcm(dec.outputFormat, pcm)
                } else if (outIndex >= 0) {
                    if (info.size > 0) {
                        var t = track
                        if (t == null) {
                            readPcm(dec.outputFormat, pcm)
                            if (pcm.encoding != AudioFormat.ENCODING_PCM_16BIT && pcm.encoding != AudioFormat.ENCODING_PCM_FLOAT) {
                                fail(run, "Format PCM decoder tidak didukung")
                                return
                            }
                            t = createTrack(pcm.rate)
                            track = t
                            val sessionId = t.audioSessionId
                            post(run) { listener.onAudioSession(sessionId) }
                            if (!run.paused) t.play()
                        }

                        val raw = dec.getOutputBuffer(outIndex)
                        if (raw != null) {
                            raw.position(info.offset)
                            raw.limit(info.offset + info.size)
                            raw.order(ByteOrder.nativeOrder())
                            val sampleCount: Int
                            if (pcm.encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                val fb = raw.asFloatBuffer()
                                sampleCount = fb.remaining()
                                if (srcBuf.size < sampleCount) srcBuf = ShortArray(sampleCount)
                                for (i in 0 until sampleCount) {
                                    srcBuf[i] = (fb.get() * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                                }
                            } else {
                                val sb = raw.asShortBuffer()
                                sampleCount = sb.remaining()
                                if (srcBuf.size < sampleCount) srcBuf = ShortArray(sampleCount)
                                sb.get(srcBuf, 0, sampleCount)
                            }

                            // Kanal 0 = L, kanal 1 = R. Mono diduplikasi ke L+R.
                            // Sumber >2 kanal: hanya dua kanal depan yang dipakai.
                            val ch = pcm.channels.coerceAtLeast(1)
                            val frames = sampleCount / ch
                            if (frames > 0) {
                                if (outBuf.size < frames * 2) outBuf = ShortArray(frames * 2)
                                val targetL = gainL
                                val targetR = gainR
                                // Gain diubah bertahap di dalam buffer agar tidak ada bunyi "klik".
                                val stepL = (targetL - curL) / frames
                                val stepR = (targetR - curR) / frames
                                var peakL = 0
                                var peakR = 0
                                for (f in 0 until frames) {
                                    curL += stepL
                                    curR += stepR
                                    val base = f * ch
                                    val l = srcBuf[base].toInt()
                                    val r = if (ch >= 2) srcBuf[base + 1].toInt() else l
                                    val outL = (l * curL).toInt().coerceIn(-32768, 32767)
                                    val outR = (r * curR).toInt().coerceIn(-32768, 32767)
                                    outBuf[2 * f] = outL.toShort()
                                    outBuf[2 * f + 1] = outR.toShort()
                                    val al = abs(outL)
                                    val ar = abs(outR)
                                    if (al > peakL) peakL = al
                                    if (ar > peakR) peakR = ar
                                }
                                curL = targetL
                                curR = targetR

                                val total = frames * 2
                                var offset = 0
                                while (offset < total && !run.stop) {
                                    val written = t.write(outBuf, offset, total - offset)
                                    if (written < 0) { fail(run, "Gagal menulis audio (kode $written)"); return }
                                    offset += written
                                }
                                framesSinceFlush += frames

                                val lv = meter(peakL)
                                val rv = meter(peakR)
                                post(run) { listener.onLevels(lv, rv) }
                                val now = SystemClock.elapsedRealtime()
                                if (now - lastProgress >= 250L) {
                                    lastProgress = now
                                    val posMs = info.presentationTimeUs / 1000L
                                    post(run) { listener.onProgress(posMs, durationMs) }
                                }
                            }
                        }
                    }
                    dec.releaseOutputBuffer(outIndex, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
            }

            if (!run.stop) {
                // Lagu selesai secara alami: tunggu sisa buffer terputar sebelum dilepas.
                val t = track
                if (t != null) {
                    try { t.stop() } catch (_: Exception) {}
                    val deadline = SystemClock.elapsedRealtime() + 2500L
                    while (!run.stop && SystemClock.elapsedRealtime() < deadline && t.playbackHeadPosition < framesSinceFlush) {
                        Thread.sleep(20)
                    }
                }
                post(run) { current = null; listener.onLevels(0f, 0f); listener.onFinished() }
            }
        } catch (e: Exception) {
            if (!run.stop) fail(run, "Gagal memutar: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            try { track?.let { it.pause(); it.flush(); it.release() } } catch (_: Exception) {}
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }
}

package com.dlmsmini.equalizer

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Panduan cara penggunaan aplikasi, ditulis sesuai fitur yang benar-benar ada di aplikasi. */
class HowToActivity : AppCompatActivity() {
    private val bg = 0xFF1B1B1D.toInt()
    private val titleColor = 0xFFE6E1E9.toInt()
    private val descColor = 0xFFCAC4D0.toInt()

    private class Section(val title: String, val body: String)

    private val sections = listOf(
        Section(
            "1. Mulai cepat",
            "1. Buka aplikasi, izinkan notifikasi (Android 13+) dan izin rekam audio (hanya untuk Spectrum).\n" +
                "2. Putar musik di aplikasi apa pun (YouTube Music, Spotify, dll.).\n" +
                "3. Di tab EQ, geser fader ke atas/bawah. Perubahan langsung terdengar.\n" +
                "4. Pastikan indikator di bagian atas berwarna hijau \"EFEK AKTIF\".\n" +
                "5. Tutup aplikasi: efek tetap bekerja selama notifikasi \"DLMS Mini Equalizer\" masih ada."
        ),
        Section(
            "2. Panel Master & indikator",
            "• Tombol MASTER mematikan atau menyalakan semua efek sekaligus (EQ, limiter, efek, volume L/R). Saat OFF, audio lewat tanpa diproses.\n" +
                "• Indikator hijau = semua efek yang Anda minta benar-benar dibuat, dikuasai aplikasi, dan menyala. " +
                "Kuning = sebagian aktif atau menunggu pemutar musik. Merah = efek gagal. Abu-abu = master OFF atau tanpa efek.\n" +
                "• Baris di bawahnya menampilkan perangkat audio saat ini (speaker, headset, Bluetooth, USB, HDMI). Ketuk panel untuk membuka Diagnostik."
        ),
        Section(
            "3. Equalizer",
            "• Tab EQ: tiap fader mengatur satu frekuensi dalam dB. Ketuk saklar EQ untuk membandingkan sebelum/sesudah.\n" +
                "• Jumlah band (5, 10, 13, atau 21) dipilih di Setelan.\n" +
                "• 1-Way: kedua kanal sama (stereo normal). 2-Way: kiri membawa frekuensi LOW dan kanan membawa HIGH dengan titik pisah (crossover) yang diatur di Setelan, " +
                "khusus untuk sistem dua jalur dengan driver kiri/kanan terpisah — jangan dipakai untuk mendengarkan stereo biasa.\n" +
                "• Rentang fader diatur lewat Setelan › Batas EQ (3–12 dB). Kekuatan Penuh memperluas ke ±22 dB; pakai dengan hati-hati dan aktifkan Limiter."
        ),
        Section(
            "4. Limiter & proteksi clipping",
            "• Tab Limiter: batas puncak suara agar tidak pecah. Atur Threshold (batas), Ratio, Attack, Release, dan Post-gain.\n" +
                "• Setelan › Proteksi clipping: \"Limiter pengaman\" menyalakan limiter otomatis saat total penguatan terlalu besar dan Limiter Anda mati; " +
                "\"+ headroom otomatis\" juga menurunkan gain masukan sedikit. Tulisan CLIP merah di spectrum muncul bila suara menyentuh batas penuh.\n" +
                "• Bila suara pecah: turunkan fader/pre-amp, aktifkan Limiter, atau naikkan Proteksi clipping."
        ),
        Section(
            "5. Efek suara",
            "Tab Efek berisi:\n" +
                "• Volume Kiri/Kanan 0–100 (0 = senyap) dan tombol SAMAKAN 100%.\n" +
                "• Pre-amp, Balance kiri/kanan, dan Mute per kanal.\n" +
                "• Bass Boost, Virtualizer (kesan lebar), Loudness, dan Reverb.\n" +
                "• Kompresor multiband dan Tone 3 band (rendah/tengah/tinggi).\n" +
                "Sebagian efek bergantung pada dukungan ponsel (lihat Diagnostik). Efek yang tidak didukung akan ditandai dan dilewati."
        ),
        Section(
            "6. Preset",
            "• Tab Preset: pilih preset bawaan, atau simpan pengaturan Anda sendiri dengan nama.\n" +
                "• \"Terakhir dipakai\" di atas daftar menyimpan 6 preset terakhir; ketuk untuk memakainya lagi.\n" +
                "• Preset kustom dapat dibagikan sebagai teks (Export) dan dipulihkan dengan Import."
        ),
        Section(
            "7. Spectrum Analyzer",
            "• Grafik frekuensi 20 Hz–20 kHz secara langsung. Pilih tampilan BAR, WAVE (bentuk gelombang), atau CURVE (kurva halus).\n" +
                "• PEAK menyalakan penahan puncak. SMOOTH mengganti tingkat penghalusan (− responsif, ● sedang, + halus).\n" +
                "• Meter BASS / MID / TREBLE di bawah grafik berdenyut mengikuti musik.\n" +
                "• Spectrum butuh izin rekam audio dan dapat dimatikan di Setelan › Spectrum analyzer."
        ),
        Section(
            "8. Mix Global vs Mode Sesi Aplikasi",
            "• Mix Global (bawaan): EQ berlaku untuk seluruh suara ponsel. Paling mudah dipakai.\n" +
                "• Mode Sesi Aplikasi (Setelan › Kompatibilitas Audio): EQ hanya dipasang pada pemutar yang mengirim sesi audio. " +
                "Pakai bila Mix Global tidak berpengaruh di ponsel Anda, atau untuk Bluetooth/Android Auto tertentu.\n" +
                "• Kelola aplikasi terdeteksi: pilih aplikasi mana yang diproses. \"Stabilkan saat peluncuran\" melewati satu lagu agar pemutar yang sudah berputar langsung terkunci."
        ),
        Section(
            "9. Headset, Bluetooth, dan speaker",
            "• Saat Anda menyambung/melepas headset atau Bluetooth, aplikasi mendeteksinya otomatis dan memasang ulang efek (sekitar 1 detik).\n" +
                "• Bila efek terasa hilang setelah berganti perangkat: buka Diagnostik › TERAPKAN ULANG.\n" +
                "• Uji yang disarankan: putar musik → sambung Bluetooth → cabut/sambung kabel → kembali ke speaker. " +
                "Setiap perpindahan harus tercatat di log Diagnostik dan indikator tetap hijau."
        ),
        Section(
            "10. Agar efek tidak mati sendiri",
            "• Biarkan Setelan › Aktif di latar belakang menyala dan izinkan notifikasi.\n" +
                "• Setelan › Pengecualian optimasi baterai: izinkan tanpa pembatasan.\n" +
                "• Setelan › Pengaturan vendor: membuka layar mulai-otomatis khusus merek ponsel Anda (Xiaomi, Samsung, Huawei, OPPO, vivo, dll.) beserta langkahnya.\n" +
                "• Jangan menutup paksa lewat \"Hentikan paksa\"; itu mematikan layanan.\n" +
                "• Matikan efek audio bawaan ponsel (Dolby Atmos, SoundAlive, dll.) bila efek tidak terdengar."
        ),
        Section(
            "11. Backup, restore, dan reset",
            "• Setelan › Backup pengaturan: simpan semua pengaturan dan preset ke berkas, clipboard, atau bagikan sebagai teks.\n" +
                "• Restore pengaturan: pulihkan dari berkas atau tempel teks. Pengaturan saat ini diganti.\n" +
                "• Reset pengaturan: kembali ke bawaan; pilih apakah preset kustom ikut dihapus."
        ),
        Section(
            "12. Masalah umum",
            "• Tidak ada perubahan suara: periksa indikator (harus hijau) dan MASTER (harus ON). Coba Mode Sesi Aplikasi, lalu buka Diagnostik.\n" +
                "• Indikator merah/kuning: lihat daftar efek di Diagnostik; ketuk TERAPKAN ULANG. Matikan efek audio bawaan ponsel.\n" +
                "• Suara pecah: aktifkan Limiter atau Proteksi clipping, kurangi boost.\n" +
                "• Efek hilang saat layar mati/aplikasi ditutup: ikuti bagian 10.\n" +
                "• Spectrum kosong: izinkan rekam audio dan pastikan musik sedang diputar; sebagian aplikasi memblokir analisis audio.\n" +
                "• Mengirim laporan masalah: Diagnostik › SALIN LAPORAN."
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(this@HowToActivity, 16), Ui.dp(this@HowToActivity, 16), Ui.dp(this@HowToActivity, 16), Ui.dp(this@HowToActivity, 8))
        }
        bar.addView(TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(Ui.dp(this@HowToActivity, 8), Ui.dp(this@HowToActivity, 4), Ui.dp(this@HowToActivity, 16), Ui.dp(this@HowToActivity, 4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        })
        bar.addView(Ui.label(this, "Cara penggunaan", 26f, titleColor))
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@HowToActivity, 16), Ui.dp(this@HowToActivity, 8), Ui.dp(this@HowToActivity, 16), Ui.dp(this@HowToActivity, 24))
        }
        sections.forEach { sec ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui.rounded(this@HowToActivity, 0xFF343437.toInt(), 18)
                setPadding(Ui.dp(this@HowToActivity, 18), Ui.dp(this@HowToActivity, 14), Ui.dp(this@HowToActivity, 18), Ui.dp(this@HowToActivity, 14))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@HowToActivity, 10) }
            }
            card.addView(Ui.label(this, sec.title, 16f, titleColor, true))
            card.addView(Ui.label(this, sec.body, 13f, descColor).apply {
                setPadding(0, Ui.dp(this@HowToActivity, 6), 0, 0)
                setLineSpacing(0f, 1.2f)
            })
            list.addView(card)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.fitSystemBars(root)
        setContentView(root)
    }
}

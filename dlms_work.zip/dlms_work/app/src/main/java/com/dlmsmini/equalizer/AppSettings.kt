package com.dlmsmini.equalizer

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import java.util.TreeMap

/**
 * Semua pengaturan aplikasi tersimpan di SharedPreferences.
 * Nilai band EQ dalam half-dB: -24..24 = -12.0..+12.0 dB.
 */
object AppSettings {
    private lateinit var prefs: SharedPreferences

    /** Kurva EQ saat ini (10 band), disalin dari prefs saat init. */
    val bands = IntArray(10)

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        val name = "dlms_eq_${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_")
        prefs = context.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
        loadBands()
    }

    private fun loadBands() {
        for (i in bands.indices) bands[i] = prefs.getInt("band_$i", 0).coerceIn(-24, 24)
    }

    fun saveBands() {
        val e = prefs.edit()
        bands.forEachIndexed { i, v -> e.putInt("band_$i", v) }
        e.apply()
    }

    private fun putBool(key: String, v: Boolean) { prefs.edit().putBoolean(key, v).apply() }
    private fun putFloat(key: String, v: Float) { prefs.edit().putFloat(key, v).apply() }
    private fun putInt(key: String, v: Int) { prefs.edit().putInt(key, v).apply() }

    var eqEnabled: Boolean
        get() = prefs.getBoolean("eq_enabled", true)
        set(v) = putBool("eq_enabled", v)

    var eqMode: String
        get() = prefs.getString("eq_mode", "1WAY") ?: "1WAY"
        set(v) { prefs.edit().putString("eq_mode", v).apply() }

    // ---- Limiter ----
    var limEnabled: Boolean
        get() = prefs.getBoolean("lim_enabled", false)
        set(v) = putBool("lim_enabled", v)
    var limAttack: Float            // ms
        get() = prefs.getFloat("lim_attack", 1f)
        set(v) = putFloat("lim_attack", v)
    var limRelease: Float           // ms
        get() = prefs.getFloat("lim_release", 60f)
        set(v) = putFloat("lim_release", v)
    var limRatio: Float             // x:1
        get() = prefs.getFloat("lim_ratio", 10f)
        set(v) = putFloat("lim_ratio", v)
    var limThreshold: Float         // dB
        get() = prefs.getFloat("lim_threshold", -2f)
        set(v) = putFloat("lim_threshold", v)
    var limPostGain: Float          // dB
        get() = prefs.getFloat("lim_post", 0f)
        set(v) = putFloat("lim_post", v)

    // ---- Pengaturan aplikasi ----
    /** 0 = global (sesi 0), 1 = per sesi aplikasi, 2 = maksimum (keduanya). */
    var pipeline: Int
        get() = prefs.getInt("pipeline", 2).coerceIn(0, 2)
        set(v) = putInt("pipeline", v)

    var backgroundService: Boolean
        get() = prefs.getBoolean("bg_service", true)
        set(v) = putBool("bg_service", v)

    var showSpectrum: Boolean
        get() = prefs.getBoolean("show_spectrum", true)
        set(v) = putBool("show_spectrum", v)

    /** Kembalikan semua pengaturan ke bawaan. Preset buatan pengguna tetap disimpan. */
    fun resetAll() {
        val e = prefs.edit()
        for (k in prefs.all.keys.toList()) if (!k.startsWith("custom_")) e.remove(k)
        e.apply()
        loadBands()
    }

    // ---- Preset buatan pengguna ----
    fun customPresets(): Map<String, IntArray> {
        val out = TreeMap<String, IntArray>()
        for (k in prefs.all.keys) {
            if (!k.startsWith("custom_")) continue
            try {
                val arr = JSONArray(prefs.getString(k, "[]") ?: "[]")
                if (arr.length() == 10) out[k.removePrefix("custom_")] = IntArray(10) { arr.getInt(it).coerceIn(-24, 24) }
            } catch (_: Exception) {}
        }
        return out
    }

    fun savePreset(name: String, halfDb: IntArray) {
        val arr = JSONArray()
        for (v in halfDb) arr.put(v)
        prefs.edit().putString("custom_$name", arr.toString()).apply()
    }

    fun deletePreset(name: String) {
        prefs.edit().remove("custom_$name").apply()
    }
}

package com.dlmsmini.equalizer

import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Background player; MediaSessionService provides system media controls and notification. */
class MusicPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        session = MediaSession.Builder(this, exo).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_PLAY) {
            val url = intent.getStringExtra(EXTRA_URL)
            val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
            val artist = intent.getStringExtra(EXTRA_ARTIST).orEmpty()
            if (!url.isNullOrBlank()) {
                val item = MediaItem.Builder().setUri(url).setMediaMetadata(
                    MediaMetadata.Builder().setTitle(title).setArtist(artist).build()
                ).build()
                player?.setMediaItem(item)
                player?.prepare()
                player?.play()
            }
        } else if (intent?.action == ACTION_PAUSE) player?.pause()
        return START_STICKY
    }

    override fun onDestroy() {
        session?.release()
        player?.release()
        session = null
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.dlmsmini.equalizer.music.PLAY"
        const val ACTION_PAUSE = "com.dlmsmini.equalizer.music.PAUSE"
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ARTIST = "artist"
    }
}

package com.dlmsmini.equalizer

import android.media.*
import android.media.projection.MediaProjection
import android.os.Process
import kotlin.math.*

/** Captures other apps' playback (when their capture policy permits it), processes PCM and plays it back. */
class PlaybackCaptureEngine(
    private val projection: MediaProjection,
    private val appUid: Int,
    private val onError: (String) -> Unit
) {
    @Volatile var running = false
        private set
    @Volatile var eqEnabled = true
    @Volatile var gainsDb = FloatArray(10)
    @Volatile var limiterEnabled = false
    @Volatile var attackMs = 5f
    @Volatile var releaseMs = 100f
    @Volatile var ratio = 20f
    @Volatile var thresholdDb = -1f
    @Volatile var postGainDb = 0f
    @Volatile var twoWay = false

    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null

    fun start() {
        if (running) return
        if (android.os.Build.VERSION.SDK_INT < 29) {
            onError("AudioPlaybackCapture membutuhkan Android 10 atau lebih baru")
            return
        }
        running = true
        worker = Thread({ loop() }, "dlms-playback-capture").apply { isDaemon = true; start() }
    }

    fun stop() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause() } catch (_: Exception) {}
        worker?.interrupt()
    }

    private data class Biquad(var b0: Double, var b1: Double, var b2: Double, var a1: Double, var a2: Double) {
        var x1=0.0; var x2=0.0; var y1=0.0; var y2=0.0
        fun process(x: Double): Double {
            val y=b0*x+b1*x1+b2*x2-a1*y1-a2*y2
            x2=x1; x1=x; y2=y1; y1=y
            return y
        }
    }

    private fun makePeak(freq: Double, gainDb: Double, rate: Double): Biquad {
        val a=10.0.pow(gainDb/40.0); val w=2.0*PI*freq/rate; val alpha=sin(w)/(2.0*1.0)
        val c=cos(w); val a0=1.0+alpha/a
        return Biquad((1+alpha*a)/a0,(-2*c)/a0,(1-alpha*a)/a0,(-2*c)/a0,(1-alpha/a)/a0)
    }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val rate=48000
        val min=AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { running=false; onError("Konfigurasi AudioRecord tidak didukung"); return }
        val config=AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .excludeUid(appUid)
            .build()
        try {
            val format=AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val rec=AudioRecord.Builder().setAudioFormat(format)
                .setBufferSizeInBytes(max(min*2, rate/2))
                .setAudioPlaybackCaptureConfig(config).build()
            recorder=rec
            val outMin=AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val out=AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(max(outMin*2, rate/2)).setTransferMode(AudioTrack.MODE_STREAM).build()
            player=out
            val freqs=doubleArrayOf(31.0,62.0,125.0,250.0,500.0,1000.0,2000.0,4000.0,8000.0,16000.0)
            val filtersL=Array(10) { makePeak(freqs[it], 0.0, rate.toDouble()) }
            val filtersR=Array(10) { makePeak(freqs[it], 0.0, rate.toDouble()) }
            var previousGains=FloatArray(10) { Float.NaN }
            val input=ShortArray(2048); val output=ShortArray(2048)
            var envelope=0.0
            rec.startRecording(); out.play()
            while (running) {
                val count=rec.read(input,0,input.size,AudioRecord.READ_BLOCKING)
                if (count<=0) continue
                if (eqEnabled) for (i in 0..9) {
                    val gain=gainsDb[i].coerceIn(-12f,12f)
                    if (gain != previousGains[i]) {
                        val db=gain.toDouble()
                        filtersL[i]=makePeak(freqs[i], db, rate.toDouble())
                        filtersR[i]=makePeak(freqs[i], db, rate.toDouble())
                        previousGains[i]=gain
                    }
                }
                val attack=exp(-1.0/(rate*(attackMs.coerceIn(0.1f,200f)/1000.0)))
                val release=exp(-1.0/(rate*(releaseMs.coerceIn(1f,2000f)/1000.0)))
                val post=10.0.pow(postGainDb.coerceIn(-12f,12f)/20.0)
                var i=0
                while (i+1<count) {
                    var left=input[i].toDouble()/32768.0
                    var right=input[i+1].toDouble()/32768.0
                    if (eqEnabled) for (band in 0..9) {
                        left=filtersL[band].process(left)
                        right=filtersR[band].process(right)
                    }
                    if (limiterEnabled) {
                        val peak=max(abs(left),abs(right)); val coeff=if(peak>envelope) attack else release
                        envelope=coeff*envelope+(1-coeff)*peak
                        val envDb=20.0*log10(envelope.coerceAtLeast(1e-9))
                        val thresholdValue=thresholdDb.coerceIn(-24f,0f).toDouble()
                        if (envDb>thresholdValue) {
                            val over=envDb-thresholdValue
                            val reduction=over*(1.0-1.0/ratio.coerceIn(1f,40f))
                            val gain=10.0.pow(-reduction/20.0)
                            left*=gain; right*=gain
                        }
                    }
                    left*=post; right*=post
                    output[i]=(left.coerceIn(-1.0,0.999969)*32767.0).roundToInt().toShort()
                    output[i+1]=(right.coerceIn(-1.0,0.999969)*32767.0).roundToInt().toShort()
                    i+=2
                }
                var offset=0
                while(offset<count && running) {
                    val written=out.write(output,offset,count-offset,AudioTrack.WRITE_BLOCKING)
                    if(written<0) throw IllegalStateException("AudioTrack write error: $written")
                    offset+=written
                }
            }
        } catch (e: Exception) {
            if (running) onError("Audio capture gagal: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            running=false
            try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
            try { player?.pause(); player?.flush(); player?.release() } catch (_: Exception) {}
            recorder=null; player=null
        }
    }
}

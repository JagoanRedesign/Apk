package com.dlmsmini.equalizer

import android.media.audiofx.AudioEffect
import android.os.Handler
import java.util.UUID

/**
 * Pembatas laju untuk pembaruan efek yang dipicu slider. Panggilan pertama langsung diterapkan; panggilan berikutnya
 * dalam [gapMs] digabung dan nilai TERAKHIR diterapkan di ujung jendela. Setiap pengaturan efek adalah transaksi binder
 * ke audioserver, jadi tanpa ini menggeser fader 21 band bisa membanjiri antrean dan terasa tertunda.
 */
class Throttle(private val handler: Handler, private val gapMs: Long, private val action: () -> Unit) {
    private var armed = false
    private var dirty = false
    private val release = Runnable {
        armed = false
        if (dirty) {
            dirty = false
            fire()
        }
    }

    fun fire() {
        if (armed) {
            dirty = true
            return
        }
        armed = true
        try {
            action()
        } finally {
            handler.postDelayed(release, gapMs)
        }
    }

    fun cancel() {
        handler.removeCallbacks(release)
        armed = false
        dirty = false
    }
}

/**
 * Mendeteksi efek vendor/bawaan perangkat (Dolby, SoundAlive, MaxxAudio, dll.) yang terpasang pada rantai audio.
 * Efek semacam itu tidak bisa dimatikan dari aplikasi ini; bila aktif bersamaan dengan EQ kita, suara bisa diproses dua kali.
 */
object EffectConflicts {
    class Finding(val kind: String, val name: String, val vendor: String, val foreign: Boolean)

    private val DP_TYPE: UUID = UUID.fromString("7261676f-6d75-7369-6364-28e2fd3ac39e")

    private fun kinds(): List<Pair<UUID, String>> = listOf(
        AudioEffect.EFFECT_TYPE_EQUALIZER to "Equalizer",
        DP_TYPE to "DynamicsProcessing",
        AudioEffect.EFFECT_TYPE_BASS_BOOST to "Bass Boost",
        AudioEffect.EFFECT_TYPE_VIRTUALIZER to "Virtualizer",
        AudioEffect.EFFECT_TYPE_LOUDNESS_ENHANCER to "Loudness",
        AudioEffect.EFFECT_TYPE_PRESET_REVERB to "Reverb"
    )

    fun scan(): List<Finding> {
        val all: Array<AudioEffect.Descriptor> = try {
            AudioEffect.queryEffects() ?: emptyArray()
        } catch (_: Throwable) {
            emptyArray()
        }
        val out = ArrayList<Finding>()
        val kindList = kinds()
        for (d in all) {
            val kind = kindList.firstOrNull { it.first == d.type }?.second ?: continue
            val vendor = d.implementor ?: ""
            val foreign = !vendor.contains("Android Open Source", ignoreCase = true)
            out.add(Finding(kind, d.name ?: "?", vendor, foreign))
        }
        return out
    }

    /** Teks untuk layar Diagnostik. */
    fun report(): String {
        val found = scan()
        if (found.isEmpty()) return "Tidak dapat membaca daftar efek sistem."
        val foreign = found.filter { it.foreign }
        val sb = StringBuilder()
        if (foreign.isEmpty()) {
            sb.appendLine("✔ Tidak ada efek vendor yang terdeteksi pada tipe efek yang dipakai aplikasi ini.")
        } else {
            sb.appendLine("⚠ Efek vendor/bawaan perangkat terdeteksi:")
            foreign.forEach { sb.appendLine("  • ${it.kind}: ${it.name}" + if (it.vendor.isNotEmpty()) " (${it.vendor})" else "") }
            sb.appendLine()
            sb.appendLine("Bila efek seperti Dolby/Sound effects bawaan HP aktif, suara bisa diproses dua kali.")
            sb.appendLine("Matikan efek tersebut di Pengaturan suara HP, atau pakai Mode Sesi Aplikasi.")
        }
        sb.appendLine()
        sb.append("Total efek terdaftar di sistem: ${found.size}")
        return sb.toString()
    }
}

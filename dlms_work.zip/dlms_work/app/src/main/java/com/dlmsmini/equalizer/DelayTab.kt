package com.dlmsmini.equalizer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.view.Gravity
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Tab Delay: kontrol penuh (Time, Feedback, Wet, Dry, Stereo, Ping Pong, High Cut, Low Cut) + preset.
 * Pemrosesan nyata dijalankan oleh [DelayService]. Harus dibuat di onCreate Activity (mendaftarkan peluncur izin).
 */
class DelayTab(private val act: AppCompatActivity) {
    private var s: DelaySettings = Store.loadDelay(act)
    private var switch: Switch? = null
    private var statusText: TextView? = null
    private val refreshers = mutableListOf<() -> Unit>()
    private val presetChips = mutableListOf<Pair<String, TextView>>()
    private var suppressSwitch = false

    private val micLauncher = act.registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) askProjection() else {
            setSwitch(false)
            toast("Izin rekam audio diperlukan agar Delay dapat menangkap audio pemutar")
        }
    }

    private val projectionLauncher = act.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) {
            s = s.copy(enabled = true)
            DelayService.settings = s
            Store.saveDelay(act, s)
            Store.setDelayOn(act, true)
            DelayService.start(act, r.resultCode, data)
            refresh()
        } else {
            setSwitch(false)
            toast("Izin penangkapan audio ditolak")
        }
    }

    init {
        // Pastikan keadaan tersimpan konsisten dengan layanan nyata (layanan tidak hidup setelah proses dimatikan).
        reconcile()
        DelayService.settings = s
        DelayService.onState = { act.runOnUiThread { refresh() } }
    }

    private fun toast(t: String) = Toast.makeText(act, t, Toast.LENGTH_LONG).show()

    /** Bila delay_on tersimpan tetapi layanan tidak berjalan (izin berakhir), matikan agar UI jujur. */
    private fun reconcile() {
        if (s.enabled && !DelayService.running) {
            s = s.copy(enabled = false)
            Store.setDelayOn(act, false)
        }
    }

    fun onResume() {
        s = Store.loadDelay(act)
        reconcile()
        DelayService.settings = s
        DelayService.onState = { act.runOnUiThread { refresh() } }
        refresh()
    }

    fun onDestroy() {
        if (DelayService.onState != null) DelayService.onState = null
    }

    private fun setSwitch(on: Boolean) {
        suppressSwitch = true
        switch?.isChecked = on
        suppressSwitch = false
    }

    // ---------- alur nyalakan ----------

    private fun requestStart() {
        if (!DelayService.supported) {
            setSwitch(false)
            toast("Delay DSP membutuhkan Android 10+ (AudioPlaybackCapture)")
            return
        }
        if (ContextCompat.checkSelfPermission(act, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            askProjection()
        }
    }

    private fun askProjection() {
        try {
            val mpm = act.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        } catch (e: Exception) {
            setSwitch(false)
            toast("Tidak dapat meminta izin penangkapan audio: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun requestStop() {
        s = s.copy(enabled = false)
        DelayService.settings = s
        Store.setDelayOn(act, false)
        DelayService.stop(act)
        refresh()
    }

    // ---------- perubahan parameter ----------

    private fun changed(save: Boolean = false) {
        DelayService.settings = s
        if (save) Store.saveDelay(act, s)
        updatePresetChips()
    }

    private fun updatePresetChips() {
        val m = DelayPresets.matching(s)
        presetChips.forEach { (n, v) -> Ui.setChipSelected(v, n == m) }
    }

    fun refresh() {
        val st = statusText ?: return
        val err = DelayService.lastError
        when {
            DelayService.running -> {
                st.setTextColor(0xFF7BE3B0.toInt())
                st.text = "Delay memproses audio • latensi jalur ≈ ${DelayService.latencyMs} ms" +
                    if (s.timeMs < DelayService.latencyMs) "\nWaktu < latensi: gema tidak bisa lebih cepat dari ${DelayService.latencyMs} ms" else ""
            }
            err != null -> { st.setTextColor(0xFFFFB86B.toInt()); st.text = err }
            !DelayService.supported -> { st.setTextColor(0xFFFFB86B.toInt()); st.text = "Tidak didukung: butuh Android 10+" }
            else -> { st.setTextColor(Pal.MUTED); st.text = "Nonaktif. Menyalakan akan meminta izin tangkap audio (Android)." }
        }
        setSwitch(DelayService.running && s.enabled)
        refreshers.forEach { it() }
        updatePresetChips()
    }

    // ---------- UI ----------

    fun build(content: LinearLayout) {
        Ui.sectionTitle(act, content, "DELAY (DSP INTERNAL)")
        val card = Ui.panelCard(act, 14)

        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val sw = Switch(act).apply {
            text = "Delay aktif"; textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = DelayService.running && s.enabled
            setOnCheckedChangeListener { _, checked ->
                if (suppressSwitch) return@setOnCheckedChangeListener
                if (checked) requestStart() else requestStop()
            }
        }
        switch = sw
        top.addView(sw, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(act).apply {
            text = "i"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(0xFFB5B5BA.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0)
                setStroke(Ui.dp(act, 2), 0xFF8E8E93.toInt())
            }
            isClickable = true
            contentDescription = "Info delay"
            setOnClickListener { showInfo() }
        }, LinearLayout.LayoutParams(Ui.dp(act, 32), Ui.dp(act, 32)))
        card.addView(top)

        statusText = Ui.label(act, "", 10f, Pal.MUTED).apply { setPadding(Ui.dp(act, 4), Ui.dp(act, 6), Ui.dp(act, 4), 0) }
        card.addView(statusText)

        // Preset
        card.addView(Ui.label(act, "Preset delay", 13f, Pal.MUTED, true).apply { setPadding(Ui.dp(act, 4), Ui.dp(act, 14), 0, Ui.dp(act, 6)) })
        val chipRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        presetChips.clear()
        DelayPresets.all.forEach { p ->
            val chip = Ui.chip(act, p.name)
            chip.setOnClickListener {
                s = DelayPresets.applyTo(s, p)
                changed(save = true)
                refreshers.forEach { it() }
                Toast.makeText(act, "Preset delay \"${p.name}\" digunakan", Toast.LENGTH_SHORT).show()
            }
            presetChips.add(p.name to chip)
            chipRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Ui.dp(act, 6) })
        }
        card.addView(HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) })

        refreshers.clear()
        val save = { Store.saveDelay(act, s) }
        refreshers += Ui.slider(act, card, "Delay Time", DelaySpec.time, { s.timeMs.toFloat() }, { s = s.copy(timeMs = it.toInt()); changed(); refresh() }, save)
        refreshers += Ui.slider(act, card, "Feedback", DelaySpec.feedback, { s.feedbackPct.toFloat() }, { s = s.copy(feedbackPct = it.toInt()); changed() }, save)
        refreshers += Ui.slider(act, card, "Wet Mix", DelaySpec.mix, { s.wetPct.toFloat() }, { s = s.copy(wetPct = it.toInt()); changed() }, save)
        refreshers += Ui.slider(act, card, "Dry Mix (salinan proses)", DelaySpec.mix, { s.dryPct.toFloat() }, { s = s.copy(dryPct = it.toInt()); changed() }, save)
        card.addView(Ui.label(act, "Suara asli tetap diputar sistem dan tidak bisa dibisukan aplikasi; Dry hanya mengatur salinan yang diproses. Disarankan 0%.", 10f, Pal.MUTED).apply {
            setPadding(Ui.dp(act, 4), Ui.dp(act, 2), Ui.dp(act, 4), 0)
        })
        refreshers += Ui.slider(act, card, "High Cut", DelaySpec.highCut, { s.highCutHz.toFloat() }, { s = s.copy(highCutHz = it.toInt()); changed() }, save)
        refreshers += Ui.slider(act, card, "Low Cut", DelaySpec.lowCut, { s.lowCutHz.toFloat() }, { s = s.copy(lowCutHz = it.toInt()); changed() }, save)

        refreshers += Ui.check(act, card, "Stereo Delay (kanan 1,5× lebih lambat)", { s.stereo }, { s = s.copy(stereo = it); changed(true) })
        refreshers += Ui.check(act, card, "Ping Pong (gema berpindah L ↔ R)", { s.pingPong }, { s = s.copy(pingPong = it); changed(true) })
        refreshers += Ui.check(act, card, "Karakter Tape (wow/flutter + saturasi)", { s.tape }, { s = s.copy(tape = it); changed(true) })

        val reset = Ui.pill(act, "RESET DELAY").apply { textSize = 12f; setPadding(Ui.dp(act, 8), Ui.dp(act, 11), Ui.dp(act, 8), Ui.dp(act, 11)) }
        reset.setOnClickListener {
            s = DelaySettings(enabled = s.enabled)
            changed(true)
            refreshers.forEach { it() }
        }
        card.addView(reset, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(act, 16) })
        Ui.addCard(content, card, 0)
        refresh()
    }

    private fun showInfo() {
        val msg = "Delay memakai DSP internal: audio pemutar ditangkap (AudioPlaybackCapture), diproses oleh buffer delay " +
            "milik aplikasi (Time, Feedback, Wet/Dry, Stereo, Ping Pong, High/Low Cut), lalu diputar kembali.\n\n" +
            "Batasan Android:\n" +
            "• Butuh Android 10+, izin rekam audio, dan persetujuan penangkapan layar/audio setiap kali dinyalakan.\n" +
            "• Suara asli tetap keluar dari sistem dan tidak dapat dibisukan; yang ditambahkan adalah gema. Dry Mix hanya mengatur salinan proses.\n" +
            "• Ada latensi jalur capture; waktu delay yang lebih kecil dari latensi tidak dapat dicapai.\n" +
            "• Aplikasi yang menolak penangkapan audio (DRM, dll.) tidak ikut diproses.\n" +
            "• Stereo: kanan 1,5× lebih lambat dari kiri. Ping Pong menyilangkan feedback kiri/kanan (menggantikan Stereo)."
        AlertDialog.Builder(act).setTitle("Delay DSP").setMessage(msg).setPositiveButton("Tutup", null).show()
    }
}

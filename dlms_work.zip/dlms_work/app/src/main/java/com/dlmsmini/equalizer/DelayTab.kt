package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.view.Gravity
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Tab Delay: kontrol penuh (Time, Feedback, Wet, Dry, Stereo, Ping Pong, High Cut, Low Cut) + preset.
 * Delay hanya memproses file yang diputar oleh LocalDelayPlayerService. Audio aplikasi lain tidak disentuh.
 */
class DelayTab(private val act: AppCompatActivity) {
    private var s: DelaySettings = Store.loadDelay(act)
    private var switch: Switch? = null
    private var statusText: TextView? = null
    private val refreshers = mutableListOf<() -> Unit>()
    private val presetChips = mutableListOf<Pair<String, TextView>>()
    private var suppressSwitch = false

    private val openAudio = act.registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                act.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {}
            try {
                LocalDelayPlayerService.play(act, uri)
                toast("Memutar file lokal dengan jalur DSP DLMS")
                refresh()
            } catch (t: Throwable) {
                toast("Gagal membuka audio: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    init {
        // Matikan layanan capture versi lama bila masih tertinggal setelah pembaruan aplikasi.
        DelayService.stop(act)
        // Delay tidak menggunakan AudioPlaybackCapture / MediaProjection.
        LocalDelayPlayerService.onState = { act.runOnUiThread { refresh() } }
        DelayService.settings = s
        LocalDelayPlayerService.settings = s
    }

    private fun toast(t: String) = Toast.makeText(act, t, Toast.LENGTH_LONG).show()

    fun onResume() {
        s = Store.loadDelay(act)
        DelayService.settings = s
        LocalDelayPlayerService.settings = s
        LocalDelayPlayerService.onState = { act.runOnUiThread { refresh() } }
        refresh()
    }

    fun onDestroy() {
        if (LocalDelayPlayerService.onState != null) LocalDelayPlayerService.onState = null
    }

    private fun setSwitch(on: Boolean) {
        suppressSwitch = true
        switch?.isChecked = on
        suppressSwitch = false
    }

    private fun changed(save: Boolean = false) {
        DelayService.settings = s
        LocalDelayPlayerService.settings = s
        if (save) Store.saveDelay(act, s)
        updatePresetChips()
    }

    fun refresh() {
        val st = statusText ?: return
        val isPlaying = LocalDelayPlayerService.playing
        st.setTextColor(if (isPlaying) 0xFF7BE3B0.toInt() else Pal.MUTED)
        st.text = when {
            isPlaying -> "Memutar: ${LocalDelayPlayerService.trackName}\nDelay ${if (s.enabled) "AKTIF" else "BYPASS"} • khusus pemutar lokal"
            else -> "Pilih file musik lokal untuk memulai. Spotify dan YouTube Music tidak diproses Delay."
        }
        setSwitch(s.enabled)
        refreshers.forEach { it() }
        updatePresetChips()
    }

    private fun requestStart() {
        s = s.copy(enabled = true)
        Store.saveDelay(act, s)
        Store.setDelayOn(act, true)
        DelayService.settings = s
        LocalDelayPlayerService.settings = s
        refresh()
        toast("Delay aktif untuk pemutar lokal DLMS. Pilih lagu untuk memulai.")
    }

    private fun requestStop() {
        s = s.copy(enabled = false)
        Store.saveDelay(act, s)
        Store.setDelayOn(act, false)
        DelayService.settings = s
        LocalDelayPlayerService.settings = s
        refresh()
    }

    private fun updatePresetChips() {
        val m = DelayPresets.matching(s)
        presetChips.forEach { (n, v) -> Ui.setChipSelected(v, n == m) }
    }

    // ---------- UI ----------

    fun build(content: LinearLayout) {
        Ui.sectionTitle(act, content, "DELAY (DSP INTERNAL)")
        val card = Ui.panelCard(act, 14)

        val playerTitle = Ui.label(act, "PEMUTAR MUSIK LOKAL", 13f, Pal.MUTED, true)
        card.addView(playerTitle)
        val playerStatus = Ui.label(act, "Pilih file musik lokal untuk memulai.", 12f, Pal.MUTED)
        statusText = playerStatus
        card.addView(playerStatus)
        val playerButtons = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val choose = Ui.pill(act, "PILIH LAGU").apply { textSize = 12f }
        choose.setOnClickListener { openAudio.launch(arrayOf("audio/*")) }
        val stop = Ui.pill(act, "STOP").apply { textSize = 12f }
        stop.setOnClickListener { LocalDelayPlayerService.stop(act); refresh() }
        playerButtons.addView(choose, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(act, 6) })
        playerButtons.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(playerButtons)
        card.addView(Ui.label(act, "Delay hanya bekerja pada lagu yang diputar dari pemutar lokal ini. Audio Spotify dan YouTube Music tidak diambil atau diubah.", 10f, Pal.MUTED))

        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val sw = Switch(act).apply {
            text = "Delay aktif"; textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = s.enabled
            setOnCheckedChangeListener { _, checked ->
                if (suppressSwitch) return@setOnCheckedChangeListener
                if (checked) requestStart() else requestStop()
            }
        }
        switch = sw
        top.addView(sw, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(act).apply {
            text = "i"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(0xFFB5B5BA.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0)
                setStroke(Ui.dp(act, 2), 0xFF8E8E93.toInt())
            }
            isClickable = true
            contentDescription = "Info delay"
            setOnClickListener { showInfo() }
        }, LinearLayout.LayoutParams(Ui.dp(act, 32), Ui.dp(act, 32)))
        card.addView(top)

        // Preset
        card.addView(Ui.label(act, "Preset delay", 13f, Pal.MUTED, true).apply { setPadding(Ui.dp(act, 4), Ui.dp(act, 14), 0, Ui.dp(act, 6)) })
        val chipRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        presetChips.clear()
        DelayPresets.all.forEach { p ->
            val chip = Ui.chip(act, p.name)
            chip.setOnClickListener {
                s = DelayPresets.applyTo(s, p)
                changed(save = true)
                refreshers.forEach { it() }
                Toast.makeText(act, "Preset delay \"${p.name}\" digunakan", Toast.LENGTH_SHORT).show()
            }
            presetChips.add(p.name to chip)
            chipRow.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Ui.dp(act, 6) })
        }
        card.addView(HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) })

        refreshers.clear()
        val save = { Store.saveDelay(act, s) }
        refreshers += Ui.slider(act, card, "Delay Time", DelaySpec.time, { s.timeMs.toFloat() }, { s = s.copy(timeMs = it.toInt()); changed(); refresh() }, save)
        refreshers += Ui.slider(act, card, "Feedback", DelaySpec.feedback, { s.feedbackPct.toFloat() }, { s = s.copy(feedbackPct = it.toInt()); changed() }, save)
        refreshers += Ui.slider(act, card, "Wet Mix", DelaySpec.mix, { s.wetPct.toFloat() }, { s = s.copy(wetPct = it.toInt()); changed() }, save)
        refreshers += Ui.slider(act, card, "Dry Mix (sinyal asli)", DelaySpec.mix, { s.dryPct.toFloat() }, { s = s.copy(dryPct = it.toInt()); changed() }, save)
        card.addView(Ui.label(act, "Dry 0% = tanpa sinyal asli; Wet 100% = hanya sinyal gema. Tidak ada audio capture atau suara asli ganda.", 10f, Pal.MUTED))
        refreshers += Ui.slider(act, card, "High Cut", DelaySpec.highCut, { s.highCutHz.toFloat() }, { s = s.copy(highCutHz = it.toInt()); changed() }, save)
        refreshers += Ui.slider(act, card, "Low Cut", DelaySpec.lowCut, { s.lowCutHz.toFloat() }, { s = s.copy(lowCutHz = it.toInt()); changed() }, save)

        refreshers += Ui.check(act, card, "Stereo Delay (kanan 1,5× lebih lambat)", { s.stereo }, { s = s.copy(stereo = it); changed(true) })
        refreshers += Ui.check(act, card, "Ping Pong (gema berpindah L ↔ R)", { s.pingPong }, { s = s.copy(pingPong = it); changed(true) })
        refreshers += Ui.check(act, card, "Karakter Tape (wow/flutter + saturasi)", { s.tape }, { s = s.copy(tape = it); changed(true) })

        val reset = Ui.pill(act, "RESET DELAY").apply { textSize = 12f; setPadding(Ui.dp(act, 8), Ui.dp(act, 11), Ui.dp(act, 8), Ui.dp(act, 11)) }
        reset.setOnClickListener {
            s = DelaySettings(enabled = s.enabled)
            changed(true)
            Store.setDelayOn(act, s.enabled)
            refreshers.forEach { it() }
        }
        card.addView(reset, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(act, 16) })
        Ui.addCard(content, card, 0)
        refresh()
    }

    private fun showInfo() {
        val msg = "Pemutar lokal DLMS membaca file audio, decode ke PCM, lalu memprosesnya melalui DSP internal dan mengeluarkannya lewat AudioTrack.\n\n" +
            "• EQ, limiter, dan efek sistem tetap tersedia pada sesi audio bila perangkat Android mendukung efek sesi.\n" +
            "• Delay internal hanya memproses pemutar lokal DLMS.\n" +
            "• Spotify dan YouTube Music tidak diproses Delay dan tidak ditangkap.\n" +
            "• Tidak menggunakan MediaProjection / AudioPlaybackCapture, sehingga tidak ada audio asli ganda dari jalur capture.\n" +
            "• Dry 0% menghilangkan sinyal langsung pada output DSP; Wet mengatur sinyal gema."
        AlertDialog.Builder(act).setTitle("Delay DSP + Pemutar Lokal").setMessage(msg).setPositiveButton("Tutup", null).show()
    }
}

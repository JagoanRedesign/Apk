package com.dlmsmini.equalizer

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Diagnostik & uji perangkat: dukungan efek HP, status efek yang terverifikasi, foreground service,
 * penanganan vendor, perangkat audio saat ini, log kejadian, dan panduan uji ganti headset/Bluetooth/speaker.
 */
class DiagnosticsActivity : AppCompatActivity() {
    private val bg = Pal.c(0xFF1B1B1D)
    private val titleColor = Pal.c(0xFFE6E1E9)
    private val descColor = Pal.c(0xFFCAC4D0)
    private var service: EqualizerService? = null
    private var bound = false
    private lateinit var body: LinearLayout
    private var capText: String? = null
    private fun caps(): String = capText ?: Capabilities.scan(this).text().also { capText = it }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as? EqualizerService.LocalBinder)?.service
            service?.onChanged = { runOnUiThread { render() } }
            render()
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        })
        bar.addView(Ui.label(this, "Diagnostik", 26f, titleColor))
        root.addView(bar)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(24)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.fitSystemBars(root)
        setContentView(root)
        bound = bindService(Intent(this, EqualizerService::class.java), connection, Context.BIND_AUTO_CREATE)
    }

    override fun onResume() {
        super.onResume()
        capText = null
        render()
    }

    override fun onDestroy() {
        service?.onChanged = null
        if (bound) { try { unbindService(connection) } catch (_: Exception) {}; bound = false }
        service = null
        super.onDestroy()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun card(title: String, text: String, tint: Int = descColor): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(this@DiagnosticsActivity, Pal.c(0xFF343437), 18)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        c.addView(Ui.label(this, title, 16f, titleColor, true))
        c.addView(Ui.label(this, text, 12f, tint).apply {
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(6), 0, 0)
            setLineSpacing(0f, 1.15f)
        })
        return c
    }

    private fun button(text: String, onClick: () -> Unit): TextView =
        Ui.pill(this, text).apply {
            textSize = 12f
            setPadding(dp(8), dp(11), dp(8), dp(11))
            setOnClickListener { onClick() }
        }

    private fun isIgnoringBattery(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (_: Exception) { false }

    private fun report(): String {
        val sb = StringBuilder()
        sb.appendLine("DLMS Mini Equalizer — laporan diagnostik")
        sb.appendLine(Capabilities.deviceLine())
        sb.appendLine("Vendor: ${VendorGuide.family().title}")
        sb.appendLine("Output audio: ${service?.route?.label ?: "-"} ${service?.route?.name.orEmpty()}")
        sb.appendLine("Status: ${service?.status ?: "-"}")
        sb.appendLine("Foreground service: " + (EqualizerService.lastFgError ?: "normal"))
        sb.appendLine("Pengecualian baterai: ${if (isIgnoringBattery()) "ya" else "tidak"}")
        sb.appendLine()
        sb.appendLine(caps())
        sb.appendLine()
        service?.indicator()?.let { ind ->
            sb.appendLine("Indikator: ${ind.text}")
            ind.details.forEach { sb.appendLine("  - ${it.name}: ${it.state}${if (it.detail.isNotEmpty()) " (${it.detail})" else ""}") }
        }
        sb.appendLine()
        sb.appendLine(EffectConflicts.report())
        sb.appendLine()
        DiagLog.snapshot().forEach { sb.appendLine(it) }
        return sb.toString()
    }

    private fun render() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        val s = service

        // 1. Perangkat & output
        body.addView(card(
            "Perangkat & output audio",
            Capabilities.deviceLine() + "\nVendor : ${VendorGuide.family().title}\n" +
                "Output : " + (s?.route?.let { it.label + if (it.name.isNotEmpty()) " (${it.name})" else "" } ?: "menyambung…")
        ))

        // 2. Indikator efek terverifikasi
        val ind = s?.indicator()
        val lines = StringBuilder()
        if (ind == null) lines.append("Layanan belum terhubung")
        else {
            lines.appendLine(ind.text)
            if (ind.details.isEmpty()) lines.appendLine("Tidak ada efek yang diminta / diterapkan saat ini.")
            ind.details.forEach {
                lines.appendLine((if (it.state == FxState.ACTIVE) "✔ " else "✘ ") + it.name +
                    if (it.detail.isNotEmpty()) " — ${it.detail}" else "")
            }
            if (s?.safetyLimiterActive == true) lines.appendLine("ℹ Limiter pengaman aktif (proteksi clipping)")
            val issues = s?.fxIssues().orEmpty()
            if (issues.isNotEmpty()) lines.appendLine("⚠ Tidak diterapkan perangkat: " + issues.joinToString(", "))
        }
        body.addView(card(
            "Efek benar-benar aktif?", lines.toString().trim(),
            when (ind?.level) { Level.OK -> Pal.c(0xFF7BE3B0); Level.FAIL -> Pal.c(0xFFFF6B6B); Level.PARTIAL -> Pal.c(0xFFFFB86B); else -> descColor }
        ))

        // 2b. Konflik efek vendor & hasil baca-balik
        val extra = StringBuilder(EffectConflicts.report())
        if (s?.contested == true) extra.appendLine().appendLine().append("⚠ Kendali efek direbut berulang kali oleh aplikasi/efek lain.")
        val note = s?.limiterReadbackNote.orEmpty()
        if (note.isNotEmpty()) extra.appendLine().appendLine().append("⚠ Limiter: $note")
        body.addView(card("Efek vendor & konflik", extra.toString()))

        // 3. Dukungan efek HP
        body.addView(card("Dukungan efek perangkat", caps()))

        // 4. Foreground service & izin
        val notif = if (Build.VERSION.SDK_INT >= 33)
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED else true
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        body.addView(card(
            "Layanan latar belakang & izin",
            "Foreground service   : " + (EqualizerService.lastFgError?.let { "DITOLAK — $it" } ?: "normal") + "\n" +
                "Izin notifikasi      : " + (if (notif) "diberikan" else "BELUM (notifikasi tersembunyi, layanan tetap jalan)") + "\n" +
                "Izin rekam audio     : " + (if (mic) "diberikan" else "belum (Spectrum)") + "\n" +
                "Bebas optimasi baterai: " + (if (isIgnoringBattery()) "ya" else "belum")
        ))

        // 5. Vendor
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tips = "Agar layanan tidak dimatikan:\n" + VendorGuide.backgroundTips().joinToString("\n") { "• $it" } +
            "\n\nBila efek tidak terdengar:\n" + VendorGuide.audioTips().joinToString("\n") { "• $it" }
        v.addView(card("Penanganan vendor — ${VendorGuide.family().name}", tips))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("MULAI OTOMATIS") {
            if (!VendorGuide.openAutostart(this)) Toast.makeText(this, "Layar vendor tidak ditemukan; dibuka info aplikasi", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(6), dp(3), 0) })
        row.addView(button("BATERAI") { VendorGuide.openBatterySettings(this) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(6), dp(3), 0) })
        v.addView(row)
        body.addView(v)

        // 6. Panduan uji
        body.addView(card(
            "Uji ganti perangkat audio",
            "1. Putar musik, pastikan indikator di layar utama hijau.\n" +
                "2. Sambung headset Bluetooth → log di bawah harus mencatat \"Perangkat audio berganti\" lalu \"Verifikasi\".\n" +
                "3. Cabut/ sambung headset kabel, lalu kembali ke speaker; ulangi tiap perpindahan.\n" +
                "4. Bila efek hilang setelah berganti, tekan TERAPKAN ULANG dan periksa daftar efek di atas.\n" +
                "5. Bluetooth LDAC/aptX atau Android Auto: aktifkan Mode Sesi Aplikasi."
        ))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("TERAPKAN ULANG") {
            service?.rebuildAll("manual")
            render()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(6), dp(3), 0) })
        actions.addView(button("SALIN LAPORAN") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("DLMS diagnostik", report()))
            Toast.makeText(this, "Laporan disalin", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(6), dp(3), 0) })
        body.addView(actions)

        // 7. Log
        val log = DiagLog.snapshot()
        body.addView(card("Log kejadian", if (log.isEmpty()) "(belum ada kejadian)" else log.takeLast(25).reversed().joinToString("\n")))
    }
}

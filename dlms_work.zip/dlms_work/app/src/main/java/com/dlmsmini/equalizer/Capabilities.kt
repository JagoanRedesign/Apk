package com.dlmsmini.equalizer

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.media.audiofx.Visualizer
import android.os.Build
import androidx.core.content.ContextCompat

class CapItem(val name: String, val supported: Boolean, val detail: String)

class CapReport(val items: List<CapItem>) {
    fun text(): String = items.joinToString("\n") { (if (it.supported) "✔ " else "✘ ") + it.name + (if (it.detail.isNotEmpty()) " — " + it.detail else "") }
}

/**
 * Deteksi dukungan efek audio perangkat. Setiap efek dicoba dibuat pada sesi audio PRIBADI (bukan sesi 0), sehingga
 * pengujian tidak merebut kendali dari efek yang sedang dipakai mesin utama. Dukungan Mix Global (sesi 0) dilaporkan
 * terpisah oleh layanan lewat status efek yang benar-benar terverifikasi.
 */
object Capabilities {

    private fun <T : AudioEffect> probe(name: String, make: () -> T, describe: (T) -> String = { "" }): CapItem {
        var e: T? = null
        return try {
            e = make()
            val control = e.hasControl()
            CapItem(name, control, if (control) describe(e) else "dibuat, tetapi kendali dipegang pihak lain")
        } catch (t: Throwable) {
            CapItem(name, false, "tidak didukung (${t.javaClass.simpleName})")
        } finally {
            try { e?.release() } catch (_: Throwable) {}
        }
    }

    fun scan(ctx: Context): CapReport {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val sid = try { am.generateAudioSessionId() } catch (_: Exception) { 0 }
        val items = mutableListOf<CapItem>()

        items += probe("Equalizer sistem", { Equalizer(0, sid) }) { e ->
            val r = e.bandLevelRange
            "${e.numberOfBands} band hardware, ${r[0] / 100}..${r[1] / 100} dB"
        }
        items += probe("Bass Boost", { BassBoost(0, sid) }) { if (it.strengthSupported) "kekuatan dapat diatur" else "hanya ON/OFF" }
        items += probe("Virtualizer", { Virtualizer(0, sid) }) { if (it.strengthSupported) "kekuatan dapat diatur" else "hanya ON/OFF" }
        items += probe("Reverb (preset)", { PresetReverb(0, sid) })
        items += probe("Loudness Enhancer", { LoudnessEnhancer(sid) })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val basic = probe("DynamicsProcessing (limiter, gain per kanal)", {
                DynamicsProcessing(0, sid, DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2, false, 0, false, 0, false, 0, true).build())
            })
            items += basic
            items += probe("DynamicsProcessing penuh (EQ 10 band, MBC/crossover 2-Way, Post-EQ)", {
                DynamicsProcessing(0, sid, DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2, true, 10, true, 3, true, 3, true).build())
            })
        } else {
            items += CapItem("DynamicsProcessing", false, "butuh Android 9+")
        }

        val hasRec = ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        items += if (!hasRec) CapItem("Spectrum Analyzer (Visualizer)", false, "izin rekam audio belum diberikan") else try {
            val v = Visualizer(sid)
            val size = Visualizer.getCaptureSizeRange()[1]
            v.release()
            CapItem("Spectrum Analyzer (Visualizer)", true, "FFT $size titik")
        } catch (t: Throwable) {
            CapItem("Spectrum Analyzer (Visualizer)", false, "tidak didukung (${t.javaClass.simpleName})")
        }

        items += CapItem(
            "Delay DSP (AudioPlaybackCapture)", DelayService.supported,
            if (DelayService.supported) "didukung (Android 10+), butuh izin rekam + persetujuan MediaProjection" else "butuh Android 10+"
        )
        return CapReport(items)
    }

    fun deviceLine(): String =
        "${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
}

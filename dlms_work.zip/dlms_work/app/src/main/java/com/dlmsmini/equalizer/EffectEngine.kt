package com.dlmsmini.equalizer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Mesin efek audio (Equalizer + Limiter) yang dipakai bersama oleh aplikasi dan layanan latar belakang.
 *
 * Agar efek terasa di pemutar lain (YouTube, Spotify, dll.) ada dua jalur:
 *  1. Sesi global (ID 0).
 *  2. Per sesi: pemutar yang mengumumkan sesi audionya lewat broadcast
 *     ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION, ditambah pemindaian sesi pemutaran aktif (best effort).
 * Pilihan jalur ada di Pengaturan > Pipeline audio. Semua dipanggil dari main thread.
 */
object EffectEngine {
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    private class Fx(val session: Int) {
        var eq: Equalizer? = null
        var limiter: LimiterFx? = null
    }

    private val sessions = LinkedHashMap<Int, Fx>()
    private val scanned = HashSet<Int>()
    private val handler = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var refs = 0
    private var receiverRegistered = false
    private var eqError: String? = null
    private var limiterError: String? = null

    /** Dipanggil (main thread) setiap daftar sesi atau status berubah. */
    var onChange: (() -> Unit)? = null

    // ---------------- siklus hidup ----------------

    fun retain(context: Context) {
        refs++
        if (refs == 1) {
            app = context.applicationContext
            AppSettings.init(context)
            start()
        }
    }

    fun release() {
        if (refs > 0) refs--
        if (refs == 0) stop()
    }

    private fun start() {
        val ctx = app ?: return
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            else ctx.registerReceiver(receiver, filter)
            receiverRegistered = true
        } catch (_: Exception) {}
        applyPipeline()
    }

    private fun stop() {
        handler.removeCallbacks(scanTask)
        if (receiverRegistered) {
            try { app?.unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        for (fx in sessions.values) releaseFx(fx)
        sessions.clear()
        scanned.clear()
        onChange?.invoke()
    }

    // ---------------- pipeline ----------------

    /** Terapkan pilihan pipeline: 0 = global, 1 = per sesi, 2 = keduanya. */
    fun applyPipeline() {
        if (refs == 0) return
        val mode = AppSettings.pipeline
        if (mode != 1) attach(0) else detach(0)
        handler.removeCallbacks(scanTask)
        if (mode != 0) {
            handler.post(scanTask)
        } else {
            for (s in sessions.keys.filter { it != 0 }) detach(s)
            scanned.clear()
        }
        onChange?.invoke()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (AppSettings.pipeline == 0) return
            val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (session <= 0) return
            if (intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) == context.packageName) return
            if (intent.action == AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION) {
                if (attach(session)) onChange?.invoke()
            } else {
                scanned.remove(session)
                detach(session)
                onChange?.invoke()
            }
        }
    }

    private val scanTask = object : Runnable {
        override fun run() {
            scanActiveSessions()
            handler.postDelayed(this, 2500L)
        }
    }

    /** Best effort: baca sesi audio dari pemutaran aktif. Bisa gagal di versi Android yang menyembunyikan API ini. */
    private fun scanActiveSessions() {
        if (Build.VERSION.SDK_INT < 26) return
        val ctx = app ?: return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val found = HashSet<Int>()
            for (cfg in am.activePlaybackConfigurations) {
                val id = sessionIdOf(cfg)
                if (id > 0) found.add(id)
            }
            var changed = false
            for (id in found) {
                if (!sessions.containsKey(id) && attach(id)) { scanned.add(id); changed = true }
            }
            for (id in scanned.toList()) {
                if (!found.contains(id)) { scanned.remove(id); detach(id); changed = true }
            }
            if (changed) onChange?.invoke()
        } catch (_: Throwable) {}
    }

    private fun sessionIdOf(config: Any): Int {
        for (name in arrayOf("getAudioSessionId", "getSessionId")) {
            try {
                val v = config.javaClass.getMethod(name).invoke(config)
                if (v is Int) return v
            } catch (_: Throwable) {}
        }
        return -1
    }

    // ---------------- efek per sesi ----------------

    private fun attach(session: Int): Boolean {
        if (sessions.containsKey(session)) return true
        val fx = Fx(session)
        try {
            fx.eq = Equalizer(0, session)
            if (session == 0) eqError = null
        } catch (e: Throwable) {
            if (session == 0) eqError = e.javaClass.simpleName
        }
        if (fx.eq == null) return false
        sessions[session] = fx
        applyEq(fx)
        applyLimiter(fx)
        return true
    }

    private fun detach(session: Int) {
        val fx = sessions.remove(session) ?: return
        releaseFx(fx)
    }

    private fun releaseFx(fx: Fx) {
        try { fx.eq?.release() } catch (_: Exception) {}
        fx.eq = null
        try { fx.limiter?.release() } catch (_: Throwable) {}
        fx.limiter = null
    }

    // ---------------- Equalizer ----------------

    fun applyEq() {
        for (fx in sessions.values) applyEq(fx)
    }

    private fun applyEq(fx: Fx) {
        val eq = fx.eq ?: return
        try {
            eq.setEnabled(AppSettings.eqEnabled)
            if (!AppSettings.eqEnabled) return
            val range = eq.bandLevelRange
            val count = eq.numberOfBands.toInt()
            val buckets = Array(count) { mutableListOf<Int>() }
            for (i in 0 until 10) buckets[nearestBand(eq, centerHz[i])].add(AppSettings.bands[i])
            for (band in 0 until count) {
                val half = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                val milliBel = (half * 50).coerceIn(range[0].toInt(), range[1].toInt())
                eq.setBandLevel(band.toShort(), milliBel.toShort())
            }
        } catch (_: Exception) {}
    }

    private fun nearestBand(eq: Equalizer, hz: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until eq.numberOfBands.toInt()) {
            val center = eq.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    // ---------------- Limiter ----------------

    fun applyLimiter() {
        for (fx in sessions.values) applyLimiter(fx)
        onChange?.invoke()
    }

    private fun applyLimiter(fx: Fx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        if (!AppSettings.limEnabled) {
            if (fx.limiter != null) {
                try { fx.limiter?.release() } catch (_: Throwable) {}
                fx.limiter = null
            }
            if (fx.session == 0) limiterError = null
            return
        }
        try {
            val lim = fx.limiter ?: LimiterFx(fx.session).also { fx.limiter = it }
            lim.update(
                LimiterParams(
                    AppSettings.limAttack, AppSettings.limRelease, AppSettings.limRatio,
                    AppSettings.limThreshold, AppSettings.limPostGain
                )
            )
            if (fx.session == 0) limiterError = null
        } catch (e: Throwable) {
            fx.limiter = null
            if (fx.session == 0) limiterError = e.javaClass.simpleName
        }
    }

    // ---------------- status untuk UI ----------------

    fun statusText(): String {
        val global = sessions.containsKey(0)
        val others = sessions.size - (if (global) 1 else 0)
        val parts = ArrayList<String>()
        parts.add(
            when {
                AppSettings.pipeline == 1 -> "Global: dimatikan"
                global -> "Global: aktif"
                else -> "Global: gagal (${eqError ?: "tidak didukung"})"
            }
        )
        parts.add(if (AppSettings.pipeline == 0) "Per sesi: dimatikan" else "Sesi pemutar: $others")
        return parts.joinToString("  •  ")
    }

    fun limiterNote(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return "Limiter memerlukan Android 9 (API 28) atau lebih baru."
        if (!AppSettings.limEnabled) return ""
        val active = sessions.values.count { it.limiter != null }
        return when {
            active > 0 -> "Limiter aktif pada $active sesi audio."
            sessions.isEmpty() -> "Limiter menunggu sesi audio."
            else -> "Limiter belum aktif: perangkat tidak mendukung DynamicsProcessing pada sesi ini" +
                (limiterError?.let { " ($it)" } ?: "") + "."
        }
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.media.audiofx.Equalizer
import android.os.Build
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Efek output-mix global Android. Session ID 0 meminta efek pada jalur output mix,
 * bukan menangkap/menyalin audio aplikasi lain.
 * Dukungan ditentukan oleh implementasi Android/vendor dan dapat ditolak perangkat.
 */
object EffectEngine {
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    private var refs = 0
    private var eq: Equalizer? = null
    private var limiter: LimiterFx? = null
    private var eqError: String? = null
    private var limiterError: String? = null

    var onChange: (() -> Unit)? = null

    fun retain(context: Context) {
        refs++
        if (refs == 1) {
            AppSettings.init(context.applicationContext)
            attachGlobalEffects()
        }
    }

    fun release() {
        if (refs > 0) refs--
        if (refs == 0) detachAll()
    }

    /** Buat kedua efek secara independen; kegagalan EQ tidak boleh mematikan limiter. */
    private fun attachGlobalEffects() {
        attachGlobalEqualizer()
        applyLimiter()
        onChange?.invoke()
    }

    private fun attachGlobalEqualizer() {
        if (eq == null) {
            try {
                // PRIORITAS: global output mix (audio session ID 0).
                eq = Equalizer(0, 0).also { it.enabled = AppSettings.eqEnabled }
                eqError = null
            } catch (t: Throwable) {
                eq = null
                eqError = errorName(t)
            }
        }
        applyEq()
    }

    private fun detachAll() {
        try { eq?.release() } catch (_: Throwable) {}
        eq = null
        try { limiter?.release() } catch (_: Throwable) {}
        limiter = null
        onChange?.invoke()
    }

    /** Dipertahankan agar pemanggil UI lama tetap kompatibel. Sekarang selalu global. */
    fun applyPipeline() {
        if (refs <= 0) return
        attachGlobalEqualizer()
        applyLimiter()
        onChange?.invoke()
    }

    fun applyEq() {
        val effect = eq
        if (effect == null) return
        try {
            effect.enabled = AppSettings.eqEnabled
            if (!AppSettings.eqEnabled) return
            val count = effect.numberOfBands.toInt()
            if (count <= 0) throw IllegalStateException("No EQ bands")
            val range = effect.bandLevelRange
            val bucket = Array(count) { mutableListOf<Int>() }
            for (i in centerHz.indices) bucket[nearestBand(effect, centerHz[i])].add(AppSettings.bands[i])
            for (band in 0 until count) {
                val halfDb = bucket[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                val milliBel = (halfDb * 50).coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band.toShort(), milliBel.toShort())
            }
            eqError = null
        } catch (t: Throwable) {
            eqError = errorName(t)
        }
        onChange?.invoke()
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Int {
        var best = 0
        var bestDiff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands.toInt()) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val diff = abs(center - hz.toLong())
            if (diff < bestDiff) { bestDiff = diff; best = i }
        }
        return best
    }

    fun applyLimiter() {
        if (refs <= 0) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            limiterError = "Memerlukan Android 9+"
            onChange?.invoke()
            return
        }
        if (!AppSettings.limEnabled) {
            try { limiter?.release() } catch (_: Throwable) {}
            limiter = null
            limiterError = null
            onChange?.invoke()
            return
        }
        try {
            // DynamicsProcessing juga diminta pada output mix global, session ID 0.
            val active = limiter ?: LimiterFx(0).also { limiter = it }
            active.update(LimiterParams(
                AppSettings.limAttack.coerceIn(0.1f, 500f),
                AppSettings.limRelease.coerceIn(1f, 2000f),
                AppSettings.limRatio.coerceIn(1f, 100f),
                AppSettings.limThreshold.coerceIn(-60f, 0f),
                AppSettings.limPostGain.coerceIn(-24f, 24f)
            ))
            limiterError = null
        } catch (t: Throwable) {
            try { limiter?.release() } catch (_: Throwable) {}
            limiter = null
            limiterError = errorName(t)
        }
        onChange?.invoke()
    }

    fun statusText(): String = when {
        eq != null -> "Global output mix: Equalizer(0, 0) terpasang"
        else -> "Global output mix: tidak didukung / ditolak" + (eqError?.let { " ($it)" } ?: "")
    }

    fun limiterNote(): String = when {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> "Limiter memerlukan Android 9 (API 28) atau lebih baru."
        !AppSettings.limEnabled -> "Limiter nonaktif."
        limiter != null -> "Limiter global output mix aktif."
        else -> "Limiter global tidak didukung / ditolak perangkat" + (limiterError?.let { " ($it)" } ?: "") + "."
    }

    private fun errorName(t: Throwable): String =
        (t.javaClass.simpleName.ifBlank { "AudioEffectError" } + (t.message?.let { ": $it" } ?: ""))
            .take(120)
}

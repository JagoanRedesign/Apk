package com.dlmsmini.equalizer

import android.content.Context
import android.media.audiofx.Equalizer
import android.os.Build
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Pengelola efek audio global Android.
 * Session 0 adalah output mix. Android/vendor dapat menolak efek global;
 * aplikasi tidak dapat memaksa pemrosesan audio milik aplikasi lain.
 */
object EffectEngine {
    private val sliderHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    private var refs = 0
    private var eq: Equalizer? = null
    private var limiter: LimiterFx? = null
    private var eqError: String? = null
    private var limiterError: String? = null
    private var lastApplied = "Belum diterapkan"

    var onChange: (() -> Unit)? = null

    @Synchronized
    fun retain(context: Context) {
        refs++
        if (refs == 1) {
            AppSettings.init(context.applicationContext)
            attachGlobalEqualizer()
            applyLimiter()
        }
    }

    @Synchronized
    fun release() {
        if (refs > 0) refs--
        if (refs == 0) detachAll()
    }

    private fun attachGlobalEqualizer() {
        if (eq != null) {
            applyEq()
            return
        }
        try {
            val created = Equalizer(0, 0)
            created.setControlStatusListener { _, granted ->
                if (granted) applyEq() else {
                    eqError = "Kontrol EQ diambil alih efek lain"
                    onChange?.invoke()
                }
            }
            eq = created
            eqError = null
            applyEq()
        } catch (t: Throwable) {
            try { eq?.release() } catch (_: Throwable) {}
            eq = null
            eqError = errorName(t)
            lastApplied = "Gagal membuat Equalizer"
            onChange?.invoke()
        }
    }

    @Synchronized
    fun applyEq() {
        val effect = eq ?: run {
            if (refs > 0) attachGlobalEqualizer()
            return
        }
        try {
            val count = effect.numberOfBands.toInt()
            if (count <= 0) throw IllegalStateException("Perangkat tidak menyediakan band EQ")
            if (!effect.hasControl()) throw IllegalStateException("Equalizer tidak memiliki kontrol audio")

            // Terapkan kurva 10-slider ke jumlah band fisik perangkat (sering 5).
            // Interpolasi dilakukan pada skala logaritmik frekuensi agar setiap slider
            // ikut memengaruhi kurva, tidak hanya slider yang kebetulan paling dekat.
            val range = effect.bandLevelRange
            for (band in 0 until count) {
                val hz = (effect.getCenterFreq(band.toShort()).toInt() / 1000)
                    .coerceAtLeast(sliderHz.first())
                val halfDb = interpolateCurve(hz)
                val milliBel = (halfDb * 50).coerceIn(range[0].toInt(), range[1].toInt())
                effect.setBandLevel(band.toShort(), milliBel.toShort())
            }
            effect.enabled = AppSettings.eqEnabled

            // Baca balik nilai dari HAL untuk memastikan parameter diterima.
            val readBack = (0 until count).map { effect.getBandLevel(it.toShort()).toInt() }
            lastApplied = if (AppSettings.eqEnabled) "${count} band hardware menerima nilai" else "EQ nonaktif"
            eqError = null
        } catch (t: Throwable) {
            eqError = errorName(t)
            lastApplied = "Penerapan band gagal"
        }
        onChange?.invoke()
    }

    /** Nilai slider dalam half-dB (-24..24); interpolasi memakai log frekuensi. */
    private fun interpolateCurve(hz: Int): Int {
        val values = AppSettings.bands
        val x = ln(hz.coerceAtLeast(1).toDouble())
        if (hz <= sliderHz.first()) return values.first()
        if (hz >= sliderHz.last()) return values.last()
        for (i in 0 until sliderHz.lastIndex) {
            if (hz <= sliderHz[i + 1]) {
                val x0 = ln(sliderHz[i].toDouble())
                val x1 = ln(sliderHz[i + 1].toDouble())
                val t = ((x - x0) / (x1 - x0)).coerceIn(0.0, 1.0)
                return (values[i] + (values[i + 1] - values[i]) * t).roundToInt()
            }
        }
        return values.last()
    }

    @Synchronized
    fun applyPipeline() {
        if (refs <= 0) return
        applyEq()
        applyLimiter()
    }

    @Synchronized
    fun applyLimiter() {
        if (refs <= 0) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            limiterError = "Memerlukan Android 9+"
            onChange?.invoke()
            return
        }
        if (!AppSettings.limEnabled) {
            try { limiter?.release() } catch (_: Throwable) {}
            limiter = null
            limiterError = null
            onChange?.invoke()
            return
        }
        try {
            val active = limiter ?: LimiterFx(0).also { limiter = it }
            active.update(
                LimiterParams(
                    AppSettings.limAttack.coerceIn(0.1f, 500f),
                    AppSettings.limRelease.coerceIn(1f, 2000f),
                    AppSettings.limRatio.coerceIn(1f, 100f),
                    AppSettings.limThreshold.coerceIn(-60f, 0f),
                    AppSettings.limPostGain.coerceIn(-24f, 24f)
                )
            )
            limiterError = null
        } catch (t: Throwable) {
            try { limiter?.release() } catch (_: Throwable) {}
            limiter = null
            limiterError = errorName(t)
        }
        onChange?.invoke()
    }

    @Synchronized
    private fun detachAll() {
        try { eq?.release() } catch (_: Throwable) {}
        eq = null
        try { limiter?.release() } catch (_: Throwable) {}
        limiter = null
        lastApplied = "Efek dilepas"
        onChange?.invoke()
    }

    fun statusText(): String = when {
        eq == null -> "EQ global tidak tersedia" + (eqError?.let { " ($it)" } ?: "")
        !AppSettings.eqEnabled -> "Equalizer terpasang, tetapi nonaktif"
        eqError != null -> "Equalizer gagal: $eqError"
        else -> "Equalizer global: $lastApplied"
    }

    fun limiterNote(): String = when {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> "Limiter memerlukan Android 9 (API 28) atau lebih baru."
        !AppSettings.limEnabled -> "Limiter nonaktif."
        limiter != null -> "Limiter global output mix aktif."
        else -> "Limiter global tidak tersedia" + (limiterError?.let { " ($it)" } ?: ".")
    }

    private fun errorName(t: Throwable): String =
        (t.javaClass.simpleName.ifBlank { "AudioEffectError" } + (t.message?.let { ": $it" } ?: ""))
            .take(120)
}

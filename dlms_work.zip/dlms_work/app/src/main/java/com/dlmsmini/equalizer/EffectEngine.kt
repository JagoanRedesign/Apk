package com.dlmsmini.equalizer

import android.content.Context
import android.os.Build

/**
 * Efek output-mix global Android. Session ID 0 meminta efek pada jalur output mix,
 * bukan menangkap/menyalin audio aplikasi lain.
 * Dukungan ditentukan oleh implementasi Android/vendor dan dapat ditolak perangkat.
 */
object EffectEngine {
    private var refs = 0
    private var limiter: LimiterFx? = null
    private var limiterError: String? = null

    var onChange: (() -> Unit)? = null

    fun retain(context: Context) {
        refs++
        if (refs == 1) {
            AppSettings.init(context.applicationContext)
            attachGlobalEffects()
        }
    }

    fun release() {
        if (refs > 0) refs--
        if (refs == 0) detachAll()
    }

    /** Pasang limiter secara terpisah dari Equalizer. */
    private fun attachGlobalEffects() {
        applyLimiter()
        onChange?.invoke()
    }

    private fun detachAll() {
        try { limiter?.release() } catch (_: Throwable) {}
        limiter = null
        onChange?.invoke()
    }

    /** Jalankan ulang pipeline limiter setelah pengaturan berubah. */
    fun applyPipeline() {
        if (refs <= 0) return
        applyLimiter()
        onChange?.invoke()
    }

    /** EQ dikelola langsung oleh MainActivity agar konsisten dengan versi stabil. */
    fun applyEq() { /* compatibility no-op */ }

    fun applyLimiter() {
        if (refs <= 0) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            limiterError = "Memerlukan Android 9+"
            onChange?.invoke()
            return
        }
        if (!AppSettings.limEnabled) {
            try { limiter?.release() } catch (_: Throwable) {}
            limiter = null
            limiterError = null
            onChange?.invoke()
            return
        }
        try {
            // DynamicsProcessing juga diminta pada output mix global, session ID 0.
            val active = limiter ?: LimiterFx(0).also { limiter = it }
            active.update(LimiterParams(
                AppSettings.limAttack.coerceIn(0.1f, 500f),
                AppSettings.limRelease.coerceIn(1f, 2000f),
                AppSettings.limRatio.coerceIn(1f, 100f),
                AppSettings.limThreshold.coerceIn(-60f, 0f),
                AppSettings.limPostGain.coerceIn(-24f, 24f)
            ))
            limiterError = null
        } catch (t: Throwable) {
            try { limiter?.release() } catch (_: Throwable) {}
            limiter = null
            limiterError = errorName(t)
        }
        onChange?.invoke()
    }

    fun statusText(): String = "Equalizer dikelola langsung oleh MainActivity."

    fun limiterNote(): String = when {
        Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> "Limiter memerlukan Android 9 (API 28) atau lebih baru."
        !AppSettings.limEnabled -> "Limiter nonaktif."
        limiter != null -> "Limiter global output mix aktif."
        else -> "Limiter global tidak didukung / ditolak perangkat" + (limiterError?.let { " ($it)" } ?: "") + "."
    }

    private fun errorName(t: Throwable): String =
        (t.javaClass.simpleName.ifBlank { "AudioEffectError" } + (t.message?.let { ": $it" } ?: ""))
            .take(120)
}

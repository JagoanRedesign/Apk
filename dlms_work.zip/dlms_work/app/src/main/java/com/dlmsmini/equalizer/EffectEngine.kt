package com.dlmsmini.equalizer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlin.math.abs
import kotlin.math.roundToInt

object EffectEngine {
    private const val TAG = "EffectEngine"
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    // Prioritas dari TERTINGGI → TERENDAH, agar bisa override efek pabrikan (Dolby/DTS)
    private val EQ_PRIORITIES      = intArrayOf(2000, 1500, 1000, 0)
    private val LIMITER_PRIORITIES = intArrayOf(2001, 1501, 1001, 1)

    private class Fx(val session: Int) {
        var eq: Equalizer? = null
        var limiter: LimiterFx? = null
    }

    private val sessions = LinkedHashMap<Int, Fx>()
    private val scanned = HashSet<Int>()
    private val handler = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var refs = 0
    private var receiverRegistered = false
    private var eqError: String? = null
    private var limiterError: String? = null

    var onChange: (() -> Unit)? = null

    // ---------------- siklus hidup ----------------

    fun retain(context: Context) {
        refs++
        if (refs == 1) {
            app = context.applicationContext
            AppSettings.init(context)
            start()
        }
    }

    fun release() {
        if (refs > 0) refs--
        if (refs == 0) stop()
    }

    private fun start() {
        val ctx = app ?: return
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
            priority = IntentFilter.SYSTEM_HIGH_PRIORITY
        }
        try {
            if (Build.VERSION.SDK_INT >= 33)
                ctx.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            else
                ctx.registerReceiver(receiver, filter)
            receiverRegistered = true
        } catch (e: Exception) {
            Log.e(TAG, "registerReceiver failed", e)
        }
        applyPipeline()
    }

    private fun stop() {
        handler.removeCallbacks(scanTask)
        if (receiverRegistered) {
            try { app?.unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        for (fx in sessions.values) releaseFx(fx)
        sessions.clear()
        scanned.clear()
        onChange?.invoke()
    }

    // ---------------- pipeline ----------------

    fun applyPipeline() {
        if (refs == 0) return
        val mode = AppSettings.pipeline

        if (mode != 1) {
            if (!attach(0)) Log.w(TAG, "Global attach failed: $eqError")
        } else {
            detach(0)
        }

        handler.removeCallbacks(scanTask)
        handler.post(scanTask)   // selalu aktif agar bisa retry session 0

        if (mode == 0) {
            for (s in sessions.keys.filter { it != 0 }) detach(s)
            scanned.clear()
        }
        onChange?.invoke()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (AppSettings.pipeline == 0) return
            val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (session <= 0) return
            if (intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) == context.packageName) return
            if (intent.action == AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION) {
                if (attach(session)) onChange?.invoke()
            } else {
                scanned.remove(session)
                detach(session)
                onChange?.invoke()
            }
        }
    }

    private val scanTask = object : Runnable {
        override fun run() {
            if (refs == 0) return
            scanActiveSessions()
            handler.postDelayed(this, 2500L)
        }
    }

    private fun scanActiveSessions() {
        // 1) Deteksi EQ yang kehilangan kontrol (mis. Dolby diaktifkan user)
        val lostControl = sessions.filter { (_, fx) -> fx.eq?.hasControl == false }.keys.toList()
        for (id in lostControl) {
            Log.w(TAG, "Lost control on session=$id, akan re-attach")
            detach(id)
        }
        if (lostControl.isNotEmpty()) onChange?.invoke()

        // 2) Retry session 0 (global) bila perlu
        if (AppSettings.pipeline != 1 && !sessions.containsKey(0)) {
            if (attach(0)) onChange?.invoke()
        }

        // 3) Scan sesi pemutar (hanya mode 1 & 2)
        if (AppSettings.pipeline == 0) return
        if (Build.VERSION.SDK_INT < 26) return
        val ctx = app ?: return

        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val found = HashSet<Int>()
            for (cfg in am.activePlaybackConfigurations) {
                val id = sessionIdOf(cfg)
                if (id > 0) found.add(id)
            }
            var changed = false
            for (id in found) {
                if (!sessions.containsKey(id) && attach(id)) { scanned.add(id); changed = true }
            }
            for (id in scanned.toList()) {
                if (!found.contains(id)) { scanned.remove(id); detach(id); changed = true }
            }
            if (changed) onChange?.invoke()
        } catch (e: Throwable) {
            Log.e(TAG, "scanActiveSessions failed", e)
        }
    }

    private fun sessionIdOf(config: Any): Int {
        for (name in arrayOf("getAudioSessionId", "getSessionId")) {
            try {
                val v = config.javaClass.getMethod(name).invoke(config)
                if (v is Int) return v
            } catch (_: Throwable) {}
        }
        return -1
    }

    // ---------------- efek per sesi ----------------

    /**
     * Coba buat Equalizer dengan beberapa prioritas.
     * Hanya diterima bila hasControl() == true — jika tidak, release & coba prioritas berikutnya.
     */
    private fun attach(session: Int): Boolean {
        if (sessions.containsKey(session)) return true

        var eq: Equalizer? = null
        var lastError: String? = null

        for (priority in EQ_PRIORITIES) {
            var candidate: Equalizer? = null
            try {
                candidate = Equalizer(priority, session)
                if (candidate.hasControl()) {
                    eq = candidate
                    Log.d(TAG, "Equalizer OK session=$session priority=$priority")
                    break
                }
                lastError = "hasControl=false priority=$priority"
                Log.w(TAG, "Equalizer session=$session priority=$priority tanpa kontrol, retry")
                try { candidate.release() } catch (_: Exception) {}
            } catch (e: Throwable) {
                lastError = "${e.javaClass.simpleName}: ${e.message}"
                try { candidate?.release() } catch (_: Exception) {}
            }
        }

        if (eq == null) {
            if (session == 0) eqError = lastError ?: "unknown"
            Log.w(TAG, "Equalizer FAILED session=$session: $lastError")
            return false
        }

        val fx = Fx(session)
        fx.eq = eq
        if (session == 0) eqError = null

        sessions[session] = fx
        applyEq(fx)
        applyLimiter(fx)
        return true
    }

    private fun detach(session: Int) {
        val fx = sessions.remove(session) ?: return
        releaseFx(fx)
    }

    private fun releaseFx(fx: Fx) {
        try { fx.eq?.release() } catch (_: Exception) {}
        fx.eq = null
        try { fx.limiter?.release() } catch (_: Throwable) {}
        fx.limiter = null
    }

    // ---------------- Equalizer ----------------

    fun applyEq() {
        for (fx in sessions.values.toList()) applyEq(fx)
    }

    private fun applyEq(fx: Fx) {
        val eq = fx.eq ?: return
        try {
            // Cek kontrol runtime — jika hilang, jangan sentuh band (biarkan scanTask re-attach)
            if (!eq.hasControl) {
                Log.w(TAG, "applyEq: no control session=${fx.session}, skip")
                return
            }

            eq.enabled = AppSettings.eqEnabled
            if (!AppSettings.eqEnabled) return

            val range = eq.bandLevelRange
            val count = eq.numberOfBands.toInt()
            val buckets = Array(count) { mutableListOf<Int>() }
            for (i in 0 until 10) buckets[nearestBand(eq, centerHz[i])].add(AppSettings.bands[i])

            for (band in 0 until count) {
                val half = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                // Android pakai milliBel: 1 dB = 100 mB
                val milliBel = (half * 100).coerceIn(range[0].toInt(), range[1].toInt())
                eq.setBandLevel(band.toShort(), milliBel.toShort())
            }
        } catch (e: Throwable) {
            Log.e(TAG, "applyEq failed session=${fx.session}", e)
        }
    }

    private fun nearestBand(eq: Equalizer, hz: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until eq.numberOfBands.toInt()) {
            val center = eq.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    // ---------------- Limiter ----------------

    fun applyLimiter() {
        for (fx in sessions.values.toList()) applyLimiter(fx)
        onChange?.invoke()
    }

    private fun applyLimiter(fx: Fx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return

        if (!AppSettings.limEnabled) {
            if (fx.limiter != null) {
                try { fx.limiter?.release() } catch (_: Throwable) {}
                fx.limiter = null
            }
            if (fx.session == 0) limiterError = null
            return
        }
        try {
            val lim = fx.limiter ?: LimiterFx(fx.session, LIMITER_PRIORITIES).also { fx.limiter = it }
            lim.update(
                LimiterParams(
                    AppSettings.limAttack, AppSettings.limRelease, AppSettings.limRatio,
                    AppSettings.limThreshold, AppSettings.limPostGain
                )
            )
            if (fx.session == 0) limiterError = null
        } catch (e: Throwable) {
            fx.limiter = null
            if (fx.session == 0) limiterError = "${e.javaClass.simpleName}: ${e.message}"
            Log.e(TAG, "applyLimiter failed session=${fx.session}", e)
        }
    }

    // ---------------- status untuk UI ----------------

    fun statusText(): String {
        val fx0 = sessions[0]
        val globalAttached = fx0 != null
        val globalControl  = fx0?.eq?.hasControl == true
        val others = sessions.size - (if (globalAttached) 1 else 0)

        val parts = ArrayList<String>()
        parts.add(
            when {
                AppSettings.pipeline == 1 -> "Global: dimatikan"
                globalControl  -> "Global: aktif"
                globalAttached -> "Global: tanpa kontrol (cek Dolby/DTS di perangkat)"
                else -> "Global: gagal (${eqError ?: "tidak didukung"})"
            }
        )
        parts.add(if (AppSettings.pipeline == 0) "Per sesi: dimatikan" else "Sesi pemutar: $others")
        return parts.joinToString("  •  ")
    }

    fun limiterNote(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P)
            return "Limiter memerlukan Android 9 (API 28) atau lebih baru."
        if (!AppSettings.limEnabled) return ""

        val controlled = sessions.values.count { it.limiter?.hasControl == true }
        val attempted  = sessions.values.count { it.limiter != null }

        return when {
            controlled > 0 -> "Limiter aktif pada $controlled sesi audio."
            attempted > 0 ->
                "Limiter terpasang tetapi TIDAK memegang kontrol. " +
                    "Matikan efek audio pabrikan (Dolby/DTS/Sound Alive) di pengaturan perangkat."
            sessions.isEmpty() -> "Limiter menunggu sesi audio."
            else -> "Limiter belum aktif: perangkat tidak mendukung DynamicsProcessing" +
                (limiterError?.let { " ($it)" } ?: "") + "."
        }
    }
}
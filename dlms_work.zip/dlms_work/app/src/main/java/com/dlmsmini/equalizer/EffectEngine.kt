package com.dlmsmini.equalizer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Audio effects are attached independently: an unsupported Equalizer must not
 * prevent DynamicsProcessing (limiter) from being created for the same session.
 */
object EffectEngine {
    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    private class Fx(val session: Int) {
        var eq: Equalizer? = null
        var limiter: LimiterFx? = null
    }

    private val sessions = LinkedHashMap<Int, Fx>()
    private val scanned = HashSet<Int>()
    private val handler = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var refs = 0
    private var receiverRegistered = false
    private var eqError: String? = null
    private var limiterError: String? = null
    var onChange: (() -> Unit)? = null

    fun retain(context: Context) {
        refs++
        if (refs == 1) {
            app = context.applicationContext
            AppSettings.init(context)
            start()
        }
    }

    fun release() {
        if (refs > 0) refs--
        if (refs == 0) stop()
    }

    private fun start() {
        val ctx = app ?: return
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33)
                ctx.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            else @Suppress("DEPRECATION") ctx.registerReceiver(receiver, filter)
            receiverRegistered = true
        } catch (_: Exception) { }
        applyPipeline()
    }

    private fun stop() {
        handler.removeCallbacks(scanTask)
        if (receiverRegistered) {
            try { app?.unregisterReceiver(receiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        sessions.values.toList().forEach(::releaseFx)
        sessions.clear()
        scanned.clear()
        onChange?.invoke()
    }

    fun applyPipeline() {
        if (refs == 0) return
        when (AppSettings.pipeline) {
            0 -> {
                attach(0)
                sessions.keys.filter { it != 0 }.toList().forEach(::detach)
                scanned.clear()
                handler.removeCallbacks(scanTask)
            }
            1 -> {
                detach(0)
                handler.removeCallbacks(scanTask)
                handler.post(scanTask)
            }
            else -> {
                attach(0)
                handler.removeCallbacks(scanTask)
                handler.post(scanTask)
            }
        }
        onChange?.invoke()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (AppSettings.pipeline == 0) return
            val session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (session <= 0) return
            if (intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) == context.packageName) return
            if (intent.action == AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION) attach(session)
            else {
                scanned.remove(session)
                detach(session)
            }
            onChange?.invoke()
        }
    }

    private val scanTask = object : Runnable {
        override fun run() {
            scanActiveSessions()
            if (AppSettings.pipeline != 0 && refs > 0) handler.postDelayed(this, 2500L)
        }
    }

    private fun scanActiveSessions() {
        if (Build.VERSION.SDK_INT < 26) return
        val ctx = app ?: return
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val found = HashSet<Int>()
            for (cfg in am.activePlaybackConfigurations) {
                val id = sessionIdOf(cfg)
                if (id > 0) found.add(id)
            }
            var changed = false
            for (id in found) {
                if (!sessions.containsKey(id)) {
                    attach(id)
                    if (sessions.containsKey(id)) { scanned.add(id); changed = true }
                }
            }
            for (id in scanned.toList()) {
                if (id !in found) { scanned.remove(id); detach(id); changed = true }
            }
            if (changed) onChange?.invoke()
        } catch (_: Throwable) { }
    }

    private fun sessionIdOf(config: Any): Int {
        for (name in arrayOf("getAudioSessionId", "getSessionId")) {
            try {
                val value = config.javaClass.getMethod(name).invoke(config)
                if (value is Int) return value
            } catch (_: Throwable) { }
        }
        return -1
    }

    /** Keep a session even when only one of its two effects is supported. */
    private fun attach(session: Int): Boolean {
        val fx = sessions[session] ?: Fx(session).also { sessions[session] = it }
        if (fx.eq == null) {
            try {
                fx.eq = Equalizer(0, session)
                if (session == 0) eqError = null
            } catch (e: Throwable) {
                if (session == 0) eqError = e.javaClass.simpleName
            }
        }
        applyEq(fx)
        applyLimiter(fx)
        return fx.eq != null || fx.limiter != null
    }

    private fun detach(session: Int) {
        val fx = sessions.remove(session) ?: return
        releaseFx(fx)
    }

    private fun releaseFx(fx: Fx) {
        try { fx.eq?.release() } catch (_: Throwable) { }
        fx.eq = null
        try { fx.limiter?.release() } catch (_: Throwable) { }
        fx.limiter = null
    }

    fun applyEq() {
        sessions.values.toList().forEach(::applyEq)
        onChange?.invoke()
    }

    private fun applyEq(fx: Fx) {
        val eq = fx.eq ?: return
        try {
            val count = eq.numberOfBands.toInt()
            if (count <= 0) return
            val range = eq.bandLevelRange
            // Map the ten UI bands onto the actual hardware bands by nearest centre frequency.
            val mapped = Array(count) { mutableListOf<Int>() }
            for (i in centerHz.indices) mapped[nearestBand(eq, centerHz[i], count)].add(AppSettings.bands[i])
            for (band in 0 until count) {
                val halfDb = mapped[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
                val levelMb = (halfDb * 50).coerceIn(range[0].toInt(), range[1].toInt())
                eq.setBandLevel(band.toShort(), levelMb.toShort())
            }
            // Enable only after writing values; some vendor implementations reset on enable.
            eq.setEnabled(AppSettings.eqEnabled)
            if (fx.session == 0) eqError = null
        } catch (e: Throwable) {
            if (fx.session == 0) eqError = e.javaClass.simpleName
        }
    }

    private fun nearestBand(eq: Equalizer, hz: Int, count: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until count) {
            val center = eq.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    fun applyLimiter() {
        sessions.values.toList().forEach(::applyLimiter)
        onChange?.invoke()
    }

    private fun applyLimiter(fx: Fx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        if (!AppSettings.limEnabled) {
            try { fx.limiter?.release() } catch (_: Throwable) { }
            fx.limiter = null
            if (fx.session == 0) limiterError = null
            return
        }
        try {
            val effect = fx.limiter ?: LimiterFx(fx.session).also { fx.limiter = it }
            effect.update(
                LimiterParams(
                    AppSettings.limAttack.coerceIn(0.1f, 200f),
                    AppSettings.limRelease.coerceIn(1f, 2000f),
                    AppSettings.limRatio.coerceIn(1f, 20f),
                    AppSettings.limThreshold.coerceIn(-60f, 0f),
                    AppSettings.limPostGain.coerceIn(-12f, 12f)
                )
            )
            if (fx.session == 0) limiterError = null
        } catch (e: Throwable) {
            try { fx.limiter?.release() } catch (_: Throwable) { }
            fx.limiter = null
            if (fx.session == 0) limiterError = e.javaClass.simpleName
        }
    }

    fun statusText(): String {
        val globalFx = sessions[0]
        val eqOk = globalFx?.eq != null
        val perSession = sessions.values.count { it.session != 0 && it.eq != null }
        val pipeline = AppSettings.pipeline
        val global = when {
            pipeline == 1 -> "Global: mati"
            eqOk -> "Global EQ: aktif"
            else -> "Global EQ: gagal (${eqError ?: "tidak didukung"})"
        }
        val sessionText = if (pipeline == 0) "EQ sesi: mati" else "EQ sesi: $perSession"
        val limCount = sessions.values.count { it.limiter != null }
        val limText = if (AppSettings.limEnabled) "Limiter: $limCount sesi" else "Limiter: mati"
        return "$global  •  $sessionText  •  $limText"
    }

    fun limiterNote(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P)
            return "Limiter memerlukan Android 9 (API 28) atau lebih baru."
        if (!AppSettings.limEnabled) return "Limiter nonaktif."
        val active = sessions.values.count { it.limiter != null }
        return when {
            active > 0 -> "Limiter aktif pada $active sesi audio."
            sessions.isEmpty() -> "Limiter menunggu sesi audio. Putar audio lalu coba mode Per sesi atau Maksimum."
            else -> "Limiter tidak didukung pada sesi audio ini" +
                (limiterError?.let { " ($it)" } ?: "") + "."
        }
    }
}

package com.dlmsmini.equalizer

import android.media.audiofx.DynamicsProcessing
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi

class LimiterParams(
    val attackMs: Float,
    val releaseMs: Float,
    val ratio: Float,
    val thresholdDb: Float,
    val postGainDb: Float
)

@RequiresApi(Build.VERSION_CODES.P)
class LimiterFx(
    session: Int,
    priorities: IntArray = intArrayOf(2001, 1501, 1001, 1)
) {
    private val dp: DynamicsProcessing

    /** true jika limiter benar-benar memegang kontrol audio pada sesi ini. */
    var hasControl: Boolean = false
        private set

    init {
        var created: DynamicsProcessing? = null
        var lastError: Throwable? = null

        for (p in priorities) {
            var candidate: DynamicsProcessing? = null
            try {
                val cfg = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION,
                    2,
                    false, 0,
                    false, 0,
                    false, 0,
                    true   // limiterInUse
                ).build()

                candidate = DynamicsProcessing(p, session, cfg)
                if (candidate.hasControl()) {
                    created = candidate
                    hasControl = true
                    Log.d("LimiterFx", "DP OK session=$session priority=$p")
                    break
                }
                Log.w("LimiterFx", "DP session=$session priority=$p tanpa kontrol, retry")
                try { candidate.release() } catch (_: Exception) {}
            } catch (e: Throwable) {
                lastError = e
                Log.w("LimiterFx", "DP failed session=$session priority=$p: ${e.message}")
                try { candidate?.release() } catch (_: Exception) {}
            }
        }

        if (created == null) {
            throw lastError ?: IllegalStateException(
                "DynamicsProcessing tidak dapat mengontrol session=$session"
            )
        }
        dp = created
    }

    fun update(p: LimiterParams) {
        if (!hasControl) throw IllegalStateException("Limiter tidak memegang kontrol audio")

        // Validasi parameter agar native tidak error
        val attack    = p.attackMs.coerceIn(1f, 100f)
        val release   = p.releaseMs.coerceIn(10f, 1000f)
        val ratio     = p.ratio.coerceIn(1f, 20f)
        val threshold = p.thresholdDb.coerceIn(-60f, 0f)
        val postGain  = p.postGainDb.coerceIn(-20f, 20f)

        val limiter = DynamicsProcessing.Limiter(
            true, true, 0, attack, release, ratio, threshold, postGain
        )

        val ret = dp.setLimiterAllChannelsTo(limiter)
        if (ret != 0) throw IllegalStateException("setLimiterAllChannelsTo failed: $ret")

        dp.enabled = true
        if (!dp.enabled) throw IllegalStateException("DynamicsProcessing.enabled gagal di-set true")

        Log.d("LimiterFx",
            "Limiter updated: atk=$attack rel=$release ratio=$ratio thr=$threshold post=$postGain")
    }

    fun release() {
        try { dp.release() } catch (_: Exception) {}
    }
}
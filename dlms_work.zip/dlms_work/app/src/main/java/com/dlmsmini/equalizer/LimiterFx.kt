package com.dlmsmini.equalizer

import android.media.audiofx.DynamicsProcessing
import android.os.Build
import androidx.annotation.RequiresApi

data class LimiterParams(
    val attackMs: Float,
    val releaseMs: Float,
    val ratio: Float,
    val thresholdDb: Float,
    val postGainDb: Float
)

/**
 * Hardware DynamicsProcessing limiter. This is a session effect, not a
 * system-wide audio processor; Android/device policy may reject some sessions.
 */
@RequiresApi(Build.VERSION_CODES.P)
class LimiterFx(session: Int) {
    private val effect: DynamicsProcessing

    init {
        val config = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION,
            2,                  // stereo channels
            false, 0,           // pre-EQ disabled
            false, 0,           // multiband compressor disabled
            false, 0,           // post-EQ disabled
            true                // limiter enabled
        ).build()
        effect = DynamicsProcessing(0, session, config)
        effect.setEnabled(true)
    }

    fun update(params: LimiterParams) {
        val limiter = DynamicsProcessing.Limiter(
            true,
            true,
            0,
            params.attackMs.coerceIn(0.1f, 200f),
            params.releaseMs.coerceIn(1f, 2000f),
            params.ratio.coerceIn(1f, 20f),
            params.thresholdDb.coerceIn(-60f, 0f),
            params.postGainDb.coerceIn(-12f, 12f)
        )
        effect.setLimiterAllChannelsTo(limiter)
        effect.setEnabled(true)
    }

    fun release() {
        try { effect.setEnabled(false) } catch (_: Throwable) { }
        try { effect.release() } catch (_: Throwable) { }
    }
}

package com.dlmsmini.equalizer

import android.media.audiofx.DynamicsProcessing
import android.os.Build
import androidx.annotation.RequiresApi

class LimiterParams(
    val attackMs: Float,
    val releaseMs: Float,
    val ratio: Float,
    val thresholdDb: Float,
    val postGainDb: Float
)

/** Limiter Android pada output mix global (session 0); tersedia mulai API 28. */
@RequiresApi(Build.VERSION_CODES.P)
class LimiterFx(session: Int) {
    private val dp: DynamicsProcessing

    init {
        val config = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION,
            2,              // stereo
            false, 0,       // pre-EQ off
            false, 0,       // MBC off
            false, 0,       // post-EQ off
            true            // limiter on
        ).build()
        dp = DynamicsProcessing(0, session, config)
    }

    fun update(p: LimiterParams) {
        val limiter = DynamicsProcessing.Limiter(
            true,
            true,
            0,
            p.attackMs,
            p.releaseMs,
            p.ratio,
            p.thresholdDb,
            p.postGainDb
        )
        dp.setLimiterAllChannelsTo(limiter)
        dp.enabled = true
    }

    fun release() {
        try { dp.release() } catch (_: Throwable) {}
    }
}

package com.dlmsmini.equalizer

import android.media.audiofx.DynamicsProcessing
import android.os.Build
import androidx.annotation.RequiresApi

class LimiterParams(
    val attackMs: Float,
    val releaseMs: Float,
    val ratio: Float,
    val thresholdDb: Float,
    val postGainDb: Float
)

@RequiresApi(Build.VERSION_CODES.P)
class LimiterFx(session: Int) {
    private val dp: DynamicsProcessing

    init {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION, 2,
            false, 0, false, 0, false, 0, true
        ).build()
        
        // PERBAIKAN: Prioritas diubah menjadi 1000. Prioritas 0 membuat sistem mengabaikan efek limiter.
        dp = DynamicsProcessing(1000, session, cfg)
    }

    fun update(p: LimiterParams) {
        val limiter = DynamicsProcessing.Limiter(
            true, true, 0, p.attackMs, p.releaseMs, p.ratio, p.thresholdDb, p.postGainDb
        )
        dp.setLimiterAllChannelsTo(limiter)
        dp.enabled = true
    }

    fun release() {
        try { dp.release() } catch (_: Exception) {}
    }
}

package com.dlmsmini.equalizer

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.os.Build
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class FxState { ACTIVE, FAILED, NO_CONTROL }

/** Hasil verifikasi satu efek yang diminta: benar-benar dibuat, dikuasai aplikasi ini, dan menyala. */
class EffectStatus(val name: String, val state: FxState, val detail: String = "")

/** Hasil pemeriksaan kesehatan satu mesin efek. */
enum class Health { OK, REAPPLIED, REBUILT, CONTESTED }

/**
 * Satu "mesin" efek untuk satu sesi audio (0 = Mix Global, >0 = sesi aplikasi).
 *
 * Pipeline EQ:
 *  - STANDAR : Equalizer sistem Android (band hardware dipetakan ke band UI: 5/10/13/15/21/31).
 *  - MAKSIMUM: DynamicsProcessing (Android 9+) dengan PreEq sebanyak band UI.
 *
 * EQ kiri/kanan terpisah: PreEq DynamicsProcessing bersifat per kanal, sehingga kurva kiri ([half]) dan kanan
 * ([halfR]) dapat berbeda. Equalizer sistem hanya satu kurva, jadi mode ini otomatis memakai DynamicsProcessing;
 * bila perangkat menolaknya, kedua kurva dirata-ratakan dan "EQ L/R" dicatat di [issues].
 *
 * DynamicsProcessing (DP) juga membawa: limiter, gain masukan per kanal (pre-amp, balance, mute, volume L/R, headroom),
 * kompresor multiband (3 band) dan satu stage Post-EQ RAPAT (64 pita ≈ 1/6 oktaf) yang menggabungkan:
 *   tone 3 band + Parametric EQ + crossover 2-Way (low-pass/high-pass dengan slope 12/24/36/48 dB/okt, gain LOW/HIGH).
 * Stage Post-EQ DP hanya mengatur MAGNITUDO (tanpa fase), sehingga fase/polaritas tidak dapat diatur lewat DP.
 * Efek sistem terpisah: BassBoost, Virtualizer, LoudnessEnhancer, PresetReverb.
 *
 * Penjaga kendali:
 *  - Semua efek dibuat dengan prioritas tinggi dan dipantau lewat listener kendali/enable.
 *  - [verifyAndRepair] memeriksa kendali, status enable, dan membaca balik parameter; bila perlu menerapkan ulang
 *    atau membangun ulang efek (dibatasi agar tidak berebut tanpa henti dengan aplikasi lain).
 */
class AudioEngine(private val session: Int = 0) {
    companion object {
        const val SPLIT_NONE = 0
        const val SPLIT_MBC = 1     // cadangan: crossover lewat band MBC (slope tidak dapat diatur)
        const val SPLIT_EQ = 2      // cadangan: pendekatan lewat EQ (perangkat tanpa MBC)
        const val SPLIT_FAIL = 3
        const val SPLIT_FILTER = 4  // crossover LPF/HPF dengan slope sesuai pilihan lewat Post-EQ rapat

        /** Prioritas tinggi agar kendali tidak diambil aplikasi lain yang memakai prioritas normal (0). */
        private const val PRIORITY = 100
        private val GRID_SIZES = intArrayOf(64, 40, 24)
        private val SAFETY = LimiterSettings(true, 1f, 80f, 20f, -1f, 0f)
        private const val RECLAIM_WINDOW_MS = 30_000L
        private const val RECLAIM_MAX = 3
    }

    /** Dipanggil (thread utama) saat sistem memberi tahu kendali/enable efek berubah. */
    var onHealthEvent: ((String) -> Unit)? = null

    private val controlListener = AudioEffect.OnControlStatusChangeListener { _, granted ->
        if (!granted) {
            DiagLog.log("Kendali efek sesi $session diambil pihak lain")
            onHealthEvent?.invoke("kendali hilang")
        }
    }

    private val enableListener = AudioEffect.OnEnableStatusChangeListener { _, enabled ->
        if (!enabled && SystemClock.uptimeMillis() - lastSelfWrite > 600L) {
            DiagLog.log("Efek sesi $session dimatikan pihak lain")
            onHealthEvent?.invoke("efek dimatikan")
        }
    }

    @Volatile private var lastSelfWrite = 0L
    private fun touch() { lastSelfWrite = SystemClock.uptimeMillis() }

    private var eq: Equalizer? = null
    private var dp: DynamicsProcessing? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null
    private var reverb: PresetReverb? = null

    private var builtPipeline = -1
    private var builtBands = -1
    private var lastPipeline = Store.PIPE_STANDARD
    private var layout: BandLayout = Bands.forCount(Bands.DEFAULT)
    private var dpCarriesEq = false
    private var dpFull = false
    private var grid: FilterGrid? = null
    private var gridFloorDb = -60f
    private var maxFellBack = false
    private var limiterOn = false
    private var twoWay = false
    private var crossoverHz = Store.DEFAULT_CROSSOVER
    private var xo = CrossoverSettings()
    private var peq = PeqSettings()
    private var postPeakDb = 0f
    private var swapChannels = false
    private var splitMode = SPLIT_NONE
    private var fx = EffectSettings()
    private var master = MasterSettings()
    private var userLimiter = LimiterSettings()
    private var half = IntArray(0)
    private var halfR = IntArray(0)
    private var chSplit = false
    private var eqOnNow = false
    private val issueSet = linkedSetOf<String>()

    // Cache nilai yang sudah dikirim ke efek (hanya kirim yang berubah).
    private var appliedPre = FloatArray(0)
    private var appliedPreR = FloatArray(0)
    private var appliedPostL = FloatArray(0)
    private var appliedPostR = FloatArray(0)
    private var appliedHw: ShortArray? = null
    private var appliedLim: LimiterSettings? = null
    private var appliedLimUnlinked = false
    private var lastEqPeak = Float.NaN

    // Peta band UI -> band hardware (dihitung sekali per efek agar tidak memanggil binder berulang kali).
    private var hwMap: IntArray? = null
    private var hwCount = 0
    private var hwMin = 0
    private var hwMax = 0

    // Penjaga kendali
    private val reclaimTimes = mutableListOf<Long>()
    @Volatile var contested: Boolean = false
        private set
    private var eqReadbackOk: Boolean? = null
    private var limReadbackOk: Boolean? = null
    private var limReadbackNote = ""
    private var reordering = false

    val limiterAvailable: Boolean get() = dp != null
    val isActive: Boolean get() = dp != null || eq != null
    val split: Int get() = splitMode

    /** True bila Post-EQ rapat tersedia (Parametric EQ dan crossover dengan slope dapat diterapkan). */
    val gridSupported: Boolean get() = dp != null && grid != null

    /** True bila proteksi clipping sedang memakai limiter pengaman (limiter pengguna mati). */
    val safetyLimiterActive: Boolean get() = !userLimiter.enabled && effectiveLimiter() === SAFETY

    /** Nama efek yang gagal dibuat/diterapkan oleh perangkat. */
    val issues: Set<String> get() = issueSet

    /** Limiter yang benar-benar dipakai (milik pengguna atau pengaman), atau null bila tidak aktif. */
    fun effectiveLimiterSnapshot(): LimiterSettings? {
        if (dp == null) return null
        val l = effectiveLimiter()
        return if (l.enabled) l else null
    }

    fun limiterReadbackNote(): String = limReadbackNote

    /** [swap] = true: kiri membawa HIGH, kanan membawa LOW (kebalikan bawaan). */
    fun setSplit(on: Boolean, x: CrossoverSettings, swap: Boolean = false) {
        twoWay = on
        swapChannels = swap
        xo = x
        crossoverHz = x.freqHz.coerceIn(Store.MIN_CROSSOVER, Store.MAX_CROSSOVER)
    }

    fun setPeq(p: PeqSettings) { peq = p }

    /** Atur kurva kanal kanan. [on] = false: kedua kanal memakai kurva utama (stereo). Harus sebanyak band aktif. */
    fun setChannelEq(on: Boolean, right: IntArray) {
        chSplit = on
        halfR = right
    }

    /** True bila kurva kiri dan kanan benar-benar berbeda diterapkan per kanal (butuh PreEq DynamicsProcessing). */
    val channelEqActive: Boolean get() = splitActive()

    private fun splitActive(): Boolean =
        chSplit && dpCarriesEq && splitMode != SPLIT_EQ && halfR.size == builtBands && builtBands > 0

    /** Kurva untuk Equalizer sistem (satu kurva): rata-rata kiri dan kanan bila mode L/R terpisah aktif. */
    private fun mergedHalf(): IntArray =
        if (chSplit && halfR.size == half.size) IntArray(half.size) { ((half[it] + halfR[it]) / 2.0).roundToInt() } else half

    fun setFx(f: EffectSettings) { fx = f }

    fun setMaster(m: MasterSettings) { master = m }

    /** Terapkan efek tambahan secara langsung (dipanggil saat slider efek digeser). */
    fun updateFx(f: EffectSettings, eqOn: Boolean) {
        fx = f
        eqOnNow = eqOn
        applyFx()
        applyLimiter()
        syncEnabled()
    }

    /** Volume L/R atau mode proteksi berubah. */
    fun updateMaster(m: MasterSettings) {
        master = m
        applyGains()
        applyLimiter()
        syncEnabled()
    }

    /** Parametric EQ berubah (slider/grafik). */
    fun updatePeq(p: PeqSettings) {
        peq = p
        val d = dp
        if (d != null) {
            if (dpFull) applyPostEq(d) else flagLegacyFx()
        }
        applyLimiter()
        syncEnabled()
    }

    /** Pengaturan crossover berubah (frekuensi, slope, LPF/HPF, gain, tukar kanal). */
    fun updateCrossover(x: CrossoverSettings, swap: Boolean) {
        xo = x
        swapChannels = swap
        crossoverHz = x.freqHz.coerceIn(Store.MIN_CROSSOVER, Store.MAX_CROSSOVER)
        if (!twoWay || dp == null) return
        when (splitMode) {
            SPLIT_FILTER, SPLIT_MBC -> {
                applyDspFx()
                applyLimiter()
                syncEnabled()
            }
            SPLIT_EQ -> updateEq(eqOnNow, half)
            else -> {}
        }
    }

    /** Buat ulang efek bila pipeline atau jumlah band berubah, lalu terapkan semua parameter. */
    fun configure(pipeline: Int, eqOn: Boolean, halfDb: IntArray, lim: LimiterSettings): String {
        lastPipeline = pipeline
        // 2-Way membutuhkan proses per kanal, yang hanya tersedia lewat DynamicsProcessing.
        val effective = if (twoWay || chSplit) Store.PIPE_MAX else pipeline
        if (builtPipeline != effective || builtBands != halfDb.size) {
            release()
            build(effective, halfDb.size)
        }
        half = halfDb
        eqOnNow = eqOn
        userLimiter = lim
        splitMode = when {
            !twoWay -> SPLIT_NONE
            dp != null && grid != null -> SPLIT_FILTER
            dp != null && dpFull -> SPLIT_MBC
            dp != null && dpCarriesEq -> SPLIT_EQ
            else -> SPLIT_FAIL
        }
        invalidateCaches()
        updateEq(eqOn, halfDb)
        applyFx()
        applyLimiter()
        syncEnabled()
        return describe()
    }

    /** Lepas semua efek lalu pasang ulang dengan parameter terakhir. */
    fun rebuild(): String {
        if (half.isEmpty()) return describe()
        val pipe = lastPipeline
        val h = half
        val on = eqOnNow
        val lim = userLimiter
        release()
        return configure(pipe, on, h, lim)
    }

    fun resetContest() {
        reclaimTimes.clear()
        contested = false
    }

    fun release() {
        try { dp?.release() } catch (_: Throwable) {}
        try { eq?.release() } catch (_: Throwable) {}
        try { bass?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { loud?.release() } catch (_: Throwable) {}
        try { reverb?.release() } catch (_: Throwable) {}
        dp = null
        eq = null
        bass = null
        virt = null
        loud = null
        reverb = null
        dpCarriesEq = false
        dpFull = false
        grid = null
        postPeakDb = 0f
        builtPipeline = -1
        builtBands = -1
        hwMap = null
        eqReadbackOk = null
        limReadbackOk = null
        limReadbackNote = ""
        contested = false
        invalidateCaches()
        issueSet.clear()
    }

    private fun invalidateCaches() {
        appliedPre = FloatArray(0)
        appliedPreR = FloatArray(0)
        appliedPostL = FloatArray(0)
        appliedPostR = FloatArray(0)
        appliedHw = null
        appliedLim = null
        lastEqPeak = Float.NaN
    }

    private fun <T : AudioEffect> watch(e: T): T {
        try {
            e.setControlStatusListener(controlListener)
            e.setEnableStatusListener(enableListener)
        } catch (_: Throwable) {
        }
        return e
    }

    private fun makeEq(): Equalizer? = try {
        watch(Equalizer(PRIORITY, session))
    } catch (t: Throwable) {
        DiagLog.log("Equalizer sesi $session gagal dibuat: ${t.javaClass.simpleName}")
        null
    }

    /**
     * Urutan pembuatan menentukan urutan rantai efek: Equalizer sistem dibuat lebih dulu dan DynamicsProcessing
     * (limiter) dibuat terakhir, sehingga limiter berada di ujung rantai dan memotong hasil akhir.
     */
    private fun build(pipeline: Int, bands: Int) {
        builtPipeline = pipeline
        builtBands = bands
        layout = Bands.forCount(bands)
        maxFellBack = false
        gridFloorDb = -60f
        val canDp = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
        if (pipeline != Store.PIPE_MAX || !canDp) eq = makeEq()
        if (canDp) {
            if (pipeline == Store.PIPE_MAX) {
                dp = createDp(true, bands)
                dpCarriesEq = dp != null
                if (dp == null) {
                    maxFellBack = true
                    dp = createDp(false, bands)
                }
            } else {
                dp = createDp(false, bands)
            }
        } else if (pipeline == Store.PIPE_MAX) {
            maxFellBack = true
        }
        if (!dpCarriesEq && eq == null) eq = makeEq()
        dp?.let { watch(it) }
    }

    /** Coba konfigurasi terlengkap dulu (Post-EQ rapat), lalu mundur bertahap. Mengisi [dpFull] dan [grid]. */
    private fun createDp(withEq: Boolean, bands: Int): DynamicsProcessing? {
        val eqBands = if (withEq) bands else 0
        for (g in GRID_SIZES) {
            val d = tryCreateDp(withEq, eqBands, true, g)
            if (d != null) {
                dpFull = true
                grid = FilterGrid(g)
                return d
            }
        }
        val legacy = tryCreateDp(withEq, eqBands, true, 3)
        if (legacy != null) {
            dpFull = true
            grid = null
            return legacy
        }
        val basic = tryCreateDp(withEq, eqBands, false, 0)
        dpFull = false
        grid = null
        return basic
    }

    private fun tryCreateDp(withEq: Boolean, eqBands: Int, full: Boolean, postBands: Int): DynamicsProcessing? = try {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2,
            withEq, eqBands,
            full, if (full) 3 else 0,
            full, postBands,
            true
        ).build()
        DynamicsProcessing(PRIORITY, session, cfg)
    } catch (t: Throwable) {
        DiagLog.log("DynamicsProcessing sesi $session (penuh=$full, post=$postBands) ditolak: ${t.javaClass.simpleName} ${t.message ?: ""}")
        null
    }

    // ---------- EQ ----------

    fun updateEq(eqOn: Boolean, halfDb: IntArray) {
        if (halfDb.size != builtBands) return
        half = halfDb
        eqOnNow = eqOn
        if (dpCarriesEq) {
            val d = dp
            if (d != null) {
                if (splitMode == SPLIT_EQ) {
                    appliedPre = FloatArray(0)
                    if (!(trySplit(d, eqOn, halfDb, -60f) || trySplit(d, eqOn, halfDb, -30f))) splitMode = SPLIT_FAIL
                } else {
                    applyPreEq(d, eqOn, halfDb)
                }
            }
        } else {
            val e = eq
            if (e != null) {
                try {
                    touch()
                    e.enabled = eqOn
                    if (eqOn) applyHardwareBands(e, if (chSplit && halfR.size == halfDb.size) mergedHalf() else halfDb)
                    issueSet.remove("EQ")
                } catch (t: Throwable) {
                    DiagLog.log("EQ sistem gagal diterapkan: ${t.javaClass.simpleName}")
                    issueSet.add("EQ")
                }
            }
        }
        if (chSplit && eqOn && !splitActive() && splitMode != SPLIT_EQ) issueSet.add("EQ L/R") else issueSet.remove("EQ L/R")
        // Headroom otomatis dan limiter pengaman bergantung pada puncak boost EQ; hanya dihitung ulang bila puncaknya berubah.
        val peak = eqPeakDb()
        if (peak != lastEqPeak) {
            lastEqPeak = peak
            applyGains()
            applyLimiter()
        }
        syncEnabled()
    }

    /** Hanya band yang berubah yang dikirim ke DynamicsProcessing. Mode L/R terpisah: tiap kanal mendapat gain sendiri. */
    private fun applyPreEq(d: DynamicsProcessing, eqOn: Boolean, halfDb: IntArray) {
        if (appliedPre.size != builtBands) appliedPre = FloatArray(builtBands) { Float.NaN }
        if (appliedPreR.size != builtBands) appliedPreR = FloatArray(builtBands) { Float.NaN }
        val split = splitActive()
        var failed = false
        for (i in 0 until builtBands) {
            val gl = if (eqOn) halfDb[i] / 2f else 0f
            val gr = if (!eqOn) 0f else if (split) halfR[i] / 2f else gl
            if (appliedPre[i] == gl && appliedPreR[i] == gr) continue
            try {
                if (gl == gr) {
                    d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], gl))
                } else {
                    d.setPreEqBandByChannelIndex(0, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], gl))
                    d.setPreEqBandByChannelIndex(1, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], gr))
                }
                appliedPre[i] = gl
                appliedPreR[i] = gr
            } catch (t: Throwable) {
                failed = true
                DiagLog.log("EQ DSP band $i gagal: ${t.javaClass.simpleName}")
            }
        }
        if (failed) issueSet.add("EQ") else issueSet.remove("EQ")
    }

    /** Pendekatan 2-Way via EQ (hanya bila MBC tidak tersedia). Kiri: band LOW sesuai kurva; kanan: band HIGH. */
    private fun trySplit(d: DynamicsProcessing, eqOn: Boolean, halfDb: IntArray, cutDb: Float): Boolean = try {
        for (i in 0 until builtBands) {
            val g = if (eqOn) halfDb[i] / 2f else 0f
            val isLow = layout.centerHz[i] < crossoverHz
            val lowOnLeft = !swapChannels
            val left = if (!eqOn) 0f else if (isLow == lowOnLeft) g else cutDb
            val right = if (!eqOn) 0f else if (isLow == lowOnLeft) cutDb else g
            d.setPreEqBandByChannelIndex(0, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], left))
            d.setPreEqBandByChannelIndex(1, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], right))
        }
        true
    } catch (_: Throwable) {
        false
    }

    // ---------- Proteksi clipping ----------

    private fun eqPeakDb(): Float {
        if (!eqOnNow || half.isEmpty()) return 0f
        var m = 0
        for (v in half) if (v > m) m = v
        if (splitActive()) for (v in halfR) if (v > m) m = v
        return m / 2f
    }

    /** Perkiraan konservatif total boost (dB) dari semua tahap penguat. */
    private fun totalBoostDb(): Float {
        var t = eqPeakDb() + max(0f, fx.preampDb)
        if (fx.loudOn) t += fx.loudDb
        if (fx.bassOn) t += fx.bassPct / 100f * 6f
        if (grid != null) {
            // Post-EQ rapat sudah mencakup tone + Parametric EQ + gain crossover.
            t += max(0f, postPeakDb)
        } else if (fx.toneOn) {
            t += max(0f, max(fx.toneLowDb, max(fx.toneMidDb, fx.toneHighDb)))
        }
        if (fx.mbcOn) t += fx.mbcMakeupDb
        return t
    }

    /** Mode 2: turunkan gain masukan 50% dari puncak boost EQ (maks 6 dB) agar ada ruang sebelum clipping. */
    private fun headroomDb(): Float =
        if (master.clipMode >= Store.CLIP_HEADROOM) -min(6f, eqPeakDb() * 0.5f) else 0f

    private fun effectiveLimiter(): LimiterSettings =
        if (userLimiter.enabled) userLimiter
        else if (master.clipMode >= Store.CLIP_LIMITER && totalBoostDb() > 0.5f) SAFETY
        else userLimiter

    private fun needsDsp(): Boolean =
        fx.needsDsp || master.volumeActive || headroomDb() != 0f ||
            splitMode == SPLIT_MBC || splitMode == SPLIT_FILTER || peq.active

    private fun wantsDp(): Boolean = limiterOn || (dpCarriesEq && eqOnNow) || needsDsp()

    fun updateLimiter(lim: LimiterSettings, eqOn: Boolean) {
        userLimiter = lim
        eqOnNow = eqOn
        applyLimiter()
        syncEnabled()
    }

    /**
     * Limiter dipasang pada DynamicsProcessing, jadi aktif di pipeline Standar MAUPUN Maksimum. Pada 2-Way setiap kanal
     * membawa isi berbeda (LOW/HIGH) sehingga detektornya dipisah (link group berbeda); selain itu kedua kanal terhubung.
     */
    private fun applyLimiter() {
        val lim = effectiveLimiter()
        limiterOn = lim.enabled
        val d = dp ?: return
        val unlinked = splitMode == SPLIT_FILTER || splitMode == SPLIT_MBC
        if (appliedLim == lim && appliedLimUnlinked == unlinked) return
        try {
            for (ch in 0 until 2) {
                d.setLimiterByChannelIndex(
                    ch,
                    DynamicsProcessing.Limiter(
                        true, lim.enabled, if (unlinked) ch else 0,
                        lim.attackMs, lim.releaseMs, lim.ratio, lim.thresholdDb, lim.postGainDb
                    )
                )
            }
            appliedLim = lim
            appliedLimUnlinked = unlinked
            issueSet.remove("Limiter")
        } catch (t: Throwable) {
            DiagLog.log("Limiter gagal diterapkan: ${t.javaClass.simpleName} ${t.message ?: ""}")
            issueSet.add("Limiter")
        }
    }

    private fun syncEnabled() {
        val d = dp ?: return
        try {
            touch()
            d.enabled = wantsDp()
        } catch (_: Throwable) {
        }
    }

    // ---------- Gain masukan: pre-amp, balance, mute, volume L/R, headroom ----------

    private fun applyGains() {
        val d = dp
        if (d == null) {
            if (master.volumeActive) issueSet.add("Volume L/R") else issueSet.remove("Volume L/R")
            return
        }
        val base = fx.channelGainsDb()
        val h = headroomDb()
        val left = max(-80f, base.first + master.volumeDb(master.volL) + h)
        val right = max(-80f, base.second + master.volumeDb(master.volR) + h)
        try {
            d.setInputGainbyChannel(0, left)
            d.setInputGainbyChannel(1, right)
            issueSet.remove("Pre-amp/Balance")
            issueSet.remove("Volume L/R")
        } catch (_: Throwable) {
            issueSet.add("Pre-amp/Balance")
            if (master.volumeActive) issueSet.add("Volume L/R")
        }
    }

    // ---------- Efek tambahan ----------

    private fun applyFx() {
        applyGains()
        applyDspFx()
        applySystemFx()
    }

    private fun flagLegacyFx() {
        if (fx.mbcOn) issueSet.add("Kompresor") else issueSet.remove("Kompresor")
        if (fx.toneOn) issueSet.add("Post-EQ") else issueSet.remove("Post-EQ")
        if (peq.active) issueSet.add("Parametric EQ") else issueSet.remove("Parametric EQ")
    }

    private fun applyDspFx() {
        val d = dp ?: return
        if (!dpFull) {
            flagLegacyFx()
            return
        }
        applyMbc(d)
        applyPostEq(d)
    }

    /** Kompresor multiband 3 band. Hanya pada mode cadangan SPLIT_MBC band MBC dipakai ganda untuk crossover. */
    private fun applyMbc(d: DynamicsProcessing) {
        val xoMbc = splitMode == SPLIT_MBC
        try {
            val cutoffs = if (xoMbc) floatArrayOf(crossoverHz.toFloat(), 21000f, 22000f) else floatArrayOf(250f, 3000f, 22000f)
            for (ch in 0 until 2) {
                for (i in 0 until 3) {
                    // Bawaan: kiri = LOW (band 0), kanan = HIGH (band 1-2). Tukar: kebalikannya.
                    val keepsLow = (ch == 0) != swapChannels
                    val muted = xoMbc && (if (keepsLow) i != 0 else i == 0)
                    val post = (if (fx.mbcOn) fx.mbcMakeupDb else 0f) + (if (muted) -80f else 0f)
                    val band = DynamicsProcessing.MbcBand(
                        fx.mbcOn || xoMbc, cutoffs[i],
                        fx.mbcAttackMs, fx.mbcReleaseMs,
                        if (fx.mbcOn) fx.mbcRatio else 1f,
                        fx.mbcThresholdDb,
                        3f, -90f, 1f,
                        0f, post
                    )
                    d.setMbcBandByChannelIndex(ch, i, band)
                }
            }
            issueSet.remove("Kompresor")
            if (xoMbc) issueSet.remove("Crossover 2-Way")
        } catch (_: Throwable) {
            if (fx.mbcOn) issueSet.add("Kompresor")
            if (xoMbc) {
                issueSet.add("Crossover 2-Way")
                splitMode = SPLIT_FAIL
            }
        }
    }

    /**
     * Post-EQ: tone + Parametric EQ + crossover. Dengan grid rapat semuanya digabung menjadi gain per pita per kanal;
     * tanpa grid (perangkat menolak) tersisa tone 3 band lama dan Parametric EQ dinyatakan tidak didukung.
     */
    private fun applyPostEq(d: DynamicsProcessing) {
        val g = grid
        if (g == null) {
            try {
                val cutoffs = floatArrayOf(250f, 4000f, 22000f)
                val toneGains = floatArrayOf(fx.toneLowDb, fx.toneMidDb, fx.toneHighDb)
                for (i in 0 until 3) {
                    val gain = if (fx.toneOn) toneGains[i] else 0f
                    d.setPostEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cutoffs[i], gain))
                }
                issueSet.remove("Post-EQ")
            } catch (_: Throwable) {
                if (fx.toneOn) issueSet.add("Post-EQ")
            }
            if (peq.active) issueSet.add("Parametric EQ") else issueSet.remove("Parametric EQ")
            return
        }
        val xoActive = twoWay && splitMode == SPLIT_FILTER
        val t = FilterSynth.build(g, fx, peq, if (xoActive) xo else null, swapChannels, gridFloorDb)
        postPeakDb = t.peakBoostDb
        if (appliedPostL.size != g.count) appliedPostL = FloatArray(g.count) { Float.NaN }
        if (appliedPostR.size != g.count) appliedPostR = FloatArray(g.count) { Float.NaN }
        try {
            for (i in 0 until g.count) {
                val l = t.left[i]
                val r = t.right[i]
                val edge = g.edgeHz[i]
                if (l == r) {
                    if (appliedPostL[i] != l || appliedPostR[i] != r) {
                        d.setPostEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, edge, l))
                        appliedPostL[i] = l
                        appliedPostR[i] = r
                    }
                } else {
                    if (appliedPostL[i] != l) {
                        d.setPostEqBandByChannelIndex(0, i, DynamicsProcessing.EqBand(true, edge, l))
                        appliedPostL[i] = l
                    }
                    if (appliedPostR[i] != r) {
                        d.setPostEqBandByChannelIndex(1, i, DynamicsProcessing.EqBand(true, edge, r))
                        appliedPostR[i] = r
                    }
                }
            }
            issueSet.remove("Post-EQ")
            issueSet.remove("Parametric EQ")
            issueSet.remove("Crossover 2-Way")
        } catch (e: Throwable) {
            DiagLog.log("Post-EQ rapat gagal (lantai ${gridFloorDb} dB): ${e.javaClass.simpleName} ${e.message ?: ""}")
            if (gridFloorDb < -30f) {
                // Sebagian perangkat menolak gain di bawah -30 dB: coba lagi dengan lantai yang lebih landai.
                gridFloorDb = -30f
                appliedPostL = FloatArray(0)
                appliedPostR = FloatArray(0)
                applyPostEq(d)
                return
            }
            if (fx.toneOn) issueSet.add("Post-EQ")
            if (peq.active) issueSet.add("Parametric EQ")
            if (xoActive) {
                issueSet.add("Crossover 2-Way")
                splitMode = SPLIT_FAIL
            }
        }
    }

    private fun applySystemFx() {
        val b0 = bass
        val v0 = virt
        val l0 = loud
        val r0 = reverb
        bass = syncEffect(bass, fx.bassOn, "Bass Boost", { BassBoost(PRIORITY, session) }) {
            it.setStrength((fx.bassPct * 10).coerceIn(0, 1000).toShort())
        }
        virt = syncEffect(virt, fx.virtOn, "Virtualizer", { Virtualizer(PRIORITY, session) }) {
            it.setStrength((fx.virtPct * 10).coerceIn(0, 1000).toShort())
        }
        loud = syncEffect(loud, fx.loudOn, "Loudness", { LoudnessEnhancer(session) }) {
            it.setTargetGain((fx.loudDb * 100f).roundToInt().coerceIn(0, 3000))
        }
        reverb = syncEffect(reverb, fx.reverbPreset != 0, "Reverb", { PresetReverb(PRIORITY, session) }) {
            it.preset = fx.reverbPreset.toShort()
        }
        val fresh = (bass != null && b0 == null) || (virt != null && v0 == null) ||
            (loud != null && l0 == null) || (reverb != null && r0 == null)
        if (fresh && !reordering) reorderDpLast()
    }

    /**
     * Efek sistem yang baru dibuat masuk ke ujung rantai, sesudah DynamicsProcessing. Agar limiter tetap yang terakhir
     * (memotong hasil Bass Boost/Loudness juga), DP dibuat ulang. Hanya dilakukan bila DP memang terpakai.
     */
    private fun reorderDpLast() {
        val old = dp ?: return
        if (!wantsDp()) return
        reordering = true
        try {
            DiagLog.log("Sesi $session: DynamicsProcessing dibuat ulang agar limiter berada di akhir rantai efek")
            try { old.release() } catch (_: Throwable) {}
            dp = null
            val fresh = createDp(dpCarriesEq, builtBands)
            if (fresh == null) {
                dpCarriesEq = false
                if (eq == null) eq = makeEq()
            } else {
                dp = watch(fresh)
            }
            invalidateCaches()
            splitMode = when {
                !twoWay -> SPLIT_NONE
                dp != null && grid != null -> SPLIT_FILTER
                dp != null && dpFull -> SPLIT_MBC
                dp != null && dpCarriesEq -> SPLIT_EQ
                else -> SPLIT_FAIL
            }
            updateEq(eqOnNow, half)
            applyGains()
            applyDspFx()
            applyLimiter()
            syncEnabled()
        } finally {
            reordering = false
        }
    }

    /** Buat/atur/lepas satu efek sistem sesuai status aktif. Kegagalan dicatat di [issues]. */
    private fun <T : AudioEffect> syncEffect(
        current: T?, on: Boolean, name: String, make: () -> T, setup: (T) -> Unit
    ): T? {
        if (!on) {
            try { current?.release() } catch (_: Throwable) {}
            issueSet.remove(name)
            return null
        }
        var e = current
        if (e == null) {
            e = try {
                watch(make())
            } catch (t: Throwable) {
                DiagLog.log("$name sesi $session gagal dibuat: ${t.javaClass.simpleName}")
                null
            }
            if (e == null) {
                issueSet.add(name)
                return null
            }
        }
        return try {
            setup(e)
            touch()
            e.enabled = true
            issueSet.remove(name)
            e
        } catch (_: Throwable) {
            issueSet.add(name)
            e
        }
    }

    // ---------- Penjaga kendali: verifikasi, baca balik, pulihkan ----------

    /**
     * Periksa semua efek yang DIMINTA: masih dikuasai, menyala, dan parameternya terbaca sama dengan yang dikirim.
     * Kendali hilang/efek mati → pasang ulang atau bangun ulang (maks [RECLAIM_MAX] kali per 30 detik agar tidak berebut
     * tanpa henti dengan EQ lain). Hasil baca-balik dipakai indikator di layar utama.
     */
    fun verifyAndRepair(): Health {
        if (!isActive) return Health.OK
        var lost = false
        var off = false
        fun probe(e: AudioEffect?, wanted: Boolean) {
            if (e == null || !wanted) return
            try {
                if (!e.hasControl()) lost = true else if (!e.enabled) off = true
            } catch (_: Throwable) {
                lost = true
            }
        }
        probe(dp, wantsDp())
        probe(eq, !dpCarriesEq && eqOnNow)
        probe(bass, fx.bassOn)
        probe(virt, fx.virtOn)
        probe(loud, fx.loudOn)
        probe(reverb, fx.reverbPreset != 0)

        if (lost) {
            val now = SystemClock.uptimeMillis()
            reclaimTimes.removeAll { now - it > RECLAIM_WINDOW_MS }
            if (reclaimTimes.size >= RECLAIM_MAX) {
                if (!contested) DiagLog.log("Sesi $session: kendali direbut berulang — berhenti merebut sementara")
                contested = true
                return Health.CONTESTED
            }
            reclaimTimes.add(now)
            DiagLog.log("Sesi $session: kendali efek hilang — efek dibuat ulang (prioritas tinggi)")
            rebuild()
            return Health.REBUILT
        }
        contested = false
        if (off) {
            DiagLog.log("Sesi $session: efek ditemukan mati — dinyalakan dan diterapkan ulang")
            reapplyAll()
            return Health.REAPPLIED
        }
        eqReadbackOk = readbackEq()
        limReadbackOk = readbackLimiter()
        if (eqReadbackOk == false || limReadbackOk == false) {
            DiagLog.log("Sesi $session: parameter terbaca berbeda dari yang dikirim — diterapkan ulang")
            reapplyAll()
            eqReadbackOk = readbackEq()
            limReadbackOk = readbackLimiter()
            return Health.REAPPLIED
        }
        return Health.OK
    }

    private fun reapplyAll() {
        invalidateCaches()
        updateEq(eqOnNow, half)
        applyFx()
        applyLimiter()
        syncEnabled()
    }

    private fun readbackEq(): Boolean? {
        if (!eqOnNow || half.isEmpty()) return null
        if (dpCarriesEq && splitMode != SPLIT_EQ) {
            val d = dp ?: return null
            return try {
                var ok = true
                val split = splitActive()
                for (i in 0 until builtBands) {
                    val want = half[i] / 2f
                    val got = d.getPreEqBandByChannelIndex(0, i).gain
                    if (abs(got - want) > 0.3f) { ok = false; break }
                    if (split) {
                        val wantR = halfR[i] / 2f
                        val gotR = d.getPreEqBandByChannelIndex(1, i).gain
                        if (abs(gotR - wantR) > 0.3f) { ok = false; break }
                    }
                }
                ok
            } catch (_: Throwable) {
                null
            }
        }
        val e = eq ?: return null
        return try {
            val want = hardwareTargets(e, mergedHalf()) ?: return null
            var ok = true
            for (b in want.indices) {
                if (abs(e.getBandLevel(b.toShort()).toInt() - want[b].toInt()) > 30) ok = false
            }
            ok
        } catch (_: Throwable) {
            null
        }
    }

    private fun closeTo(a: Float, b: Float): Boolean = abs(a - b) <= max(0.06f, abs(b) * 0.02f)

    private fun readbackLimiter(): Boolean? {
        val d = dp ?: return null
        val lim = effectiveLimiter()
        return try {
            val l = d.getLimiterByChannelIndex(0)
            val ok = l.isEnabled == lim.enabled &&
                closeTo(l.attackTime, lim.attackMs) && closeTo(l.releaseTime, lim.releaseMs) &&
                closeTo(l.ratio, lim.ratio) && closeTo(l.threshold, lim.thresholdDb) && closeTo(l.postGain, lim.postGainDb)
            limReadbackNote = if (ok) "" else
                "kirim A=${lim.attackMs} R=${lim.releaseMs} ratio=${lim.ratio} thr=${lim.thresholdDb}; " +
                    "terbaca A=${l.attackTime} R=${l.releaseTime} ratio=${l.ratio} thr=${l.threshold}"
            ok
        } catch (_: Throwable) {
            null
        }
    }

    // ---------- Verifikasi: apakah efek benar-benar aktif? ----------

    private fun check(name: String, effect: AudioEffect?): EffectStatus {
        if (effect == null) return EffectStatus(name, FxState.FAILED, "gagal dibuat oleh perangkat")
        return try {
            when {
                !effect.hasControl() -> EffectStatus(
                    name, FxState.NO_CONTROL,
                    if (contested) "direbut berulang kali oleh aplikasi/efek lain" else "dikuasai aplikasi/vendor lain"
                )
                !effect.enabled -> EffectStatus(name, FxState.FAILED, "tidak menyala")
                else -> EffectStatus(name, FxState.ACTIVE)
            }
        } catch (t: Throwable) {
            EffectStatus(name, FxState.FAILED, t.javaClass.simpleName)
        }
    }

    private fun refine(st: EffectStatus, readback: Boolean?, message: String): EffectStatus =
        if (st.state == FxState.ACTIVE && readback == false) EffectStatus(st.name, FxState.FAILED, message) else st

    /** Daftar efek yang DIMINTA beserta hasil verifikasinya (dibuat + dikuasai + menyala). Kosong bila tidak ada efek diminta. */
    fun statuses(): List<EffectStatus> {
        val list = mutableListOf<EffectStatus>()
        if (eqOnNow) {
            val st = if (dpCarriesEq) check("EQ ${builtBands} band (DSP${if (splitActive()) ", L/R terpisah" else ""})", dp) else check("EQ sistem", eq)
            list += refine(st, eqReadbackOk, "perangkat tidak menerima nilai EQ (nilai terbaca berbeda)")
        }
        val lim = effectiveLimiter()
        if (lim.enabled) {
            val name = (if (safetyLimiterActive) "Limiter pengaman" else "Limiter") +
                " (pipeline " + (if (dpCarriesEq) "Maksimum" else "Standar") + ")"
            list += refine(check(name, dp), limReadbackOk, "perangkat tidak menerima parameter limiter")
        } else if (needsDsp()) {
            list += check("DSP gain/crossover/kompresor", dp)
        }
        if (chSplit && eqOnNow && !splitActive() && splitMode != SPLIT_EQ) {
            list += EffectStatus("EQ L/R terpisah", FxState.FAILED, "perangkat tidak mendukung EQ per kanal — memakai rata-rata kiri/kanan")
        }
        if (peq.active) {
            list += if (!gridSupported) EffectStatus("Parametric EQ", FxState.FAILED, "perangkat menolak Post-EQ rapat")
            else check("Parametric EQ", dp)
        }
        if (fx.bassOn) list += check("Bass Boost", bass)
        if (fx.virtOn) list += check("Virtualizer", virt)
        if (fx.loudOn) list += check("Loudness", loud)
        if (fx.reverbPreset != 0) list += check("Reverb", reverb)
        if (twoWay) {
            list += when (splitMode) {
                SPLIT_FAIL -> EffectStatus("Crossover 2-Way", FxState.FAILED, "tidak didukung perangkat")
                SPLIT_FILTER -> check("Crossover 2-Way ${xo.slopeDbOct} dB/okt", dp)
                else -> check("Crossover 2-Way (slope tetap)", dp)
            }
        }
        return list
    }

    // ---------- Equalizer hardware (pipeline Standar) ----------

    private fun ensureHwMap(effect: Equalizer) {
        if (hwMap != null) return
        val count = effect.numberOfBands.toInt()
        val centers = IntArray(count) { effect.getCenterFreq(it.toShort()) / 1000 }
        val r = effect.bandLevelRange
        hwCount = count
        hwMin = r[0].toInt()
        hwMax = r[1].toInt()
        hwMap = IntArray(layout.count) { ui ->
            var best = 0
            var diff = Long.MAX_VALUE
            for (b in 0 until count) {
                val d = abs(centers[b].toLong() - layout.centerHz[ui].toLong())
                if (d < diff) { diff = d; best = b }
            }
            best
        }
    }

    /** Level (milliBel) tiap band hardware untuk kurva UI [halfDb]; null bila pemetaan belum tersedia. */
    private fun hardwareTargets(effect: Equalizer, halfDb: IntArray): ShortArray? {
        ensureHwMap(effect)
        val map = hwMap ?: return null
        if (halfDb.size != map.size) return null
        val sums = IntArray(hwCount)
        val cnt = IntArray(hwCount)
        halfDb.forEachIndexed { i, v ->
            sums[map[i]] += v
            cnt[map[i]]++
        }
        return ShortArray(hwCount) { b ->
            val h = if (cnt[b] == 0) 0 else (sums[b].toDouble() / cnt[b]).roundToInt()
            (h * 50).coerceIn(hwMin, hwMax).toShort()
        }
    }

    private fun applyHardwareBands(effect: Equalizer, halfDb: IntArray) {
        val target = hardwareTargets(effect, halfDb) ?: return
        var cache = appliedHw
        if (cache == null || cache.size != target.size) {
            cache = ShortArray(target.size) { Short.MIN_VALUE }
            appliedHw = cache
        }
        for (band in target.indices) {
            if (cache[band] == target[band]) continue
            effect.setBandLevel(band.toShort(), target[band])
            cache[band] = target[band]
        }
    }

    /** Teks status mesin saat ini (dipakai layanan setelah pemulihan). */
    fun describeNow(): String = describe()

    private fun describe(): String {
        val xoText = "${xo.freqHz} Hz, ${xo.slopeDbOct} dB/okt"
        val pipe = when {
            twoWay && splitMode == SPLIT_FAIL -> "2-Way tidak didukung perangkat — memakai 1-Way"
            splitMode == SPLIT_FILTER -> "2-Way aktif ($xoText): ${if (swapChannels) "Kiri = HIGH, Kanan = LOW" else "Kiri = LOW, Kanan = HIGH"} • $builtBands band"
            splitMode == SPLIT_MBC -> "2-Way aktif (${crossoverHz} Hz, slope tetap): ${if (swapChannels) "Kiri = HIGH, Kanan = LOW" else "Kiri = LOW, Kanan = HIGH"} • $builtBands band"
            splitMode == SPLIT_EQ -> "2-Way pendekatan EQ (<${Bands.crossoverEdge(layout, crossoverHz)} Hz): perangkat tanpa crossover MBC"
            dpCarriesEq && splitActive() -> "Pipeline Maksimum: $builtBands band, EQ kiri/kanan terpisah aktif"
            dpCarriesEq -> "Pipeline Maksimum: $builtBands band presisi aktif"
            eq != null && maxFellBack -> "Pipeline Maksimum tidak didukung perangkat — memakai Standar"
            eq != null -> "Pipeline Standar: Equalizer sistem (${eq?.numberOfBands} band hardware)"
            else -> "Efek audio global tidak didukung perangkat"
        }
        val lim = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> " • Limiter butuh Android 9+"
            dp == null -> " • Limiter tidak didukung perangkat"
            else -> ""
        }
        return "Status: $pipe$lim"
    }
}

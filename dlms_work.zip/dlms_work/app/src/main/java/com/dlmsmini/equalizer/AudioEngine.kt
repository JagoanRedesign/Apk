package com.dlmsmini.equalizer

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.os.Build
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pipeline audio:
 *  - STANDAR : Equalizer sistem Android (band hardware dipetakan ke band UI: 5/10/13/21).
 *  - MAKSIMUM: DynamicsProcessing (Android 9+) dengan PreEq sebanyak band UI (presisi penuh).
 * Limiter selalu memakai DynamicsProcessing (Android 9+).
 */
class AudioEngine(private val session: Int = 0) {
    private var eq: Equalizer? = null
    private var dp: DynamicsProcessing? = null
    private var builtPipeline = -1
    private var builtBands = -1
    private var layout: BandLayout = Bands.forCount(Bands.DEFAULT)
    private var dpCarriesEq = false
    private var maxFellBack = false
    private var limiterOn = false
    private var twoWay = false
    private var crossoverHz = Store.DEFAULT_CROSSOVER
    private var splitError = false

    /** Mode 2-Way: kanal kiri = LOW (di bawah crossover), kanal kanan = HIGH (di atas crossover). */
    fun setSplit(on: Boolean, hz: Int) {
        twoWay = on
        crossoverHz = hz
    }

    val limiterAvailable: Boolean get() = dp != null
    val isActive: Boolean get() = dp != null || eq != null

    /** Buat ulang efek bila pipeline atau jumlah band berubah, lalu terapkan semua parameter. */
    fun configure(pipeline: Int, eqOn: Boolean, halfDb: IntArray, lim: LimiterSettings): String {
        // 2-Way membutuhkan EQ per kanal, yang hanya tersedia lewat DynamicsProcessing.
        val effective = if (twoWay) Store.PIPE_MAX else pipeline
        if (builtPipeline != effective || builtBands != halfDb.size) {
            release()
            build(effective, halfDb.size)
        }
        updateEq(eqOn, halfDb)
        updateLimiter(lim, eqOn)
        return describe()
    }

    fun release() {
        try { dp?.release() } catch (_: Throwable) {}
        try { eq?.release() } catch (_: Throwable) {}
        dp = null
        eq = null
        dpCarriesEq = false
        builtPipeline = -1
        builtBands = -1
    }

    private fun build(pipeline: Int, bands: Int) {
        builtPipeline = pipeline
        builtBands = bands
        layout = Bands.forCount(bands)
        maxFellBack = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (pipeline == Store.PIPE_MAX) {
                dp = createDp(true, bands)
                dpCarriesEq = dp != null
                if (dp == null) {
                    maxFellBack = true
                    dp = createDp(false, bands)
                }
            } else {
                dp = createDp(false, bands)
            }
        } else if (pipeline == Store.PIPE_MAX) {
            maxFellBack = true
        }
        if (!dpCarriesEq) {
            eq = try { Equalizer(0, session) } catch (_: Throwable) { null }
        }
    }

    private fun createDp(withEq: Boolean, bands: Int): DynamicsProcessing? = try {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2,
            withEq, if (withEq) bands else 0,
            false, 0,
            false, 0,
            true
        ).build()
        DynamicsProcessing(0, session, cfg)
    } catch (_: Throwable) {
        null
    }

    fun updateEq(eqOn: Boolean, halfDb: IntArray) {
        if (halfDb.size != builtBands) return
        if (dpCarriesEq) {
            val d = dp
            if (d != null) {
                if (twoWay) {
                    splitError = !(trySplit(d, eqOn, halfDb, -60f) || trySplit(d, eqOn, halfDb, -30f))
                } else {
                    splitError = false
                    try {
                        for (i in 0 until builtBands) {
                            val gain = if (eqOn) halfDb[i] / 2f else 0f
                            d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], gain))
                        }
                    } catch (_: Throwable) {}
                }
            }
        } else {
            val e = eq
            if (e != null) {
                try {
                    e.enabled = eqOn
                    if (eqOn) applyHardwareBands(e, halfDb)
                } catch (_: Throwable) {}
            }
        }
        syncEnabled(eqOn)
    }

    /** Kiri: band LOW sesuai kurva, band HIGH diredam. Kanan: kebalikannya. */
    private fun trySplit(d: DynamicsProcessing, eqOn: Boolean, halfDb: IntArray, cutDb: Float): Boolean = try {
        for (i in 0 until builtBands) {
            val g = if (eqOn) halfDb[i] / 2f else 0f
            val isLow = layout.centerHz[i] < crossoverHz
            val left = if (!eqOn) 0f else if (isLow) g else cutDb
            val right = if (!eqOn) 0f else if (isLow) cutDb else g
            d.setPreEqBandByChannelIndex(0, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], left))
            d.setPreEqBandByChannelIndex(1, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], right))
        }
        true
    } catch (_: Throwable) {
        false
    }

    fun updateLimiter(lim: LimiterSettings, eqOn: Boolean) {
        limiterOn = lim.enabled
        val d = dp
        if (d != null) {
            try {
                d.setLimiterAllChannelsTo(
                    DynamicsProcessing.Limiter(
                        true, lim.enabled, 0,
                        lim.attackMs, lim.releaseMs, lim.ratio, lim.thresholdDb, lim.postGainDb
                    )
                )
            } catch (_: Throwable) {}
        }
        syncEnabled(eqOn)
    }

    private fun syncEnabled(eqOn: Boolean) {
        val d = dp ?: return
        try { d.enabled = limiterOn || (dpCarriesEq && eqOn) } catch (_: Throwable) {}
    }

    private fun applyHardwareBands(effect: Equalizer, halfDb: IntArray) {
        val range = effect.bandLevelRange
        val count = effect.numberOfBands.toInt()
        val buckets = Array(count) { mutableListOf<Int>() }
        halfDb.forEachIndexed { index, v -> buckets[nearestBand(effect, layout.centerHz[index])].add(v) }
        for (band in 0 until count) {
            val half = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
            val milliBel = (half * 50).coerceIn(range[0].toInt(), range[1].toInt())
            effect.setBandLevel(band.toShort(), milliBel.toShort())
        }
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands.toInt()) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    private fun describe(): String {
        val pipe = when {
            dpCarriesEq && twoWay && splitError -> "2-Way gagal diterapkan oleh perangkat"
            dpCarriesEq && twoWay -> "2-Way aktif: Kiri = LOW (<${Bands.crossoverEdge(layout, crossoverHz)} Hz), Kanan = HIGH • $builtBands band"
            dpCarriesEq -> "Pipeline Maksimum: $builtBands band presisi aktif"
            twoWay && eq != null -> "2-Way tidak didukung perangkat (butuh Android 9+) — memakai 1-Way"
            eq != null && maxFellBack -> "Pipeline Maksimum tidak didukung perangkat — memakai Standar"
            eq != null -> "Pipeline Standar: Equalizer sistem (${eq?.numberOfBands} band hardware)"
            else -> "Efek audio global tidak didukung perangkat"
        }
        val lim = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> " • Limiter butuh Android 9+"
            dp == null -> " • Limiter tidak didukung perangkat"
            else -> ""
        }
        return "Status: $pipe$lim"
    }
}

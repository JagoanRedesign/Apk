package com.dlmsmini.equalizer

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.os.Build
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pipeline audio:
 *  - STANDAR : Equalizer sistem Android (band hardware dipetakan ke 10 band UI).
 *  - MAKSIMUM: DynamicsProcessing (Android 9+) dengan 10 band PreEq presisi.
 * Limiter selalu memakai DynamicsProcessing (Android 9+).
 */
class AudioEngine {
    private var eq: Equalizer? = null
    private var dp: DynamicsProcessing? = null
    private var builtPipeline = -1
    private var dpCarriesEq = false
    private var maxFellBack = false
    private var limiterOn = false

    private val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    private val edgeHz = floatArrayOf(44f, 88f, 177f, 354f, 707f, 1414f, 2828f, 5657f, 11314f, 22000f)

    val limiterAvailable: Boolean get() = dp != null

    /** Buat ulang efek bila pipeline berubah, lalu terapkan semua parameter. Mengembalikan teks status. */
    fun configure(pipeline: Int, eqOn: Boolean, halfDb: IntArray, lim: LimiterSettings): String {
        if (builtPipeline != pipeline) {
            release()
            build(pipeline)
        }
        updateEq(eqOn, halfDb)
        updateLimiter(lim, eqOn)
        return describe()
    }

    fun release() {
        try { dp?.release() } catch (_: Throwable) {}
        try { eq?.release() } catch (_: Throwable) {}
        dp = null
        eq = null
        dpCarriesEq = false
        builtPipeline = -1
    }

    private fun build(pipeline: Int) {
        builtPipeline = pipeline
        maxFellBack = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (pipeline == Store.PIPE_MAX) {
                dp = createDp(true)
                dpCarriesEq = dp != null
                if (dp == null) {
                    maxFellBack = true
                    dp = createDp(false)
                }
            } else {
                dp = createDp(false)
            }
        } else if (pipeline == Store.PIPE_MAX) {
            maxFellBack = true
        }
        if (!dpCarriesEq) {
            eq = try { Equalizer(0, 0) } catch (_: Throwable) { null }
        }
    }

    private fun createDp(withEq: Boolean): DynamicsProcessing? = try {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2,
            withEq, if (withEq) 10 else 0,
            false, 0,
            false, 0,
            true
        ).build()
        DynamicsProcessing(0, 0, cfg)
    } catch (_: Throwable) {
        null
    }

    fun updateEq(eqOn: Boolean, halfDb: IntArray) {
        if (dpCarriesEq) {
            val d = dp
            if (d != null) {
                try {
                    for (i in 0 until 10) {
                        val gain = if (eqOn) halfDb[i] / 2f else 0f
                        d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, edgeHz[i], gain))
                    }
                } catch (_: Throwable) {}
            }
        } else {
            val e = eq
            if (e != null) {
                try {
                    e.enabled = eqOn
                    if (eqOn) applyHardwareBands(e, halfDb)
                } catch (_: Throwable) {}
            }
        }
        syncEnabled(eqOn)
    }

    fun updateLimiter(lim: LimiterSettings, eqOn: Boolean) {
        limiterOn = lim.enabled
        val d = dp
        if (d != null) {
            try {
                d.setLimiterAllChannelsTo(
                    DynamicsProcessing.Limiter(
                        true, lim.enabled, 0,
                        lim.attackMs, lim.releaseMs, lim.ratio, lim.thresholdDb, lim.postGainDb
                    )
                )
            } catch (_: Throwable) {}
        }
        syncEnabled(eqOn)
    }

    private fun syncEnabled(eqOn: Boolean) {
        val d = dp ?: return
        try { d.enabled = limiterOn || (dpCarriesEq && eqOn) } catch (_: Throwable) {}
    }

    private fun applyHardwareBands(effect: Equalizer, halfDb: IntArray) {
        val range = effect.bandLevelRange
        val count = effect.numberOfBands.toInt()
        val buckets = Array(count) { mutableListOf<Int>() }
        halfDb.forEachIndexed { index, v -> buckets[nearestBand(effect, centerHz[index])].add(v) }
        for (band in 0 until count) {
            val half = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
            val milliBel = (half * 50).coerceIn(range[0].toInt(), range[1].toInt())
            effect.setBandLevel(band.toShort(), milliBel.toShort())
        }
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands.toInt()) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    private fun describe(): String {
        val pipe = when {
            dpCarriesEq -> "Pipeline Maksimum: 10 band presisi aktif"
            eq != null && maxFellBack -> "Pipeline Maksimum tidak didukung perangkat — memakai Standar"
            eq != null -> "Pipeline Standar: Equalizer sistem (${eq?.numberOfBands} band hardware)"
            else -> "Efek audio global tidak didukung perangkat"
        }
        val lim = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> " • Limiter butuh Android 9+"
            dp == null -> " • Limiter tidak didukung perangkat"
            else -> ""
        }
        return "Status: $pipe$lim"
    }
}

package com.dlmsmini.equalizer

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.os.Build
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class FxState { ACTIVE, FAILED, NO_CONTROL }

/** Hasil verifikasi satu efek yang diminta: benar-benar dibuat, dikuasai aplikasi ini, dan menyala. */
class EffectStatus(val name: String, val state: FxState, val detail: String = "")

/**
 * Satu "mesin" efek untuk satu sesi audio (0 = Mix Global, >0 = sesi aplikasi).
 *
 * Pipeline EQ:
 *  - STANDAR : Equalizer sistem Android (band hardware dipetakan ke band UI: 5/10/13/21).
 *  - MAKSIMUM: DynamicsProcessing (Android 9+) dengan PreEq sebanyak band UI.
 * DynamicsProcessing juga membawa: limiter, gain masukan per kanal (pre-amp, balance, mute, volume L/R, headroom),
 * kompresor multiband (3 band), crossover 2-Way sungguhan (band MBC per kanal) dan Post-EQ/tone (3 band).
 * Efek sistem terpisah: BassBoost, Virtualizer, LoudnessEnhancer, PresetReverb.
 */
class AudioEngine(private val session: Int = 0) {
    companion object {
        const val SPLIT_NONE = 0
        const val SPLIT_MBC = 1   // crossover sungguhan lewat band MBC
        const val SPLIT_EQ = 2    // pendekatan lewat EQ (perangkat tanpa MBC)
        const val SPLIT_FAIL = 3
        private val SAFETY = LimiterSettings(true, 1f, 80f, 20f, -1f, 0f)
    }

    private var eq: Equalizer? = null
    private var dp: DynamicsProcessing? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null
    private var reverb: PresetReverb? = null

    private var builtPipeline = -1
    private var builtBands = -1
    private var layout: BandLayout = Bands.forCount(Bands.DEFAULT)
    private var dpCarriesEq = false
    private var dpFull = false
    private var maxFellBack = false
    private var limiterOn = false
    private var twoWay = false
    private var crossoverHz = Store.DEFAULT_CROSSOVER
    private var swapChannels = false
    private var splitMode = SPLIT_NONE
    private var fx = EffectSettings()
    private var master = MasterSettings()
    private var userLimiter = LimiterSettings()
    private var half = IntArray(0)
    private var eqOnNow = false
    private val issueSet = linkedSetOf<String>()

    val limiterAvailable: Boolean get() = dp != null
    val isActive: Boolean get() = dp != null || eq != null
    val split: Int get() = splitMode

    /** True bila proteksi clipping sedang memakai limiter pengaman (limiter pengguna mati). */
    val safetyLimiterActive: Boolean get() = !userLimiter.enabled && effectiveLimiter() === SAFETY

    /** Nama efek yang gagal dibuat/diterapkan oleh perangkat. */
    val issues: Set<String> get() = issueSet

    /** [swap] = true: kiri membawa HIGH, kanan membawa LOW (kebalikan bawaan). */
    fun setSplit(on: Boolean, hz: Int, swap: Boolean = false) {
        twoWay = on
        swapChannels = swap
        crossoverHz = hz.coerceIn(Store.MIN_CROSSOVER, Store.MAX_CROSSOVER)
    }

    fun setFx(f: EffectSettings) { fx = f }

    fun setMaster(m: MasterSettings) { master = m }

    /** Terapkan efek tambahan secara langsung (dipanggil saat slider efek digeser). */
    fun updateFx(f: EffectSettings, eqOn: Boolean) {
        fx = f
        eqOnNow = eqOn
        applyFx()
        applyLimiter()
        syncEnabled()
    }

    /** Volume L/R atau mode proteksi berubah. */
    fun updateMaster(m: MasterSettings) {
        master = m
        applyGains()
        applyLimiter()
        syncEnabled()
    }

    /** Buat ulang efek bila pipeline atau jumlah band berubah, lalu terapkan semua parameter. */
    fun configure(pipeline: Int, eqOn: Boolean, halfDb: IntArray, lim: LimiterSettings): String {
        // 2-Way membutuhkan proses per kanal, yang hanya tersedia lewat DynamicsProcessing.
        val effective = if (twoWay) Store.PIPE_MAX else pipeline
        if (builtPipeline != effective || builtBands != halfDb.size) {
            release()
            build(effective, halfDb.size)
        }
        half = halfDb
        eqOnNow = eqOn
        userLimiter = lim
        splitMode = when {
            !twoWay -> SPLIT_NONE
            dp != null && dpFull -> SPLIT_MBC
            dp != null && dpCarriesEq -> SPLIT_EQ
            else -> SPLIT_FAIL
        }
        updateEq(eqOn, halfDb)
        applyLimiter()
        applyFx()
        syncEnabled()
        return describe()
    }

    fun release() {
        try { dp?.release() } catch (_: Throwable) {}
        try { eq?.release() } catch (_: Throwable) {}
        try { bass?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { loud?.release() } catch (_: Throwable) {}
        try { reverb?.release() } catch (_: Throwable) {}
        dp = null
        eq = null
        bass = null
        virt = null
        loud = null
        reverb = null
        dpCarriesEq = false
        dpFull = false
        builtPipeline = -1
        builtBands = -1
        issueSet.clear()
    }

    private fun build(pipeline: Int, bands: Int) {
        builtPipeline = pipeline
        builtBands = bands
        layout = Bands.forCount(bands)
        maxFellBack = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (pipeline == Store.PIPE_MAX) {
                dp = createDp(true, bands)
                dpCarriesEq = dp != null
                if (dp == null) {
                    maxFellBack = true
                    dp = createDp(false, bands)
                }
            } else {
                dp = createDp(false, bands)
            }
        } else if (pipeline == Store.PIPE_MAX) {
            maxFellBack = true
        }
        if (!dpCarriesEq) {
            eq = try { Equalizer(0, session) } catch (t: Throwable) {
                DiagLog.log("Equalizer sesi $session gagal dibuat: ${t.javaClass.simpleName}")
                null
            }
        }
    }

    /** Coba konfigurasi lengkap (dengan kompresor & Post-EQ); bila ditolak, pakai versi dasar. */
    private fun createDp(withEq: Boolean, bands: Int): DynamicsProcessing? {
        val eqBands = if (withEq) bands else 0
        for (full in booleanArrayOf(true, false)) {
            try {
                val cfg = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    2,
                    withEq, eqBands,
                    full, if (full) 3 else 0,
                    full, if (full) 3 else 0,
                    true
                ).build()
                val d = DynamicsProcessing(0, session, cfg)
                dpFull = full
                return d
            } catch (t: Throwable) {
                DiagLog.log("DynamicsProcessing sesi $session (penuh=$full) ditolak: ${t.javaClass.simpleName} ${t.message ?: ""}")
            }
        }
        return null
    }

    // ---------- EQ ----------

    fun updateEq(eqOn: Boolean, halfDb: IntArray) {
        if (halfDb.size != builtBands) return
        half = halfDb
        eqOnNow = eqOn
        if (dpCarriesEq) {
            val d = dp
            if (d != null) {
                if (splitMode == SPLIT_EQ) {
                    if (!(trySplit(d, eqOn, halfDb, -60f) || trySplit(d, eqOn, halfDb, -30f))) splitMode = SPLIT_FAIL
                } else {
                    try {
                        for (i in 0 until builtBands) {
                            val gain = if (eqOn) halfDb[i] / 2f else 0f
                            d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], gain))
                        }
                    } catch (_: Throwable) {}
                }
            }
        } else {
            val e = eq
            if (e != null) {
                try {
                    e.enabled = eqOn
                    if (eqOn) applyHardwareBands(e, halfDb)
                } catch (_: Throwable) {}
            }
        }
        // Headroom otomatis dan limiter pengaman bergantung pada puncak boost EQ.
        applyGains()
        applyLimiter()
        syncEnabled()
    }

    /** Pendekatan 2-Way via EQ (hanya bila MBC tidak tersedia). Kiri: band LOW sesuai kurva; kanan: band HIGH. */
    private fun trySplit(d: DynamicsProcessing, eqOn: Boolean, halfDb: IntArray, cutDb: Float): Boolean = try {
        for (i in 0 until builtBands) {
            val g = if (eqOn) halfDb[i] / 2f else 0f
            val isLow = layout.centerHz[i] < crossoverHz
            val lowOnLeft = !swapChannels
            val left = if (!eqOn) 0f else if (isLow == lowOnLeft) g else cutDb
            val right = if (!eqOn) 0f else if (isLow == lowOnLeft) cutDb else g
            d.setPreEqBandByChannelIndex(0, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], left))
            d.setPreEqBandByChannelIndex(1, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], right))
        }
        true
    } catch (_: Throwable) {
        false
    }

    // ---------- Proteksi clipping ----------

    private fun eqPeakDb(): Float {
        if (!eqOnNow || half.isEmpty()) return 0f
        var m = 0
        for (v in half) if (v > m) m = v
        return m / 2f
    }

    /** Perkiraan konservatif total boost (dB) dari semua tahap penguat. */
    private fun totalBoostDb(): Float {
        var t = eqPeakDb() + max(0f, fx.preampDb)
        if (fx.loudOn) t += fx.loudDb
        if (fx.bassOn) t += fx.bassPct / 100f * 6f
        if (fx.toneOn) t += max(0f, max(fx.toneLowDb, max(fx.toneMidDb, fx.toneHighDb)))
        if (fx.mbcOn) t += fx.mbcMakeupDb
        return t
    }

    /** Mode 2: turunkan gain masukan 50% dari puncak boost EQ (maks 6 dB) agar ada ruang sebelum clipping. */
    private fun headroomDb(): Float =
        if (master.clipMode >= Store.CLIP_HEADROOM) -min(6f, eqPeakDb() * 0.5f) else 0f

    private fun effectiveLimiter(): LimiterSettings =
        if (userLimiter.enabled) userLimiter
        else if (master.clipMode >= Store.CLIP_LIMITER && totalBoostDb() > 0.5f) SAFETY
        else userLimiter

    private fun needsDsp(): Boolean =
        fx.needsDsp || master.volumeActive || headroomDb() != 0f || splitMode == SPLIT_MBC

    fun updateLimiter(lim: LimiterSettings, eqOn: Boolean) {
        userLimiter = lim
        eqOnNow = eqOn
        applyLimiter()
        syncEnabled()
    }

    private fun applyLimiter() {
        val lim = effectiveLimiter()
        limiterOn = lim.enabled
        val d = dp ?: return
        try {
            d.setLimiterAllChannelsTo(
                DynamicsProcessing.Limiter(
                    true, lim.enabled, 0,
                    lim.attackMs, lim.releaseMs, lim.ratio, lim.thresholdDb, lim.postGainDb
                )
            )
        } catch (_: Throwable) {}
    }

    private fun syncEnabled() {
        val d = dp ?: return
        try { d.enabled = limiterOn || (dpCarriesEq && eqOnNow) || needsDsp() } catch (_: Throwable) {}
    }

    // ---------- Gain masukan: pre-amp, balance, mute, volume L/R, headroom ----------

    private fun applyGains() {
        val d = dp
        if (d == null) {
            if (master.volumeActive) issueSet.add("Volume L/R") else issueSet.remove("Volume L/R")
            return
        }
        val base = fx.channelGainsDb()
        val h = headroomDb()
        val left = max(-80f, base.first + master.volumeDb(master.volL) + h)
        val right = max(-80f, base.second + master.volumeDb(master.volR) + h)
        try {
            d.setInputGainbyChannel(0, left)
            d.setInputGainbyChannel(1, right)
            issueSet.remove("Pre-amp/Balance")
            issueSet.remove("Volume L/R")
        } catch (_: Throwable) {
            issueSet.add("Pre-amp/Balance")
            if (master.volumeActive) issueSet.add("Volume L/R")
        }
    }

    // ---------- Efek tambahan ----------

    private fun applyFx() {
        applyGains()
        applyDspFx()
        applySystemFx()
    }

    private fun applyDspFx() {
        val d = dp ?: return
        if (!dpFull) {
            if (fx.mbcOn) issueSet.add("Kompresor") else issueSet.remove("Kompresor")
            if (fx.toneOn) issueSet.add("Post-EQ") else issueSet.remove("Post-EQ")
            return
        }
        // Band MBC dipakai ganda: kompresor 3 band (250/3000 Hz) atau crossover 2-Way sungguhan (kiri = LOW, kanan = HIGH).
        val xo = splitMode == SPLIT_MBC
        try {
            val cutoffs = if (xo) floatArrayOf(crossoverHz.toFloat(), 21000f, 22000f) else floatArrayOf(250f, 3000f, 22000f)
            for (ch in 0 until 2) {
                for (i in 0 until 3) {
                    // Bawaan: kiri = LOW (band 0), kanan = HIGH (band 1-2). Tukar: kebalikannya.
                    val keepsLow = (ch == 0) != swapChannels
                    val muted = xo && (if (keepsLow) i != 0 else i == 0)
                    val post = (if (fx.mbcOn) fx.mbcMakeupDb else 0f) + (if (muted) -80f else 0f)
                    val band = DynamicsProcessing.MbcBand(
                        fx.mbcOn || xo, cutoffs[i],
                        fx.mbcAttackMs, fx.mbcReleaseMs,
                        if (fx.mbcOn) fx.mbcRatio else 1f,
                        fx.mbcThresholdDb,
                        3f, -90f, 1f,
                        0f, post
                    )
                    d.setMbcBandByChannelIndex(ch, i, band)
                }
            }
            issueSet.remove("Kompresor")
            issueSet.remove("Crossover 2-Way")
        } catch (_: Throwable) {
            if (fx.mbcOn) issueSet.add("Kompresor")
            if (xo) { issueSet.add("Crossover 2-Way"); splitMode = SPLIT_FAIL }
        }
        try {
            val cutoffs = floatArrayOf(250f, 4000f, 22000f)
            val toneGains = floatArrayOf(fx.toneLowDb, fx.toneMidDb, fx.toneHighDb)
            for (i in 0 until 3) {
                val g = if (fx.toneOn) toneGains[i] else 0f
                d.setPostEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cutoffs[i], g))
            }
            issueSet.remove("Post-EQ")
        } catch (_: Throwable) {
            if (fx.toneOn) issueSet.add("Post-EQ")
        }
    }

    private fun applySystemFx() {
        bass = syncEffect(bass, fx.bassOn, "Bass Boost", { BassBoost(0, session) }) {
            it.setStrength((fx.bassPct * 10).coerceIn(0, 1000).toShort())
        }
        virt = syncEffect(virt, fx.virtOn, "Virtualizer", { Virtualizer(0, session) }) {
            it.setStrength((fx.virtPct * 10).coerceIn(0, 1000).toShort())
        }
        loud = syncEffect(loud, fx.loudOn, "Loudness", { LoudnessEnhancer(session) }) {
            it.setTargetGain((fx.loudDb * 100f).roundToInt().coerceIn(0, 3000))
        }
        reverb = syncEffect(reverb, fx.reverbPreset != 0, "Reverb", { PresetReverb(0, session) }) {
            it.preset = fx.reverbPreset.toShort()
        }
    }

    /** Buat/atur/lepas satu efek sistem sesuai status aktif. Kegagalan dicatat di [issues]. */
    private fun <T : AudioEffect> syncEffect(
        current: T?, on: Boolean, name: String, make: () -> T, setup: (T) -> Unit
    ): T? {
        if (!on) {
            try { current?.release() } catch (_: Throwable) {}
            issueSet.remove(name)
            return null
        }
        var e = current
        if (e == null) {
            e = try { make() } catch (t: Throwable) {
                DiagLog.log("$name sesi $session gagal dibuat: ${t.javaClass.simpleName}")
                null
            }
            if (e == null) {
                issueSet.add(name)
                return null
            }
        }
        return try {
            setup(e)
            e.enabled = true
            issueSet.remove(name)
            e
        } catch (_: Throwable) {
            issueSet.add(name)
            e
        }
    }

    // ---------- Verifikasi: apakah efek benar-benar aktif? ----------

    private fun check(name: String, effect: AudioEffect?): EffectStatus {
        if (effect == null) return EffectStatus(name, FxState.FAILED, "gagal dibuat oleh perangkat")
        return try {
            when {
                !effect.hasControl() -> EffectStatus(name, FxState.NO_CONTROL, "dikuasai aplikasi/vendor lain")
                !effect.enabled -> EffectStatus(name, FxState.FAILED, "tidak menyala")
                else -> EffectStatus(name, FxState.ACTIVE)
            }
        } catch (t: Throwable) {
            EffectStatus(name, FxState.FAILED, t.javaClass.simpleName)
        }
    }

    /** Daftar efek yang DIMINTA beserta hasil verifikasinya (dibuat + dikuasai + menyala). Kosong bila tidak ada efek diminta. */
    fun statuses(): List<EffectStatus> {
        val list = mutableListOf<EffectStatus>()
        if (eqOnNow) list += if (dpCarriesEq) check("EQ ${builtBands} band (DSP)", dp) else check("EQ sistem", eq)
        val lim = effectiveLimiter()
        if (lim.enabled) list += check(if (safetyLimiterActive) "Limiter pengaman" else "Limiter", dp)
        else if (needsDsp()) list += check("DSP gain/crossover/kompresor", dp)
        if (fx.bassOn) list += check("Bass Boost", bass)
        if (fx.virtOn) list += check("Virtualizer", virt)
        if (fx.loudOn) list += check("Loudness", loud)
        if (fx.reverbPreset != 0) list += check("Reverb", reverb)
        if (twoWay && splitMode == SPLIT_FAIL) list += EffectStatus("Crossover 2-Way", FxState.FAILED, "tidak didukung perangkat")
        return list
    }

    // ---------- Equalizer hardware (pipeline Standar) ----------

    private fun applyHardwareBands(effect: Equalizer, halfDb: IntArray) {
        val range = effect.bandLevelRange
        val count = effect.numberOfBands.toInt()
        val buckets = Array(count) { mutableListOf<Int>() }
        halfDb.forEachIndexed { index, v -> buckets[nearestBand(effect, layout.centerHz[index])].add(v) }
        for (band in 0 until count) {
            val h = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
            val milliBel = (h * 50).coerceIn(range[0].toInt(), range[1].toInt())
            effect.setBandLevel(band.toShort(), milliBel.toShort())
        }
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands.toInt()) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    private fun describe(): String {
        val pipe = when {
            twoWay && splitMode == SPLIT_FAIL -> "2-Way tidak didukung perangkat — memakai 1-Way"
            splitMode == SPLIT_MBC -> "2-Way aktif (crossover $crossoverHz Hz): ${if (swapChannels) "Kiri = HIGH, Kanan = LOW" else "Kiri = LOW, Kanan = HIGH"} • $builtBands band"
            splitMode == SPLIT_EQ -> "2-Way pendekatan EQ (<${Bands.crossoverEdge(layout, crossoverHz)} Hz): perangkat tanpa crossover MBC"
            dpCarriesEq -> "Pipeline Maksimum: $builtBands band presisi aktif"
            eq != null && maxFellBack -> "Pipeline Maksimum tidak didukung perangkat — memakai Standar"
            eq != null -> "Pipeline Standar: Equalizer sistem (${eq?.numberOfBands} band hardware)"
            else -> "Efek audio global tidak didukung perangkat"
        }
        val lim = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> " • Limiter butuh Android 9+"
            dp == null -> " • Limiter tidak didukung perangkat"
            else -> ""
        }
        return "Status: $pipe$lim"
    }
}

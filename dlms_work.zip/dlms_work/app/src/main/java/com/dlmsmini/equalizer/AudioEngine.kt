package com.dlmsmini.equalizer

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.os.Build
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Satu "mesin" efek untuk satu sesi audio (0 = Mix Global, >0 = sesi aplikasi).
 *
 * Pipeline EQ:
 *  - STANDAR : Equalizer sistem Android (band hardware dipetakan ke band UI: 5/10/13/21).
 *  - MAKSIMUM: DynamicsProcessing (Android 9+) dengan PreEq sebanyak band UI.
 * DynamicsProcessing juga membawa: limiter, pre-amp/balance/mute (gain masukan per kanal),
 * kompresor multiband (3 band), dan Post-EQ/tone (3 band).
 * Efek sistem terpisah: BassBoost, Virtualizer, LoudnessEnhancer, PresetReverb.
 */
class AudioEngine(private val session: Int = 0) {
    private var eq: Equalizer? = null
    private var dp: DynamicsProcessing? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null
    private var reverb: PresetReverb? = null

    private var builtPipeline = -1
    private var builtBands = -1
    private var layout: BandLayout = Bands.forCount(Bands.DEFAULT)
    private var dpCarriesEq = false
    private var dpFull = false
    private var maxFellBack = false
    private var limiterOn = false
    private var eqRequested = false
    private var twoWay = false
    private var crossoverHz = Store.DEFAULT_CROSSOVER
    private var splitError = false
    private var fx = EffectSettings()
    private val issueSet = linkedSetOf<String>()

    val limiterAvailable: Boolean get() = dp != null
    val isActive: Boolean get() = dp != null || eq != null

    /** Nama efek yang gagal dibuat/diterapkan oleh perangkat. */
    val issues: Set<String> get() = issueSet

    /** Permintaan crossover 2-Way; bila jalur PCM tidak tersedia, stereo tidak boleh dipisah L/R. */
    fun setSplit(on: Boolean, hz: Int) {
        twoWay = on
        crossoverHz = hz
    }

    fun setFx(f: EffectSettings) {
        fx = f
    }

    /** Terapkan efek tambahan secara langsung (dipanggil saat slider efek digeser). */
    fun updateFx(f: EffectSettings, eqOn: Boolean) {
        fx = f
        applyFx()
        syncEnabled(eqOn)
    }

    /** Buat ulang efek bila pipeline atau jumlah band berubah, lalu terapkan semua parameter. */
    fun configure(pipeline: Int, eqOn: Boolean, halfDb: IntArray, lim: LimiterSettings): String {
        // Crossover stereo sejati memerlukan filter PCM per kanal; jangan mengklaimnya dari graphic EQ.
        val effective = if (twoWay) Store.PIPE_MAX else pipeline
        if (builtPipeline != effective || builtBands != halfDb.size) {
            release()
            build(effective, halfDb.size)
        }
        updateEq(eqOn, halfDb)
        updateLimiter(lim, eqOn)
        applyFx()
        syncEnabled(eqOn)
        return describe()
    }

    fun release() {
        try { dp?.release() } catch (_: Throwable) {}
        try { eq?.release() } catch (_: Throwable) {}
        try { bass?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { loud?.release() } catch (_: Throwable) {}
        try { reverb?.release() } catch (_: Throwable) {}
        dp = null
        eq = null
        bass = null
        virt = null
        loud = null
        reverb = null
        dpCarriesEq = false
        dpFull = false
        builtPipeline = -1
        builtBands = -1
        issueSet.clear()
    }

    private fun build(pipeline: Int, bands: Int) {
        builtPipeline = pipeline
        builtBands = bands
        layout = Bands.forCount(bands)
        maxFellBack = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (pipeline == Store.PIPE_MAX) {
                dp = createDp(true, bands)
                dpCarriesEq = dp != null
                if (dp == null) {
                    maxFellBack = true
                    dp = createDp(false, bands)
                }
            } else {
                dp = createDp(false, bands)
            }
        } else if (pipeline == Store.PIPE_MAX) {
            maxFellBack = true
        }
        if (!dpCarriesEq) {
            eq = try { Equalizer(0, session) } catch (_: Throwable) { null }
        }
    }

    /** Coba konfigurasi lengkap (dengan kompresor & Post-EQ); bila ditolak, pakai versi dasar. */
    private fun createDp(withEq: Boolean, bands: Int): DynamicsProcessing? {
        val eqBands = if (withEq) bands else 0
        for (full in booleanArrayOf(true, false)) {
            try {
                val cfg = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    2,
                    withEq, eqBands,
                    full, if (full) 3 else 0,
                    full, if (full) 3 else 0,
                    true
                ).build()
                val d = DynamicsProcessing(0, session, cfg)
                dpFull = full
                return d
            } catch (_: Throwable) {
            }
        }
        return null
    }

    // ---------- EQ ----------

    fun updateEq(eqOn: Boolean, halfDb: IntArray) {
        eqRequested = eqOn
        if (halfDb.size != builtBands) return
        if (dpCarriesEq) {
            val d = dp
            if (d != null) {
                // DynamicsProcessing.EqBand is a graphic EQ band, not a per-channel
                // crossover filter. Do not split LOW into left and HIGH into right:
                // that destroys stereo imaging. Keep both channels intact and report
                // that a true stereo crossover needs an owned PCM processing path.
                splitError = twoWay
                try {
                    for (i in 0 until builtBands) {
                        val gain = if (eqOn) halfDb[i] / 2f else 0f
                        d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], gain))
                    }
                } catch (_: Throwable) {}
            }
        } else {
            val e = eq
            if (e != null) {
                try {
                    e.enabled = eqOn
                    if (eqOn) applyHardwareBands(e, halfDb)
                } catch (_: Throwable) {}
            }
        }
        syncEnabled(eqOn)
    }

    /** Kiri: band LOW sesuai kurva, band HIGH diredam. Kanan: kebalikannya. */
    private fun trySplit(d: DynamicsProcessing, eqOn: Boolean, halfDb: IntArray, cutDb: Float): Boolean = try {
        for (i in 0 until builtBands) {
            val g = if (eqOn) halfDb[i] / 2f else 0f
            val isLow = layout.centerHz[i] < crossoverHz
            val left = if (!eqOn) 0f else if (isLow) g else cutDb
            val right = if (!eqOn) 0f else if (isLow) cutDb else g
            d.setPreEqBandByChannelIndex(0, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], left))
            d.setPreEqBandByChannelIndex(1, i, DynamicsProcessing.EqBand(true, layout.edgeHz[i], right))
        }
        true
    } catch (_: Throwable) {
        false
    }

    fun updateLimiter(lim: LimiterSettings, eqOn: Boolean) {
        limiterOn = lim.enabled
        val d = dp
        if (d != null) {
            try {
                d.setLimiterAllChannelsTo(
                    DynamicsProcessing.Limiter(
                        true, lim.enabled, 0,
                        lim.attackMs, lim.releaseMs, lim.ratio, lim.thresholdDb, lim.postGainDb
                    )
                )
            } catch (_: Throwable) {}
        }
        syncEnabled(eqOn)
    }

    private fun syncEnabled(eqOn: Boolean) {
        val d = dp ?: return
        try { d.enabled = limiterOn || (dpCarriesEq && eqOn) || fx.needsDsp } catch (_: Throwable) {}
    }

    // ---------- Efek tambahan ----------

    private fun applyFx() {
        applyDspFx()
        applySystemFx()
    }

    private fun applyDspFx() {
        val d = dp ?: return
        val gains = fx.channelGainsDb()
        try {
            d.setInputGainbyChannel(0, gains.first)
            d.setInputGainbyChannel(1, gains.second)
            issueSet.remove("Pre-amp/Balance")
        } catch (_: Throwable) {
            issueSet.add("Pre-amp/Balance")
        }
        if (!dpFull) {
            if (fx.mbcOn) issueSet.add("Kompresor") else issueSet.remove("Kompresor")
            if (fx.toneOn) issueSet.add("Post-EQ") else issueSet.remove("Post-EQ")
            return
        }
        try {
            val cutoffs = floatArrayOf(250f, 3000f, 22000f)
            for (i in 0 until 3) {
                val band = DynamicsProcessing.MbcBand(
                    fx.mbcOn, cutoffs[i],
                    fx.mbcAttackMs, fx.mbcReleaseMs,
                    if (fx.mbcOn) fx.mbcRatio else 1f,
                    fx.mbcThresholdDb,
                    3f, -90f, 1f,
                    0f, if (fx.mbcOn) fx.mbcMakeupDb else 0f
                )
                d.setMbcBandAllChannelsTo(i, band)
            }
            issueSet.remove("Kompresor")
        } catch (_: Throwable) {
            if (fx.mbcOn) issueSet.add("Kompresor")
        }
        try {
            val cutoffs = floatArrayOf(250f, 4000f, 22000f)
            val toneGains = floatArrayOf(fx.toneLowDb, fx.toneMidDb, fx.toneHighDb)
            for (i in 0 until 3) {
                val g = if (fx.toneOn) toneGains[i] else 0f
                d.setPostEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cutoffs[i], g))
            }
            issueSet.remove("Post-EQ")
        } catch (_: Throwable) {
            if (fx.toneOn) issueSet.add("Post-EQ")
        }
    }

    private fun applySystemFx() {
        bass = syncEffect(bass, fx.bassOn, "Bass Boost", { BassBoost(0, session) }) {
            it.setStrength((fx.bassPct * 10).coerceIn(0, 1000).toShort())
        }
        virt = syncEffect(virt, fx.virtOn, "Virtualizer", { Virtualizer(0, session) }) {
            it.setStrength((fx.virtPct * 10).coerceIn(0, 1000).toShort())
        }
        loud = syncEffect(loud, fx.loudOn, "Loudness", { LoudnessEnhancer(session) }) {
            it.setTargetGain((fx.loudDb * 100f).roundToInt().coerceIn(0, 3000))
        }
        reverb = syncEffect(reverb, fx.reverbPreset != 0, "Reverb", { PresetReverb(0, session) }) {
            it.preset = fx.reverbPreset.toShort()
        }
    }

    /** Buat/atur/lepas satu efek sistem sesuai status aktif. Kegagalan dicatat di [issues]. */
    private fun <T : AudioEffect> syncEffect(
        current: T?, on: Boolean, name: String, make: () -> T, setup: (T) -> Unit
    ): T? {
        if (!on) {
            try { current?.release() } catch (_: Throwable) {}
            issueSet.remove(name)
            return null
        }
        var e = current
        if (e == null) {
            e = try { make() } catch (_: Throwable) { null }
            if (e == null) {
                issueSet.add(name)
                return null
            }
        }
        return try {
            setup(e)
            e.enabled = true
            issueSet.remove(name)
            e
        } catch (_: Throwable) {
            issueSet.add(name)
            e
        }
    }

    // ---------- Equalizer hardware (pipeline Standar) ----------

    private fun applyHardwareBands(effect: Equalizer, halfDb: IntArray) {
        val range = effect.bandLevelRange
        val count = effect.numberOfBands.toInt()
        val buckets = Array(count) { mutableListOf<Int>() }
        halfDb.forEachIndexed { index, v -> buckets[nearestBand(effect, layout.centerHz[index])].add(v) }
        for (band in 0 until count) {
            val half = buckets[band].takeIf { it.isNotEmpty() }?.average()?.roundToInt() ?: 0
            val milliBel = (half * 50).coerceIn(range[0].toInt(), range[1].toInt())
            effect.setBandLevel(band.toShort(), milliBel.toShort())
        }
    }

    private fun nearestBand(effect: Equalizer, hz: Int): Int {
        var best = 0
        var diff = Long.MAX_VALUE
        for (i in 0 until effect.numberOfBands.toInt()) {
            val center = effect.getCenterFreq(i.toShort()).toLong() / 1000L
            val d = abs(center - hz.toLong())
            if (d < diff) { diff = d; best = i }
        }
        return best
    }

    private fun describe(): String {
        val applied = (eqRequested && ((dpCarriesEq && dp?.enabled == true) || (eq != null && eq?.enabled == true))) ||
            (limiterOn && dp?.enabled == true) ||
            (fx.needsDsp && dp?.enabled == true) ||
            listOfNotNull(bass, virt, loud, reverb).any { it.enabled }
        val pipe = when {
            dpCarriesEq && twoWay && splitError -> "Crossover stereo sejati belum didukung jalur efek sistem ini; stereo dipertahankan tanpa pemisahan kanal"
            dpCarriesEq -> "Pipeline Maksimum: $builtBands band presisi aktif"
            twoWay && eq != null -> "Crossover stereo sejati tidak tersedia pada efek hardware; memakai EQ stereo standar"
            eq != null && maxFellBack -> "Pipeline Maksimum tidak didukung perangkat — memakai Standar"
            eq != null -> "Pipeline Standar: Equalizer sistem (${eq?.numberOfBands} band hardware)"
            else -> "Efek audio global tidak didukung perangkat"
        }
        val lim = when {
            Build.VERSION.SDK_INT < Build.VERSION_CODES.P -> " • Limiter butuh Android 9+"
            dp == null -> " • Limiter tidak didukung perangkat"
            else -> ""
        }
        val state = if (applied) "EFEK AKTIF" else "EFEK TIDAK AKTIF / BELUM DITERAPKAN"
        return "$state • $pipe$lim"
    }
}

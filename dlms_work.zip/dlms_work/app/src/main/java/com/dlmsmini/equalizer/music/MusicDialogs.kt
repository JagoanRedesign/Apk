package com.dlmsmini.equalizer.music

import android.content.Context
import android.graphics.Typeface
import android.view.inputmethod.EditorInfo
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Panel lirik: tersinkron (baris aktif disorot dan digulirkan) atau teks biasa. */
class LyricsPanel(private val ctx: Context) : ScrollView(ctx) {
    private val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 80))
    }
    private var lines: List<LrcLine> = emptyList()
    private val views = ArrayList<TextView>()
    private var cur = -1
    var onSeek: ((Long) -> Unit)? = null

    init {
        addView(box)
        overScrollMode = OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
    }

    private fun reset() { box.removeAllViews(); views.clear(); lines = emptyList(); cur = -1 }

    fun message(text: String) {
        reset()
        box.addView(Ui.label(ctx, text, 15f, Pal.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(ctx, 24), 0, 0) })
    }

    fun plain(text: String) {
        reset()
        box.addView(Ui.label(ctx, text, 16f, Pal.TEXT).apply { setLineSpacing(0f, 1.25f) })
    }

    fun synced(list: List<LrcLine>) {
        reset()
        lines = list
        for (l in list) {
            val tv = Ui.label(ctx, l.text.ifBlank { "♪" }, 18f, Pal.MUTED, true).apply {
                setPadding(0, Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8))
                setOnClickListener { onSeek?.invoke(l.timeMs) }
            }
            views.add(tv)
            box.addView(tv)
        }
    }

    fun update(posMs: Long) {
        if (lines.isEmpty()) return
        val i = LrcParser.indexAt(lines, posMs)
        if (i == cur) return
        if (cur in views.indices) style(views[cur], false)
        cur = i
        if (i in views.indices) {
            val v = views[i]
            style(v, true)
            smoothScrollTo(0, (v.top - height / 2 + v.height / 2).coerceAtLeast(0))
        }
    }

    private fun style(v: TextView, on: Boolean) {
        v.setTextColor(if (on) Pal.TEXT else Pal.MUTED)
        v.textSize = if (on) 22f else 18f
        v.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
}

/** Dialog pencarian kandidat lirik manual (LRCLIB). */
object LyricsPicker {
    private fun describe(c: LyricsCandidate): String {
        val tag = when {
            c.instrumental -> "instrumental"
            c.hasSynced -> "tersinkron"
            c.hasText -> "teks"
            else -> "kosong"
        }
        val album = if (c.album.isBlank()) "" else "${c.album} • "
        return "${c.title} — ${c.artist}\n$album${fmtTime(c.durationSec)} • $tag"
    }

    fun show(a: AppCompatActivity, scope: CoroutineScope, t: Track, onChosen: (LyricsCandidate) -> Unit) {
        val (title, artist) = TitleClean.forLyrics(t.title, t.artist)
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0) }
        val input = EditText(a).apply {
            setText("$title $artist".trim()); hint = "Judul atau artis"; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        val searchBtn = Button(a).apply { text = "Cari" }
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(searchBtn)
        val status = TextView(a).apply { text = "Mencari…"; setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8)) }
        val list = ListView(a)
        body.addView(row)
        body.addView(status)
        body.addView(list, LinearLayout.LayoutParams(-1, Ui.dp(a, 320)))

        val dlg = AlertDialog.Builder(a).setTitle("Cari lirik").setView(body).setNegativeButton("Tutup", null).create()
        var cands: List<LyricsCandidate> = emptyList()

        fun run(first: Boolean) {
            val q = input.text.toString().trim()
            if (q.isEmpty()) return
            status.text = "Mencari…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { if (first) LrcLib.candidatesFor(t) else LrcLib.search(q) } }
                r.onSuccess {
                    cands = it
                    list.adapter = ArrayAdapter(a, android.R.layout.simple_list_item_1, it.map { c -> describe(c) })
                    status.text = if (it.isEmpty()) "Tidak ada hasil. Ubah kata kunci lalu cari lagi." else "${it.size} kandidat — ketuk untuk memakai"
                }.onFailure { status.text = "Gagal: ${it.message}" }
            }
        }
        searchBtn.setOnClickListener { run(false) }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEARCH) { run(false); true } else false }
        list.setOnItemClickListener { _, _, pos, _ ->
            val c = cands.getOrNull(pos) ?: return@setOnItemClickListener
            scope.launch {
                withContext(Dispatchers.IO) { LrcLib.choose(a, t, c) }
                dlg.dismiss()
                onChosen(c)
            }
        }
        dlg.show()
        run(true)
    }
}

/** Dialog unduh: pilih kualitas, lalu pilih sematkan sampul/lirik. */
object DownloadDialog {
    fun show(a: AppCompatActivity, scope: CoroutineScope, t: Track) {
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0) }
        val status = TextView(a).apply { text = "Mengambil daftar kualitas…"; setPadding(0, 0, 0, Ui.dp(a, 8)) }
        val group = RadioGroup(a)
        val cbCover = CheckBox(a).apply { text = "Sematkan sampul album"; isChecked = MusicPrefs.embedCover(a) }
        val cbLyrics = CheckBox(a).apply { text = "Sematkan lirik (LRCLIB)"; isChecked = MusicPrefs.embedLyrics(a) }
        val cbSynced = CheckBox(a).apply { text = "Pakai lirik tersinkron (LRC) bila ada"; isChecked = MusicPrefs.syncedLyrics(a) }
        val note = TextView(a).apply {
            text = "Format Opus/WebM tidak mendukung sematan: sampul dan lirik tetap tampil di aplikasi ini."
            textSize = 12f; visibility = View.GONE; setPadding(0, Ui.dp(a, 6), 0, 0)
        }
        body.addView(status); body.addView(group); body.addView(cbCover); body.addView(cbLyrics); body.addView(cbSynced); body.addView(note)
        cbLyrics.setOnCheckedChangeListener { _, on -> cbSynced.isEnabled = on }
        cbSynced.isEnabled = cbLyrics.isChecked

        val dlg = AlertDialog.Builder(a).setTitle("Unduh lagu").setView(ScrollView(a).apply { addView(body) })
            .setNegativeButton("Batal", null).setPositiveButton("Unduh", null).create()
        dlg.show()
        val ok = dlg.getButton(AlertDialog.BUTTON_POSITIVE)
        ok.isEnabled = false
        var opts: List<AudioOption> = emptyList()

        fun refreshEmbedState() {
            val o = opts.getOrNull(group.checkedRadioButtonId - 1000) ?: return
            val can = o.canEmbed
            cbCover.isEnabled = can
            cbLyrics.isEnabled = can
            cbSynced.isEnabled = can && cbLyrics.isChecked
            note.visibility = if (can) View.GONE else View.VISIBLE
        }
        group.setOnCheckedChangeListener { _, _ -> refreshEmbedState() }

        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { StreamResolver.options(t.id, force = true) } }
            r.onSuccess { list ->
                opts = list
                status.text = "Pilih kualitas:"
                list.forEachIndexed { i, o ->
                    val mb = if (t.durationSec > 0) "  ~%.1f MB".format(o.bitrateKbps * t.durationSec / 8.0 / 1024.0) else ""
                    group.addView(RadioButton(a).apply {
                        id = 1000 + i
                        text = o.label + mb + if (o.canEmbed) "" else "  (tanpa sematan)"
                    })
                }
                group.check(1000 + list.indexOfFirst { it.canEmbed }.coerceAtLeast(0))
                refreshEmbedState()
                ok.isEnabled = true
            }.onFailure { status.text = "Gagal mengambil stream: ${it.message}" }
        }

        ok.setOnClickListener {
            val o = opts.getOrNull(group.checkedRadioButtonId - 1000) ?: return@setOnClickListener
            val cover = cbCover.isChecked && o.canEmbed
            val lyr = cbLyrics.isChecked && o.canEmbed
            if (o.canEmbed) MusicPrefs.setDownloadDefaults(a, cbCover.isChecked, cbLyrics.isChecked, cbSynced.isChecked)
            DownloadCenter.enqueue(a, t, o, cover, lyr, cbSynced.isChecked)
            Toast.makeText(a, "Ditambahkan ke unduhan", Toast.LENGTH_SHORT).show()
            dlg.dismiss()
        }
    }
}

/** Pengaturan musik: kualitas streaming dan instans Piped buatan sendiri. */
object MusicSettingsDialog {
    fun show(a: AppCompatActivity) {
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0) }
        body.addView(TextView(a).apply { text = "Kualitas streaming"; setTypeface(typeface, Typeface.BOLD) })
        val group = RadioGroup(a)
        listOf("Tinggi (bitrate terbesar)", "Standar (≈128 kbps)", "Hemat data (terendah)").forEachIndexed { i, s ->
            group.addView(RadioButton(a).apply { id = 2000 + i; text = s })
        }
        group.check(2000 + MusicPrefs.streamQuality(a))
        body.addView(group)
        body.addView(TextView(a).apply { text = "Instans Piped (opsional)"; setPadding(0, Ui.dp(a, 16), 0, 0); setTypeface(typeface, Typeface.BOLD) })
        val et = EditText(a).apply {
            setText(MusicPrefs.customPiped(a)); hint = "https://pipedapi.contoh.com"; setSingleLine()
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        body.addView(et)
        body.addView(TextView(a).apply {
            text = "Dicoba lebih dulu sebelum daftar instans publik. Kosongkan untuk otomatis. Bila semua instans gagal, pencarian dialihkan ke NewPipeExtractor."
            textSize = 12f
        })
        AlertDialog.Builder(a).setTitle("Pengaturan musik").setView(ScrollView(a).apply { addView(body) })
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                MusicPrefs.setStreamQuality(a, group.checkedRadioButtonId - 2000)
                MusicPrefs.setCustomPiped(a, et.text.toString())
                Toast.makeText(a, "Tersimpan (kualitas berlaku di lagu berikutnya)", Toast.LENGTH_SHORT).show()
            }.show()
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/** Ukuran bersama agar fader dan kolom skala sejajar persis. */
internal object FaderGeom {
    const val PAD_DP = 14f
    const val RED = 0xFFFF2D2D.toInt()
}

/**
 * Fader EQ vertikal gaya mixer: slot hitam, garis skala di kiri-kanan slot setiap 3 dB,
 * tanda MERAH di 0 dB, dan tutup (cap) abu-abu terang. Nilai dalam satuan 0,5 dB (-maxHalf..maxHalf).
 */
class VerticalFader(context: Context) : View(context) {
    var value: Int = 0
        private set
    var maxHalf: Int = 24
    var onValueChanged: ((Int, Boolean) -> Unit)? = null

    /** Warna garis isi tipis di dalam slot (biru = stereo, oranye = kiri, ungu = kanan). */
    var fillColor: Int = 0xFF168DFF.toInt()

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    private val slotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slotEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF2B3548.toInt() }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val capPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val capShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
    private val capLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val capEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF8A90A0.toInt() }
    private val rect = RectF()

    fun setMax(newMax: Int) {
        maxHalf = newMax
        setValue(value, false)
        invalidate()
    }

    fun setValue(newValue: Int, fromUser: Boolean = false) {
        val v = newValue.coerceIn(-maxHalf, maxHalf)
        if (value != v) {
            value = v
            invalidate()
            onValueChanged?.invoke(v, fromUser)
        } else if (fromUser) onValueChanged?.invoke(v, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = d(FaderGeom.PAD_DP)
        val bottom = height - top
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val y = center - (value / maxHalf.toFloat()) * half
        val slotHalf = d(5f)

        // Slot gelap
        rect.set(cx - slotHalf, top - d(5f), cx + slotHalf, bottom + d(5f))
        slotPaint.shader = LinearGradient(rect.left, 0f, rect.right, 0f,
            intArrayOf(0xFF000000.toInt(), 0xFF171E2C.toInt(), 0xFF000000.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, d(5f), d(5f), slotPaint)
        slotEdge.strokeWidth = d(1f)
        canvas.drawRoundRect(rect, d(5f), d(5f), slotEdge)

        // Garis skala tiap 3 dB di kiri & kanan slot; 0 dB = merah dan lebih panjang
        val maxDb = maxHalf / 2
        val gap = d(1.5f)
        val avail = (width / 2f - slotHalf - gap).coerceAtLeast(d(2f))
        val tickColor = Pal.c(0xFFD7DCE6)
        var db = -(maxDb / 3) * 3
        while (db <= maxDb) {
            val ty = center - (db * 2f / maxHalf) * half
            val zero = db == 0
            val major = db % 6 == 0
            val len = min(if (zero) d(9f) else if (major) d(7f) else d(4.5f), avail)
            tickPaint.color = if (zero) FaderGeom.RED else tickColor
            tickPaint.strokeWidth = if (zero) d(2.2f) else d(1.3f)
            canvas.drawLine(cx - slotHalf - gap - len, ty, cx - slotHalf - gap, ty, tickPaint)
            canvas.drawLine(cx + slotHalf + gap, ty, cx + slotHalf + gap + len, ty, tickPaint)
            db += 3
        }

        // Garis merah 0 dB di dalam slot
        tickPaint.color = FaderGeom.RED
        tickPaint.strokeWidth = d(2f)
        canvas.drawLine(cx - slotHalf + d(1f), center, cx + slotHalf - d(1f), center, tickPaint)

        // Garis isi tipis dari 0 ke posisi cap
        fillPaint.color = fillColor
        if (value > 0) { rect.set(cx - d(1.5f), y, cx + d(1.5f), center); canvas.drawRoundRect(rect, d(1.5f), d(1.5f), fillPaint) }
        else if (value < 0) { rect.set(cx - d(1.5f), center, cx + d(1.5f), y); canvas.drawRoundRect(rect, d(1.5f), d(1.5f), fillPaint) }

        // Cap
        val capW = min(width - d(2f), d(28f)).coerceAtLeast(d(14f))
        val capH = d(15f)
        rect.set(cx - capW / 2f, y - capH / 2f + d(1.5f), cx + capW / 2f, y + capH / 2f + d(1.5f))
        canvas.drawRoundRect(rect, d(2.5f), d(2.5f), capShadow)
        rect.set(cx - capW / 2f, y - capH / 2f, cx + capW / 2f, y + capH / 2f)
        capPaint.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            intArrayOf(0xFFF4F5F8.toInt(), 0xFFC9CDD6.toInt(), 0xFFE8EAEE.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, d(2.5f), d(2.5f), capPaint)
        capEdge.strokeWidth = d(1f)
        canvas.drawRoundRect(rect, d(2.5f), d(2.5f), capEdge)
        capLine.color = if (value == 0) FaderGeom.RED else 0xFF2A2F3A.toInt()
        capLine.strokeWidth = if (value == 0) d(2.2f) else d(1.5f)
        canvas.drawLine(rect.left + d(3f), y, rect.right - d(3f), y, capLine)
    }

    private fun updateFromY(y: Float) {
        val top = d(FaderGeom.PAD_DP)
        val bottom = height - top
        val clamped = y.coerceIn(top, bottom)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        setValue((maxHalf * (center - clamped) / half).roundToInt(), true)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                updateFromY(event.y)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

/** Kolom label skala "+12 / +6 / 0 / -6 / -12" di sisi kiri deretan fader. Angka 0 berwarna merah. */
class FaderScaleView(context: Context) : View(context) {
    var maxHalf: Int = 24
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.RIGHT
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }

    fun setMax(m: Int) { maxHalf = m; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val top = d(FaderGeom.PAD_DP)
        val bottom = height - top
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val maxDb = maxHalf / 2
        var db = -(maxDb / 6) * 6
        while (db <= maxDb) {
            val y = center - (db * 2f / maxHalf) * half
            val zero = db == 0
            val col = if (zero) FaderGeom.RED else Pal.c(0xFFDDE7F8)
            text.color = col
            text.textSize = d(if (zero) 12f else 10.5f)
            text.isFakeBoldText = zero
            line.color = col
            line.strokeWidth = d(if (zero) 2.2f else 1.3f)
            val label = if (db > 0) "+$db" else "$db"
            canvas.drawText(label, width - d(9f), y + text.textSize * 0.35f, text)
            canvas.drawLine(width - d(6f), y, width - d(1f), y, line)
            db += 6
        }
    }
}

// =====================================================================================================
// Tampilan DYNAMIC LIMITER / COMP
// =====================================================================================================

/** Satu parameter limiter yang dipetakan ke fader (posisi 0..1, linear atau logaritmik). */
internal class DynParam(
    val title: String,
    val spec: Spec,
    val log: Boolean,
    val valueColor: Int,
    val read: () -> Float,
    val write: (Float) -> Unit,
    val fmt: (Float) -> String,
    val step: (Float) -> Float
) {
    fun toFrac(v: Float): Float {
        val f = if (log) ln(v / spec.min) / ln(spec.max / spec.min) else (v - spec.min) / (spec.max - spec.min)
        return f.coerceIn(0f, 1f)
    }

    fun fromFrac(f: Float): Float {
        val x = f.coerceIn(0f, 1f)
        val raw = if (log) spec.min * (spec.max / spec.min).pow(x) else spec.min + x * (spec.max - spec.min)
        return snap(raw)
    }

    fun snap(v: Float): Float = spec.toValue(spec.toProgress(v))

    /** Geser satu langkah ke atas (+1) atau bawah (-1). */
    fun nudge(v: Float, dir: Int): Float = snap(spec.clamp(v + dir * step(v)))
}

/** Fader vertikal gelap bergaya "dinamika": slot gelap membulat dan tutup bergaris cyan menyala. Posisi 0 (bawah)..1 (atas). */
class DynFader(context: Context) : View(context) {
    var fraction = 0f
        private set
    var locked = false
        set(v) { field = v; alpha = if (v) 0.6f else 1f }

    /** Dipanggil hanya dari sentuhan pengguna. */
    var onChange: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val capPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x3300E5FF }
    private val capEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF3B4A6B.toInt() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E5FF.toInt(); strokeCap = Paint.Cap.ROUND }
    private val rect = RectF()

    private val pad get() = d(8f)
    private val capH get() = d(26f)

    fun setFraction(f: Float) {
        val v = f.coerceIn(0f, 1f)
        if (v != fraction) { fraction = v; invalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        rect.set(d(1f), d(1f), width - d(1f), height - d(1f))
        body.color = 0xFF060A12.toInt()
        canvas.drawRoundRect(rect, d(14f), d(14f), body)
        edge.color = 0xFF22314D.toInt(); edge.strokeWidth = d(1.2f)
        canvas.drawRoundRect(rect, d(14f), d(14f), edge)

        val topC = pad + capH / 2f
        val botC = height - pad - capH / 2f
        val y = botC - fraction * (botC - topC)
        rect.set(d(8f), y - capH / 2f, width - d(8f), y + capH / 2f)
        glow.strokeWidth = d(5f)
        canvas.drawRoundRect(rect, d(8f), d(8f), glow)
        capPaint.shader = LinearGradient(0f, rect.top, 0f, rect.bottom,
            intArrayOf(0xFF2A3654.toInt(), 0xFF161E33.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, d(8f), d(8f), capPaint)
        capEdge.strokeWidth = d(1.2f)
        canvas.drawRoundRect(rect, d(8f), d(8f), capEdge)
        line.strokeWidth = d(2.2f)
        canvas.drawLine(rect.left + d(8f), y, rect.right - d(8f), y, line)
    }

    private fun fracFromY(y: Float): Float {
        val topC = pad + capH / 2f
        val botC = height - pad - capH / 2f
        return ((botC - y) / (botC - topC)).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (locked) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onChange?.invoke(fracFromY(event.y))
                return true
            }
            MotionEvent.ACTION_UP -> {
                onChange?.invoke(fracFromY(event.y))
                onRelease?.invoke()
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> { onRelease?.invoke(); return true }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

/**
 * Grafik kurva transfer limiter/kompresor (input -60..0 dB di sumbu X, output di sumbu Y).
 * Titik oranye = THRESHOLD (geser kiri/kanan), titik hijau = RATIO (geser naik/turun). Label kotak mengikuti titik.
 */
class LimiterCurveView(context: Context) : View(context) {
    var thresholdDb = -2f
        private set
    var ratio = 10f
        private set
    var locked = false

    /** (threshold, ratio) — hanya dari sentuhan pengguna. */
    var onChange: ((Float, Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private val plot = RectF()
    private val tmp = RectF()
    private var drag = 0 // 0 = tidak ada, 1 = threshold, 2 = ratio

    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1B2740.toInt(); style = Paint.Style.STROKE }
    private val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8FA3C4.toInt(); typeface = Typeface.MONOSPACE; letterSpacing = 0.12f
    }
    private val curvePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E5FF.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dashed = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tagBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0B1424.toInt() }
    private val tagEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.04f
    }
    private val path = Path()

    fun set(t: Float, r: Float) {
        thresholdDb = t.coerceIn(-60f, 0f)
        ratio = r.coerceIn(1f, 20f)
        invalidate()
    }

    private fun layoutPlot() {
        plot.set(d(40f), d(12f), width - d(14f), height - d(28f))
    }

    private fun xOf(db: Float) = plot.left + (db + 60f) / 60f * plot.width()
    private fun yOf(db: Float) = plot.top + (0f - db) / 60f * plot.height()
    private fun outAt0() = thresholdDb + (0f - thresholdDb) / ratio

    private fun tag(c: Canvas, text: String, color: Int, left: Float, top: Float): RectF {
        tagText.textSize = d(11f)
        tagText.color = color
        val w = tagText.measureText(text) + d(16f)
        tmp.set(left, top, left + w, top + d(26f))
        val box = RectF(tmp)
        c.drawRoundRect(box, d(7f), d(7f), tagBg)
        tagEdge.color = color; tagEdge.strokeWidth = d(1.5f)
        c.drawRoundRect(box, d(7f), d(7f), tagEdge)
        c.drawText(text, box.left + d(8f), box.centerY() + tagText.textSize * 0.35f, tagText)
        return box
    }

    private fun tagWidth(text: String): Float {
        tagText.textSize = d(11f)
        return tagText.measureText(text) + d(16f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        layoutPlot()
        if (plot.width() <= 0f || plot.height() <= 0f) return

        // Grid + label sumbu
        grid.strokeWidth = d(1f)
        axis.textSize = d(10.5f)
        var v = 0
        while (v >= -60) {
            val gy = yOf(v.toFloat())
            val gx = xOf(v.toFloat())
            canvas.drawLine(plot.left, gy, plot.right, gy, grid)
            canvas.drawLine(gx, plot.top, gx, plot.bottom, grid)
            axis.textAlign = Paint.Align.RIGHT
            canvas.drawText("$v", plot.left - d(6f), gy + axis.textSize * 0.35f, axis)
            axis.textAlign = Paint.Align.CENTER
            canvas.drawText("$v", gx, plot.bottom + d(16f), axis)
            v -= 12
        }

        val t = thresholdDb
        val hx = xOf(t)
        val hy = yOf(t)
        val rx = xOf(0f)
        val ry = yOf(outAt0())

        // Garis threshold putus-putus
        dashed.strokeWidth = d(1.2f)
        dashed.color = 0x88FFC857.toInt()
        dashed.pathEffect = DashPathEffect(floatArrayOf(d(5f), d(5f)), 0f)
        canvas.drawLine(plot.left, hy, plot.right, hy, dashed)

        // Kurva transfer
        path.reset()
        path.moveTo(xOf(-60f), yOf(-60f))
        path.lineTo(hx, hy)
        path.lineTo(rx, ry)
        curvePaint.strokeWidth = d(3f)
        canvas.drawPath(path, curvePaint)

        val amber = 0xFFFFC857.toInt()
        val green = 0xFF35E0A0.toInt()

        // Label RATIO (kiri atas) + garis penuntun ke titik hijau
        val ratioText = String.format(Locale.US, "RATIO: %.1f:1", ratio)
        val rBox = tag(canvas, ratioText, green, plot.left + d(10f), plot.top + d(8f))
        dashed.color = green
        path.reset()
        path.moveTo(rBox.right, rBox.centerY())
        path.lineTo(max(rBox.right + d(8f), rx - d(18f)), rBox.centerY())
        path.lineTo(rx, ry)
        canvas.drawPath(path, dashed)

        // Label THRESH + garis penuntun ke titik oranye
        val thText = String.format(Locale.US, "THRESH: %.1f dB", t)
        val tw = tagWidth(thText)
        val boxTop = (hy - d(40f)).coerceIn(plot.top + d(44f), max(plot.top + d(44f), plot.bottom - d(34f)))
        var boxLeft = plot.right - tw
        val onRight = hx + d(16f) <= boxLeft
        if (!onRight) boxLeft = max(plot.left + d(2f), hx - d(16f) - tw)
        val tBox = tag(canvas, thText, amber, boxLeft, boxTop)
        dashed.color = amber
        path.reset()
        path.moveTo(hx, hy)
        if (onRight) {
            path.lineTo(hx + d(14f), tBox.centerY())
            path.lineTo(tBox.left, tBox.centerY())
        } else {
            path.lineTo(hx - d(14f), tBox.centerY())
            path.lineTo(tBox.right, tBox.centerY())
        }
        canvas.drawPath(path, dashed)
        dashed.pathEffect = null

        // Titik pegangan
        drawHandle(canvas, hx, hy, amber)
        drawHandle(canvas, rx, ry, green)
    }

    private fun drawHandle(c: Canvas, x: Float, y: Float, color: Int) {
        ring.color = color; ring.strokeWidth = d(2f)
        dot.color = 0xFF0B1424.toInt()
        c.drawCircle(x, y, d(9f), dot)
        c.drawCircle(x, y, d(9f), ring)
        dot.color = color
        c.drawCircle(x, y, d(4.5f), dot)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (locked) return false
        layoutPlot()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dT = hypot(event.x - xOf(thresholdDb), event.y - yOf(thresholdDb))
                val dR = hypot(event.x - xOf(0f), event.y - yOf(outAt0()))
                drag = when {
                    min(dT, dR) > d(40f) -> 0
                    dT <= dR -> 1
                    else -> 2
                }
                if (drag == 0) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (drag) {
                    1 -> {
                        val db = (event.x - plot.left) / plot.width() * 60f - 60f
                        thresholdDb = ((db.coerceIn(-60f, 0f)) * 2f).roundToInt() / 2f
                        onChange?.invoke(thresholdDb, ratio)
                    }
                    2 -> if (thresholdDb <= -1f) {
                        val db = -((event.y - plot.top) / plot.height()) * 60f
                        val out = db.coerceIn(thresholdDb * 0.95f, 0f)
                        val r = (-thresholdDb) / (out - thresholdDb)
                        ratio = ((r.coerceIn(1f, 20f)) * 2f).roundToInt() / 2f
                        onChange?.invoke(thresholdDb, ratio)
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drag != 0) { drag = 0; onRelease?.invoke() }
                return true
            }
        }
        return true
    }
}

/** Panel "GR (DB)": bar vertikal pengurangan gain (estimasi) dengan skala 0, -3, -6, -12, -18, -24. */
class GrMeterView(context: Context) : View(context) {
    @Volatile private var target = 0f
    @Volatile private var lastData = 0L
    private var shown = 0f
    private var lastFrame = 0L

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF4D6A.toInt(); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER; letterSpacing = 0.1f
    }
    private val scaleText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8FA3C4.toInt(); typeface = Typeface.MONOSPACE; textAlign = Paint.Align.RIGHT
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF04070D.toInt() }
    private val trackEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF1E2C45.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val value = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB9C7E0.toInt(); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val marks = floatArrayOf(0f, 3f, 6f, 12f, 18f, 24f)

    /** [grDb] = besar pengurangan gain (nilai positif, dB). Aman dipanggil dari thread lain. */
    fun submit(grDb: Float) {
        target = grDb.coerceIn(0f, 24f)
        lastData = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    fun clear() { target = 0f; postInvalidateOnAnimation() }

    /** Skala sama jarak antar label (0, 3, 6, 12, 18, 24), sehingga dB dipetakan per segmen. */
    private fun frac(gr: Float): Float {
        val g = gr.coerceIn(0f, 24f)
        for (i in 0 until marks.size - 1) {
            if (g <= marks[i + 1]) return (i + (g - marks[i]) / (marks[i + 1] - marks[i])) / (marks.size - 1)
        }
        return 1f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.1f)
        lastFrame = now
        val goal = if (now - lastData < 1500) target else 0f
        shown = if (goal >= shown) goal else max(goal, shown - 30f * dt)

        rect.set(d(1f), d(1f), width - d(1f), height - d(1f))
        panel.color = 0xFF0B1220.toInt()
        canvas.drawRoundRect(rect, d(14f), d(14f), panel)
        edge.color = 0xFF22314D.toInt(); edge.strokeWidth = d(1.2f)
        canvas.drawRoundRect(rect, d(14f), d(14f), edge)

        title.textSize = d(10.5f)
        canvas.drawText("GR (DB)", width / 2f, d(24f), title)

        val tTop = d(40f)
        val tBottom = height - d(44f)
        val tLeft = width * 0.56f
        val tRight = min(width - d(12f), tLeft + d(16f))
        rect.set(tLeft, tTop, tRight, tBottom)
        canvas.drawRoundRect(rect, d(4f), d(4f), track)
        trackEdge.strokeWidth = d(1f)
        canvas.drawRoundRect(rect, d(4f), d(4f), trackEdge)

        val fh = (tBottom - tTop) * frac(shown)
        if (fh > 1f) {
            rect.set(tLeft + d(1.5f), tTop + d(1.5f), tRight - d(1.5f), tTop + fh)
            fill.shader = LinearGradient(0f, tTop, 0f, tBottom,
                intArrayOf(0xFFFFB347.toInt(), 0xFFFF4D6A.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(rect, d(3f), d(3f), fill)
        }

        scaleText.textSize = d(10f)
        for (i in marks.indices) {
            val y = tTop + (tBottom - tTop) * i / (marks.size - 1)
            val txt = if (i == 0) "0" else "-" + marks[i].toInt()
            canvas.drawText(txt, tLeft - d(8f), y + scaleText.textSize * 0.35f, scaleText)
        }

        value.textSize = d(16f)
        canvas.drawText(String.format(Locale.US, "%.1f", shown), width / 2f, height - d(16f), value)

        if (shown > 0.05f || goal > 0.05f) postInvalidateOnAnimation() else lastFrame = 0L
    }
}

package com.dlmsmini.equalizer.music

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dlmsmini.equalizer.Pal
import com.dlmsmini.equalizer.Ui
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors

/** Ikon Font Awesome Free 6 Solid (font yang sama dengan navigasi bawah). */
object Icons {
    const val PLAY = "\uf04b"
    const val PAUSE = "\uf04c"
    const val NEXT = "\uf051"
    const val PREV = "\uf048"
    const val SHUFFLE = "\uf074"
    const val REPEAT = "\uf363"
    const val DOWNLOAD = "\uf019"
    const val HEART = "\uf004"
    const val MORE = "\uf142"
    const val BACK = "\uf060"
    const val SEARCH = "\uf002"
    const val GEAR = "\uf013"
    const val CHECK = "\uf058"
    const val DOWN = "\uf078"
    const val MUSIC = "\uf001"
    const val CLOSE = "\uf00d"

    private var face: Typeface? = null

    @Synchronized
    fun face(ctx: Context): Typeface? {
        if (face == null) face = try { Typeface.createFromAsset(ctx.applicationContext.assets, "fonts/fa-solid-900.ttf") } catch (_: Exception) { null }
        return face
    }

    fun view(ctx: Context, glyph: String, sizeSp: Float = 18f, color: Int = Pal.TEXT, desc: String? = null): TextView = TextView(ctx).apply {
        text = glyph
        textSize = sizeSp
        gravity = Gravity.CENTER
        includeFontPadding = false
        setTextColor(color)
        face(ctx)?.let { typeface = it }
        val pad = Ui.dp(ctx, 10)
        setPadding(pad, pad, pad, pad)
        isClickable = true
        isFocusable = true
        if (desc != null) contentDescription = desc
    }
}

/** Pemuat gambar mungil: cache memori + cache disk, tanpa pustaka luar. */
object Img {
    private val mem = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 10).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(iv: ImageView, url: String?, px: Int = 160) {
        iv.tag = url
        if (url.isNullOrBlank()) { iv.setImageDrawable(null); return }
        val key = "$url@$px"
        val hit = mem.get(key)
        if (hit != null) { iv.setImageBitmap(hit); return }
        iv.setImageDrawable(null)
        val app = iv.context.applicationContext
        pool.execute {
            val b = try { fetch(app, url, px) } catch (_: Throwable) { null }
            if (b != null) {
                mem.put(key, b)
                main.post { if (iv.tag == url) iv.setImageBitmap(b) }
            }
        }
    }

    private fun fetch(ctx: Context, url: String, px: Int): Bitmap? {
        val uri = Uri.parse(url)
        return when (uri.scheme) {
            "http", "https" -> {
                val dir = File(ctx.cacheDir, "thumbs").apply { mkdirs() }
                val f = File(dir, sha(url))
                if (!f.exists() || f.length() == 0L) f.writeBytes(Http.getBytes(url, NpDownloader.UA_FIREFOX, 12000, 4_000_000))
                decodeFile(f, px)
            }
            "file" -> uri.path?.let { decodeFile(File(it), px) }
            "content" -> if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, Size(px, px), null)
            else ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            else -> null
        }
    }

    private fun decodeFile(f: File, px: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun cover(ctx: Context, sizeDp: Int, radiusDp: Int = 8): ImageView = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = Ui.rounded(ctx, Pal.c(0xFF1B2638), radiusDp)
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
        layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, sizeDp), Ui.dp(ctx, sizeDp))
    }
}

sealed class Row {
    class TrackRow(val t: Track) : Row()
    class Info(val text: String, val action: (() -> Unit)? = null) : Row()
    object Loading : Row()
    class Filters(val selected: Int, val onSelect: (Int) -> Unit, val onScan: () -> Unit) : Row()
    class Job(val j: DownloadJob) : Row()
}

class MusicAdapter(
    private val onTrack: (Track) -> Unit,
    private val onMore: (Track, View) -> Unit,
    private val onCancel: (DownloadJob) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var rows: List<Row> = emptyList()
    var playingId: String? = null

    fun submit(list: List<Row>) { rows = list; notifyDataSetChanged() }

    fun setPlaying(id: String?) { if (id != playingId) { playingId = id; notifyDataSetChanged() } }

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int) = when (rows[position]) {
        is Row.TrackRow -> 0
        is Row.Info -> 1
        is Row.Loading -> 2
        is Row.Filters -> 3
        is Row.Job -> 4
    }

    private class VH(v: View) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        val root = when (viewType) {
            0 -> trackView(ctx)
            1 -> Ui.label(ctx, "", 14f, Pal.MUTED).apply { gravity = Gravity.CENTER; setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 28), Ui.dp(ctx, 16), Ui.dp(ctx, 28)) }
            2 -> ProgressBar(ctx).apply { setPadding(0, Ui.dp(ctx, 16), 0, Ui.dp(ctx, 16)) }
            3 -> HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 8)) }) }
            else -> jobView(ctx)
        }
        root.layoutParams = RecyclerView.LayoutParams(-1, -2)
        return VH(root)
    }

    // ---------- baris lagu ----------
    private fun trackView(ctx: Context): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 6), Ui.dp(ctx, 4), Ui.dp(ctx, 6))
            isClickable = true
        }
        row.addView(Img.cover(ctx, 52).apply { id = 1 })
        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(ctx, 12), 0, Ui.dp(ctx, 8), 0) }
        mid.addView(Ui.label(ctx, "", 15f, Pal.TEXT, true).apply { id = 2; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        mid.addView(Ui.label(ctx, "", 12f, Pal.MUTED).apply { id = 3; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Icons.view(ctx, Icons.MORE, 16f, Pal.MUTED, "Menu").apply { id = 4 })
        return row
    }

    private fun jobView(ctx: Context): LinearLayout {
        val c = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10)) }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.label(ctx, "", 14f, Pal.TEXT, true).apply { id = 2; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
        col.addView(Ui.label(ctx, "", 12f, Pal.MUTED).apply { id = 3; maxLines = 2 })
        head.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(Icons.view(ctx, Icons.CLOSE, 14f, Pal.MUTED, "Batalkan").apply { id = 4 })
        c.addView(head)
        c.addView(ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { id = 5; max = 100 }, LinearLayout.LayoutParams(-1, Ui.dp(ctx, 8)).apply { topMargin = Ui.dp(ctx, 6) })
        return c
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
        val v = h.itemView
        when (val r = rows[position]) {
            is Row.TrackRow -> {
                val t = r.t
                Img.load(v.findViewById(1), t.thumb)
                val title = v.findViewById<TextView>(2)
                title.text = t.title
                title.setTextColor(if (t.id == playingId) Pal.CYAN else Pal.TEXT)
                val parts = ArrayList<String>()
                if (t.official) parts.add("✓ Resmi")
                if (t.artist.isNotBlank()) parts.add(t.artist)
                if (t.durationSec > 0) parts.add(fmtTime(t.durationSec))
                if (t.source == Track.SRC_DOWNLOAD) parts.add("Diunduh")
                v.findViewById<TextView>(3).text = parts.joinToString(" • ")
                v.setOnClickListener { onTrack(t) }
                v.findViewById<View>(4).setOnClickListener { onMore(t, it) }
            }
            is Row.Info -> {
                (v as TextView).text = r.text
                v.setOnClickListener(if (r.action != null) View.OnClickListener { r.action.invoke() } else null)
                v.isClickable = r.action != null
            }
            is Row.Loading -> {}
            is Row.Filters -> {
                val box = (v as HorizontalScrollView).getChildAt(0) as LinearLayout
                box.removeAllViews()
                val ctx = v.context
                listOf("Semua", "Unduhan", "Disimpan", "Perangkat").forEachIndexed { i, name ->
                    box.addView(Ui.chip(ctx, name, i == r.selected).apply { setOnClickListener { r.onSelect(i) } },
                        LinearLayout.LayoutParams(-2, -2).apply { rightMargin = Ui.dp(ctx, 8) })
                }
                box.addView(Ui.chip(ctx, "⟳ Pindai perangkat").apply { setOnClickListener { r.onScan() } })
            }
            is Row.Job -> {
                val j = r.j
                v.findViewById<TextView>(2).text = "${j.track.artist} — ${j.track.title}"
                v.findViewById<TextView>(3).text = "${j.option.label} • ${j.message}"
                val bar = v.findViewById<ProgressBar>(5)
                bar.progress = j.progress
                bar.visibility = if (j.state == DlState.RUNNING || j.state == DlState.QUEUED) View.VISIBLE else View.GONE
                val x = v.findViewById<View>(4)
                x.visibility = if (j.state == DlState.RUNNING || j.state == DlState.QUEUED) View.VISIBLE else View.GONE
                x.setOnClickListener { onCancel(j) }
            }
        }
    }
}

package com.dlmsmini.equalizer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Fader vertikal. Nilai dalam satuan half-dB: -24..24 = -12.0..+12.0 dB. */
internal class VerticalFader(context: Context) : View(context) {
    var value: Int = 0
        private set
    var onValueChanged: ((Int, Boolean) -> Unit)? = null
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBFC5D0.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f
    }
    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    fun setValue(newValue: Int, fromUser: Boolean = false) {
        val v = newValue.coerceIn(-24, 24)
        if (value != v) {
            value = v
            invalidate()
            onValueChanged?.invoke(v, fromUser)
        } else if (fromUser) onValueChanged?.invoke(v, true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val top = d(8f)
        val bottom = height - d(8f)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        val y = center - (value / 24f) * half
        val rail = RectF(cx - d(5f), top, cx + d(5f), bottom)
        trackPaint.shader = LinearGradient(rail.left, 0f, rail.right, 0f,
            intArrayOf(0xFF050A14.toInt(), 0xFF25364E.toInt(), 0xFF050A14.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rail, d(5f), d(5f), trackPaint)
        fillPaint.color = 0xFF168DFF.toInt()
        if (value >= 0) canvas.drawRoundRect(RectF(cx - d(3f), y, cx + d(3f), center), d(3f), d(3f), fillPaint)
        else canvas.drawRoundRect(RectF(cx - d(3f), center, cx + d(3f), y), d(3f), d(3f), fillPaint)
        val thumbHalf = (width * 0.43f).coerceAtMost(d(12f)).coerceAtLeast(d(5f))
        val thumb = RectF(cx - thumbHalf, y - d(10f), cx + thumbHalf, y + d(10f))
        thumbPaint.shader = LinearGradient(thumb.left, thumb.top, thumb.right, thumb.bottom,
            intArrayOf(0xFFF0F1F4.toInt(), 0xFFBFC3CC.toInt(), 0xFFE4E6EA.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(thumb, d(11f), d(11f), thumbPaint)
        canvas.drawRoundRect(thumb, d(11f), d(11f), borderPaint)
    }

    private fun updateFromY(y: Float) {
        val top = d(8f)
        val bottom = height - d(8f)
        val clamped = y.coerceIn(top, bottom)
        val center = (top + bottom) / 2f
        val half = (bottom - top) / 2f
        setValue((24f * (center - clamped) / half).roundToInt(), true)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                updateFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                updateFromY(event.y)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

/** Tampilan spektrum 36 batang. */
internal class SpectrumView(context: Context) : View(context) {
    private var bars = FloatArray(36)
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x4436AFFF; style = Paint.Style.FILL }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x223B82C5; strokeWidth = 1f }

    fun setBars(newBars: FloatArray) { bars = newBars; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (bars.isEmpty() || width <= 0) return
        for (line in 1..3) {
            val y = height * line / 4f
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
        }
        val gap = width * 0.012f
        val barWidth = (width - gap * (bars.size - 1)) / bars.size
        val base = height * 0.9f
        bars.forEachIndexed { i, level ->
            val h = (height * 0.78f * level.coerceIn(0.04f, 1f)).coerceAtLeast(4f)
            val left = i * (barWidth + gap)
            val rect = RectF(left, base - h, left + barWidth, base)
            glowPaint.color = if (i > bars.size * 0.72f) 0x553F6BFF else 0x4436AFFF
            barPaint.shader = LinearGradient(0f, base - h, 0f, base,
                intArrayOf(if (i > bars.size * 0.72f) 0xFF9B63FF.toInt() else 0xFF20D6E8.toInt(), 0xFF167CFF.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(left - 1, base - h - 2, left + barWidth + 1, base + 1), 4f, 4f, glowPaint)
            canvas.drawRoundRect(rect, 3f, 3f, barPaint)
        }
    }
}

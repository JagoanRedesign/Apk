package com.dlmsmini.equalizer

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Pengaturan aplikasi DLMS Mini Equalizer. */
class SettingsActivity : AppCompatActivity() {

    private val pipelineNames = arrayOf(
        "Global (sesi 0)",
        "Per sesi aplikasi",
        "Maksimum (global + per sesi)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.init(this)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(c(0xFF121214))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(16), dp(16), dp(12))
        }
        val back = TextView(this).apply {
            text = "←"; textSize = 26f; setTextColor(c(0xFFFFFFFF))
            setPadding(dp(14), dp(2), dp(18), dp(2)); isClickable = true
        }
        back.setOnClickListener { finish() }
        bar.addView(back)
        bar.addView(label("Pengaturan", 24f, c(0xFFFFFFFF)))
        root.addView(bar)

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), dp(24))
        }
        val title = label("Umum", 14f, c(0xFFD0D0DA), true)
        title.setPadding(dp(6), dp(8), 0, dp(10))
        list.addView(title)

        addRow(list, switchRow(
            "Layanan latar belakang",
            "Equalizer dan limiter tetap berlaku saat aplikasi ditutup. Menampilkan notifikasi.",
            AppSettings.backgroundService
        ) { on ->
            AppSettings.backgroundService = on
            if (on) EffectService.start(this) else EffectService.stop(this)
        })

        addRow(list, infoRow(
            "Pipeline audio",
            pipelineNames[AppSettings.pipeline]
        ) { choosePipeline() })

        addRow(list, switchRow(
            "Tampilkan spektrum",
            "Analisis spektrum memakai izin rekam audio dan sedikit baterai.",
            AppSettings.showSpectrum
        ) { on -> AppSettings.showSpectrum = on })

        addRow(list, infoRow(
            "Pita Equalizer",
            "10 band (dipetakan ke jumlah band yang disediakan perangkat)"
        ) { })

        addRow(list, infoRow(
            "Reset semua pengaturan",
            "Kembalikan EQ, limiter, dan pengaturan ke bawaan. Preset buatan sendiri tetap tersimpan."
        ) { confirmReset() })

        addRow(list, infoRow("Tentang aplikasi", "Versi, fitur, dan catatan penggunaan") {
            startActivity(Intent(this, AboutActivity::class.java))
        })

        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addRow(parent: LinearLayout, row: View) {
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) })
    }

    private fun textColumn(title: String, subtitle: String): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 17f, c(0xFFEDEDF3), true))
        col.addView(label(subtitle, 14f, c(0xFFB6B6C2)).apply { setPadding(0, dp(4), 0, 0) })
        return col
    }

    private fun infoRow(title: String, subtitle: String, onClick: () -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(c(0xFF2A2A2E), 14)
            isClickable = true
        }
        card.addView(textColumn(title, subtitle))
        card.setOnClickListener { onClick() }
        return card
    }

    private fun switchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(c(0xFF2A2A2E), 14)
        }
        card.addView(textColumn(title, subtitle), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(12) })
        val sw = Switch(this).apply {
            isChecked = checked
            thumbTintList = ColorStateList.valueOf(c(0xFF9DAFC9))
        }
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        card.addView(sw)
        card.setOnClickListener { sw.toggle() }
        return card
    }

    private fun choosePipeline() {
        AlertDialog.Builder(this).setTitle("Pipeline audio")
            .setSingleChoiceItems(pipelineNames, AppSettings.pipeline) { dialog, which ->
                AppSettings.pipeline = which
                EffectEngine.applyPipeline()
                dialog.dismiss()
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this).setTitle("Reset pengaturan")
            .setMessage("Kembalikan semua pengaturan ke bawaan?")
            .setPositiveButton("Reset") { _, _ ->
                AppSettings.resetAll()
                EffectEngine.applyPipeline()
                EffectEngine.applyEq()
                EffectEngine.applyLimiter()
                setResult(RESULT_OK)
                Toast.makeText(this, "Pengaturan dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

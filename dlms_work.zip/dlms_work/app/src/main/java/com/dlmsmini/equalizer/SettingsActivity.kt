package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Layar Pengaturan aplikasi. Perubahan langsung disimpan; layanan & layar utama menyesuaikan. */
class SettingsActivity : AppCompatActivity() {
    private class Row(val card: LinearLayout, val sw: Switch?)

    private lateinit var prefs: SharedPreferences
    private var pipelineValue: TextView? = null
    private var bandsValue: TextView? = null
    private var appsRow: Row? = null
    private var stabilizeRow: Row? = null

    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) writeBackup(uri)
    }
    private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readBackup(uri)
    }

    private val bg = 0xFF1B1B1D.toInt()
    private val cardBg = 0xFF343437.toInt()
    private val titleColor = 0xFFE6E1E9.toInt()
    private val descColor = 0xFFCAC4D0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Store.prefs(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshDependents()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        })
        bar.addView(Ui.label(this, "Pengaturan", 28f, titleColor))
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // ---- Umum ----
        list.addView(plainCard("Cara penggunaan", "Panduan langkah demi langkah: mulai cepat, EQ, limiter, efek, preset, spectrum, Bluetooth, dan pemecahan masalah.") {
            startActivity(Intent(this, HowToActivity::class.java))
        })
        list.addView(sectionTitle("Umum"))

        list.addView(switchCard(
            "Kekuatan Penuh - Dinamis Diperluas",
            "Modalitas lanjutan untuk pengguna terampil: rentang fader diperluas dari ±12 dB menjadi ±22 dB. " +
                "Penguatan penuh terasa pada pipeline Maksimum; pada pipeline Standar dibatasi hardware. " +
                "Aktifkan Limiter untuk membantu mengelola distorsi yang akhirnya terjadi.",
            Store.KEY_FULL_POWER, false,
            guard = { checked, commit, revert ->
                if (!checked) commit() else AlertDialog.Builder(this)
                    .setTitle("Aktifkan Kekuatan Penuh?")
                    .setMessage("Rentang ±22 dB dapat menyebabkan distorsi dan merusak speaker atau headphone jika volume terlalu tinggi. Gunakan dengan hati-hati dan pertimbangkan mengaktifkan Limiter.")
                    .setPositiveButton("Aktifkan") { _, _ -> commit() }
                    .setNegativeButton("Batal") { _, _ -> revert() }
                    .setOnCancelListener { revert() }
                    .show()
            }
        ).card)

        list.addView(bandsCard())
        list.addView(eqLimitCard())
        list.addView(pipelineCard())
        list.addView(crossoverCard())
        list.addView(switchCard(
            "Tukar LOW/HIGH kiri-kanan",
            "Mode 2-Way: bawaan kiri = LOW dan kanan = HIGH. Aktifkan untuk membalik: kiri = HIGH dan kanan = LOW (berguna bila kabel atau driver terpasang terbalik).",
            Store.KEY_XO_SWAP, false
        ).card)
        list.addView(clipCard())

        list.addView(switchCard(
            "Spectrum analyzer",
            "Tampilkan analisis spektrum audio secara langsung. Membutuhkan izin rekam audio dan sedikit baterai tambahan.",
            Store.KEY_SPECTRUM, true
        ).card)

        list.addView(switchCard(
            "Layar tetap menyala",
            "Cegah layar mati selama aplikasi dibuka.",
            Store.KEY_KEEP_SCREEN, false
        ).card)

        // ---- Latar belakang ----
        list.addView(sectionTitle("Latar belakang"))

        list.addView(switchCard(
            "Aktif di latar belakang",
            "Jalankan layanan dengan notifikasi agar equalizer dan limiter tetap bekerja saat aplikasi ditutup. " +
                "Matikan untuk menghentikan efek begitu aplikasi ditutup.",
            Store.KEY_BG, true
        ).card)

        list.addView(plainCard(
            "Pengecualian optimasi baterai",
            "Beberapa ponsel menghentikan layanan latar belakang untuk menghemat baterai. Izinkan DLMS Mini Equalizer berjalan tanpa pembatasan agar efek tidak mati sendiri."
        ) { openBatterySettings() })
        list.addView(plainCard(
            "Pengaturan vendor (${VendorGuide.family().title})",
            "Langkah khusus untuk ponsel Anda agar layanan tidak dimatikan dan efek audio tidak ditimpa. Ketuk untuk membuka layar mulai otomatis."
        ) {
            if (!VendorGuide.openAutostart(this)) Toast.makeText(this, "Layar vendor tidak ditemukan; dibuka info aplikasi", Toast.LENGTH_LONG).show()
        })

        // ---- Kompatibilitas Audio ----
        list.addView(sectionTitle("Kompatibilitas Audio"))
        list.addView(Ui.label(this, "Hanya berfungsi dengan pemutar musik tertentu.", 15f, descColor)
            .apply { setPadding(dp(8), 0, dp(8), 0) })
        list.addView(Ui.label(this, "Lihat daftar", 15f, 0xFF4D8DF7.toInt()).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(8), dp(2), dp(8), dp(12))
            isClickable = true
            setOnClickListener { showCompatList() }
        })

        list.addView(switchCard(
            "Mode Sesi Aplikasi",
            "Menerapkan EQ hanya pada aplikasi yang sedang memutar musik. Diperlukan jika Anda memakai Android Auto atau Bluetooth dengan protokol LDAC atau aptX. " +
                "Saat aktif, Mix Global dimatikan.",
            Store.KEY_SESSION_MODE, false,
            guard = { checked, commit, revert ->
                if (checked) commit() else AlertDialog.Builder(this)
                    .setTitle("Beralih ke Mix Global?")
                    .setMessage(
                        "Mode Sesi Aplikasi akan dinonaktifkan dan DLMS Mini Equalizer akan menyeimbangkan seluruh output audio Android secara langsung (Mix Global).\n\n" +
                            "Pada beberapa perangkat, restart disarankan (tetapi tidak wajib) untuk peralihan yang paling optimal."
                    )
                    .setPositiveButton("Beralih ke Mix Global") { _, _ -> commit() }
                    .setNegativeButton("Pertahankan App Session") { _, _ -> revert() }
                    .setOnCancelListener { revert() }
                    .show()
            },
            onChanged = { refreshDependents() }
        ).card)

        appsRow = plainRow(
            "Kelola aplikasi terdeteksi",
            "Lihat dan edit aplikasi mana yang diproses equalizer."
        ) { startActivity(Intent(this, AppsActivity::class.java)) }
        list.addView(appsRow!!.card)

        stabilizeRow = switchCard(
            "Stabilkan saat peluncuran",
            "Jika musik sudah berputar saat layanan dimulai, lewati satu lagu agar Mode Sesi Aplikasi langsung terkunci ke equalizer. (Disarankan)",
            Store.KEY_STABILIZE, true
        )
        list.addView(stabilizeRow!!.card)

        // ---- Lainnya ----
        list.addView(sectionTitle("Lainnya"))

        list.addView(plainCard("Diagnostik & kompatibilitas", "Dukungan efek ponsel, status efek terverifikasi, perangkat audio, vendor, dan panduan uji ganti headset/Bluetooth/speaker.") {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        })
        list.addView(plainCard("Backup pengaturan", "Simpan seluruh pengaturan (EQ, limiter, efek, volume, preset, dll.) ke berkas atau salin sebagai teks.") {
            showBackupMenu()
        })
        list.addView(plainCard("Restore pengaturan", "Pulihkan pengaturan dari berkas backup atau teks. Pengaturan saat ini akan diganti.") {
            showRestoreMenu()
        })
        list.addView(plainCard("Reset pengaturan", "Kembalikan semua pengaturan ke bawaan. Pilih apakah preset kustom ikut dihapus.") {
            confirmReset()
        })
        list.addView(plainCard("Tentang aplikasi", "DLMS Mini Equalizer ${versionName()}") {
            startActivity(Intent(this, AboutActivity::class.java))
        })

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.fitSystemBars(root)
        setContentView(root)
        refreshDependents()
    }

    private fun refreshDependents() {
        val on = prefs.getBoolean(Store.KEY_SESSION_MODE, false)
        appsRow?.let { setRowEnabled(it, on) }
        stabilizeRow?.let { setRowEnabled(it, on) }
    }

    private fun setRowEnabled(row: Row, on: Boolean) {
        row.card.isEnabled = on
        row.card.alpha = if (on) 1f else 0.45f
        row.sw?.isEnabled = on
    }

    private fun versionName(): String = try {
        "v" + (packageManager.getPackageInfo(packageName, 0).versionName ?: "-")
    } catch (_: Exception) {
        ""
    }

    private fun sectionTitle(text: String): TextView =
        Ui.label(this, text, 15f, 0xFFD0BCFF.toInt(), true).apply { setPadding(dp(8), dp(20), dp(8), dp(10)) }

    private fun cardBase(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = Ui.rounded(this@SettingsActivity, cardBg, 18)
        setPadding(dp(22), dp(18), dp(18), dp(18))
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
    }

    private fun textBlock(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(Ui.label(this@SettingsActivity, title, 18f, titleColor, true))
        if (desc.isNotEmpty()) addView(Ui.label(this@SettingsActivity, desc, 15f, descColor).apply {
            setPadding(0, dp(6), 0, 0)
            setLineSpacing(0f, 1.1f)
        })
    }

    private fun switchCard(
        title: String, desc: String, key: String, default: Boolean,
        guard: ((Boolean, () -> Unit, () -> Unit) -> Unit)? = null,
        onChanged: (() -> Unit)? = null
    ): Row {
        val card = cardBase()
        card.addView(textBlock(title, desc), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { isChecked = prefs.getBoolean(key, default) }
        var suppress = false
        sw.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            val commit: () -> Unit = {
                prefs.edit().putBoolean(key, checked).apply()
                onChanged?.invoke()
            }
            val revert: () -> Unit = {
                suppress = true
                sw.isChecked = !checked
                suppress = false
            }
            if (guard != null) guard(checked, commit, revert) else commit()
        }
        card.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        card.setOnClickListener { sw.toggle() }
        return Row(card, sw)
    }


    // ---------- Pita Equalizer ----------
    private fun currentBands(): Int =
        prefs.getInt(Store.KEY_BANDS, Bands.DEFAULT).let { if (Bands.isValid(it)) it else Bands.DEFAULT }

    private fun bandsCard(): View {
        val card = cardBase()
        val block = textBlock("Pita Equalizer", "")
        val value = Ui.label(this, "${currentBands()} Bands", 15f, descColor).apply { setPadding(0, dp(6), 0, 0) }
        bandsValue = value
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { showBandsDialog() }
        return card
    }

    private fun bandHint(n: Int): String = when (n) {
        5 -> "Sederhana: koreksi cepat bass, tengah, dan treble."
        10 -> "Seimbang: susunan standar 31 Hz – 16 kHz."
        13 -> "Lebih rinci di menengah–tinggi untuk vokal dan instrumen."
        else -> "Hibrida: bass ringkas, menengah & tinggi dirapatkan untuk presisi."
    }

    private fun showBandsDialog() {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        var selected = currentBands()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(this@SettingsActivity, 0xFF232428.toInt(), 28)
            setPadding(dp(24), dp(26), dp(24), dp(20))
        }
        root.addView(Ui.label(this, "Pita Equalizer", 28f, Color.WHITE).apply { setPadding(dp(6), 0, 0, dp(10)) })

        val hint = Ui.label(this, bandHint(selected), 13f, descColor).apply { setPadding(dp(6), 0, dp(6), dp(6)) }
        val radios = mutableListOf<Pair<Int, RadioButton>>()
        Bands.COUNTS.forEach { n ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(16), dp(6), dp(16))
                isClickable = true
            }
            row.addView(Ui.label(this, "$n Bands", 20f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            val rb = RadioButton(this).apply {
                isChecked = n == selected
                buttonTintList = ColorStateList.valueOf(0xFFD0BCFF.toInt())
                isClickable = false
                isFocusable = false
            }
            row.addView(rb)
            row.setOnClickListener {
                selected = n
                radios.forEach { (k, r) -> r.isChecked = k == selected }
                hint.text = bandHint(selected)
            }
            radios.add(n to rb)
            root.addView(row)
        }
        root.addView(hint)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val info = Ui.label(this, "Info lebih lanjut", 16f, 0xFF4D8DF7.toInt(), true).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            setOnClickListener { showBandsInfo() }
        }
        actions.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val applyBtn = TextView(this).apply {
            text = "Terapkan"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = Ui.rounded(this@SettingsActivity, 0xFF4285F4.toInt(), 28)
            setPadding(dp(26), dp(16), dp(26), dp(16))
            isClickable = true
        }
        applyBtn.setOnClickListener {
            val old = currentBands()
            if (selected != old) {
                Bands.switchLayout(prefs, old, selected)
                bandsValue?.text = "$selected Bands"
                Toast.makeText(this, "Pita equalizer: $selected band (kurva disesuaikan)", Toast.LENGTH_SHORT).show()
            }
            dlg.dismiss()
        }
        actions.addView(applyBtn)
        root.addView(actions)

        dlg.setContentView(root)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dlg.show()
    }

    private fun showBandsInfo() {
        val msg = "Pita Equalizer menentukan berapa banyak slider frekuensi yang tersedia.\n\n" +
            "• 5 Bands — sederhana, untuk koreksi cepat.\n" +
            "• 10 Bands — seimbang, susunan standar.\n" +
            "• 13 Bands — tambahan band di menengah–tinggi untuk vokal dan instrumen.\n" +
            "• 21 Bands (hibrida) — bukan sekadar lebih banyak slider, tetapi tata letak yang cerdas:\n\n" +
            "Bass bertenaga dan alami: frekuensi rendah dibuat ringkas (31, 63, 125, 250 Hz) sehingga kehangatan dan \"dentuman\" didapat hanya dengan beberapa gerakan, tanpa suara keruh atau menggelegar.\n\n" +
            "Detail HD di menengah dan tinggi: jumlah band dilipatgandakan pada rentang yang paling peka bagi telinga, jadi vokal bisa dibuat menonjol atau gitar akustik tampil jernih dengan presisi tinggi.\n\n" +
            "Titik optimal: 5 atau 10 band sering terlalu terbatas untuk mendengarkan serius, sedangkan 31 band profesional bisa terlalu rumit. 21 band hibrida tetap intuitif di bass, sangat presisi di menengah–tinggi, dan transparan sehingga suara tetap alami.\n\n" +
            "Catatan:\n" +
            "• Saat jumlah band diganti, kurva saat ini disesuaikan otomatis. Preset tersimpan juga ikut menyesuaikan.\n" +
            "• 13 dan 21 band memakai tampilan yang bisa digeser ke samping.\n" +
            "• Presisi penuh 13 dan 21 band terasa pada pipeline Maksimum (Android 9+). Pada pipeline Standar, band dipetakan ke band hardware perangkat (biasanya sekitar 5)."
        AlertDialog.Builder(this).setTitle("Pita Equalizer").setMessage(msg).setPositiveButton("Oke", null).show()
    }

    /** Kartu dengan SeekBar: nilai ditampilkan langsung, disimpan saat jari diangkat. */
    private fun seekCard(
        title: String, desc: String, steps: Int, progress: Int,
        format: (Int) -> String, onCommit: (Int) -> Unit
    ): View {
        val card = cardBase()
        val block = textBlock(title, desc)
        val value = Ui.label(this, format(progress), 15f, Pal.CYAN, true).apply { setPadding(0, dp(8), 0, 0) }
        block.addView(value)
        val tint = ColorStateList.valueOf(0xFF00CFFF.toInt())
        val bar = SeekBar(this).apply {
            max = steps
            this.progress = progress
            progressTintList = tint
            thumbTintList = tint
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { value.text = format(p) }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) { onCommit(sb?.progress ?: 0) }
            })
        }
        block.addView(bar, LinearLayout.LayoutParams(-1, -2))
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.isClickable = false
        return card
    }

    private fun crossoverCard(): View = seekCard(
        "Crossover 2-Way",
        "Titik pisah LOW/HIGH sesungguhnya (filter crossover per kanal, 40 Hz – 8 kHz). Kiri membawa LOW (di bawah titik ini), kanan membawa HIGH. " +
            "Cocok untuk sistem dua jalur dengan driver kiri/kanan terpisah, bukan untuk mendengarkan stereo biasa. " +
            "Perangkat tanpa dukungan crossover akan memakai pendekatan EQ atau 1-Way (lihat Diagnostik).",
        Store.XO_STEPS, Store.progressFromCrossover(Store.loadCrossover(prefs)),
        { "${Store.crossoverFromProgress(it)} Hz" }
    ) { prefs.edit().putInt(Store.KEY_CROSSOVER, Store.crossoverFromProgress(it)).apply() }

    private fun eqLimitCard(): View = seekCard(
        "Batas EQ",
        "Rentang fader equalizer: −N dB sampai +N dB (3–12 dB, bawaan ±12 dB). Dipakai bila Kekuatan Penuh mati.",
        9, prefs.getInt(Store.KEY_EQ_LIMIT, 12).coerceIn(3, 12) - 3,
        { "±${it + 3} dB" }
    ) { prefs.edit().putInt(Store.KEY_EQ_LIMIT, it + 3).apply() }

    private fun clipName(m: Int) = when (m) {
        Store.CLIP_OFF -> "Mati"
        Store.CLIP_HEADROOM -> "Limiter pengaman + headroom otomatis"
        else -> "Limiter pengaman"
    }

    private fun clipCard(): View {
        val card = cardBase()
        val block = textBlock(
            "Proteksi clipping",
            "Mencegah suara pecah saat total penguatan (EQ, pre-amp, loudness, bass, tone) melebihi batas. " +
                "Limiter pengaman aktif otomatis bila Limiter Anda mati dan ada boost; headroom menurunkan gain masukan 50% dari puncak EQ (maks 6 dB)."
        )
        val value = Ui.label(this, clipName(prefs.getInt(Store.KEY_CLIP_MODE, Store.CLIP_LIMITER)), 15f, Pal.CYAN, true)
            .apply { setPadding(0, dp(8), 0, 0) }
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener {
            val modes = intArrayOf(Store.CLIP_OFF, Store.CLIP_LIMITER, Store.CLIP_HEADROOM)
            val items = modes.map { clipName(it) }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Proteksi clipping")
                .setSingleChoiceItems(items, prefs.getInt(Store.KEY_CLIP_MODE, Store.CLIP_LIMITER).coerceIn(0, 2)) { d, which ->
                    prefs.edit().putInt(Store.KEY_CLIP_MODE, modes[which]).apply()
                    value.text = items[which]
                    d.dismiss()
                }.setNegativeButton("Batal", null).show()
        }
        return card
    }

    // ---------- Backup & restore ----------

    private fun backupName(): String =
        "dlms-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"

    private fun showBackupMenu() {
        AlertDialog.Builder(this).setTitle("Backup pengaturan")
            .setItems(arrayOf("Simpan ke berkas…", "Salin ke clipboard", "Bagikan sebagai teks")) { _, which ->
                when (which) {
                    0 -> try { createBackup.launch(backupName()) } catch (e: Exception) {
                        Toast.makeText(this, "Tidak dapat membuka penyimpanan: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                    1 -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("DLMS backup", Backup.export(this)))
                        Toast.makeText(this, "Backup disalin ke clipboard", Toast.LENGTH_SHORT).show()
                    }
                    else -> startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, Backup.export(this)),
                        "Bagikan backup"
                    ))
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun writeBackup(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri, "wt")?.use { it.write(Backup.export(this).toByteArray(Charsets.UTF_8)) }
                ?: throw IllegalStateException("tidak dapat menulis berkas")
            Toast.makeText(this, "Backup disimpan", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Backup gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showRestoreMenu() {
        AlertDialog.Builder(this).setTitle("Restore pengaturan")
            .setItems(arrayOf("Pilih berkas…", "Tempel teks backup")) { _, which ->
                if (which == 0) {
                    try { openBackup.launch(arrayOf("application/json", "text/plain", "*/*")) } catch (e: Exception) {
                        Toast.makeText(this, "Tidak dapat membuka penyimpanan: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val input = EditText(this).apply { hint = "Tempel isi backup di sini"; minLines = 4; maxLines = 8; textSize = 12f }
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.let { t ->
                        if (t.contains(Backup.FORMAT)) input.setText(t)
                    }
                    AlertDialog.Builder(this).setTitle("Tempel backup").setView(input)
                        .setPositiveButton("Pulihkan") { _, _ -> confirmRestore(input.text.toString()) }
                        .setNegativeButton("Batal", null).show()
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun readBackup(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: throw IllegalStateException("tidak dapat membaca berkas")
            confirmRestore(text)
        } catch (e: Exception) {
            Toast.makeText(this, "Membaca berkas gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmRestore(text: String) {
        AlertDialog.Builder(this).setTitle("Pulihkan pengaturan?")
            .setMessage("Seluruh pengaturan saat ini akan diganti dengan isi backup.")
            .setPositiveButton("Pulihkan") { _, _ ->
                val r = Backup.restore(this, text)
                Toast.makeText(this, r.message, Toast.LENGTH_LONG).show()
                if (r.ok) recreate()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun pipelineName(p: Int) = if (p == Store.PIPE_MAX) "Maksimum" else "Standar"

    private fun pipelineCard(): View {
        val card = cardBase()
        val block = textBlock("Pipeline audio", "")
        val value = Ui.label(this, pipelineName(prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)), 15f, descColor)
            .apply { setPadding(0, dp(6), 0, 0) }
        pipelineValue = value
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener {
            val items = arrayOf(
                "Standar — Equalizer sistem Android (band hardware dipetakan ke 10 band)",
                "Maksimum — 10 band presisi lewat DynamicsProcessing (Android 9+)"
            )
            val current = prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
            AlertDialog.Builder(this)
                .setTitle("Pipeline audio")
                .setSingleChoiceItems(items, current) { dialog, which ->
                    if (which == Store.PIPE_MAX && Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                        Toast.makeText(this, "Pipeline Maksimum membutuhkan Android 9+", Toast.LENGTH_SHORT).show()
                    } else {
                        prefs.edit().putInt(Store.KEY_PIPELINE, which).apply()
                        pipelineValue?.text = pipelineName(which)
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        return card
    }

    private fun plainRow(title: String, desc: String, onClick: () -> Unit): Row {
        val card = cardBase()
        card.addView(textBlock(title, desc), LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { onClick() }
        return Row(card, null)
    }

    private fun plainCard(title: String, desc: String, onClick: () -> Unit): View = plainRow(title, desc, onClick).card

    private fun showCompatList() {
        val seen = AppStore.detected(this)
        val seenText = if (seen.isEmpty()) "belum ada" else seen.joinToString("\n") { "• $it" }
        val msg = "Pemutar musik yang umumnya mendukung Mode Sesi Aplikasi:\n" +
            "• YouTube Music\n• Spotify\n\n" +
            "Pemutar lain yang mengirim sinyal sesi audio standar Android juga dapat bekerja. " +
            "Tidak semua pemutar didukung: sebagian tidak mengikuti standar API audio Android atau menolak equalizer eksternal.\n\n" +
            "Tips: buka DLMS Mini Equalizer lebih dulu, lalu buka aplikasi musik dan tekan putar/jeda.\n\n" +
            "Sudah terdeteksi di perangkat ini:\n$seenText"
        AlertDialog.Builder(this).setTitle("Pemutar yang didukung").setMessage(msg).setPositiveButton("Oke", null).show()
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Pengaturan baterai tidak dapat dibuka", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun confirmReset() {
        fun doReset(includePresets: Boolean) {
            val editor = prefs.edit()
            prefs.all.keys.filter { includePresets || !it.startsWith("custom_") }.forEach { editor.remove(it) }
            editor.commit()
            Toast.makeText(this, if (includePresets) "Semua pengaturan dan preset direset" else "Pengaturan direset", Toast.LENGTH_SHORT).show()
            recreate()
        }
        AlertDialog.Builder(this)
            .setTitle("Reset semua pengaturan")
            .setMessage("EQ, limiter, efek, volume L/R, master, spectrum, dan pengaturan aplikasi dikembalikan ke bawaan. Preset kustom dapat dipertahankan atau ikut dihapus.")
            .setPositiveButton("Reset (simpan preset)") { _, _ -> doReset(false) }
            .setNeutralButton("Reset total + preset") { _, _ -> doReset(true) }
            .setNegativeButton("Batal", null)
            .show()
    }
}

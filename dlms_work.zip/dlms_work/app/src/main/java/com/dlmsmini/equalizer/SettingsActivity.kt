package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Layar Pengaturan aplikasi. Perubahan langsung disimpan dan dibaca MainActivity saat kembali. */
class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private var pipelineValue: TextView? = null

    private val bg = 0xFF1B1B1D.toInt()
    private val cardBg = 0xFF343437.toInt()
    private val titleColor = 0xFFE6E1E9.toInt()
    private val descColor = 0xFFCAC4D0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Store.prefs(this)
        buildUi()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        val back = TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        }
        bar.addView(back)
        bar.addView(Ui.label(this, "Pengaturan", 28f, titleColor))
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        list.addView(sectionTitle("Umum"))

        list.addView(switchCard(
            "Kekuatan Penuh - Dinamis Diperluas",
            "Modalitas lanjutan untuk pengguna terampil: rentang fader diperluas dari ±12 dB menjadi ±22 dB. " +
                "Penguatan penuh terasa pada pipeline Maksimum; pada pipeline Standar dibatasi hardware. " +
                "Aktifkan Limiter untuk membantu mengelola distorsi yang akhirnya terjadi.",
            Store.KEY_FULL_POWER, false, confirmOn = true
        ))

        list.addView(pipelineCard())

        list.addView(switchCard(
            "Spectrum analyzer",
            "Tampilkan analisis spektrum audio secara langsung. Membutuhkan izin rekam audio dan sedikit baterai tambahan.",
            Store.KEY_SPECTRUM, true
        ))

        list.addView(switchCard(
            "Layar tetap menyala",
            "Cegah layar mati selama aplikasi dibuka.",
            Store.KEY_KEEP_SCREEN, false
        ))

        list.addView(sectionTitle("Lainnya"))

        list.addView(plainCard("Reset pengaturan", "Kembalikan equalizer, limiter, dan pengaturan aplikasi ke bawaan. Preset kustom tetap tersimpan.") {
            confirmReset()
        })
        list.addView(plainCard("Tentang aplikasi", "DLMS Mini Equalizer ${versionName()}") {
            startActivity(Intent(this, AboutActivity::class.java))
        })

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun versionName(): String = try {
        "v" + (packageManager.getPackageInfo(packageName, 0).versionName ?: "-")
    } catch (_: Exception) {
        ""
    }

    private fun sectionTitle(text: String): TextView =
        Ui.label(this, text, 15f, 0xFFD0BCFF.toInt(), true).apply { setPadding(dp(8), dp(20), dp(8), dp(10)) }

    private fun cardBase(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = Ui.rounded(this@SettingsActivity, cardBg, 18)
        setPadding(dp(22), dp(18), dp(18), dp(18))
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
    }

    private fun textBlock(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(Ui.label(this@SettingsActivity, title, 18f, titleColor, true))
        if (desc.isNotEmpty()) addView(Ui.label(this@SettingsActivity, desc, 15f, descColor).apply {
            setPadding(0, dp(6), 0, 0)
            setLineSpacing(0f, 1.1f)
        })
    }

    private fun switchCard(title: String, desc: String, key: String, default: Boolean, confirmOn: Boolean = false): View {
        val card = cardBase()
        card.addView(textBlock(title, desc), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { isChecked = prefs.getBoolean(key, default) }
        var suppress = false
        sw.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            if (checked && confirmOn) {
                AlertDialog.Builder(this)
                    .setTitle("Aktifkan Kekuatan Penuh?")
                    .setMessage("Rentang ±22 dB dapat menyebabkan distorsi dan merusak speaker atau headphone jika volume terlalu tinggi. Gunakan dengan hati-hati dan pertimbangkan mengaktifkan Limiter.")
                    .setPositiveButton("Aktifkan") { _, _ -> prefs.edit().putBoolean(key, true).apply() }
                    .setNegativeButton("Batal") { _, _ -> suppress = true; sw.isChecked = false; suppress = false }
                    .setOnCancelListener { suppress = true; sw.isChecked = false; suppress = false }
                    .show()
            } else {
                prefs.edit().putBoolean(key, checked).apply()
            }
        }
        card.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        card.setOnClickListener { sw.toggle() }
        return card
    }

    private fun pipelineName(p: Int) =
        if (p == Store.PIPE_MAX) "Maksimum" else "Standar"

    private fun pipelineCard(): View {
        val card = cardBase()
        val block = textBlock("Pipeline audio", "")
        val value = Ui.label(this, pipelineName(prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)), 15f, descColor)
            .apply { setPadding(0, dp(6), 0, 0) }
        pipelineValue = value
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener {
            val items = arrayOf(
                "Standar — Equalizer sistem Android (band hardware dipetakan ke 10 band)",
                "Maksimum — 10 band presisi lewat DynamicsProcessing (Android 9+)"
            )
            val current = prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
            AlertDialog.Builder(this)
                .setTitle("Pipeline audio")
                .setSingleChoiceItems(items, current) { dialog, which ->
                    if (which == Store.PIPE_MAX && Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                        Toast.makeText(this, "Pipeline Maksimum membutuhkan Android 9+", Toast.LENGTH_SHORT).show()
                    } else {
                        prefs.edit().putInt(Store.KEY_PIPELINE, which).apply()
                        pipelineValue?.text = pipelineName(which)
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        return card
    }

    private fun plainCard(title: String, desc: String, onClick: () -> Unit): View {
        val card = cardBase()
        card.addView(textBlock(title, desc), LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { onClick() }
        return card
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset pengaturan")
            .setMessage("Equalizer, limiter, dan semua pengaturan aplikasi akan dikembalikan ke bawaan. Preset kustom tidak dihapus.")
            .setPositiveButton("Reset") { _, _ ->
                val editor = prefs.edit()
                prefs.all.keys.filter { !it.startsWith("custom_") }.forEach { editor.remove(it) }
                editor.apply()
                Toast.makeText(this, "Pengaturan direset", Toast.LENGTH_SHORT).show()
                recreate()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

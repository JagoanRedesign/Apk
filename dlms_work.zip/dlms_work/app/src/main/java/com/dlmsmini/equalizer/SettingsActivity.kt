package com.dlmsmini.equalizer

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Layar Pengaturan aplikasi. Perubahan langsung disimpan; layanan & layar utama menyesuaikan. */
class SettingsActivity : AppCompatActivity() {
    private class Row(val card: LinearLayout, val sw: Switch?)

    private lateinit var prefs: SharedPreferences
    private var pipelineValue: TextView? = null
    private var bandsValue: TextView? = null
    private var appsRow: Row? = null
    private var stabilizeRow: Row? = null

    private val bg = 0xFF1B1B1D.toInt()
    private val cardBg = 0xFF343437.toInt()
    private val titleColor = 0xFFE6E1E9.toInt()
    private val descColor = 0xFFCAC4D0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Store.prefs(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshDependents()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        })
        bar.addView(Ui.label(this, "Pengaturan", 28f, titleColor))
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // ---- Umum ----
        list.addView(sectionTitle("Umum"))

        list.addView(switchCard(
            "Kekuatan Penuh - Dinamis Diperluas",
            "Modalitas lanjutan untuk pengguna terampil: rentang fader diperluas dari ±12 dB menjadi ±22 dB. " +
                "Penguatan penuh terasa pada pipeline Maksimum; pada pipeline Standar dibatasi hardware. " +
                "Aktifkan Limiter untuk membantu mengelola distorsi yang akhirnya terjadi.",
            Store.KEY_FULL_POWER, false,
            guard = { checked, commit, revert ->
                if (!checked) commit() else AlertDialog.Builder(this)
                    .setTitle("Aktifkan Kekuatan Penuh?")
                    .setMessage("Rentang ±22 dB dapat menyebabkan distorsi dan merusak speaker atau headphone jika volume terlalu tinggi. Gunakan dengan hati-hati dan pertimbangkan mengaktifkan Limiter.")
                    .setPositiveButton("Aktifkan") { _, _ -> commit() }
                    .setNegativeButton("Batal") { _, _ -> revert() }
                    .setOnCancelListener { revert() }
                    .show()
            }
        ).card)

        list.addView(bandsCard())
        list.addView(pipelineCard())
        list.addView(crossoverCard())

        list.addView(switchCard(
            "Spectrum analyzer",
            "Tampilkan analisis spektrum audio secara langsung. Membutuhkan izin rekam audio dan sedikit baterai tambahan.",
            Store.KEY_SPECTRUM, true
        ).card)

        list.addView(switchCard(
            "Layar tetap menyala",
            "Cegah layar mati selama aplikasi dibuka.",
            Store.KEY_KEEP_SCREEN, false
        ).card)

        // ---- Latar belakang ----
        list.addView(sectionTitle("Latar belakang"))

        list.addView(switchCard(
            "Aktif di latar belakang",
            "Jalankan layanan dengan notifikasi agar equalizer dan limiter tetap bekerja saat aplikasi ditutup. " +
                "Matikan untuk menghentikan efek begitu aplikasi ditutup.",
            Store.KEY_BG, true
        ).card)

        list.addView(plainCard(
            "Pengecualian optimasi baterai",
            "Beberapa ponsel menghentikan layanan latar belakang untuk menghemat baterai. Izinkan DLMS Mini Equalizer berjalan tanpa pembatasan agar efek tidak mati sendiri."
        ) { openBatterySettings() })

        // ---- Kompatibilitas Audio ----
        list.addView(sectionTitle("Kompatibilitas Audio"))
        list.addView(Ui.label(this, "Hanya berfungsi dengan pemutar musik tertentu.", 15f, descColor)
            .apply { setPadding(dp(8), 0, dp(8), 0) })
        list.addView(Ui.label(this, "Lihat daftar", 15f, 0xFF4D8DF7.toInt()).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(8), dp(2), dp(8), dp(12))
            isClickable = true
            setOnClickListener { showCompatList() }
        })

        list.addView(switchCard(
            "Mode Sesi Aplikasi",
            "Menerapkan EQ hanya pada aplikasi yang sedang memutar musik. Diperlukan jika Anda memakai Android Auto atau Bluetooth dengan protokol LDAC atau aptX. " +
                "Saat aktif, Mix Global dimatikan.",
            Store.KEY_SESSION_MODE, false,
            guard = { checked, commit, revert ->
                if (checked) commit() else AlertDialog.Builder(this)
                    .setTitle("Beralih ke Mix Global?")
                    .setMessage(
                        "Mode Sesi Aplikasi akan dinonaktifkan dan DLMS Mini Equalizer akan menyeimbangkan seluruh output audio Android secara langsung (Mix Global).\n\n" +
                            "Pada beberapa perangkat, restart disarankan (tetapi tidak wajib) untuk peralihan yang paling optimal."
                    )
                    .setPositiveButton("Beralih ke Mix Global") { _, _ -> commit() }
                    .setNegativeButton("Pertahankan App Session") { _, _ -> revert() }
                    .setOnCancelListener { revert() }
                    .show()
            },
            onChanged = { refreshDependents() }
        ).card)

        appsRow = plainRow(
            "Kelola aplikasi terdeteksi",
            "Lihat dan edit aplikasi mana yang diproses equalizer."
        ) { startActivity(Intent(this, AppsActivity::class.java)) }
        list.addView(appsRow!!.card)

        stabilizeRow = switchCard(
            "Stabilkan saat peluncuran",
            "Jika musik sudah berputar saat layanan dimulai, lewati satu lagu agar Mode Sesi Aplikasi langsung terkunci ke equalizer. (Disarankan)",
            Store.KEY_STABILIZE, true
        )
        list.addView(stabilizeRow!!.card)

        // ---- Lainnya ----
        list.addView(sectionTitle("Lainnya"))

        list.addView(plainCard("Reset pengaturan", "Kembalikan equalizer, limiter, dan pengaturan aplikasi ke bawaan. Preset kustom tetap tersimpan.") {
            confirmReset()
        })
        list.addView(plainCard("Tentang aplikasi", "DLMS Mini Equalizer ${versionName()}") {
            startActivity(Intent(this, AboutActivity::class.java))
        })

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshDependents()
    }

    private fun refreshDependents() {
        val on = prefs.getBoolean(Store.KEY_SESSION_MODE, false)
        appsRow?.let { setRowEnabled(it, on) }
        stabilizeRow?.let { setRowEnabled(it, on) }
    }

    private fun setRowEnabled(row: Row, on: Boolean) {
        row.card.isEnabled = on
        row.card.alpha = if (on) 1f else 0.45f
        row.sw?.isEnabled = on
    }

    private fun versionName(): String = try {
        "v" + (packageManager.getPackageInfo(packageName, 0).versionName ?: "-")
    } catch (_: Exception) {
        ""
    }

    private fun sectionTitle(text: String): TextView =
        Ui.label(this, text, 15f, 0xFFD0BCFF.toInt(), true).apply { setPadding(dp(8), dp(20), dp(8), dp(10)) }

    private fun cardBase(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = Ui.rounded(this@SettingsActivity, cardBg, 18)
        setPadding(dp(22), dp(18), dp(18), dp(18))
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
    }

    private fun textBlock(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(Ui.label(this@SettingsActivity, title, 18f, titleColor, true))
        if (desc.isNotEmpty()) addView(Ui.label(this@SettingsActivity, desc, 15f, descColor).apply {
            setPadding(0, dp(6), 0, 0)
            setLineSpacing(0f, 1.1f)
        })
    }

    private fun switchCard(
        title: String, desc: String, key: String, default: Boolean,
        guard: ((Boolean, () -> Unit, () -> Unit) -> Unit)? = null,
        onChanged: (() -> Unit)? = null
    ): Row {
        val card = cardBase()
        card.addView(textBlock(title, desc), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { isChecked = prefs.getBoolean(key, default) }
        var suppress = false
        sw.setOnCheckedChangeListener { _, checked ->
            if (suppress) return@setOnCheckedChangeListener
            val commit: () -> Unit = {
                prefs.edit().putBoolean(key, checked).apply()
                onChanged?.invoke()
            }
            val revert: () -> Unit = {
                suppress = true
                sw.isChecked = !checked
                suppress = false
            }
            if (guard != null) guard(checked, commit, revert) else commit()
        }
        card.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        card.setOnClickListener { sw.toggle() }
        return Row(card, sw)
    }


    // ---------- Pita Equalizer ----------
    private fun currentBands(): Int =
        prefs.getInt(Store.KEY_BANDS, Bands.DEFAULT).let { if (Bands.isValid(it)) it else Bands.DEFAULT }

    private fun bandsCard(): View {
        val card = cardBase()
        val block = textBlock("Pita Equalizer", "")
        val value = Ui.label(this, "${currentBands()} Bands", 15f, descColor).apply { setPadding(0, dp(6), 0, 0) }
        bandsValue = value
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { showBandsDialog() }
        return card
    }

    private fun bandHint(n: Int): String = when (n) {
        5 -> "Sederhana: koreksi cepat bass, tengah, dan treble."
        10 -> "Seimbang: susunan standar 31 Hz – 16 kHz."
        13 -> "Lebih rinci di menengah–tinggi untuk vokal dan instrumen."
        else -> "Hibrida: bass ringkas, menengah & tinggi dirapatkan untuk presisi."
    }

    private fun showBandsDialog() {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        var selected = currentBands()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(this@SettingsActivity, 0xFF232428.toInt(), 28)
            setPadding(dp(24), dp(26), dp(24), dp(20))
        }
        root.addView(Ui.label(this, "Pita Equalizer", 28f, Color.WHITE).apply { setPadding(dp(6), 0, 0, dp(10)) })

        val hint = Ui.label(this, bandHint(selected), 13f, descColor).apply { setPadding(dp(6), 0, dp(6), dp(6)) }
        val radios = mutableListOf<Pair<Int, RadioButton>>()
        Bands.COUNTS.forEach { n ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(16), dp(6), dp(16))
                isClickable = true
            }
            row.addView(Ui.label(this, "$n Bands", 20f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            val rb = RadioButton(this).apply {
                isChecked = n == selected
                buttonTintList = ColorStateList.valueOf(0xFFD0BCFF.toInt())
                isClickable = false
                isFocusable = false
            }
            row.addView(rb)
            row.setOnClickListener {
                selected = n
                radios.forEach { (k, r) -> r.isChecked = k == selected }
                hint.text = bandHint(selected)
            }
            radios.add(n to rb)
            root.addView(row)
        }
        root.addView(hint)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val info = Ui.label(this, "Info lebih lanjut", 16f, 0xFF4D8DF7.toInt(), true).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            setOnClickListener { showBandsInfo() }
        }
        actions.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val applyBtn = TextView(this).apply {
            text = "Terapkan"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = Ui.rounded(this@SettingsActivity, 0xFF4285F4.toInt(), 28)
            setPadding(dp(26), dp(16), dp(26), dp(16))
            isClickable = true
        }
        applyBtn.setOnClickListener {
            val old = currentBands()
            if (selected != old) {
                Bands.switchLayout(prefs, old, selected)
                bandsValue?.text = "$selected Bands"
                Toast.makeText(this, "Pita equalizer: $selected band (kurva disesuaikan)", Toast.LENGTH_SHORT).show()
            }
            dlg.dismiss()
        }
        actions.addView(applyBtn)
        root.addView(actions)

        dlg.setContentView(root)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dlg.show()
    }

    private fun showBandsInfo() {
        val msg = "Pita Equalizer menentukan berapa banyak slider frekuensi yang tersedia.\n\n" +
            "• 5 Bands — sederhana, untuk koreksi cepat.\n" +
            "• 10 Bands — seimbang, susunan standar.\n" +
            "• 13 Bands — tambahan band di menengah–tinggi untuk vokal dan instrumen.\n" +
            "• 21 Bands (hibrida) — bukan sekadar lebih banyak slider, tetapi tata letak yang cerdas:\n\n" +
            "Bass bertenaga dan alami: frekuensi rendah dibuat ringkas (31, 63, 125, 250 Hz) sehingga kehangatan dan \"dentuman\" didapat hanya dengan beberapa gerakan, tanpa suara keruh atau menggelegar.\n\n" +
            "Detail HD di menengah dan tinggi: jumlah band dilipatgandakan pada rentang yang paling peka bagi telinga, jadi vokal bisa dibuat menonjol atau gitar akustik tampil jernih dengan presisi tinggi.\n\n" +
            "Titik optimal: 5 atau 10 band sering terlalu terbatas untuk mendengarkan serius, sedangkan 31 band profesional bisa terlalu rumit. 21 band hibrida tetap intuitif di bass, sangat presisi di menengah–tinggi, dan transparan sehingga suara tetap alami.\n\n" +
            "Catatan:\n" +
            "• Saat jumlah band diganti, kurva saat ini disesuaikan otomatis. Preset tersimpan juga ikut menyesuaikan.\n" +
            "• 13 dan 21 band memakai tampilan yang bisa digeser ke samping.\n" +
            "• Presisi penuh 13 dan 21 band terasa pada pipeline Maksimum (Android 9+). Pada pipeline Standar, band dipetakan ke band hardware perangkat (biasanya sekitar 5)."
        AlertDialog.Builder(this).setTitle("Pita Equalizer").setMessage(msg).setPositiveButton("Oke", null).show()
    }

    private val crossoverChoices = intArrayOf(250, 500, 700, 1000, 2000)

    private fun crossoverCard(): View {
        val card = cardBase()
        val block = textBlock(
            "Crossover 2-Way",
            "Mode 2-Way memilih frekuensi crossover, tetapi API efek sistem Android yang digunakan aplikasi ini tidak menyediakan filter crossover PCM stereo sejati. Kanal kiri/kanan tetap dipertahankan agar suara tidak rusak. " +
                "Nilai dibulatkan ke batas band terdekat. Cocok untuk sistem dua jalur dengan driver kiri/kanan terpisah, bukan untuk mendengarkan stereo biasa."
        )
        val value = Ui.label(this, "${prefs.getInt(Store.KEY_CROSSOVER, Store.DEFAULT_CROSSOVER)} Hz", 15f, Pal.CYAN, true)
            .apply { setPadding(0, dp(8), 0, 0) }
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener {
            val current = prefs.getInt(Store.KEY_CROSSOVER, Store.DEFAULT_CROSSOVER)
            val items = crossoverChoices.map { "$it Hz" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Crossover 2-Way")
                .setSingleChoiceItems(items, crossoverChoices.indexOf(current)) { dialog, which ->
                    prefs.edit().putInt(Store.KEY_CROSSOVER, crossoverChoices[which]).apply()
                    value.text = items[which]
                    dialog.dismiss()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        return card
    }

    private fun pipelineName(p: Int) = if (p == Store.PIPE_MAX) "Maksimum" else "Standar"

    private fun pipelineCard(): View {
        val card = cardBase()
        val block = textBlock("Pipeline audio", "")
        val value = Ui.label(this, pipelineName(prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)), 15f, descColor)
            .apply { setPadding(0, dp(6), 0, 0) }
        pipelineValue = value
        block.addView(value)
        card.addView(block, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener {
            val items = arrayOf(
                "Standar — Equalizer sistem Android (band hardware dipetakan ke 10 band)",
                "Maksimum — 10 band presisi lewat DynamicsProcessing (Android 9+)"
            )
            val current = prefs.getInt(Store.KEY_PIPELINE, Store.PIPE_STANDARD)
            AlertDialog.Builder(this)
                .setTitle("Pipeline audio")
                .setSingleChoiceItems(items, current) { dialog, which ->
                    if (which == Store.PIPE_MAX && Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                        Toast.makeText(this, "Pipeline Maksimum membutuhkan Android 9+", Toast.LENGTH_SHORT).show()
                    } else {
                        prefs.edit().putInt(Store.KEY_PIPELINE, which).apply()
                        pipelineValue?.text = pipelineName(which)
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        return card
    }

    private fun plainRow(title: String, desc: String, onClick: () -> Unit): Row {
        val card = cardBase()
        card.addView(textBlock(title, desc), LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { onClick() }
        return Row(card, null)
    }

    private fun plainCard(title: String, desc: String, onClick: () -> Unit): View = plainRow(title, desc, onClick).card

    private fun showCompatList() {
        val seen = AppStore.detected(this)
        val seenText = if (seen.isEmpty()) "belum ada" else seen.joinToString("\n") { "• $it" }
        val msg = "Pemutar musik yang umumnya mendukung Mode Sesi Aplikasi:\n" +
            "• YouTube Music\n• Spotify\n\n" +
            "Pemutar lain yang mengirim sinyal sesi audio standar Android juga dapat bekerja. " +
            "Tidak semua pemutar didukung: sebagian tidak mengikuti standar API audio Android atau menolak equalizer eksternal.\n\n" +
            "Tips: buka DLMS Mini Equalizer lebih dulu, lalu buka aplikasi musik dan tekan putar/jeda.\n\n" +
            "Sudah terdeteksi di perangkat ini:\n$seenText"
        AlertDialog.Builder(this).setTitle("Pemutar yang didukung").setMessage(msg).setPositiveButton("Oke", null).show()
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Pengaturan baterai tidak dapat dibuka", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset pengaturan")
            .setMessage("Equalizer, limiter, dan semua pengaturan aplikasi akan dikembalikan ke bawaan. Preset kustom tidak dihapus.")
            .setPositiveButton("Reset") { _, _ ->
                val editor = prefs.edit()
                prefs.all.keys.filter { !it.startsWith("custom_") }.forEach { editor.remove(it) }
                editor.apply()
                Toast.makeText(this, "Pengaturan direset", Toast.LENGTH_SHORT).show()
                recreate()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

package com.dlmsmini.equalizer

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Halaman Tentang aplikasi. */
class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "-"
        } catch (_: Exception) {
            "-"
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(c(0xFF121214))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(16), dp(16), dp(12))
        }
        val back = TextView(this).apply {
            text = "←"; textSize = 26f; setTextColor(c(0xFFFFFFFF))
            setPadding(dp(14), dp(2), dp(18), dp(2)); isClickable = true
        }
        back.setOnClickListener { finish() }
        bar.addView(back)
        bar.addView(label("Tentang aplikasi", 24f, c(0xFFFFFFFF)))
        root.addView(bar)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), dp(28))
        }

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(24), dp(18), dp(24))
            background = rounded(c(0xFF111827), 20, c(0xFF263B5D))
        }
        hero.addView(label("DLMS", 34f, c(0xFFF3F6FF), true))
        hero.addView(label("MINI EQUALIZER", 13f, c(0xFF35B8FF), true))
        hero.addView(label("Versi $version", 13f, c(0xFF9DAFC9)).apply { setPadding(0, dp(8), 0, 0) })
        content.addView(hero)

        addBlock(content, "Tentang",
            "DLMS Mini Equalizer adalah equalizer 10 band dengan limiter untuk Android. " +
                "Efek diterapkan ke audio sistem sehingga dapat dipakai bersama pemutar lain seperti YouTube.")

        addBlock(content, "Fitur",
            "• Equalizer 10 band (31 Hz – 16 kHz), langkah 0,5 dB\n" +
                "• Limiter: attack, release, ratio, threshold, post-gain\n" +
                "• Preset bawaan dan preset buatan sendiri\n" +
                "• Import dan export preset lewat salin & tempel\n" +
                "• Analisis spektrum\n" +
                "• Layanan latar belakang")

        addBlock(content, "Catatan penggunaan",
            "• Equalizer memakai Android Equalizer(0, 0) untuk meminta akses ke efek output audio global.\n" +
                "• EQ semua aplikasi hanya bekerja jika Android/vendor mengizinkan global output-mix effects.\n" +
                "• Aplikasi tidak memakai AudioPlaybackCapture sebagai jalur EQ karena itu hanya menangkap salinan audio.\n" +
                "• Limiter memerlukan Android 9 (API 28) atau lebih baru.\n" +
                "• Jika perangkat hanya menyediakan 5 band, 10 pita akan digabung ke band terdekat.")

        addBlock(content, "Pembuat", "Dibuat oleh Ilham Galeh")

        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addBlock(parent: LinearLayout, title: String, body: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(c(0xFF2A2A2E), 14)
        }
        card.addView(label(title, 16f, c(0xFFEDEDF3), true))
        card.addView(label(body, 13f, c(0xFFB6B6C2)).apply {
            setPadding(0, dp(6), 0, 0); setLineSpacing(0f, 1.15f)
        })
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, 0) })
    }
}

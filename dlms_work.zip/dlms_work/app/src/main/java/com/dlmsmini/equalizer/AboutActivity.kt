package com.dlmsmini.equalizer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Layar Tentang Aplikasi. */
class AboutActivity : AppCompatActivity() {
    private val bg = 0xFF1B1B1D.toInt()
    private val cardBg = 0xFF343437.toInt()
    private val titleColor = 0xFFE6E1E9.toInt()
    private val descColor = 0xFFCAC4D0.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "-"
    } catch (_: Exception) {
        "-"
    }

    private fun deviceInfo(): String =
        "DLMS Mini Equalizer v${versionName()}\n" +
            "Paket: $packageName\n" +
            "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Limiter: ${if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) "didukung (Android 9+)" else "tidak didukung (butuh Android 9+)"}"

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.rounded(this@AboutActivity, cardBg, 18)
        setPadding(dp(22), dp(18), dp(22), dp(18))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        bar.addView(TextView(this).apply {
            text = "←"; textSize = 28f; setTextColor(titleColor)
            setPadding(dp(8), dp(4), dp(16), dp(4))
            isClickable = true
            contentDescription = "Kembali"
            setOnClickListener { finish() }
        })
        bar.addView(Ui.label(this, "Tentang aplikasi", 28f, titleColor))
        root.addView(bar)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // Logo / nama
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = Ui.rounded(this@AboutActivity, Pal.PANEL, 22, Pal.PANEL_STROKE)
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        brand.addView(Ui.label(this, "DLMS", 40f, 0xFFF3F6FF.toInt(), true).apply { gravity = Gravity.CENTER })
        brand.addView(Ui.label(this, "MINI EQUALIZER", 13f, 0xFF35B8FF.toInt(), true).apply { gravity = Gravity.CENTER })
        brand.addView(Ui.label(this, "Versi ${versionName()}", 13f, Pal.MUTED).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0)
        })
        list.addView(brand, LinearLayout.LayoutParams(-1, -2))

        val about = card()
        about.addView(Ui.label(this, "Tentang", 18f, titleColor, true))
        about.addView(Ui.label(this,
            "DLMS Mini Equalizer adalah equalizer 10 band yang ringan untuk Android, dengan fader presisi 0,5 dB, " +
                "limiter, spectrum analyzer, serta preset yang bisa diekspor dan diimpor lewat salin & tempel.",
            15f, descColor).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.1f) })
        list.addView(about)

        val features = card()
        features.addView(Ui.label(this, "Fitur", 18f, titleColor, true))
        features.addView(Ui.label(this,
            "• Equalizer 10 band: 31 Hz – 16 kHz, ±12 dB (±22 dB pada mode Kekuatan Penuh)\n" +
                "• Limiter: attack, release, ratio, threshold, post-gain\n" +
                "• Pipeline Standar dan Maksimum\n" +
                "• Preset bawaan, preset kustom, export & import teks\n" +
                "• Spectrum analyzer\n" +
                "• Aktif di latar belakang (foreground service)\n" +
                "• Mode Sesi Aplikasi untuk pemutar musik tertentu",
            15f, descColor).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.15f) })
        list.addView(features)

        val dev = card()
        dev.addView(Ui.label(this, "Informasi", 18f, titleColor, true))
        dev.addView(Ui.label(this, deviceInfo(), 14f, descColor).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.15f) })
        val copy = Ui.pill(this, "SALIN INFO").apply { textSize = 12f }
        copy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("DLMS info", deviceInfo()))
            Toast.makeText(this, "Info disalin", Toast.LENGTH_SHORT).show()
        }
        dev.addView(copy, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        list.addView(dev)

        val note = card()
        note.addView(Ui.label(this, "Catatan", 18f, titleColor, true))
        note.addView(Ui.label(this,
            "Efek bekerja pada sesi audio global Android. Hasil bergantung pada dukungan perangkat dan ROM. " +
                "Dengan \"Aktif di latar belakang\" menyala, efek tetap bekerja walau aplikasi ditutup dari layar; hentikan lewat tombol Matikan di notifikasi.",
            14f, descColor).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.1f) })
        list.addView(note)

        list.addView(Ui.label(this, "Dibuat oleh Ilham Galeh", 13f, 0xFF8294B2.toInt(), true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(22), 0, dp(2))
        })
        list.addView(Ui.label(this, "© 2026 Ilham Galeh", 11f, 0xFF6E7C96.toInt()).apply { gravity = Gravity.CENTER })

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}

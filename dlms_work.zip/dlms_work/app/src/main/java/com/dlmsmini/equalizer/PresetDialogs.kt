package com.dlmsmini.equalizer

import android.app.Activity
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Dialog Export / Import preset berbasis salin & tempel. */
object PresetDialogs {
    private val HEAD_BG = 0xFF222222.toInt()
    private val BODY_BG = 0xFF0D0D0D.toInt()

    private fun shell(a: Activity, title: String, desc: String, body: LinearLayout, buttons: List<TextView>): Dialog {
        val dlg = Dialog(a)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(a, HEAD_BG, 24)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        val head = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(HEAD_BG)
            setPadding(Ui.dp(a, 20), Ui.dp(a, 22), Ui.dp(a, 20), Ui.dp(a, 22))
        }
        head.addView(Ui.label(a, title, 26f, Color.WHITE, true))
        head.addView(Ui.label(a, desc, 15f, 0xFFEDEDED.toInt()).apply { setPadding(0, Ui.dp(a, 12), 0, 0) })
        root.addView(head)
        body.setBackgroundColor(BODY_BG)
        body.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16))
        root.addView(body)
        val bar = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(HEAD_BG)
            setPadding(Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12))
        }
        buttons.forEach { b ->
            bar.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
                setMargins(Ui.dp(a, 5), 0, Ui.dp(a, 5), 0)
            })
        }
        root.addView(bar)
        dlg.setContentView(root)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            setLayout((a.resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        return dlg
    }

    private fun editor(a: Activity, hint: String): EditText = EditText(a).apply {
        this.hint = hint
        setHintTextColor(0xFF6A6A6A.toInt())
        setTextColor(Color.WHITE)
        textSize = 13f
        typeface = android.graphics.Typeface.MONOSPACE
        gravity = Gravity.TOP or Gravity.START
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        minLines = 10
        maxLines = 10
        background = Ui.rounded(a, BODY_BG, 2, 0xFF8A8A8A.toInt())
        setPadding(Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14))
    }

    fun showExport(a: Activity, payload: String) {
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val box = editor(a, "").apply {
            setText(payload)
            keyListener = null
            setTextIsSelectable(true)
        }
        body.addView(box, LinearLayout.LayoutParams(-1, -2))
        val copy = Ui.pill(a, "SALIN")
        val share = Ui.pill(a, "BAGIKAN")
        val close = Ui.pill(a, "TUTUP")
        val dlg = shell(
            a, "Export presets",
            "Salin teks preset di bawah, simpan di catatan atau kirim ke teman. Tempel di menu Import presets untuk memulihkannya.",
            body, listOf(copy, share, close)
        )
        copy.setOnClickListener {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("DLMS preset", payload))
            Toast.makeText(a, "Preset disalin ke clipboard", Toast.LENGTH_SHORT).show()
        }
        share.setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, payload)
            }
            a.startActivity(Intent.createChooser(send, "Bagikan preset"))
        }
        close.setOnClickListener { dlg.dismiss() }
        dlg.show()
    }

    fun showImport(a: Activity, onImport: (List<PresetCodec.Item>) -> Unit) {
        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val box = editor(a, "[Preset Data]")
        val info = Ui.label(a, "", 12f, 0xFF9A9A9A.toInt()).apply { setPadding(Ui.dp(a, 2), Ui.dp(a, 10), 0, 0) }
        body.addView(box, LinearLayout.LayoutParams(-1, -2))
        body.addView(info)
        val paste = Ui.pill(a, "PASTE")
        val doImport = Ui.pill(a, "IMPORT")
        val close = Ui.pill(a, "CLOSE")
        Ui.setPillEnabled(doImport, false)
        val dlg = shell(
            a, "Import presets",
            "Paste your preset data as text to the window, then verify and import them to the app. Be careful to leave the text on the exact exported format to avoid issues.",
            body, listOf(paste, doImport, close)
        )
        var parsed: List<PresetCodec.Item> = emptyList()
        box.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val r = PresetCodec.parse(s?.toString().orEmpty())
                val ok = r.items.isNotEmpty() && r.errors.isEmpty()
                parsed = if (ok) r.items else emptyList()
                Ui.setPillEnabled(doImport, ok)
                when {
                    s.isNullOrBlank() -> info.text = ""
                    ok -> {
                        info.setTextColor(0xFF7BE3B0.toInt())
                        info.text = "✓ ${r.items.size} preset valid: " + r.items.joinToString(", ") { it.name }
                    }
                    else -> {
                        info.setTextColor(0xFFFF7B7B.toInt())
                        info.text = r.errors.take(3).joinToString("\n")
                    }
                }
            }
        })
        paste.setOnClickListener {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(a)?.toString() else null
            if (t.isNullOrBlank()) Toast.makeText(a, "Clipboard kosong", Toast.LENGTH_SHORT).show()
            else box.setText(t)
        }
        doImport.setOnClickListener {
            if (parsed.isNotEmpty()) { onImport(parsed); dlg.dismiss() }
        }
        close.setOnClickListener { dlg.dismiss() }
        dlg.show()
    }
}

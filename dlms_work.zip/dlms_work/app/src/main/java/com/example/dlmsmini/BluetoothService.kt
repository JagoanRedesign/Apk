package com.example.dlmsmini

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Bluetooth Classic SPP client.
 * All blocking socket work is performed on a worker thread.
 */
class BluetoothService(
    private val onStatus: (String) -> Unit,
    private val onData: (String) -> Unit
) {
    private val sppUuid: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val executor = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var connected = false

    private fun status(message: String) {
        mainHandler.post { onStatus(message) }
    }

    @SuppressLint("MissingPermission")
    fun connect(adapter: BluetoothAdapter, address: String) {
        executor.execute {
            closeSocket()
            status("Menghubungkan...")
            try {
                val device = adapter.getRemoteDevice(address)
                val newSocket = device.createRfcommSocketToServiceRecord(sppUuid)
                newSocket.connect()
                socket = newSocket
                connected = true
                status("Terhubung: ${device.name ?: address}")
                listen(newSocket)
            } catch (e: Exception) {
                connected = false
                closeSocket()
                status("Gagal terhubung: ${e.message ?: "kesalahan Bluetooth"}")
            }
        }
    }

    fun send(command: String) {
        executor.execute {
            val activeSocket = socket
            if (!connected || activeSocket == null) {
                status("Belum terhubung")
                return@execute
            }
            try {
                activeSocket.outputStream.write(command.toByteArray(Charsets.UTF_8))
                activeSocket.outputStream.flush()
            } catch (e: IOException) {
                connected = false
                status("Pengiriman gagal: ${e.message}")
                closeSocket()
            }
        }
    }

    private fun listen(activeSocket: BluetoothSocket) {
        val buffer = ByteArray(1024)
        try {
            val input = activeSocket.inputStream
            while (connected) {
                val count = input.read(buffer)
                if (count < 0) break
                val message = String(buffer, 0, count, Charsets.UTF_8)
                mainHandler.post { onData(message) }
            }
        } catch (_: IOException) {
            // Expected when the remote device disconnects.
        } finally {
            connected = false
            closeSocket()
            status("Koneksi terputus")
        }
    }

    fun disconnect() {
        executor.execute {
            connected = false
            closeSocket()
            status("Terputus")
        }
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: IOException) {}
        socket = null
        connected = false
    }

    fun shutdown() {
        connected = false
        closeSocket()
        executor.shutdownNow()
    }
}

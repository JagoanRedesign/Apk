package com.example.dlmsmini

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dlmsmini.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var bluetoothAdapter: BluetoothAdapter? = null
    private lateinit var btService: BluetoothService
    private val pairedDevices = mutableListOf<Pair<String, String>>()
    private val permissionRequest = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val manager = getSystemService(BluetoothManager::class.java)
        bluetoothAdapter = manager?.adapter

        btService = BluetoothService(
            onStatus = { binding.txtStatus.text = it },
            onData = { binding.txtReceived.append(it) }
        )

        setupControls()
        requestBluetoothPermissionIfNeeded()
    }

    private fun setupControls() {
        binding.btnRefresh.setOnClickListener { loadPairedDevices() }
        binding.btnConnect.setOnClickListener { connectSelectedDevice() }
        binding.btnDisconnect.setOnClickListener { btService.disconnect() }

        binding.seekInputGain.max = 120
        binding.seekOutputGain.max = 120
        binding.seekInputGain.setOnSeekBarChangeListener(seekListener { value ->
            send("SET_INPUT_GAIN,1,$value\n")
            binding.txtInputGain.text = "Input Gain: $value"
        })
        binding.seekOutputGain.setOnSeekBarChangeListener(seekListener { value ->
            send("SET_OUTPUT_GAIN,1,$value\n")
            binding.txtOutputGain.text = "Output Gain: $value"
        })

        binding.switchInputPhase.setOnCheckedChangeListener { _, checked ->
            send("SET_INPUT_PHASE,1,${if (checked) "INVERT" else "NORMAL"}\n")
        }
        binding.switchInputMute.setOnCheckedChangeListener { _, checked ->
            send("SET_INPUT_MUTE,1,${if (checked) "ON" else "OFF"}\n")
        }
        binding.switchOutputEq.setOnCheckedChangeListener { _, checked ->
            send("SET_OUTPUT_EQ,1,${if (checked) "ON" else "OFF"}\n")
        }

        binding.btnClearLog.setOnClickListener { binding.txtReceived.text = "" }

        // PEQ demo controls. Replace command syntax with the device's actual protocol.
        val peqBars = listOf(
            binding.seekPeq1, binding.seekPeq2, binding.seekPeq3,
            binding.seekPeq4, binding.seekPeq5, binding.seekPeq6, binding.seekPeq7
        )
        peqBars.forEachIndexed { index, bar ->
            bar.max = 24
            bar.progress = 12
            bar.setOnSeekBarChangeListener(seekListener { value ->
                val db = value - 12
                send("SET_PEQ,1,${index + 1},$db\n")
            })
        }

        binding.seekCompressor.max = 100
        binding.seekCompressor.setOnSeekBarChangeListener(seekListener { value ->
            send("SET_COMPRESSOR,1,$value\n")
        })
        binding.seekLimiter.max = 100
        binding.seekLimiter.setOnSeekBarChangeListener(seekListener { value ->
            send("SET_LIMITER,1,$value\n")
        })
    }

    private fun seekListener(action: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) action(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

    private fun send(command: String) {
        btService.send(command)
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), permissionRequest)
        } else {
            loadPairedDevices()
        }
    }

    @SuppressLint("MissingPermission")
    private fun loadPairedDevices() {
        val adapter = bluetoothAdapter
        if (adapter == null) {
            binding.txtStatus.text = "Perangkat tidak mendukung Bluetooth"
            return
        }
        if (!adapter.isEnabled) {
            binding.txtStatus.text = "Aktifkan Bluetooth dari pengaturan Android"
            return
        }
        pairedDevices.clear()
        pairedDevices.addAll(adapter.bondedDevices.map { device ->
            (device.name ?: "Bluetooth device") to device.address
        }.sortedBy { it.first })

        val labels = if (pairedDevices.isEmpty()) {
            listOf("Belum ada perangkat ter-pair")
        } else {
            pairedDevices.map { "${it.first} (${it.second})" }
        }
        binding.spinnerDevices.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, labels
        )
        binding.txtStatus.text = "Perangkat tersimpan: ${pairedDevices.size}. Pair perangkat dari Settings Android."
    }

    private fun connectSelectedDevice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestBluetoothPermissionIfNeeded()
            return
        }
        val index = binding.spinnerDevices.selectedItemPosition
        if (index !in pairedDevices.indices) {
            Toast.makeText(this, "Pilih perangkat Bluetooth yang sudah di-pair", Toast.LENGTH_SHORT).show()
            return
        }
        val adapter = bluetoothAdapter ?: return
        btService.connect(adapter, pairedDevices[index].second)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadPairedDevices()
            } else {
                binding.txtStatus.text = "Izin Bluetooth diperlukan untuk memakai aplikasi"
            }
        }
    }

    override fun onDestroy() {
        btService.shutdown()
        super.onDestroy()
    }
}

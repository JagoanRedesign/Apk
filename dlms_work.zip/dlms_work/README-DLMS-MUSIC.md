# DLMS Mini 3.2 — DLMS Music

Modul DLMS Music ditambahkan ke proyek Equalizer yang sudah ada.

## Fitur yang tersedia pada build ini

- Pencarian musik menggunakan Piped API dengan filter `music_songs`.
- Hasil resmi/verified dan kanal `- Topic` diprioritaskan di atas unggahan lain.
- Pagination Piped (`nextpage/search`) saat pengguna menggulir daftar.
- Pemutaran audio online melalui URL audio yang diekstrak di perangkat menggunakan NewPipeExtractor.
- Pemutar latar belakang berbasis AndroidX Media3 `MediaSessionService` dan ExoPlayer.
- Kontrol media sistem / headset melalui MediaSession.
- Pemindaian dan pemutaran file audio lokal menggunakan MediaStore.
- Pencarian kandidat lirik LRCLIB dan pemilihan kandidat secara manual.
- Pengunduhan stream dengan pilihan bitrate/format yang tersedia.

## Batasan yang perlu diketahui

1. "Tanpa batas" berarti aplikasi terus meminta halaman lanjutan selama Piped menyediakan token `nextpage`; jumlah hasil tetap ditentukan oleh instance dan sumber.
2. Piped adalah jaringan instance publik. Instance dapat offline, lambat, atau membatasi akses. Tombol `PIPED` pada layar musik mengganti instance.
3. NewPipeExtractor mengekstrak stream di perangkat, tetapi perubahan YouTube dapat sewaktu-waktu membuat ekstraksi gagal sampai library diperbarui.
4. Tidak semua konten mempunyai stream audio terpisah atau dapat diputar. Konten privat, dibatasi usia/wilayah, atau konten yang tidak diizinkan tidak dijamin tersedia.
5. LRCLIB membatasi pencarian v1 sampai 20 kandidat dan tidak menyediakan pagination pencarian. Kandidat dipilih manual oleh pengguna.
6. Unduhan menyimpan stream dengan ekstensi format yang dilaporkan extractor ke `Music/DLMS Music`. Pada build ini penanaman cover art dan lirik ke metadata berkas BELUM diimplementasikan. Opsi metadata tidak ditampilkan agar tidak menyesatkan.
7. Lirik sinkron (LRC) ditampilkan sebagai teks bertimestamp; penyorotan baris real-time belum diimplementasikan.
8. UI musik adalah layar awal fungsional, belum merupakan replika penuh Spotify/YouTube Music (belum ada akun, sinkronisasi playlist cloud, rekomendasi, atau katalog berlisensi).

## Dependensi dan lisensi

- NewPipeExtractor `v0.27.1` — GPL-3.0-or-later.
- AndroidX Media3 ExoPlayer / MediaSession.
- Piped public API.
- LRCLIB public API.

**Penting untuk distribusi:** NewPipeExtractor adalah GPL-3.0-or-later. Sebelum mendistribusikan APK, tinjau kewajiban GPL untuk aplikasi gabungan, sertakan teks lisensi dan tawarkan Corresponding Source sesuai ketentuan GPL. Jangan mengklaim proyek ini sebagai perangkat lunak proprietary tertutup tanpa peninjauan lisensi.

## Build

Workflow GitHub Actions di `.github/workflows/android-build.yml` menggunakan arsip `dlms_work.zip` yang berada di root repository. Jika mengunggah arsip hasil perubahan ini, ubah nama menjadi `dlms_work.zip` atau sesuaikan nama pada langkah `unzip` workflow.

Dependency NewPipeExtractor diambil dari JitPack. Build membutuhkan akses jaringan saat Gradle menyelesaikan dependency.

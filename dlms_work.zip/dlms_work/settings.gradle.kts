pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories {
    google(); mavenCentral()
    // NewPipeExtractor dipublikasikan lewat JitPack.
    maven("https://jitpack.io") { content { includeGroupByRegex("com\\.github\\..*") } }
} }
rootProject.name = "DlmsMiniEqualizer"
include(":app")

# DLMS Mini Controller

Starter project Android Kotlin untuk Bluetooth Classic SPP dengan build APK otomatis melalui GitHub Actions.

## Build APK dengan GitHub Actions

1. Buat repository GitHub baru.
2. Upload **seluruh isi folder** proyek ini ke root repository (folder `app`, `gradle.properties`, `settings.gradle.kts`, `build.gradle.kts`, `.github/workflows`, dan `.gitignore`).
3. Pastikan branch utama bernama `main` atau `master`.
4. Buka tab **Actions**. Workflow **Build DLMS Mini APK** berjalan otomatis setelah push, atau pilih workflow tersebut lalu tekan **Run workflow**.
5. Setelah status workflow hijau, buka halaman run dan unduh artifact **dlms-mini-debug-apk**. Ekstrak ZIP artifact untuk memperoleh `app-debug.apk`.

Workflow memasang JDK 17 dan Android SDK, menyiapkan Gradle 8.9, lalu membuat Gradle Wrapper karena file ZIP sumber tidak menyertakan `gradlew` maupun `gradle-wrapper.jar`. Setelah itu workflow menjalankan `clean assembleDebug` dan memverifikasi APK sebelum mengunggahnya.

## Pairing Bluetooth

Pair perangkat DLMS Mini dari Android Settings terlebih dahulu. Aplikasi menampilkan perangkat yang sudah dipasangkan. Koneksi menggunakan Bluetooth Classic SPP dengan UUID standar.

## Protokol perangkat

Perintah `SET_INPUT_GAIN`, `SET_OUTPUT_GAIN`, `SET_INPUT_PHASE`, `SET_INPUT_MUTE`, `SET_OUTPUT_EQ`, `SET_PEQ`, `SET_COMPRESSOR`, dan `SET_LIMITER` masih berupa contoh/placeholder. Pastikan format, delimiter, terminator, skala nilai, dan checksum sesuai protokol resmi DLMS Mini sebelum menghubungkan ke perangkat nyata.

## Batasan versi awal

- Koneksi Bluetooth Classic SPP saja; bukan BLE.
- Kontrol PEQ/dynamics mengirim perintah contoh, belum membaca/menyimpan preset.
- Panel data menampilkan data yang diterima sebagai teks; Spectrum RTA grafis memerlukan format data dan spesifikasi protokol perangkat.
- APK debug cocok untuk pengujian. Untuk distribusi publik, siapkan signing release dengan keystore dan simpan kredensial sebagai GitHub Actions Secrets.

# DLMS Mini Equalizer

Proyek Android equalizer dengan build otomatis melalui GitHub Actions.

## Fitur yang diminta untuk versi lengkap

- Graphic Equalizer 31-band pada rentang 20 Hz–20 kHz.
- Parametric Equalizer 8-band dengan pengaturan frekuensi, gain, dan Q.
- Preamp.
- Bass Boost dan Treble Boost.
- Compressor dan Limiter.
- Pengaturan keseimbangan kanal kiri/kanan (L/R).
- Preset Rock, Pop, Jazz, Classical, Vocal, Bass, dan Flat.
- Spectrum Analyzer.
- Mesin DSP native C++.
- Sasaran pemrosesan audio aplikasi lain (YouTube, pemutar musik, game, dan aplikasi lain yang mengizinkan audio capture).

## Batasan penting Android untuk audio semua aplikasi

Aplikasi Android biasa tidak dapat menjamin penyisipan DSP ke jalur output semua aplikasi. `AudioPlaybackCapture` hanya menangkap audio aplikasi yang mengizinkan capture dan hanya setelah pengguna memberikan izin MediaProjection. Audio yang ditangkap merupakan salinan; memutarnya kembali melalui `AudioTrack` tidak mengganti atau menyisipkan efek ke jalur audio asli dan dapat menyebabkan audio ganda, echo, serta latensi. Sebagian aplikasi (termasuk aplikasi streaming tertentu) melarang capture. Pemrosesan global sesungguhnya memerlukan dukungan audio effect dari vendor/ROM atau integrasi tingkat sistem.

## Status implementasi pada source saat ini

Source yang ada saat ini mengimplementasikan equalizer output-mix Android `AudioEffect` (jika vendor mengizinkan), band sesuai kemampuan perangkat, preset hardware, Bass Boost, Virtualizer, penyimpanan pengaturan, dan antarmuka dasar. **Daftar fitur lengkap di atas belum seluruhnya diimplementasikan pada source ini.** Fitur PEQ 8-band, preamp, treble, compressor, limiter, L/R, spectrum analyzer, serta mesin DSP C++ memerlukan pengembangan lanjutan dan tidak boleh dianggap aktif hanya karena tercantum di daftar kebutuhan.

## Build APK melalui GitHub Actions

1. Upload folder proyek ini ke repository GitHub. File `settings.gradle.kts` harus berada di dalam folder proyek Android.
2. Workflow otomatis mencari `settings.gradle` atau `settings.gradle.kts` sampai kedalaman 6 folder, jadi proyek boleh berada di subfolder repository.
3. Buka tab **Actions**.
4. Jalankan **Build DLMS Mini Equalizer APK** (atau push ke branch `main`/`master`).
5. Unduh artifact **DLMS-Mini-APK**. Di dalamnya ada `app-debug.apk`.

Workflow menggunakan Java 17 dan Gradle 8.9. Tidak menggunakan `android-actions/setup-android` sehingga tidak meminta paket SDK lama bernama `tools`.

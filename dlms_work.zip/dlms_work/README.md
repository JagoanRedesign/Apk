# DLMS Equalizer 3.0

Project Android Kotlin untuk DLMS Equalizer.

## Fitur
- Equalizer 10-band dengan rentang -12 dB sampai +12 dB.
- Mode EQ 1-Way dan 2-Way.
- Preset bawaan dan preset kustom.
- Import preset melalui JSON copy-paste (tombol PASTE membaca clipboard).
- Export preset menjadi JSON dan tombol COPY.
- YouTube embedded player menggunakan iframe resmi YouTube; masukkan URL atau ID video.
- Limiter Android DynamicsProcessing: enable, attack, release, ratio, threshold, post-gain.
- Menu Pengaturan dan About aplikasi.
- Tidak ada pemutar file audio lokal, VOL L/R, MUTE, atau meter output L/R.

## Catatan kompatibilitas audio
Equalizer dan DynamicsProcessing dibuat pada audio session global 0. Efek global tidak dijamin oleh semua vendor Android; beberapa perangkat hanya mengizinkan efek pada sesi audio aplikasi sendiri. Limiter membutuhkan Android 9/API 28 atau lebih baru dan dukungan efek DynamicsProcessing pada firmware perangkat. Kontrol limiter tetap disimpan pada perangkat yang tidak mendukung efek tersebut, tetapi tidak akan memproses audio.

Pemutar YouTube berjalan melalui YouTube embedded player. Video tertentu dapat menolak embedding, dan batasan wilayah, usia, hak cipta, login, jaringan, serta kebijakan YouTube tetap berlaku. Audio YouTube tidak dijamin melewati EQ/limiter global karena implementasi audio WebView/vendor Android berbeda-beda.

## Format JSON
```json
{
  "format": "dlms-mini-presets",
  "version": 1,
  "presets": [
    {
      "name": "Warm Vocal",
      "bands_db": [-2, -1, 0, 2, 4, 5, 3, 1.5, 0, -1]
    }
  ]
}
```
`bands_db` harus berisi tepat 10 angka dalam dB, urutan frekuensi: 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k Hz. Nilai dibatasi ke -12..+12 dB.

## Build via GitHub Actions
1. Upload `dlms_work.zip` ke root repository GitHub.
2. Upload file `build.yml` ke `.github/workflows/build.yml`.
3. Buka tab **Actions**, pilih **Build DLMS Equalizer APK**, lalu **Run workflow**.
4. Setelah selesai, unduh artifact **DLMS-Equalizer-APK**.

Build APK belum dapat diuji di lingkungan ini karena Android SDK/Gradle tidak tersedia. Verifikasi akhir dilakukan oleh GitHub Actions.

# DLMS Mini Equalizer

## Fitur
- Equalizer 10-band: 31, 62, 125, 250, 500 Hz, 1, 2, 4, 8, 16 kHz.
- Rentang kontrol −12 dB hingga +12 dB, resolusi 0,5 dB (49 posisi).
- Fader vertikal metalik dengan jalur biru, dapat digeser langsung.
- Tombol + di atas dan − di bawah setiap fader; nilai dB di bawah fader.
- Panel 10 band berbagi lebar layar, tanpa scroll horizontal.
- Mode 1-Way (full-range) dan 2-Way (LOW 31–500 Hz / HIGH 1–16 kHz).
- Preset Flat, Pop, Rock, Jazz, Bass Boost, Vocal, Dangdut, DJ Horeg, preset kustom, dan reset.
- Spectrum Analyzer.
- Limiter (DynamicsProcessing, Android 9+): Limiter enabled, Attack time, Release time, Ratio, Threshold, Post-gain.
- Pita Equalizer: 5, 10, 13, atau 21 band (21 band hibrida: bass ringkas, menengah–tinggi rapat).
- Preset menyimpan kurva EQ dan pengaturan limiter.
- Export / Import preset berbasis salin & tempel (teks `DLMS-PRESET v2`, v1 tetap diterima).
- Layar Pengaturan: Kekuatan Penuh (±22 dB), Pipeline audio (Standar/Maksimum), Spectrum analyzer, Layar tetap menyala, Reset.
- Layar Tentang aplikasi.
- Efek: pre-amp, balance, mute kiri/kanan, Bass Boost, Virtualizer, Loudness, Reverb, kompresor multiband (3 band), Post-EQ/tone (3 band).
- Profil headphone generik (preset koreksi umum, bukan hasil ukur model tertentu).
- Notifikasi "Preset ... digunakan" setiap kali preset/profil dipilih.
- Aktif di latar belakang: foreground service dengan notifikasi (tombol Matikan).
- Mode Sesi Aplikasi (App Session Mode): EQ dipasang per sesi audio pemutar musik lewat broadcast OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION; daftar aplikasi terdeteksi dapat dikelola; opsi Stabilkan saat peluncuran.
- Copyright: Dibuat oleh Ilham Galeh.

## Catatan audio Android
Tampilan UI menyediakan 10 band dengan resolusi 0,5 dB. Android `Equalizer` memakai jumlah band hardware yang disediakan perangkat; jika jumlahnya kurang dari 10, beberapa band UI dipetakan ke band hardware terdekat. Karena itu, hasil suara aktual dapat berbeda antarperangkat. Spectrum Analyzer dan efek audio global juga bergantung pada dukungan Android/ROM serta sesi audio aktif.

Mode 2-Way di aplikasi ini adalah pembagian kontrol LOW/HIGH pada equalizer 10-band, bukan crossover aktif dengan dua output amplifier terpisah.

## Build melalui GitHub Actions
1. Upload `dlms_work.zip` ke root repository.
2. Upload file workflow `build.yml` ke `.github/workflows/build.yml`.
3. Push ke branch `main`, atau buka tab **Actions** lalu jalankan **Build DLMS Mini APK** melalui **Run workflow**.
4. Setelah selesai, buka hasil workflow dan unduh artifact **DLMS-Mini-APK**.

Kompilasi APK di GitHub Actions belum dijalankan pada saat paket ini diserahkan.

## Format preset (salin & tempel)
```
DLMS-PRESET v2
Nama Preset|0,2,4,0,-2,0,2,4,2,0|L1,1,60,10,-2,0
```
- Kolom 2: 5, 10, 13, atau 21 angka (satuan 0,5 dB, -44..44), urut dari band terendah.
- Kolom 3 (opsional): limiter `L<aktif 0/1>,<attack ms>,<release ms>,<ratio>,<threshold dB>,<post-gain dB>`.
- Header `DLMS-PRESET v1` (10 band tanpa limiter) tetap diterima.

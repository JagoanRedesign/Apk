# DLMS Mini Equalizer

Android project for the DLMS Mini Equalizer.

## Added in this revision

- VOL L (SUB) and VOL R (MID) gain controls, each centered at `0.0 dB`.
- Gain range `-12.0 dB` to `+12.0 dB`, in `0.5 dB` steps.
- Separate MUTE state for both controls; state is saved in SharedPreferences and applied to the built-in player.
- Level meters with a red peak-hold marker.
- Import custom presets from a JSON file using Android's document picker.
- Existing 10-band equalizer, 1-Way/2-Way mode, music presets, and spectrum view remain.

## Import preset JSON format

Use `preset-import-template.json` as the example. `presets` is an array. Each item needs a unique `name` and `bands_db` with exactly 10 numeric values in dB, ordered as:

`31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k Hz`.

Values are rounded to the nearest 0.5 dB and clamped to `-12.0..+12.0 dB`. To import, open **Preset Musik > Import preset**, choose the JSON file, and the imported presets will appear in the preset list.

Legacy single-preset JSON with a `bands` array is also accepted. In that legacy form, each value is an integer half-dB unit (`-24..24`).

## Cara kerja VOL L / VOL R / MUTE (diperbaiki di versi 2.2)

Sebelumnya kontrol ini hanya menyimpan angka di UI. Penyebabnya: Android tidak menyediakan gain atau mute per-kanal untuk audio sistem. `Equalizer(0, 0)` dan `Visualizer(0)` bekerja pada hasil campuran seluruh aplikasi, jadi tidak bisa memisahkan kiri dan kanan.

Sekarang ada **Pemutar** bawaan (`ChannelPlayer.kt`). Pemutar men-decode file audio menjadi PCM stereo, mengalikan kanal L dan kanal R dengan gain masing-masing (MUTE = gain 0, perubahan dihaluskan agar tidak ada bunyi klik), lalu memutarnya lewat `AudioTrack`.

- VOL L / VOL R / MUTE **bekerja nyata** pada lagu yang diputar di Pemutar.
- Meter level L/R dibaca dari sampel PCM yang benar-benar dikirim (sesudah gain dan mute), bukan lagi perkiraan dari FFT.
- Equalizer 10-band dan spektrum dipasang ke sesi audio Pemutar, sehingga juga bekerja pada lagu tersebut.
- Audio aplikasi lain (Spotify, YouTube, dll.) tetap **tidak** bisa diatur per-kanal; untuk itu hanya EQ global (jika didukung perangkat).
- Sumber mono diduplikasi ke L+R. Sumber lebih dari 2 kanal hanya memakai dua kanal depan.
- Import preset dan simpan preset kini langsung memperbarui daftar tanpa `recreate()`, sehingga lagu tidak terhenti.

Keterbatasan: pemutaran belum memakai foreground service, jadi bisa berhenti jika aplikasi dimatikan sistem saat di latar belakang.

## Build

Open this folder in Android Studio or upload the project to GitHub and run the included workflow under `.github/workflows/android-build.yml`.

The APK build has not been verified in this environment.

Copyright: Dibuat oleh Ilham Galeh.

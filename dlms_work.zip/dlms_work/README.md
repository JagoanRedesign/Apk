# DLMS Mini Equalizer 3.1

Android app with a 10-slider EQ UI, built-in/custom presets, optional limiter, and GitHub Actions APK build.

## Build APK with GitHub Actions

1. Extract this ZIP.
2. Upload the **contents of the `dlms_work` folder** to the root of a GitHub repository.
3. Open **Actions** and run **Build DLMS Mini APK** (or push to `main`).
4. Download the `DLMS-Mini-APK` artifact from the completed workflow.

## Important Android audio limitation

The app creates `Equalizer(0, 0)`, which requests an Android output-mix effect. Android device vendors may deny or ignore global output-mix effects. The app cannot force-process audio from every other app. The status line reports whether the effect was created and whether band values were accepted by the Android audio effect. A device with no global output-mix support needs an app-owned audio playback pipeline (or a supported audio-capture workflow with user consent); it cannot be fixed by changing slider UI code alone.

The ten UI sliders are mapped with logarithmic interpolation to the number of physical EQ bands exposed by the device. If the device exposes five hardware bands, it cannot provide ten independent hardware filters.

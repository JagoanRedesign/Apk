# DLMS Mini Equalizer

Android equalizer app by **Ilham Galeh**.

## Features in this source
- 10 user-facing EQ sliders: 31, 62, 125, 250, 500 Hz, 1, 2, 4, 8, 16 kHz.
- Live FFT spectrum display through Android `Visualizer` (requests `RECORD_AUDIO`).
- Android `Equalizer`, `Virtualizer`, and `PresetReverb` effects.
- Preamp control and Smart Limiter / Auto-Reduce gain calculation.
- Balance control setting (persisted per device; see platform limitation below).
- Built-in Pop, Rock, Jazz, Bass Boost, Vocal, Dangdut, and DJ Horeg presets.
- Save and reload custom EQ presets.
- Auto-save EQ values, preamp, balance, and limiter setting in device-specific preferences.
- App credit: **Dibuat oleh Ilham Galeh**.

## Important Android limitations
This app requests Android audio effects on audio session `0` (output mix). Android vendors can reject or ignore global effects; therefore system-wide processing is not guaranteed on every phone. Android's standard global `Equalizer` API exposes the number of bands supplied by the device. The ten UI controls are mapped to the nearest available hardware bands, so some controls can share a hardware band on phones with fewer than ten bands. A true independent ten-band DSP requires an app-owned audio pipeline or OEM/system audio-effect support.

The Android public audio-effect API does not provide a universal per-channel L/R balance control for all other apps' system audio. The balance value is saved for a future app-owned playback pipeline; it is not falsely applied to global audio. `Visualizer` requires microphone permission and may show no data when the device/ROM does not expose output-mix visualization. Reverb and virtualizer are likewise device-dependent.

The limiter is a gain-reduction calculation that lowers the effective EQ gain based on the highest boost plus preamp. It is not a sample-accurate brickwall limiter because Android's global Equalizer API does not expose raw PCM samples.

## Build using GitHub Actions
1. Upload this project directory as `dlms_work.zip` to the root of your GitHub repository.
2. Upload `.github/workflows/build.yml` to the repository at that exact path (the outer package includes it).
3. Push to `main` or run **Build DLMS Mini APK** from Actions.
4. Download artifact `DLMS-Mini-APK`.

Package name: `com.dlmsmini.equalizer`  
Min SDK: 23  
Compile SDK: 35  
Copyright: © Ilham Galeh

# DLMS Mini Equaliser 3.0

Android equaliser project with a dark/cyan interface, 10-band software EQ, clipboard preset transfer, AudioPlaybackCapture and a configurable limiter.

## Main features
- 10-band equaliser: 31 Hz through 16 kHz, -12 dB to +12 dB in 0.5 dB steps.
- 1-Way / 2-Way mode selector.
- AudioPlaybackCapture input for audio from other apps, including YouTube where the source app permits capture.
- Limiter: enable, attack (0.1–200 ms), release (1–2000 ms), ratio (1:1–40:1), threshold (-24–0 dB), post-gain (-12–+12 dB).
- Preset COPY/PASTE through the Android clipboard; JSON text is used so presets can also be shared manually.
- Settings and About dialogs. Settings persist locally.
- Built-in file player, left/right output controls and L/R meters have been removed.

## Audio capture limitations
AudioPlaybackCapture requires Android 10 (API 29) or newer, explicit MediaProjection consent, and source apps that allow playback capture. Some apps, protected streams, DRM content, or device vendors may block capture. The app cannot force YouTube or another app to permit capture. The capture session runs while this activity remains alive; stopping/destroying the activity stops capture.

## Build locally
Open this directory in Android Studio or run `gradle wrapper --gradle-version 8.9` and `./gradlew assembleDebug`.

## GitHub Actions
The workflow expects `dlms_work.zip` at the repository root. Push the archive to the `main` branch or use Actions → Build DLMS Mini APK → Run workflow. Download the `DLMS-Mini-APK` artifact after a successful build.

## Preset clipboard format
```json
{
  "format": "dlms-mini-presets",
  "version": 1,
  "presets": [
    { "name": "My Preset", "bands_db": [0, 1, 2, 3, 2, 1, 0, -1, -2, -1] }
  ]
}
```

Copyright: Dibuat oleh Ilham Galeh.

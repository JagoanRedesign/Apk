# DLMS Mini Equalizer

## Fitur
- Equalizer 10-band: 31, 62, 125, 250, 500 Hz, 1, 2, 4, 8, 16 kHz.
- Mode **1-Way**: seluruh 10 band tampil sebagai satu kurva full-range.
- Mode **2-Way**: 10 band dibagi menjadi dua kelompok kontrol, LOW (31–500 Hz) dan HIGH (1–16 kHz).
- Preset Flat, Pop, Rock, Jazz, Bass Boost, Vocal, Dangdut, dan DJ Horeg.
- Simpan preset kustom, reset flat, auto-save berdasarkan perangkat, dan spectrum visualizer.
- Copyright: Dibuat oleh Ilham Galeh.

## Catatan implementasi
Mode 2-Way di aplikasi ini adalah pemisahan kelompok kontrol frekuensi LOW/HIGH dalam satu kurva 10-band, bukan crossover aktif dengan dua output amplifier terpisah. Android `Equalizer` memakai jumlah band hardware dari perangkat. Jika hardware menyediakan lebih sedikit band daripada 10, beberapa nilai UI digabung ke band hardware terdekat agar tidak saling menimpa. Efek sistem dan visualizer bergantung dukungan perangkat/ROM.

## Build
Gunakan workflow `.github/workflows/android-build.yml` dari repository induk. Workflow mengunduh `dlms_work.zip`, mengekstraknya, lalu menjalankan `assembleDebug`.

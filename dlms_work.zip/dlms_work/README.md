# DLMS Mini Equalizer 3.0

Equalizer 10 band + limiter untuk Android, dibuat dengan Kotlin tanpa file layout XML.

## Fitur
- Equalizer 10 band (31 Hz - 16 kHz), langkah 0,5 dB, preset bawaan dan preset buatan sendiri.
- **Limiter** (DynamicsProcessing, Android 9+): Limiter enabled, Attack time, Release time, Ratio, Threshold, Post-gain.
- **Import / Export preset lewat salin & tempel** (teks JSON, lihat `preset-import-template.json`).
- Mendukung pemutar lain termasuk YouTube melalui pipeline audio (global, per sesi, atau maksimum).
- Layanan latar belakang (notifikasi) agar efek tetap aktif saat aplikasi ditutup.
- Halaman **Pengaturan** dan **Tentang aplikasi** (menu titik tiga di pojok kanan atas).
- Dihapus: pemutar bawaan serta kontrol VOL L/R, MUTE, dan meter output L/R.

## Pipeline audio
| Mode | Cara kerja |
|---|---|
| Global | Efek dipasang pada sesi audio 0. |
| Per sesi | Efek dipasang pada sesi pemutar yang mengumumkan diri lewat broadcast efek audio atau terdeteksi dari pemutaran aktif. |
| Maksimum (bawaan) | Keduanya. |

Dukungan efek global dan deteksi sesi berbeda antar perangkat dan versi Android. Jika YouTube belum terpengaruh, pakai mode Maksimum dan biarkan layanan latar belakang aktif.

## Struktur kode
- `MainActivity.kt` - layar utama (spektrum, EQ, limiter, preset, import/export)
- `SettingsActivity.kt`, `AboutActivity.kt` - pengaturan dan tentang aplikasi
- `EffectEngine.kt` - Equalizer + limiter pada sesi global dan per sesi
- `EffectService.kt` - layanan latar belakang
- `LimiterFx.kt` - pembungkus DynamicsProcessing
- `AppSettings.kt`, `PresetCodec.kt` - penyimpanan dan format preset
- `Ui.kt`, `Widgets.kt` - helper UI, fader, spektrum

## Build
Upload `dlms_work.zip` dan `.github/workflows/build.yml` ke repository GitHub (zip di root repo), lalu jalankan Actions.

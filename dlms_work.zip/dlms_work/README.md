# DLMS Mini Equalizer

Android project for the DLMS Mini Equalizer.

## Added in this revision

- VOL L (SUB) and VOL R (MID) gain controls, each centered at `0.0 dB`.
- Gain range `-12.0 dB` to `+12.0 dB`, in `0.5 dB` steps.
- Separate MUTE state for both controls; state is saved in SharedPreferences.
- Level meters with a red peak-hold marker.
- Import custom presets from a JSON file using Android's document picker.
- Existing 10-band equalizer, 1-Way/2-Way mode, music presets, and spectrum view remain.

## Import preset JSON format

Use `preset-import-template.json` as the example. `presets` is an array. Each item needs a unique `name` and `bands_db` with exactly 10 numeric values in dB, ordered as:

`31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k Hz`.

Values are rounded to the nearest 0.5 dB and clamped to `-12.0..+12.0 dB`. To import, open **Preset Musik > Import preset**, choose the JSON file, and the imported presets will appear in the preset list.

Legacy single-preset JSON with a `bands` array is also accepted. In that legacy form, each value is an integer half-dB unit (`-24..24`).

## Important audio-routing limitation

This project uses Android's global `Equalizer(0, 0)` and `Visualizer(0)` effects. Android's global Equalizer API does not expose independent left/right output gain or per-channel mute controls. Therefore, the new VOL L/VOL R values and MUTE states are persisted and displayed by the UI, while the meter values are estimates derived from the global mixed FFT signal (lower-frequency bins for SUB and higher-frequency bins for MID). They are **not** independent left/right hardware meters and do **not** alter system audio yet.

To make those controls affect sound independently, the app needs to own the audio playback/output pipeline (for example, route PCM stereo samples through a DSP mixer and apply gain/mute to channel 0 and channel 1 before output). This cannot be reliably added to a system-wide equalizer by calling the public global Equalizer API alone.

## Build

Open this folder in Android Studio or upload the project to GitHub and run the included workflow under `.github/workflows/android-build.yml`.

The APK build has not been verified in this environment.

Copyright: Dibuat oleh Ilham Galeh.

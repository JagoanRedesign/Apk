# DLMS Mini Equalizer v3.2

## Baru di v3.2 — Pemutar musik (tab **Musik** di navigasi bawah)
- **Pencarian** lewat **NewPipeExtractor lokal di perangkat** (jalur utama, cepat, tanpa antre failover); bila gagal, dialihkan ke instans **Piped** publik (daftar instans diambil otomatis, bisa diisi instans sendiri di Pengaturan musik). Lagu resmi diutamakan: tahap `music_songs` (katalog YouTube Music) → `music_videos` → `videos`; di dalam tiap halaman skor keresmian (kanal Topic/VEVO, terverifikasi, "Official Audio") dinaikkan dan cover/remix/live/karaoke diturunkan kecuali memang dicari. Hasil **tanpa batas**, dimuat bertahap saat menggulir. Lagu berikutnya di antrean di-prefetch di latar.
- **Pemutaran streaming**: URL audio diekstrak **lokal di perangkat** dengan **NewPipeExtractor**, diputar ExoPlayer (Media3) di dalam MediaSessionService (notifikasi media, layar kunci, Bluetooth). Kualitas streaming: Tinggi / Standar / Hemat. Equalizer aplikasi ini ikut memproses musik di pemutar ini (sesi audio dikirim lewat broadcast yang sama dengan pemutar lain).
- **Perpustakaan lokal**: lagu tersimpan, lagu terunduh, dan hasil pindai musik di perangkat (SQLite).
- **Lirik LRCLIB**: otomatis (cocokkan durasi, utamakan yang bertimestamp), tampil tersinkron; tombol **Cari lirik** untuk memilih kandidat manual (pilihan disimpan).
- **Unduh** dengan pilihan kualitas (M4A/AAC dan Opus), opsi **sematkan sampul** dan **sematkan lirik** (LRC tersinkron atau teks biasa). Berkas disimpan di `Music/DLMS`. Penyematan tag (ditulis sendiri, tanpa pustaka luar) hanya untuk **M4A**; untuk Opus/WebM sampul dan lirik tetap tersedia di aplikasi tetapi tidak disematkan. M4A DASH di-remux ke M4A biasa (tanpa transcoding) agar durasi/tag terbaca benar.
- Catatan: ekstraksi YouTube sering berubah. Bila pemutaran gagal, naikkan versi `NewPipeExtractor` di `app/build.gradle.kts`.


## Baru di v3.1
- **Audio engine**: efek dibuat berprioritas tinggi + listener kendali/enable; pengawas 5 dtk memeriksa kendali, status enable, dan *baca-balik* parameter (EQ & limiter), lalu menerapkan ulang/membangun ulang (maks 3x per 30 dtk agar tidak berebut dengan EQ lain). Pembaruan slider hanya mengirim band yang berubah dan dibatasi laju (throttle) agar langsung terasa. Pemulihan Bluetooth/kabel/speaker bertahap (0,7 / 3 / 7 dtk) + pemantau playback. Deteksi efek vendor (Dolby dll.) di Diagnostik. Limiter selalu di ujung rantai efek.
- **Limiter**: aktif di pipeline Standar dan Maksimum (terverifikasi baca-balik attack/release/ratio/threshold); link group dipisah saat 2-Way; **meter OUT (terukur), IN dan GR (estimasi dari kurva limiter)**.
- **Crossover 2-Way**: frekuensi, slope 12/24/36/48 dB/okt (Linkwitz-Riley), LPF/HPF, gain LOW/HIGH, tukar kanal — tab 2-Way. Phase/polaritas TIDAK tersedia (DynamicsProcessing hanya magnitudo).
- **Parametric EQ 2.0** (tab PEQ): hingga 10 band, tipe Peak/Low shelf/High shelf/Low-pass/High-pass/Notch/Band-pass, Frequency, Gain, Q, grafik respons yang bisa digeser; ikut tersimpan di preset (format `DLMS-PRESET v4`).
- **Spectrum Analyzer 2.0**: mode WATERFALL, RMS/puncak dBFS, frekuensi puncak, kursor frekuensi, pilihan ukuran FFT.


## Baru di v3.0
- **Foreground service Android 14/15**: tipe `mediaPlayback` + izin `FOREGROUND_SERVICE_MEDIA_PLAYBACK`; penolakan start dari latar belakang (Android 12+) ditangkap dan dicatat; izin notifikasi runtime (Android 13+); tampilan edge-to-edge (targetSdk 35). `minSdk` 28 (Android 9), `targetSdk` 35.
- **Master ON/OFF**, **indikator efek benar-benar aktif** (efek dibuat + dikuasai aplikasi + menyala), **deteksi dukungan efek HP** (layar Diagnostik), **volume L/R 0–100**, **Batas EQ** 3–12 dB, **crossover LOW/HIGH sungguhan** (band MBC per kanal, 40 Hz–8 kHz), **reset total**, **backup/restore** (berkas/clipboard), **proteksi clipping** (limiter pengaman + headroom otomatis + indikator CLIP), **deteksi perangkat audio** (speaker/kabel/Bluetooth/USB/HDMI; efek dipasang ulang saat berganti), **riwayat preset**.
- **Spectrum Analyzer 2.0**: 20 Hz–20 kHz, mode BAR/WAVE/CURVE, peak hold, smoothing 3 tingkat, meter animasi BASS/MID/TREBLE.
- **Penanganan vendor**: panduan + pintasan mulai-otomatis untuk Xiaomi, Samsung, Huawei, OPPO/realme/OnePlus, vivo, Tecno/Infinix, ASUS.
- **Uji**: unit test JVM (`./gradlew testDebugUnitTest`) dan panduan uji ganti headset di layar Diagnostik.
- **Cara penggunaan**: panduan di dalam aplikasi (Setelan › Cara penggunaan).



## Fitur
- Equalizer 10-band: 31, 62, 125, 250, 500 Hz, 1, 2, 4, 8, 16 kHz.
- Rentang kontrol −12 dB hingga +12 dB, resolusi 0,5 dB (49 posisi).
- Fader vertikal metalik dengan jalur biru, dapat digeser langsung.
- Tombol + di atas dan − di bawah setiap fader; nilai dB di bawah fader.
- Panel 5 dan 10 band berbagi lebar layar; 13, 15, 21, dan 31 band memakai tampilan geser ke samping.
- Mode 1-Way (full-range) dan 2-Way (LOW 31–500 Hz / HIGH 1–16 kHz).
- Preset Flat, Pop, Rock, Jazz, Bass Boost, Vocal, Dangdut, DJ Horeg, preset kustom, dan reset.
- Spectrum Analyzer.
- Limiter (DynamicsProcessing, Android 9+): Limiter enabled, Attack time, Release time, Ratio, Threshold, Post-gain.
- Pita Equalizer: 5, 10, 13, 15, 21, atau 31 band. 15 band = 2/3 oktaf (25 Hz–16 kHz), 31 band = 1/3 oktaf standar ISO (20 Hz–20 kHz), 21 band hibrida (bass ringkas, menengah–tinggi rapat).
- **EQ kiri/kanan terpisah**: pilih STEREO / L / R di atas fader (L oranye, R ungu). STEREO = satu kurva untuk kedua kanal; L/R = kurva sendiri per kanal; tombol L→R dan R→L menyalin kurva. Dipakai bersama 2-Way, Parametric EQ, dan limiter. Mode ini memakai DynamicsProcessing (pipeline Maksimum otomatis); bila perangkat menolak EQ per kanal, kurva kiri/kanan dirata-ratakan dan hal itu ditampilkan di Diagnostik.
- **Tema**: Setelan › Tampilan: Ikuti sistem / Terang / Gelap, dan Warna dinamis (Material You, Android 12+).
- Preset menyimpan kurva EQ, limiter, dan semua efek.
- Navigasi bawah dengan ikon Font Awesome Free 6 (font di `app/src/main/assets/fonts/`): EQ, Limiter, Efek, Preset, Setelan.
- Preset bawaan (Flat, Pop, Rock, Jazz, Bass Boost, Vocal, Dangdut, Horeg Clarity) juga membawa limiter dan efek; definisinya ada di `Presets.kt`.
- Export / Import preset berbasis salin & tempel (teks `DLMS-PRESET v5`; v1 sampai v4 tetap diterima). Preset EQ L/R terpisah ikut tersimpan.
- Layar Pengaturan: Kekuatan Penuh (±22 dB), Pipeline audio (Standar/Maksimum), Spectrum analyzer, Layar tetap menyala, Reset.
- Layar Tentang aplikasi.
- Efek: pre-amp, balance, mute kiri/kanan, Bass Boost, Virtualizer, Loudness, Reverb, kompresor multiband (3 band), Post-EQ/tone (3 band).
- Profil headphone generik (preset koreksi umum, bukan hasil ukur model tertentu).
- Notifikasi "Preset ... digunakan" setiap kali preset/profil dipilih.
- Aktif di latar belakang: foreground service dengan notifikasi (tombol Matikan).
- Mode Sesi Aplikasi (App Session Mode): EQ dipasang per sesi audio pemutar musik lewat broadcast OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION; daftar aplikasi terdeteksi dapat dikelola; opsi Stabilkan saat peluncuran.
- Copyright: Dibuat oleh Ilham Galeh.

## Catatan audio Android
Tampilan UI menyediakan 10 band dengan resolusi 0,5 dB. Android `Equalizer` memakai jumlah band hardware yang disediakan perangkat; jika jumlahnya kurang dari 10, beberapa band UI dipetakan ke band hardware terdekat. Karena itu, hasil suara aktual dapat berbeda antarperangkat. Spectrum Analyzer dan efek audio global juga bergantung pada dukungan Android/ROM serta sesi audio aktif.

Mode 2-Way di aplikasi ini adalah pembagian kontrol LOW/HIGH pada equalizer 10-band, bukan crossover aktif dengan dua output amplifier terpisah.

## Build melalui GitHub Actions
1. Upload `dlms_work.zip` ke root repository.
2. Upload file workflow `build.yml` ke `.github/workflows/build.yml`.
3. Push ke branch `main`, atau buka tab **Actions** lalu jalankan **Build DLMS Mini APK** melalui **Run workflow**.
4. Setelah selesai, buka hasil workflow dan unduh artifact **DLMS-Mini-APK**.

Kompilasi APK di GitHub Actions belum dijalankan pada saat paket ini diserahkan.

## Format preset (salin & tempel)
```
DLMS-PRESET v5
Nama|0,2,4,0,-2,0,2,4,2,0|L1,1,60,10,-2,0|F0,0,0,0,0,50,0,50,0,4,0,0,-24,3,10,150,2,0,0,0,0
```
- Kolom 2: 5, 10, 13, 15, 21, atau 31 angka (satuan 0,5 dB, -44..44), urut dari band terendah. Pada preset EQ L/R terpisah ini adalah kanal kiri.
- `R` (opsional): kurva kanal kanan, `R<angka,angka,...>` dengan jumlah angka sama seperti kolom 2. Tanpa kolom ini preset berlaku untuk kedua kanal (stereo).
- `L` (opsional): limiter `L<aktif 0/1>,<attack ms>,<release ms>,<ratio>,<threshold dB>,<post-gain dB>`.
- `F` (opsional): 21 nilai efek, berurutan: preamp dB, balance (-100..100), mute kiri, mute kanan, bass aktif, bass %, virtualizer aktif, virtualizer %, loudness aktif, loudness dB, reverb (0-6), kompresor aktif, threshold, ratio, attack, release, makeup, tone aktif, tone bass, tone mid, tone treble. Flag aktif/mute memakai 0 atau 1.
- Header `DLMS-PRESET v1` sampai `v4` tetap diterima.

## Pembaruan aplikasi (notifikasi + wajib update)
1. Ubah `UpdateConfig.URL` di `Updater.kt` ke alamat HTTPS berkas `update.json` Anda (mis. raw GitHub).
2. Setiap rilis: naikkan `versionCode`/`versionName` di `app/build.gradle.kts`, unggah APK (mis. GitHub Releases), lalu perbarui `update.json`:
   - `versionCode` / `versionName`: versi terbaru. `apkUrl`: tautan HTTPS ke APK. `notes`, `message`: teks pada dialog.
   - `minVersionCode`: versi minimum yang boleh berjalan. Versi terpasang di bawah angka ini **wajib update** (dialog tidak bisa ditutup).
3. Aplikasi memeriksa saat dibuka dan tiap 6 jam (WorkManager), lalu menampilkan notifikasi. Ini polling berkala; aplikasi tidak memakai push FCM (fitur push dan Firebase sudah dihapus).

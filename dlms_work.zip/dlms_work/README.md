# DLMS Mini Equalizer 3.0

Android equalizer with 10-band DSP, 1-Way/2-Way mode selection, configurable limiter, clipboard JSON preset transfer, app settings and About screen.

## AudioPlaybackCapture

- Android 10 (API 29) or newer is required.
- Start capture and grant Android's screen/audio capture consent plus the RECORD_AUDIO permission.
- Capture is limited by Android's AudioPlaybackCapture policy. Source apps can opt out; protected content and some YouTube/device combinations may not be capturable.
- Important: AudioPlaybackCapture is a copy/tap of another app's playback. Android does not expose an API to mute or replace that source stream. This project processes the captured copy and plays the processed copy through AudioTrack, so the original source may remain audible and can sound doubled/echoed. Use headphones and lower/mute the source app where possible. This is not a system-wide insert effect.

## DSP

- 10 peaking EQ bands: 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16kHz.
- Band range: -12 to +12 dB in 0.5 dB steps.
- Limiter: enable, attack, release, ratio, threshold and post-gain.
- Limiter threshold range: -24..0 dB; post-gain: -12..+12 dB.

## Clipboard presets

Open Import / Export presets. COPY copies the current settings as JSON. PASTE reads JSON from clipboard into the text area. IMPORT validates and applies the first preset in the `presets` array.

Example structure:

```json
{
  "format": "dlms-equalizer-presets",
  "version": 1,
  "presets": [{
    "name": "My preset",
    "bands_db": [0, 1, 2, 0, -1, 0, 1, 2, 1, 0],
    "eq_enabled": true,
    "eq_mode": "1WAY",
    "limiter": {
      "enabled": true,
      "attack_ms": 10,
      "release_ms": 100,
      "ratio": 20,
      "threshold_db": -3,
      "post_gain_db": 0
    }
  }]
}
```

## Build

Open `dlms_work` in Android Studio, or upload `dlms_work.zip` and the root workflow `build.yml` to a GitHub repository and run Actions manually. The workflow extracts the ZIP and builds `assembleDebug`.

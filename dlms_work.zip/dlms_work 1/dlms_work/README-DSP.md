# DLMS Mini DSP (tanpa root)

## Build GitHub Actions

Workflow `.github/workflows/android-build.yml` otomatis mencari folder proyek berdasarkan `settings.gradle.kts` dan `app/build.gradle.kts`. Workflow mendukung:

- Proyek Android langsung di root repository.
- Folder `dlms_dsp/` atau `dlms_work/`.
- Arsip `dlms_mini_dsp_no_root.zip`, `dlms_work.zip`, atau `dlms_work_updated.zip`.

Disarankan upload isi folder `dlms_dsp` langsung ke root repository agar struktur `.github/workflows`, `app`, `build.gradle.kts`, dan `settings.gradle.kts` berada di root.

## Import / export preset

- Import memakai Android Storage Access Framework (`ACTION_OPEN_DOCUMENT` melalui `OpenDocument`), tidak membutuhkan izin storage.
- Export memakai `ACTION_CREATE_DOCUMENT` melalui `CreateDocument`, tidak membutuhkan izin storage.
- Format JSON versi 1 mendukung objek `{ "presets": [...] }`, satu objek preset, atau array preset.
- Format band yang direkomendasikan: `bands_db`, 10 nilai dB dari -12 sampai +12.
- Format lama `bands` didukung sebagai unit setengah dB integer (-24..24).
- Import memvalidasi seluruh preset sebelum menyimpan agar file tidak tersimpan setengah jika ada data yang rusak.
- Export menyertakan preset kustom dan nilai EQ aktif sebagai preset `Current`.

Contoh:

```json
{
  "format": "dlms-mini-presets",
  "version": 1,
  "presets": [
    { "name": "Warm", "bands_db": [-2, 1, 2, 1, 0, 0, 1, 2, 1, -1] }
  ]
}
```

## Batasan audio Android

APK tanpa root tidak dapat menyisipkan DSP ke global output mix untuk semua aplikasi pada semua perangkat. `AudioPlaybackCapture` Android 10+ hanya menangkap playback yang diizinkan oleh aplikasi sumber dan tidak menggantikan output aslinya. DSP stereo pada `StereoDspProcessor` memproses buffer PCM yang secara eksplisit dialirkan ke fungsi `process()`; agar terdengar, aplikasi harus memiliki jalur PCM sendiri (misalnya pemutar audio internal). Efek Android `Equalizer` yang tersedia pada perangkat juga bergantung pada vendor dan audio session.

Jadi aplikasi ini kompatibel untuk dipasang pada banyak perangkat Android yang memenuhi minSdk, tetapi fitur global system-wide tidak dapat dijamin tanpa dukungan vendor/ROM/root.


## Per-channel volume 0–100 dan JSON copy/paste
- VOL L dan VOL R memakai skala linear 0–100%; 0 = senyap, 100 = level asli (unity).
- Mesin `StereoDspProcessor` menerapkan volume, mute, dan 10-band EQ pada buffer PCM Float stereo milik aplikasi (`L,R,L,R`). Integrasikan `processOwnedStereoPcm()` ke callback/player PCM milik aplikasi agar audio yang diproses benar-benar terdengar.
- Import/Export preset sekarang memakai dialog JSON: Export → Salin, lalu tempel di aplikasi lain; Import → tempel JSON → Import. JSON memuat daftar preset serta pengaturan volume/mute channel.
- **Batasan penting:** layar Equalizer Android yang ada tidak menyediakan jalur PCM stereo untuk seluruh audio HP. APK biasa tidak dapat menyisipkan DSP ke semua aplikasi tanpa dukungan OEM/system atau root. Karena itu VOL L/R dan MUTE di UI disimpan dan diteruskan ke mesin DSP, tetapi tidak mengubah suara semua aplikasi HP pada perangkat non-root tanpa pipeline audio PCM yang dimiliki aplikasi.

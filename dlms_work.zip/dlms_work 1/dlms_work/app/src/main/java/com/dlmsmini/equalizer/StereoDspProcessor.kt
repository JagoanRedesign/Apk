package com.dlmsmini.equalizer

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.pow

/** DSP PCM stereo interleaved Float: L,R,L,R. Processes only audio owned by DLMS. */
class StereoDspProcessor(sampleRate: Int = 48000) {
    companion object {
        val BAND_HZ = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        private const val MIN_DB = -12f
        private const val MAX_DB = 12f
    }
    @Volatile private var volumeL = 100
    @Volatile private var volumeR = 100
    @Volatile var muteL = false
    @Volatile var muteR = false
    @Volatile var peakLeft = 0f; private set
    @Volatile var peakRight = 0f; private set
    @Volatile var rmsLeft = 0f; private set
    @Volatile var rmsRight = 0f; private set
    private val sr = sampleRate.coerceAtLeast(8000)
    private val gains = FloatArray(10)
    private val left = Array(10) { Biquad() }
    private val right = Array(10) { Biquad() }

    /** Independent channel volume: 0..100 percent; 100 is unity gain. */
    @Synchronized fun setChannelVolume(leftPercent: Int, rightPercent: Int) {
        volumeL = leftPercent.coerceIn(0, 100)
        volumeR = rightPercent.coerceIn(0, 100)
    }

    /** Backward-compatible dB API. */
    @Synchronized fun setChannelGain(leftDb: Float, rightDb: Float) {
        volumeL = (100f * 10f.pow(leftDb.coerceIn(MIN_DB, MAX_DB) / 20f)).roundToInt().coerceIn(0, 100)
        volumeR = (100f * 10f.pow(rightDb.coerceIn(MIN_DB, MAX_DB) / 20f)).roundToInt().coerceIn(0, 100)
    }
    @Synchronized fun setBandGain(index: Int, db: Float) {
        require(index in 0..9)
        gains[index] = db.coerceIn(MIN_DB, MAX_DB)
        configure(index)
    }
    @Synchronized fun setAllBandGains(db: FloatArray) {
        require(db.size == 10)
        for (i in 0..9) { gains[i] = db[i].coerceIn(MIN_DB, MAX_DB); configure(i) }
    }
    @Synchronized fun resetEq() { for (i in 0..9) { gains[i] = 0f; configure(i) } }
    private fun configure(i: Int) {
        val hz = BAND_HZ[i].coerceAtMost((sr * 0.45f).toInt()).toFloat()
        left[i].setPeaking(sr, hz, 1f, gains[i]); right[i].setPeaking(sr, hz, 1f, gains[i])
    }

    /** Process an interleaved stereo FloatArray in-place; call from audio thread. */
    fun process(pcm: FloatArray, offset: Int = 0, length: Int = pcm.size - offset) {
        require(offset >= 0 && length >= 0 && offset + length <= pcm.size && length % 2 == 0)
        val gl = volumeL / 100f
        val gr = volumeR / 100f
        var pl = 0f; var pr = 0f; var sl = 0.0; var srms = 0.0; var n = 0
        var p = offset
        while (p < offset + length) {
            var l = if (muteL) 0f else pcm[p] * gl
            var r = if (muteR) 0f else pcm[p + 1] * gr
            if (!muteL) for (f in left) l = f.process(l)
            if (!muteR) for (f in right) r = f.process(r)
            l = l.coerceIn(-1f, 1f); r = r.coerceIn(-1f, 1f)
            pcm[p] = l; pcm[p + 1] = r
            pl = maxOf(pl, abs(l)); pr = maxOf(pr, abs(r))
            sl += l.toDouble() * l; srms += r.toDouble() * r
            n++; p += 2
        }
        if (n > 0) { peakLeft = pl; peakRight = pr; rmsLeft = sqrt(sl / n).toFloat(); rmsRight = sqrt(srms / n).toFloat() }
    }

    private class Biquad {
        private var b0=1f; private var b1=0f; private var b2=0f; private var a1=0f; private var a2=0f
        private var x1=0f; private var x2=0f; private var y1=0f; private var y2=0f
        fun setPeaking(fs: Int, hz: Float, q: Float, db: Float) {
            val a = 10.0.pow((db / 40.0).toDouble()).toFloat()
            val w = (2.0 * PI * hz / fs).toFloat(); val cw=cos(w); val sw=sin(w); val alpha=sw/(2f*q)
            val a0=1f+alpha/a
            b0=(1f+alpha*a)/a0; b1=(-2f*cw)/a0; b2=(1f-alpha*a)/a0
            a1=(-2f*cw)/a0; a2=(1f-alpha/a)/a0
        }
        fun process(x: Float): Float {
            val y=b0*x+b1*x1+b2*x2-a1*y1-a2*y2
            x2=x1; x1=x; y2=y1; y1=y
            return if (y.isFinite()) y else 0f
        }
    }
}

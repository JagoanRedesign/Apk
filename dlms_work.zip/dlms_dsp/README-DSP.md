# DLMS Mini — DSP stereo tanpa root

## Batasan Android
APK biasa tidak dapat mengambil alih atau mengganti global output mix Android. `AudioEffect` untuk global output session 0 sudah deprecated; efek resmi ditujukan pada audio session milik `AudioTrack`/`MediaPlayer` tertentu.

`AudioPlaybackCapture` (Android 10/API 29+) hanya menangkap audio yang memenuhi usage UNKNOWN/GAME/MEDIA dan kebijakan capture yang mengizinkan. Dibutuhkan RECORD_AUDIO dan persetujuan dialog MediaProjection. Aplikasi sumber dapat melarang capture. Capture adalah salinan PCM, bukan insert effect pada output; memutar salinan kembali tidak mematikan audio asli dan dapat menyebabkan suara ganda/delay.

## Mesin DSP
`StereoDspProcessor.kt` adalah pemroses PCM Float stereo interleaved L,R. Fitur: gain L/R -12..+12 dB, MUTE independen, 10 peaking-EQ band, peak dan RMS terpisah.

Contoh integrasi pada callback audio milik DLMS:
```kotlin
val dsp = StereoDspProcessor(48000)
dsp.setChannelGain(volLeftDb, volRightDb)
dsp.muteL = muteLeft
dsp.muteR = muteRight
dsp.setAllBandGains(floatArrayOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f))
// Pada audio callback, untuk buffer Float PCM stereo L,R,L,R:
dsp.process(floatPcmBuffer)
// meter: dsp.peakLeft, dsp.peakRight, dsp.rmsLeft, dsp.rmsRight
```
Panggil `process()` pada audio thread, bukan UI thread. Untuk produk low-latency, hubungkan ke Oboe/AAudio/AudioTrack dan hindari alokasi/operasi blocking pada callback.

## Audio semua aplikasi HP
Untuk pemrosesan transparan semua audio diperlukan integrasi audio effect vendor/system (privileged/system app, ROM khusus, atau root + modul yang cocok perangkat). Tanpa root dan tanpa dukungan OEM, tidak ada API APK universal untuk memproses semua audio aplikasi lain. Karena versi Android dan model HP belum diketahui, dukungan OEM tidak dapat dipastikan.

## Build
1. Ekstrak ZIP dan upload seluruh isi folder `dlms_dsp` ke root repository GitHub.
2. Pastikan `.github/workflows/android-build.yml` ikut terupload.
3. Buka Actions → workflow Android Build → Run workflow.
4. Unduh APK dari artifact.

Kompilasi belum diuji. Kelas DSP ini siap dipanggil oleh pipeline PCM aplikasi, tetapi proyek UI saat ini belum mempunyai player PCM internal yang mengirim audio ke kelas ini. Jadi jangan menganggap kontrol VOL L/R sudah mengubah audio sistem.

# DLMS Mini Equalizer

Aplikasi Android equalizer output-mix (global) berbasis Android `AudioEffect` dengan 31-band/ jumlah band sesuai HAL perangkat, preset hardware, Bass Boost, Virtualizer, penyimpanan pengaturan, dan build GitHub Actions.

## Penting: kompatibilitas system-wide
Aplikasi meminta `Equalizer(0, 0)` (audio session 0/output mix). Pada perangkat yang mengekspos global output-mix effects, efek dapat memproses audio lintas aplikasi. Banyak ROM/OEM modern menolak atau mengabaikan global session; aplikasi akan menampilkan pesan status dan tidak berpura-pura bahwa audio sistem telah diproses. Aplikasi biasa tidak dapat memaksa efek global pada perangkat yang membatasi akses tersebut.

Tidak memakai `AudioPlaybackCapture` sebagai jalur EQ: API itu menangkap salinan audio dan memutarnya kembali, bukan menyisipkan filter ke jalur audio asli, sehingga dapat menghasilkan audio ganda/echo dan latensi. Aplikasi sumber juga harus mengizinkan capture.

## Build
Push seluruh folder ke GitHub, buka Actions, jalankan workflow **Build DLMS Mini Equalizer APK**, lalu unduh artifact `DLMS-Mini-Equalizer-APK`. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur
- Global output mix equalizer (jika didukung vendor)
- Band/frekuensi mengikuti kemampuan audio HAL perangkat
- Preset equalizer bawaan perangkat
- Bass Boost dan Virtualizer jika tersedia
- Simpan gain band dan status enable
- Antarmuka gelap, tanpa izin microphone atau screen capture

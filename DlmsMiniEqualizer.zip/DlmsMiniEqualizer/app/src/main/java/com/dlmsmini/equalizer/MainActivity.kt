package com.dlmsmini.equalizer

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.math.roundToInt

/**
 * Best-effort system output-mix equalizer. Audio session 0 means global output mix
 * on devices whose audio HAL/vendor implementation exposes global effects.
 * Android/OEMs may reject or ignore this session; the app reports that honestly.
 */
class MainActivity : AppCompatActivity() {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var enableSwitch: Switch
    private lateinit var bandsBox: LinearLayout
    private lateinit var presetSpinner: Spinner
    private val presetLabels = mutableListOf("Flat")
    private var minLevel = -1500
    private var maxLevel = 1500
    private var bandCount = 0
    private val prefs by lazy { getSharedPreferences("eq_state", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        initializeEffects()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 12, 24), Color.rgb(22, 25, 48)))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("DLMS MINI", 13, Color.rgb(0,229,255), true))
        root.addView(text("EQUALIZER", 27, Color.WHITE, true))
        status = text("Menyiapkan audio effect…", 13, Color.LTGRAY, false)
        status.setPadding(0, dp(8), 0, dp(12)); root.addView(status)

        enableSwitch = Switch(this).apply {
            text = "Equalizer aktif"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
                applyEnabled(checked)
            }
        }
        root.addView(card(enableSwitch))

        root.addView(section("PRESET"))
        presetSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presetLabels)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position > 0) applyPreset(position - 1)
                }
            }
        }
        root.addView(card(presetSpinner))

        root.addView(section("GRAPHIC EQUALIZER"))
        bandsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(card(bandsBox))

        root.addView(section("ENHANCEMENT"))
        addEffectSlider("Bass Boost", "bass", 1000) { v -> try { bassBoost?.setStrength(v.toShort()) } catch (_: Exception) {} }
        addEffectSlider("Virtualizer", "virtual", 1000) { v -> try { virtualizer?.setStrength(v.toShort()) } catch (_: Exception) {} }

        val reset = Button(this).apply {
            text = "RESET KE FLAT"
            setOnClickListener { resetFlat() }
        }
        root.addView(reset)
        root.addView(text("Catatan: Equalizer sistem bergantung dukungan audio HAL/perangkat. Jika Android menolak output-mix session, aplikasi tidak dapat memaksa pemrosesan semua aplikasi tanpa akses sistem/root.", 12, Color.LTGRAY, false).apply { setPadding(0, dp(14), 0, 0) })
    }

    private fun initializeEffects() {
        try {
            // Session 0 requests the device output mix rather than one app's player session.
            equalizer = Equalizer(0, 0)
            equalizer?.enabled = prefs.getBoolean("enabled", true)
            minLevel = equalizer?.bandLevelRange?.get(0)?.toInt() ?: -1500
            maxLevel = equalizer?.bandLevelRange?.get(1)?.toInt() ?: 1500
            bandCount = equalizer?.numberOfBands?.toInt() ?: 0
            if (bandCount <= 0) throw IllegalStateException("Perangkat tidak menyediakan band equalizer global")
            try { bassBoost = BassBoost(0, 0).apply { enabled = true } } catch (_: Exception) {}
            try { virtualizer = Virtualizer(0, 0).apply { enabled = true } } catch (_: Exception) {}
            createBandControls()
            presetLabels.clear()
            presetLabels.add("Flat")
            for (i in 0 until ((equalizer?.numberOfPresets ?: 0).toInt())) {
                presetLabels.add(equalizer?.getPresetName(i.toShort()) ?: "Preset ${i + 1}")
            }
            (presetSpinner.adapter as? ArrayAdapter<String>)?.notifyDataSetChanged()
            status.text = "Equalizer output sistem tersedia • $bandCount band"
            status.setTextColor(Color.rgb(0,230,118))
            restoreBands()
        } catch (e: Exception) {
            status.text = "Equalizer global tidak didukung perangkat ini: ${e.message ?: e.javaClass.simpleName}"
            status.setTextColor(Color.rgb(255,120,120))
            bandsBox.removeAllViews()
            bandsBox.addView(text("Perangkat/ROM ini tidak mengizinkan efek Equalizer pada output mix (audio session 0). Aplikasi biasa tidak dapat mengubah audio semua aplikasi secara paksa. Coba ROM/perangkat yang mendukung global audio effects atau gunakan equalizer bawaan sistem.", 13, Color.WHITE, false))
            enableSwitch.isEnabled = false
        }
    }

    private fun createBandControls() {
        bandsBox.removeAllViews()
        for (i in 0 until bandCount) {
            val band = i.toShort()
            val centerMilliHz = equalizer!!.getCenterFreq(band)
            val hz = centerMilliHz / 1000
            val label = when {
                hz >= 1000 -> "${hz / 1000.0} kHz"
                else -> "$hz Hz"
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, dp(7)) }
            val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            header.addView(text(label, 13, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            val value = text("0.0 dB", 12, Color.rgb(0,229,255), true)
            header.addView(value)
            row.addView(header)
            val seek = SeekBar(this).apply {
                max = maxLevel - minLevel
                progress = (-minLevel).coerceIn(0, max)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                        val level = (p + minLevel).coerceIn(minLevel, maxLevel)
                        value.text = String.format("%.1f dB", level / 100f)
                        if (fromUser) try { equalizer?.setBandLevel(band, level.toShort()); saveBand(i, level) } catch (_: Exception) {}
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            row.addView(seek)
            bandsBox.addView(row)
        }
    }

    private fun addEffectSlider(title: String, key: String, strengthMax: Int, onChange: (Int) -> Unit) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        val line = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        line.addView(text(title, 13, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val value = text("0%", 12, Color.rgb(0,229,255), true); line.addView(value); wrap.addView(line)
        val seek = SeekBar(this).apply {
            max = strengthMax
            progress = prefs.getInt(key, 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    value.text = "${p / 10}%"
                    if (fromUser) { onChange(p); prefs.edit().putInt(key, p).apply() }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        wrap.addView(seek); root.addView(card(wrap))
    }

    private fun applyPreset(preset: Int) {
        try {
            val eq = equalizer ?: return
            if (preset == 0) { resetFlat(); return }
            if (eq.numberOfPresets.toInt() >= preset) {
                eq.usePreset((preset - 1).toShort())
                for (i in 0 until bandCount) prefs.edit().putInt("band_$i", eq.getBandLevel(i.toShort()).toInt()).apply()
                refreshBandControls()
            }
        } catch (e: Exception) { status.text = "Preset tidak tersedia: ${e.message}" }
    }

    private fun resetFlat() {
        try {
            for (i in 0 until bandCount) {
                equalizer?.setBandLevel(i.toShort(), 0)
                prefs.edit().putInt("band_$i", 0).apply()
            }
            refreshBandControls()
            presetSpinner.setSelection(0)
        } catch (_: Exception) {}
    }

    private fun restoreBands() {
        for (i in 0 until bandCount) {
            val level = prefs.getInt("band_$i", 0).coerceIn(minLevel, maxLevel)
            try { equalizer?.setBandLevel(i.toShort(), level.toShort()) } catch (_: Exception) {}
        }
        refreshBandControls()
        val bass = prefs.getInt("bass", 0); try { bassBoost?.setStrength(bass.toShort()) } catch (_: Exception) {}
        val virt = prefs.getInt("virtual", 0); try { virtualizer?.setStrength(virt.toShort()) } catch (_: Exception) {}
    }

    private fun refreshBandControls() {
        for (i in 0 until bandsBox.childCount) {
            val row = bandsBox.getChildAt(i) as? LinearLayout ?: continue
            val header = row.getChildAt(0) as? LinearLayout ?: continue
            val value = header.getChildAt(1) as? TextView
            val seek = row.getChildAt(1) as? SeekBar
            val level = try { equalizer?.getBandLevel(i.toShort())?.toInt() ?: 0 } catch (_: Exception) { 0 }
            value?.text = String.format("%.1f dB", level / 100f)
            seek?.progress = (level - minLevel).coerceIn(0, seek.max)
        }
    }

    private fun saveBand(index: Int, level: Int) { prefs.edit().putInt("band_$index", level).apply() }
    private fun applyEnabled(enabled: Boolean) {
        try { equalizer?.enabled = enabled } catch (_: Exception) {}
        status.text = if (enabled) "Equalizer aktif" else "Equalizer nonaktif"
    }

    private fun section(s: String) = text(s, 12, Color.rgb(0,229,255), true).apply { setPadding(2, dp(18), 2, dp(7)) }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun card(child: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(10), dp(13), dp(10))
        background = GradientDrawable().apply { setColor(Color.argb(35,255,255,255)); cornerRadius = dp(14).toFloat() }
        addView(child)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(7); layoutParams = lp
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        equalizer = null; bassBoost = null; virtualizer = null
        super.onDestroy()
    }
}

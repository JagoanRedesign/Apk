# AdBlock Browser

Peramban Android ringan dengan pemblokir iklan, pemblokir popup, multi-tab, dan DNS over HTTPS (DoH).

## Fitur

1. **Multi-tab**: tab counter, TabSwitcher, tiap tab = WebViewFragment, state tersimpan saat rotasi
2. **Ad blocker**: berbasis host (domain + subdomain), respons 204 No Content
3. **DNS Unblock (DoH)**: Cloudflare (default) dan Google sebagai cadangan
4. **Navigasi**: smart URL, tombol back hardware, progress bar, judul & URL otomatis
5. **Popup blocker**: popup tanpa interaksi pengguna diblokir

## Spesifikasi

- Package: `com.adblock.browser`
- Kotlin, minSdk 24, targetSdk 34
- AGP 8.2.0, Gradle 8.2, JVM 17
- Material 3 + ViewBinding

## Build

Build otomatis lewat GitHub Actions (`assembleDebug`). APK ada di artifact hasil workflow.

Build lokal:

    gradle assembleDebug

## Daftar host iklan

Edit `app/src/main/assets/adblock_hosts.txt`, satu domain per baris. Baris yang diawali `#` diabaikan.

---

© 2025 by Wong Mranggen

## Build APK melalui GitHub Actions

1. Ekstrak isi ZIP ini ke repository GitHub (pastikan `settings.gradle.kts` berada di root repository).
2. Commit dan push ke branch `main` atau `master`, atau buka tab **Actions** lalu jalankan workflow **Build AdBlock Browser APK** dengan **Run workflow**.
3. Tunggu sampai job selesai dengan status hijau.
4. Buka hasil workflow, cari bagian **Artifacts**, lalu unduh `AdBlockBrowser-debug-apk`.
5. Ekstrak file artifact ZIP untuk mendapatkan `app-debug.apk`, lalu instal di perangkat Android.

Workflow memakai JDK 17, Gradle 8.2, dan Android SDK 34. APK debug ditandatangani otomatis dengan debug key; untuk distribusi publik, buat konfigurasi signing release milik sendiri.

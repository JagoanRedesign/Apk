package com.adblock.browser

import android.content.Context
import android.content.SharedPreferences
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import okhttp3.Cache
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.util.concurrent.TimeUnit

object DnsConfig {

    const val PROVIDER_CLOUDFLARE = 0
    const val PROVIDER_GOOGLE = 1

    private const val PREFS_NAME = "adblock_browser_prefs"
    private const val KEY_DOH_ENABLED = "doh_enabled"
    private const val KEY_DOH_PROVIDER = "doh_provider"
    private const val CACHE_SIZE_BYTES = 50L * 1024L * 1024L

    private val skippedRequestHeaders = setOf("cookie", "accept-encoding", "host")
    private val skippedResponseHeaders = setOf(
        "content-type",
        "content-length",
        "content-encoding",
        "transfer-encoding",
        "set-cookie"
    )

    @Volatile
    private var cachedClient: OkHttpClient? = null
    private var httpCache: Cache? = null

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DOH_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_DOH_ENABLED, enabled).apply()
    }

    fun provider(context: Context): Int =
        prefs(context).getInt(KEY_DOH_PROVIDER, PROVIDER_CLOUDFLARE)

    fun setProvider(context: Context, provider: Int) {
        prefs(context).edit().putInt(KEY_DOH_PROVIDER, provider).apply()
        invalidate()
    }

    fun invalidate() {
        cachedClient = null
    }

    fun client(context: Context): OkHttpClient {
        cachedClient?.let { return it }
        return synchronized(this) {
            cachedClient ?: buildClient(context.applicationContext).also { cachedClient = it }
        }
    }

    private fun buildClient(context: Context): OkHttpClient {
        val cache = httpCache ?: Cache(
            File(context.cacheDir, "doh_http_cache"),
            CACHE_SIZE_BYTES
        ).also { httpCache = it }

        return OkHttpClient.Builder()
            .dns(CustomDns.create(provider(context)))
            .cookieJar(WebCookieJar)
            .cache(cache)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /**
     * Mengambil request GET lewat OkHttp (DNS over HTTPS).
     * Mengembalikan null agar WebView menangani sendiri bila DoH mati,
     * request bukan GET, terjadi redirect pada main frame, atau terjadi error.
     */
    fun intercept(context: Context, request: WebResourceRequest): WebResourceResponse? {
        if (!isEnabled(context)) return null
        if (!request.method.equals("GET", ignoreCase = true)) return null
        val url = request.url.toString().toHttpUrlOrNull() ?: return null

        return try {
            val builder = Request.Builder().url(url)
            request.requestHeaders?.forEach { (name, value) ->
                if (name.lowercase() !in skippedRequestHeaders) {
                    builder.header(name, value)
                }
            }

            var http = client(context)
            if (request.isForMainFrame) {
                http = http.newBuilder()
                    .followRedirects(false)
                    .followSslRedirects(false)
                    .build()
            }

            val response = http.newCall(builder.build()).execute()
            toWebResponse(url.toString(), response)
        } catch (e: Exception) {
            null
        }
    }

    private fun toWebResponse(url: String, response: Response): WebResourceResponse? {
        val code = response.code
        val body = response.body
        if (body == null || code < 200 || code > 599 || code in 300..399) {
            response.close()
            return null
        }

        val contentType = body.contentType()
        val mime = if (contentType != null) {
            "${contentType.type}/${contentType.subtype}"
        } else {
            guessMime(url)
        }
        val charset = contentType?.charset()?.name()

        val headers = HashMap<String, String>()
        for (name in response.headers.names()) {
            if (name.lowercase() in skippedResponseHeaders) continue
            headers[name] = response.headers.values(name).joinToString(", ")
        }

        val reason = response.message.ifBlank { "OK" }
        return WebResourceResponse(mime, charset, code, reason, headers, body.byteStream())
    }

    private fun guessMime(url: String): String {
        val extension = MimeTypeMap.getFileExtensionFromUrl(url)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "text/html"
    }
}

private object WebCookieJar : CookieJar {

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val manager = CookieManager.getInstance()
        for (cookie in cookies) {
            manager.setCookie(url.toString(), cookie.toString())
        }
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val raw = CookieManager.getInstance().getCookie(url.toString()) ?: return emptyList()
        return raw.split(";").mapNotNull { Cookie.parse(url, it.trim()) }
    }
}

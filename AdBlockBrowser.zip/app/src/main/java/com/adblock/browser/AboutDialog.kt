package com.adblock.browser

import android.content.Context
import android.view.LayoutInflater
import com.adblock.browser.databinding.DialogAboutBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object AboutDialog {

    fun show(context: Context) {
        val binding = DialogAboutBinding.inflate(LayoutInflater.from(context))
        binding.aboutVersion.text = context.getString(R.string.about_version, BuildConfig.VERSION_NAME)

        MaterialAlertDialogBuilder(context)
            .setView(binding.root)
            .setPositiveButton(R.string.about_close, null)
            .show()
    }
}

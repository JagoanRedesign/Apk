package com.adblock.browser

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TabItem(
    val id: Long,
    var title: String = "",
    var url: String = ""
) : Parcelable

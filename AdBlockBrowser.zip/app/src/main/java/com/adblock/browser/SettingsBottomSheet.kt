package com.adblock.browser

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.adblock.browser.databinding.BottomSheetSettingsBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class SettingsBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext().applicationContext

        binding.switchDoh.isChecked = DnsConfig.isEnabled(ctx)
        if (DnsConfig.provider(ctx) == DnsConfig.PROVIDER_GOOGLE) {
            binding.radioGoogle.isChecked = true
        } else {
            binding.radioCloudflare.isChecked = true
        }
        updateProviderEnabled(binding.switchDoh.isChecked)

        binding.switchDoh.setOnCheckedChangeListener { _, checked ->
            DnsConfig.setEnabled(ctx, checked)
            updateProviderEnabled(checked)
        }

        binding.radioProvider.setOnCheckedChangeListener { _, checkedId ->
            val provider = if (checkedId == R.id.radioGoogle) {
                DnsConfig.PROVIDER_GOOGLE
            } else {
                DnsConfig.PROVIDER_CLOUDFLARE
            }
            DnsConfig.setProvider(ctx, provider)
        }

        binding.textVersion.text = getString(R.string.about_version, BuildConfig.VERSION_NAME)
    }

    override fun onStart() {
        super.onStart()
        val behavior = (dialog as? BottomSheetDialog)?.behavior
        behavior?.skipCollapsed = true
        behavior?.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun updateProviderEnabled(enabled: Boolean) {
        binding.radioCloudflare.isEnabled = enabled
        binding.radioGoogle.isEnabled = enabled
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    companion object {
        const val TAG = "SettingsBottomSheet"
    }
}

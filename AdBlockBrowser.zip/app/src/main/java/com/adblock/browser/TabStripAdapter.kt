package com.adblock.browser

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adblock.browser.databinding.ItemTabBinding

class TabStripAdapter(
    private val onSelect: (TabItem) -> Unit,
    private val onClose: (TabItem) -> Unit
) : RecyclerView.Adapter<TabStripAdapter.VH>() {

    private var items: List<TabItem> = emptyList()
    private var currentId: Long = -1L

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<TabItem>, current: Long) {
        items = list
        currentId = current
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemTabBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val b = holder.binding
        val isCurrent = item.id == currentId

        b.tabTitle.text = item.title.ifBlank { b.root.context.getString(R.string.tab_new_title) }
        b.tabUrl.text = item.url
        b.tabTitle.setTypeface(null, if (isCurrent) Typeface.BOLD else Typeface.NORMAL)

        if (isCurrent) {
            b.root.setBackgroundResource(R.drawable.bg_urlbar)
        } else {
            b.root.setBackgroundResource(0)
        }

        b.root.setOnClickListener { onSelect(item) }
        b.btnCloseTab.setOnClickListener { onClose(item) }
    }

    class VH(val binding: ItemTabBinding) : RecyclerView.ViewHolder(binding.root)
}

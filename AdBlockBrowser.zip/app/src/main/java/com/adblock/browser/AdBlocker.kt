package com.adblock.browser

import android.content.Context
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.IOException

object AdBlocker {

    private const val ASSET_FILE = "adblock_hosts.txt"

    @Volatile
    private var blockedHosts: Set<String> = emptySet()

    @Volatile
    private var initialized = false

    private val builtInHosts = listOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "googletagservices.com",
        "google-analytics.com",
        "googletagmanager.com",
        "adservice.google.com",
        "admob.com",
        "2mdn.net",
        "adnxs.com",
        "adsrvr.org",
        "adform.net",
        "advertising.com",
        "adcolony.com",
        "applovin.com",
        "ads.unity3d.com",
        "unityads.unity3d.com",
        "mopub.com",
        "inmobi.com",
        "chartboost.com",
        "vungle.com",
        "ironsrc.com",
        "supersonicads.com",
        "tapjoy.com",
        "startappservice.com",
        "smaato.net",
        "rubiconproject.com",
        "pubmatic.com",
        "openx.net",
        "casalemedia.com",
        "criteo.com",
        "criteo.net",
        "taboola.com",
        "outbrain.com",
        "revcontent.com",
        "mgid.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "exoclick.com",
        "juicyads.com",
        "trafficjunky.net",
        "adsterra.com",
        "hilltopads.net",
        "clickadu.com",
        "onclickads.net",
        "scorecardresearch.com",
        "quantserve.com",
        "moatads.com",
        "adsafeprotected.com",
        "imrworldwide.com",
        "hotjar.com",
        "mixpanel.com",
        "segment.io",
        "amplitude.com",
        "appsflyer.com",
        "adjust.com",
        "kochava.com",
        "flurry.com",
        "adtech.com",
        "yieldmo.com",
        "teads.tv",
        "smartadserver.com",
        "media.net",
        "bidswitch.net",
        "33across.com",
        "sharethrough.com",
        "lijit.com",
        "sovrn.com",
        "zedo.com",
        "ads.yahoo.com",
        "ads.twitter.com",
        "ads.linkedin.com",
        "ads.pinterest.com",
        "an.facebook.com",
        "pixel.facebook.com"
    )

    fun init(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            val set = HashSet<String>(builtInHosts)
            try {
                context.applicationContext.assets.open(ASSET_FILE).bufferedReader().useLines { lines ->
                    lines.forEach { raw ->
                        val line = raw.substringBefore('#').trim()
                        if (line.isNotEmpty()) {
                            val domain = line.split(Regex("\\s+")).last().lowercase().trimEnd('.')
                            if (domain.contains('.')) {
                                set.add(domain)
                            }
                        }
                    }
                }
            } catch (e: IOException) {
                // File aset tidak terbaca: tetap pakai daftar bawaan
            }
            blockedHosts = set
            initialized = true
        }
    }

    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrBlank()) return false
        val hosts = blockedHosts
        var candidate = host.lowercase().trimEnd('.')
        while (candidate.contains('.')) {
            if (hosts.contains(candidate)) return true
            candidate = candidate.substringAfter('.')
        }
        return false
    }

    fun blockedResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            204,
            "No Content",
            emptyMap(),
            ByteArrayInputStream(ByteArray(0))
        )
    }
}

package com.adblock.browser

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.adblock.browser.databinding.BottomSheetTabsBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class TabSwitcherBottomSheet : BottomSheetDialogFragment() {

    interface Host {
        fun tabsSnapshot(): List<TabItem>
        fun currentTabId(): Long
        fun selectTab(id: Long)
        fun closeTab(id: Long)
        fun newTab()
    }

    private var _binding: BottomSheetTabsBinding? = null
    private val binding get() = _binding!!

    private lateinit var stripAdapter: TabStripAdapter

    private val host: Host?
        get() = activity as? Host

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetTabsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        stripAdapter = TabStripAdapter(
            onSelect = { tab ->
                host?.selectTab(tab.id)
                dismiss()
            },
            onClose = { tab ->
                host?.closeTab(tab.id)
                refresh()
            }
        )

        binding.tabsRecycler.layoutManager = LinearLayoutManager(requireContext())
        binding.tabsRecycler.adapter = stripAdapter

        binding.btnNewTab.setOnClickListener {
            host?.newTab()
            dismiss()
        }

        refresh()
    }

    override fun onStart() {
        super.onStart()
        val behavior = (dialog as? BottomSheetDialog)?.behavior
        behavior?.skipCollapsed = true
        behavior?.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun refresh() {
        val list = host?.tabsSnapshot().orEmpty()
        stripAdapter.submit(list, host?.currentTabId() ?: -1L)
        binding.tabsTitle.text = getString(R.string.tabs_count_format, list.size)

        val density = resources.displayMetrics.density
        val itemPx = (56 * density).toInt()
        val maxPx = (resources.displayMetrics.heightPixels * 0.5f).toInt()
        val params = binding.tabsRecycler.layoutParams
        params.height = minOf(list.size * itemPx, maxPx)
        binding.tabsRecycler.layoutParams = params
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    companion object {
        const val TAG = "TabSwitcherBottomSheet"
    }
}

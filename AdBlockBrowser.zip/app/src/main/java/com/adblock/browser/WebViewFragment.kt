package com.adblock.browser

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import com.adblock.browser.databinding.FragmentWebviewBinding
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

class WebViewFragment : Fragment() {

    interface Host {
        fun registerWebFragment(fragment: WebViewFragment)
        fun unregisterWebFragment(fragment: WebViewFragment)
        fun onTabUrlChanged(tabId: Long, url: String)
        fun onTabTitleChanged(tabId: Long, title: String)
        fun onTabProgress(tabId: Long, progress: Int)
        fun onTabNavStateChanged(tabId: Long)
        fun onOpenNewTab(url: String)
    }

    private var _binding: FragmentWebviewBinding? = null
    private val binding get() = _binding!!

    private var host: Host? = null
    private lateinit var appContext: Context

    val tabId: Long
        get() = requireArguments().getLong(ARG_TAB_ID)

    private val webView: WebView?
        get() = _binding?.webView

    override fun onAttach(context: Context) {
        super.onAttach(context)
        host = context as? Host
        appContext = context.applicationContext
    }

    override fun onDetach() {
        super.onDetach()
        host = null
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AdBlocker.init(appContext)
        setupWebView()

        val restored = savedInstanceState
            ?.getBundle(STATE_WEB)
            ?.let { binding.webView.restoreState(it) != null }
            ?: false

        if (!restored) {
            val initialUrl = requireArguments().getString(ARG_URL).orEmpty().ifBlank { HOME_URL }
            binding.webView.loadUrl(initialUrl)
        }

        host?.registerWebFragment(this)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val id = tabId
        val wv = binding.webView

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, false)

        wv.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val scheme = request.url.scheme?.lowercase()
                if (scheme != "http" && scheme != "https") return null
                if (AdBlocker.isBlocked(request.url.host)) return AdBlocker.blockedResponse()
                return DnsConfig.intercept(appContext, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase()
                if (scheme in ALLOWED_SCHEMES) return false
                if (scheme == "tel" || scheme == "mailto" || scheme == "sms") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e: Exception) {
                        // Tidak ada aplikasi yang bisa menangani
                    }
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url != null) host?.onTabUrlChanged(id, url)
                host?.onTabNavStateChanged(id)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url != null) host?.onTabUrlChanged(id, url)
                val title = view?.title
                if (!title.isNullOrBlank()) host?.onTabTitleChanged(id, title)
                host?.onTabNavStateChanged(id)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                if (url != null) host?.onTabUrlChanged(id, url)
                host?.onTabNavStateChanged(id)
            }
        }

        wv.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                host?.onTabProgress(id, newProgress)
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                if (!title.isNullOrBlank()) host?.onTabTitleChanged(id, title)
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message
            ): Boolean {
                // Popup tanpa interaksi pengguna: blokir
                if (!isUserGesture) return false

                val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                val popup = WebView(view.context)
                val handled = AtomicBoolean(false)

                popup.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        v: WebView,
                        request: WebResourceRequest
                    ): Boolean = openPopupUrl(v, request.url.toString(), handled)

                    override fun onPageStarted(v: WebView?, url: String?, favicon: Bitmap?) {
                        if (v != null) openPopupUrl(v, url, handled)
                    }
                }

                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    private fun openPopupUrl(popup: WebView, url: String?, handled: AtomicBoolean): Boolean {
        if (url.isNullOrBlank() || url == "about:blank") return false
        if (handled.compareAndSet(false, true)) {
            host?.onOpenNewTab(url)
            popup.stopLoading()
            popup.post { popup.destroy() }
        }
        return true
    }

    fun loadInput(raw: String) {
        webView?.loadUrl(resolveInput(raw))
    }

    fun goHome() {
        webView?.loadUrl(HOME_URL)
    }

    fun reload() {
        webView?.reload()
    }

    fun canGoBack(): Boolean = webView?.canGoBack() == true

    fun canGoForward(): Boolean = webView?.canGoForward() == true

    fun goBack(): Boolean {
        val wv = webView ?: return false
        if (!wv.canGoBack()) return false
        wv.goBack()
        return true
    }

    fun goForward() {
        val wv = webView ?: return
        if (wv.canGoForward()) wv.goForward()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        _binding?.webView?.let { wv ->
            val webState = Bundle()
            wv.saveState(webState)
            outState.putBundle(STATE_WEB, webState)
        }
    }

    override fun onResume() {
        super.onResume()
        _binding?.webView?.onResume()
    }

    override fun onPause() {
        _binding?.webView?.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroyView() {
        host?.unregisterWebFragment(this)
        _binding?.let { b ->
            b.webView.stopLoading()
            (b.webView.parent as? ViewGroup)?.removeView(b.webView)
            b.webView.destroy()
        }
        _binding = null
        super.onDestroyView()
    }

    companion object {
        const val HOME_URL = "https://search.brave.com"
        private const val SEARCH_URL = "https://search.brave.com/search?q="
        private const val ARG_TAB_ID = "arg_tab_id"
        private const val ARG_URL = "arg_url"
        private const val STATE_WEB = "state_web"
        private val ALLOWED_SCHEMES = setOf("http", "https", "about", "data", "blob", "javascript")

        fun newInstance(tabId: Long, url: String): WebViewFragment {
            return WebViewFragment().apply {
                arguments = bundleOf(ARG_TAB_ID to tabId, ARG_URL to url)
            }
        }

        fun resolveInput(raw: String): String {
            val input = raw.trim()
            if (input.isEmpty()) return HOME_URL
            if (input.startsWith("http://", ignoreCase = true) ||
                input.startsWith("https://", ignoreCase = true)
            ) {
                return input
            }
            if (!input.contains(' ') && input.contains('.')) {
                return "https://$input"
            }
            return SEARCH_URL + URLEncoder.encode(input, "UTF-8")
        }
    }
}

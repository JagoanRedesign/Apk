package com.adblock.browser

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.os.BundleCompat
import androidx.core.view.WindowCompat
import androidx.viewpager2.widget.ViewPager2
import com.adblock.browser.databinding.ActivityBrowserBinding

class BrowserActivity : AppCompatActivity(),
    WebViewFragment.Host,
    TabSwitcherBottomSheet.Host {

    private lateinit var binding: ActivityBrowserBinding
    private lateinit var tabsAdapter: TabsAdapter

    private val tabs = mutableListOf<TabItem>()
    private val webFragments = HashMap<Long, WebViewFragment>()
    private var nextTabId = 1L
    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrowserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AdBlocker.init(applicationContext)
        setupSystemBars()
        restoreState(savedInstanceState)
        setupPager()
        setupUrlBar()
        setupButtons()
        setupBackHandling()

        if (tabs.isEmpty()) {
            addTab(WebViewFragment.HOME_URL)
        } else {
            binding.viewPager.setCurrentItem(currentIndex, false)
            refreshUi()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putParcelableArrayList(KEY_TABS, ArrayList(tabs))
        outState.putInt(KEY_CURRENT, currentIndex)
        outState.putLong(KEY_NEXT_ID, nextTabId)
    }

    private fun restoreState(state: Bundle?) {
        if (state == null) return
        BundleCompat.getParcelableArrayList(state, KEY_TABS, TabItem::class.java)?.let {
            tabs.addAll(it)
        }
        nextTabId = state.getLong(KEY_NEXT_ID, tabs.size + 1L)
        currentIndex = state.getInt(KEY_CURRENT, 0).coerceIn(0, maxOf(0, tabs.lastIndex))
    }

    private fun setupSystemBars() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val controller = WindowCompat.getInsetsController(window, binding.root)
        controller.isAppearanceLightStatusBars = !night
        controller.isAppearanceLightNavigationBars = !night
    }

    private fun setupPager() {
        tabsAdapter = TabsAdapter(this, tabs)
        binding.viewPager.apply {
            adapter = tabsAdapter
            isUserInputEnabled = false
            offscreenPageLimit = 4
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    currentIndex = position
                    binding.progressBar.visibility = View.GONE
                    refreshUi()
                }
            })
        }
    }

    private fun setupUrlBar() {
        binding.urlEdit.setOnEditorActionListener { v, actionId, event ->
            val isGo = actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                    event.action == KeyEvent.ACTION_DOWN)
            if (isGo) {
                submitUrl(v.text.toString())
                true
            } else {
                false
            }
        }

        binding.urlEdit.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                hideKeyboard()
                showCurrentUrl()
            }
        }
    }

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { currentFragment()?.goBack() }
        binding.btnForward.setOnClickListener { currentFragment()?.goForward() }
        binding.btnHome.setOnClickListener { currentFragment()?.goHome() }
        binding.btnRefresh.setOnClickListener { currentFragment()?.reload() }
        binding.btnTabsTop.setOnClickListener { showTabSwitcher() }
        binding.btnTabsBottom.setOnClickListener { showTabSwitcher() }
        binding.btnMenuTop.setOnClickListener { showMenu(it) }
        binding.btnMenuBottom.setOnClickListener { showMenu(it) }
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.urlEdit.hasFocus()) {
                    binding.urlEdit.clearFocus()
                    return
                }
                val handled = currentFragment()?.goBack() == true
                if (!handled) finish()
            }
        })
    }

    private fun submitUrl(text: String) {
        currentFragment()?.loadInput(text)
        binding.urlEdit.clearFocus()
        hideKeyboard()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.urlEdit.windowToken, 0)
    }

    private fun showTabSwitcher() {
        binding.urlEdit.clearFocus()
        if (supportFragmentManager.findFragmentByTag(TabSwitcherBottomSheet.TAG) == null) {
            TabSwitcherBottomSheet().show(supportFragmentManager, TabSwitcherBottomSheet.TAG)
        }
    }

    private fun showSettings() {
        if (supportFragmentManager.findFragmentByTag(SettingsBottomSheet.TAG) == null) {
            SettingsBottomSheet().show(supportFragmentManager, SettingsBottomSheet.TAG)
        }
    }

    private fun showMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, MENU_NEW_TAB, 0, R.string.menu_new_tab)
        popup.menu.add(0, MENU_SETTINGS, 1, R.string.menu_settings)
        popup.menu.add(0, MENU_ABOUT, 2, R.string.menu_about)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                MENU_NEW_TAB -> addTab(WebViewFragment.HOME_URL)
                MENU_SETTINGS -> showSettings()
                MENU_ABOUT -> AboutDialog.show(this)
            }
            true
        }
        popup.show()
    }

    // ---------- Manajemen tab ----------

    private fun currentTab(): TabItem? = tabs.getOrNull(currentIndex)

    private fun currentFragment(): WebViewFragment? =
        currentTab()?.let { webFragments[it.id] }

    private fun addTab(url: String) {
        val tab = TabItem(nextTabId++, getString(R.string.tab_new_title), url)
        tabs.add(tab)
        tabsAdapter.notifyItemInserted(tabs.lastIndex)
        currentIndex = tabs.lastIndex
        binding.viewPager.setCurrentItem(currentIndex, false)
        refreshUi()
    }

    override fun tabsSnapshot(): List<TabItem> = tabs.toList()

    override fun currentTabId(): Long = currentTab()?.id ?: -1L

    override fun selectTab(id: Long) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        currentIndex = index
        binding.viewPager.setCurrentItem(index, false)
        refreshUi()
    }

    override fun closeTab(id: Long) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val previousCurrent = currentIndex

        tabs.removeAt(index)
        tabsAdapter.notifyItemRemoved(index)

        if (tabs.isEmpty()) {
            addTab(WebViewFragment.HOME_URL)
            return
        }

        currentIndex = when {
            index < previousCurrent -> previousCurrent - 1
            index == previousCurrent -> minOf(index, tabs.lastIndex)
            else -> previousCurrent
        }
        binding.viewPager.setCurrentItem(currentIndex, false)
        refreshUi()
    }

    override fun newTab() {
        addTab(WebViewFragment.HOME_URL)
    }

    // ---------- Callback dari WebViewFragment ----------

    override fun registerWebFragment(fragment: WebViewFragment) {
        webFragments[fragment.tabId] = fragment
        if (fragment.tabId == currentTab()?.id) updateNavButtons()
    }

    override fun unregisterWebFragment(fragment: WebViewFragment) {
        if (webFragments[fragment.tabId] === fragment) {
            webFragments.remove(fragment.tabId)
        }
    }

    override fun onTabUrlChanged(tabId: Long, url: String) {
        tabs.firstOrNull { it.id == tabId }?.url = url
        if (tabId == currentTab()?.id) {
            showCurrentUrl()
            updateLockIcon()
        }
    }

    override fun onTabTitleChanged(tabId: Long, title: String) {
        tabs.firstOrNull { it.id == tabId }?.title = title
    }

    override fun onTabProgress(tabId: Long, progress: Int) {
        if (tabId != currentTab()?.id) return
        if (progress in 0..99) {
            binding.progressBar.visibility = View.VISIBLE
            binding.progressBar.progress = progress
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    override fun onTabNavStateChanged(tabId: Long) {
        if (tabId == currentTab()?.id) updateNavButtons()
    }

    override fun onOpenNewTab(url: String) {
        addTab(url)
    }

    // ---------- UI ----------

    private fun refreshUi() {
        val count = if (tabs.size > 99) "99+" else tabs.size.toString()
        binding.tabCountTop.text = count
        binding.tabCountBottom.text = count
        showCurrentUrl()
        updateLockIcon()
        updateNavButtons()
    }

    private fun showCurrentUrl() {
        if (binding.urlEdit.hasFocus()) return
        binding.urlEdit.setText(currentTab()?.url.orEmpty())
    }

    private fun updateLockIcon() {
        val url = currentTab()?.url.orEmpty()
        val colorRes = when {
            url.startsWith("https://", ignoreCase = true) -> R.color.secure
            url.startsWith("http://", ignoreCase = true) -> R.color.error
            else -> R.color.on_surface_variant
        }
        binding.iconLock.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(this, colorRes))
    }

    private fun updateNavButtons() {
        val fragment = currentFragment()
        setEnabledLook(binding.btnBack, fragment?.canGoBack() == true)
        setEnabledLook(binding.btnForward, fragment?.canGoForward() == true)
    }

    private fun setEnabledLook(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        view.alpha = if (enabled) 1f else 0.38f
    }

    companion object {
        private const val KEY_TABS = "key_tabs"
        private const val KEY_CURRENT = "key_current"
        private const val KEY_NEXT_ID = "key_next_id"
        private const val MENU_NEW_TAB = 1
        private const val MENU_SETTINGS = 2
        private const val MENU_ABOUT = 3
    }
}

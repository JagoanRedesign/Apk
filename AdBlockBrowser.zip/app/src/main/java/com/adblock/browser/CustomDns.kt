package com.adblock.browser

import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.util.concurrent.TimeUnit

class CustomDns(private val resolvers: List<Dns>) : Dns {

    override fun lookup(hostname: String): List<InetAddress> {
        for (resolver in resolvers) {
            try {
                val result = resolver.lookup(hostname)
                if (result.isNotEmpty()) return result
            } catch (e: Exception) {
                // Lanjut ke resolver berikutnya
            }
        }
        return Dns.SYSTEM.lookup(hostname)
    }

    companion object {
        private const val CLOUDFLARE_URL = "https://cloudflare-dns.com/dns-query"
        private const val GOOGLE_URL = "https://dns.google/dns-query"

        fun create(provider: Int): CustomDns {
            val cloudflare = buildDoh(CLOUDFLARE_URL, listOf("1.1.1.1", "1.0.0.1"))
            val google = buildDoh(GOOGLE_URL, listOf("8.8.8.8", "8.8.4.4"))
            val chain = if (provider == DnsConfig.PROVIDER_GOOGLE) {
                listOf(google, cloudflare)
            } else {
                listOf(cloudflare, google)
            }
            return CustomDns(chain)
        }

        private fun buildDoh(url: String, bootstrapIps: List<String>): Dns {
            val bootstrapClient = OkHttpClient.Builder()
                .connectTimeout(8, TimeUnit.SECONDS)
                .readTimeout(8, TimeUnit.SECONDS)
                .build()
            return DnsOverHttps.Builder()
                .client(bootstrapClient)
                .url(url.toHttpUrl())
                .bootstrapDnsHosts(bootstrapIps.map { InetAddress.getByName(it) })
                .includeIPv6(true)
                .build()
        }
    }
}

-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

-keep class com.adblock.browser.TabItem { *; }
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}
